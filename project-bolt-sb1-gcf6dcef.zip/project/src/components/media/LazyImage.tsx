import React, { useState, useEffect, useRef } from 'react';

interface LazyImageProps {
  src: string | null;
  alt: string;
  className?: string;
  placeholderClassName?: string;
  onLoad?: () => void;
  onError?: () => void;
  quality?: number;
}

export function LazyImage({
  src,
  alt,
  className = '',
  placeholderClassName = '',
  onLoad,
  onError,
  quality = 80
}: LazyImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [optimizedSrc, setOptimizedSrc] = useState<string>('');
  const imgRef = useRef<HTMLImageElement>(null);
  const observerRef = useRef<IntersectionObserver | null>(null);

  // Optimize image URL if possible
  useEffect(() => {
    if (!src) {
      setOptimizedSrc('');
      return;
    }

    try {
      if (src.includes('unsplash.com')) {
        const urlObj = new URL(src);
        const params = new URLSearchParams(urlObj.search);
        
        // Add quality parameter if not already present
        if (!params.has('q')) {
          params.set('q', quality.toString());
        }
        
        // Add auto format and compression
        params.set('auto', 'format,compress');
        
        // Add blur-up preview
        params.set('blur', '20');
        
        // Update URL with new parameters
        urlObj.search = params.toString();
        setOptimizedSrc(urlObj.toString());
      } else {
        setOptimizedSrc(src);
      }
    } catch (error) {
      console.error('Error optimizing image URL:', error);
      setOptimizedSrc(src);
    }
  }, [src, quality]);

  useEffect(() => {
    // Reset state when src changes
    setIsLoaded(false);
    setError(false);
    
    if (!src) {
      setError(true);
      return;
    }
    
    // If the image is already in the viewport or has been loaded before, load it immediately
    if (imgRef.current && imgRef.current.complete) {
      setIsLoaded(true);
      onLoad?.();
    }
    
    // Set up intersection observer for lazy loading
    observerRef.current = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && imgRef.current && optimizedSrc) {
          // Preload the image
          const preloadLink = document.createElement('link');
          preloadLink.rel = 'preload';
          preloadLink.as = 'image';
          preloadLink.href = optimizedSrc;
          document.head.appendChild(preloadLink);

          // Start loading the image
          imgRef.current.src = optimizedSrc;
          
          // Stop observing once we've started loading
          observerRef.current?.unobserve(entry.target);
        }
      });
    }, {
      rootMargin: '50% 0px', // Start loading when image is 50% viewport height away
      threshold: 0
    });
    
    if (imgRef.current) {
      observerRef.current.observe(imgRef.current);
    }
    
    return () => {
      observerRef.current?.disconnect();
    };
  }, [optimizedSrc, onLoad, src]);

  const handleLoad = () => {
    setIsLoaded(true);
    onLoad?.();
  };

  const handleError = () => {
    setError(true);
    onError?.();
  };

  return (
    <>
      {!isLoaded && !error && (
        <div 
          className={`image-loading ${placeholderClassName || className}`}
          aria-hidden="true"
        />
      )}
      <img
        ref={imgRef}
        src={error ? 'https://via.placeholder.com/400x300?text=Image+Not+Found' : ''}
        data-src={optimizedSrc}
        alt={alt}
        className={`${className} ${!isLoaded ? 'invisible absolute' : ''}`}
        onLoad={handleLoad}
        onError={handleError}
        loading="lazy"
        decoding="async"
        fetchpriority="high"
      />
    </>
  );
}