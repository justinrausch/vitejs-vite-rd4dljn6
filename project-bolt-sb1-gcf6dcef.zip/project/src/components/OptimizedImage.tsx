import React, { useState, useEffect } from 'react';
import { LazyImage } from './LazyImage';

interface OptimizedImageProps {
  src: string | null;
  alt: string;
  className?: string;
  placeholderClassName?: string;
  width?: number;
  height?: number;
  quality?: number;
  onLoad?: () => void;
  onError?: () => void;
}

export function OptimizedImage({
  src,
  alt,
  className = '',
  placeholderClassName = '',
  width,
  height,
  quality = 80,
  onLoad,
  onError
}: OptimizedImageProps) {
  const [optimizedSrc, setOptimizedSrc] = useState<string>('');
  
  useEffect(() => {
    if (!src) {
      // Use a default image if no src is provided
      setOptimizedSrc('https://images.unsplash.com/photo-1576858574144-9ae1ebcf5ae5?auto=format&fit=crop&q=80');
      return;
    }

    try {
      // Check if the image is from Unsplash or another service that supports resizing
      if (src.includes('unsplash.com')) {
        const url = new URL(src);
        
        // Add transformation parameters if width or height is provided
        if (width || height || quality < 100) {
          const params = new URLSearchParams(url.search);
          
          if (width) params.set('w', width.toString());
          if (height) params.set('h', height.toString());
          if (quality < 100) params.set('q', quality.toString());
          
          // Update the URL with the new parameters
          url.search = params.toString();
          setOptimizedSrc(url.toString());
        } else {
          setOptimizedSrc(src);
        }
      } else {
        // Not a URL that supports optimization, use as is
        setOptimizedSrc(src);
      }
    } catch (error) {
      console.error('Error optimizing image URL:', error);
      // Fallback to default image on error
      setOptimizedSrc('https://images.unsplash.com/photo-1576858574144-9ae1ebcf5ae5?auto=format&fit=crop&q=80');
    }
  }, [src, width, height, quality]);

  return (
    <LazyImage
      src={optimizedSrc}
      alt={alt}
      className={className}
      placeholderClassName={placeholderClassName}
      onLoad={onLoad}
      onError={onError}
      quality={quality}
    />
  );
}