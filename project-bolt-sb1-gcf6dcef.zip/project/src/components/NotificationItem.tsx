import React from 'react';
import { 
  Bell, 
  MessageCircle, 
  Award, 
  CheckCircle, 
  XCircle, 
  ThumbsUp, 
  Video, 
  MessageSquare 
} from 'lucide-react';
import { Notification, NotificationType } from '../types/notification';
import { UserAvatar } from './user/UserAvatar';
import { formatTimeAgo } from '../lib/utils/date';

interface NotificationItemProps {
  notification: Notification;
  onClick: (notification: Notification) => void;
}

export function NotificationItem({ notification, onClick }: NotificationItemProps) {
  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case 'new_message':
        return <MessageCircle size={20} className="text-green-500 dark:text-green-400" />;
      case 'new_lesson':
        return <Video size={20} className="text-blue-500 dark:text-blue-400" />;
      case 'achievement':
        return <Award size={20} className="text-yellow-500 dark:text-yellow-400" />;
      case 'course_approved':
        return <CheckCircle size={20} className="text-green-500 dark:text-green-400" />;
      case 'course_denied':
        return <XCircle size={20} className="text-red-500 dark:text-red-400" />;
      case 'course_update_approved':
        return <CheckCircle size={20} className="text-green-500 dark:text-green-400" />;
      case 'course_update_denied':
        return <XCircle size={20} className="text-red-500 dark:text-red-400" />;
      case 'comment_like':
        return <ThumbsUp size={20} className="text-blue-500 dark:text-blue-400" />;
      case 'direct_message':
        return <MessageSquare size={20} className="text-purple-500 dark:text-purple-400" />;
      case 'message_like':
        return <ThumbsUp size={20} className="text-blue-500 dark:text-blue-400" />;
      default:
        return <Bell size={20} className="text-gray-500 dark:text-gray-400" />;
    }
  };

  return (
    <div 
      className={`bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden transition-all duration-300 ${
        !notification.read 
          ? 'ring-2 ring-blue-500/20 dark:ring-blue-400/20' 
          : ''
      }`}
      onClick={() => onClick(notification)}
    >
      <div className="p-4">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            {notification.data?.username ? (
              <UserAvatar 
                username={notification.data.username}
                avatarUrl={notification.data.avatarUrl}
                size="sm"
              />
            ) : (
              getNotificationIcon(notification.type)
            )}
          </div>
          <div className="ml-3 flex-1">
            <div className="flex items-center justify-between">
              <h3 className={`font-semibold ${!notification.read ? 'text-gray-900 dark:text-white' : 'text-gray-700 dark:text-gray-300'}`}>
                {notification.title}
              </h3>
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {formatTimeAgo(notification.created_at)}
              </span>
            </div>
            <p className={`mt-1 ${!notification.read ? 'text-gray-600 dark:text-gray-300' : 'text-gray-500 dark:text-gray-400'}`}>
              {notification.message}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}