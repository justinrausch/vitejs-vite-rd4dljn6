import React from 'react';

interface CoachBadgeProps {
  className?: string;
}

export function CoachBadge({ className = '' }: CoachBadgeProps) {
  return (
    <span className={`px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs font-medium rounded-full ${className}`}>
      Coach
    </span>
  );
}