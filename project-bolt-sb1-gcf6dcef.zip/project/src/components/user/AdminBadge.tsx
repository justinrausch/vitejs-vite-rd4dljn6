import React from 'react';

interface AdminBadgeProps {
  className?: string;
}

export function AdminBadge({ className = '' }: AdminBadgeProps) {
  return (
    <span className={`px-3 py-1 bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200 text-xs font-medium rounded-full ${className}`}>
      Admin
    </span>
  );
}