import React from 'react';

interface UserAvatarProps {
  username: string;
  avatarUrl: string | null;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

// Function to generate a consistent color based on username
const generateColorFromUsername = (username: string): string => {
  // List of vibrant background colors
  const colors = [
    'bg-blue-500',
    'bg-green-500',
    'bg-purple-500',
    'bg-pink-500',
    'bg-yellow-500',
    'bg-red-500',
    'bg-indigo-500',
    'bg-teal-500',
    'bg-orange-500',
    'bg-cyan-500'
  ];
  
  // Simple hash function to get a consistent index
  let hash = 0;
  for (let i = 0; i < username.length; i++) {
    hash = username.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  // Get a positive index within the colors array range
  const index = Math.abs(hash) % colors.length;
  return colors[index];
};

// Function to optimize avatar URL for different sizes
const optimizeAvatarUrl = (url: string | null, size: 'xs' | 'sm' | 'md' | 'lg' | 'xl'): string | null => {
  if (!url) return null;
  
  // Size mapping to pixel dimensions
  const sizeDimensions = {
    xs: 24,
    sm: 32,
    md: 40,
    lg: 64,
    xl: 96
  };
  
  // Only optimize Unsplash images
  if (url.includes('unsplash.com')) {
    try {
      const urlObj = new URL(url);
      const params = new URLSearchParams(urlObj.search);
      
      // Set width parameter based on size
      params.set('w', sizeDimensions[size].toString());
      
      // Set quality parameter (lower for smaller sizes)
      params.set('q', size === 'xs' || size === 'sm' ? '70' : '80');
      
      // Update URL with new parameters
      urlObj.search = params.toString();
      return urlObj.toString();
    } catch (error) {
      console.error('Error optimizing avatar URL:', error);
      return url;
    }
  }
  
  return url;
};

export function UserAvatar({ username, avatarUrl, size = 'md', className = '' }: UserAvatarProps) {
  // Get first letter of username, default to 'U' if empty
  const firstLetter = username ? username.charAt(0).toUpperCase() : 'U';
  
  // Generate background color based on username
  const bgColorClass = generateColorFromUsername(username);
  
  // Optimize avatar URL based on size
  const optimizedAvatarUrl = optimizeAvatarUrl(avatarUrl, size);
  
  // Size classes
  const sizeClasses = {
    xs: 'w-6 h-6 text-xs',
    sm: 'w-8 h-8 text-sm',
    md: 'w-10 h-10 text-base',
    lg: 'w-16 h-16 text-xl',
    xl: 'w-24 h-24 text-3xl'
  };
  
  return (
    <div className={`${sizeClasses[size]} rounded-full overflow-hidden flex-shrink-0 ${className}`}>
      {optimizedAvatarUrl ? (
        <img
          src={optimizedAvatarUrl}
          alt={username}
          className="w-full h-full object-cover"
          onError={(e) => {
            // If image fails to load, show the fallback
            e.currentTarget.style.display = 'none';
            e.currentTarget.parentElement?.classList.add(bgColorClass);
            e.currentTarget.parentElement?.classList.add('flex', 'items-center', 'justify-center', 'text-white', 'font-medium');
            
            // Create and append the text node for the first letter
            const textNode = document.createTextNode(firstLetter);
            e.currentTarget.parentElement?.appendChild(textNode);
          }}
        />
      ) : (
        <div className={`${bgColorClass} w-full h-full flex items-center justify-center text-white font-medium`}>
          {firstLetter}
        </div>
      )}
    </div>
  );
}