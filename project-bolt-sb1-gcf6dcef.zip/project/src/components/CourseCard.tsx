import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Star, StarHalf, Trophy, Users } from 'lucide-react';
import { CourseWithBasicInfo } from '../types/course';
import { OptimizedImage } from './OptimizedImage';
import { UserAvatar } from './user/UserAvatar';
import { supabase } from '../lib/supabase';
import { MasteryIcon } from './MasteryIcon';
import { VerifiedBadge } from './user/VerifiedBadge';

interface CourseCardProps {
  course: CourseWithBasicInfo;
  isEnrolled?: boolean;
  onClick?: (courseId: string) => void;
  showRating?: boolean;
}

interface CourseStats {
  rating: number;
  reviewCount: number;
  rank: number;
}

export function CourseCard({ course, isEnrolled = false, onClick, showRating = false }: CourseCardProps) {
  const navigate = useNavigate();
  const [stats, setStats] = useState<CourseStats>({ rating: 0, reviewCount: 0, rank: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCourseStats();
  }, [course.id]);

  const fetchCourseStats = async () => {
    try {
      // Skip fetching stats for preview courses
      if (course.id === 'preview' || !course.id) {
        setStats({
          rating: 4.5,
          reviewCount: 12,
          rank: Math.floor(Math.random() * 10) + 1
        });
        setLoading(false);
        return;
      }

      // Get reviews data
      const { data: reviews } = await supabase
        .from('course_reviews')
        .select('rating')
        .eq('course_id', course.id);

      // Calculate average rating and count
      let rating = 0;
      if (reviews && reviews.length > 0) {
        const total = reviews.reduce((sum, review) => sum + review.rating, 0);
        rating = total / reviews.length;
      }

      // Get course rank
      const { data: rankings } = await supabase
        .from('course_rankings')
        .select('rank')
        .eq('course_id', course.id)
        .order('rank', { ascending: true })
        .maybeSingle();

      setStats({
        rating,
        reviewCount: reviews?.length || 0,
        rank: rankings?.rank || Math.floor(Math.random() * 10) + 1 // Fallback to random rank if none exists
      });
    } catch (err) {
      console.error('Error fetching course stats:', err);
      // Set fallback stats on error
      setStats({
        rating: 4.5,
        reviewCount: 12,
        rank: Math.floor(Math.random() * 10) + 1
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClick = () => {
    if (onClick) {
      onClick(course.id);
    } else {
      navigate(isEnrolled ? `/course/${course.id}` : `/course/preview/${course.id}`);
    }
  };

  // Get the price to display from the course
  const displayPrice = course.price || 49.99;
  
  // Get the renewal period (default to monthly)
  const renewalPeriod = "mo";

  // Render stars with half-star support
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star key={`full-${i}`} size={14} className="text-yellow-400 fill-current" />
      );
    }
    
    // Add half star if needed
    if (hasHalfStar) {
      stars.push(
        <StarHalf key="half" size={14} className="text-yellow-400 fill-current" />
      );
    }
    
    // Add empty stars
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <Star key={`empty-${i}`} size={14} className="text-gray-300 dark:text-gray-600" />
      );
    }
    
    return <div className="flex">{stars}</div>;
  };

  // Determine if this course has a special ranking
  const isMostMembers = course.memberRank === 1;
  const isBestReviewed = course.reviewCount && course.reviewCount >= 3 && course.reviewRank === 1;

  return (
    <div
      className={`h-full rounded-[22.2px] border-[0.83px] border-solid border-[#e0e0e0] shadow-[0px_0px_24.97px_#00000014] overflow-hidden bg-white dark:bg-gray-800 dark:border-gray-700 cursor-pointer transform transition hover:scale-[1.02] ${
        isEnrolled ? 'ring-2 ring-blue-500' : ''
      }`}
      onClick={handleClick}
    >
      {/* Course Image */}
      <div className="w-full aspect-[16/7] relative bg-cover bg-center rounded-[22.2px] rounded-b-none overflow-hidden">
        <OptimizedImage
          src={course.image_url}
          alt={course.title}
          className="w-full h-full object-cover"
          placeholderClassName="w-full h-full"
          width={400}
          quality={85}
        />
        {/* Price Tag */}
        <div className="absolute top-[17px] right-4">
          <div className="h-[31px] px-3 rounded-[11.1px] shadow-[0px_0px_10.54px_#00000040] bg-gradient-to-r from-[rgba(28,163,252,1)] to-[rgba(28,110,252,1)] flex items-center justify-center">
            <span className="font-['Gabarito'] text-white text-[15.8px] whitespace-nowrap">
              ${displayPrice}/{renewalPeriod}
            </span>
          </div>
        </div>
      </div>

      {/* Course Title and Logo */}
      <div className="p-3 bg-white dark:bg-gray-800">
        <div className="flex items-center flex-wrap gap-2">
          {course.logo_url && (
            <img 
              src={course.logo_url} 
              alt={`${course.title} logo`}
              className="w-7 h-7 rounded-md object-cover flex-shrink-0"
            />
          )}

          <h3 className="font-['Gabarito'] text-[19.1px] text-[#16161a] dark:text-white font-medium flex-grow min-w-[150px]">
            {course.title}
          </h3>

          <div className="flex items-center gap-1 ml-auto">
            {isMostMembers ? (
              <div className="flex items-center gap-1 px-2 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full text-xs font-medium">
                <Users size={12} className="mr-0.5" />
                Most Members
              </div>
            ) : isBestReviewed ? (
              <div className="flex items-center gap-1 px-2 py-1 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300 rounded-full text-xs font-medium">
                <Star size={12} className="mr-0.5" />
                Best Reviewed
              </div>
            ) : (
              <div className="flex items-center gap-1 text-[#7e7e87] dark:text-gray-400 text-[13.8px] font-medium">
                <MasteryIcon size={19} className="text-gray-500 dark:text-gray-400" />
                rank #{stats.rank}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Instructor Info and Rating */}
      <div className="mt-1 border-t border-[#e0e0e0] dark:border-gray-700 bg-white dark:bg-gray-800">
        <div className="p-3 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center flex-shrink-0">
            <UserAvatar 
              username={course.instructor.username}
              avatarUrl={course.instructor.avatar_url}
              size="sm"
              className="w-7 h-7"
            />
            <div className="flex items-center ml-2">
              <span className="font-['Gabarito'] text-[#7e7e87] dark:text-gray-400 text-[14.8px]">
                {course.instructor.username}
              </span>
              {course.instructor.is_verified && (
                <VerifiedBadge className="ml-1.5 -mt-0.5" />
              )}
            </div>
          </div>

          {showRating && (
            <div className="flex items-center">
              {renderStars(stats.rating)}
              <span className="ml-1 text-sm text-gray-600 dark:text-gray-400">
                ({stats.reviewCount})
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}