import React from 'react';
import { Bell } from 'lucide-react';
import { useNotifications } from '../contexts/NotificationContext';

interface NotificationBadgeProps {
  className?: string;
}

export function NotificationBadge({ className = '' }: NotificationBadgeProps) {
  const { unreadCount } = useNotifications();

  return (
    <div className={`relative ${className}`}>
      <Bell size={24} />
      {unreadCount > 0 && (
        <span className="absolute -top-1.5 -right-1.5 bg-blue-500 text-white text-[10px] min-w-[16px] h-4 flex items-center justify-center rounded-full px-1">
          {unreadCount > 9 ? '9+' : unreadCount}
        </span>
      )}
    </div>
  );
}