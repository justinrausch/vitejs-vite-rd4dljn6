import React, { useState } from 'react';
import { ChevronLeft, Edit2, Save, X } from 'lucide-react';
import { LessonHeaderProps } from '../../types/lesson';

export function LessonHeader({ 
  courseTitle, 
  lessonTitle, 
  isInstructor,
  onBack,
  onEdit 
}: LessonHeaderProps) {
  const [editing, setEditing] = useState(false);
  const [newTitle, setNewTitle] = useState(lessonTitle);

  const handleSave = () => {
    if (newTitle.trim()) {
      onEdit(newTitle);
      setEditing(false);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 sticky top-0 z-10">
      <div className="max-w-lg mx-auto px-4">
        <div className="flex items-center py-4">
          <button onClick={onBack} className="mr-4 text-gray-700 dark:text-gray-300">
            <ChevronLeft size={24} />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-medium text-gray-900 dark:text-white">
              {courseTitle}
            </h1>
            <div className="flex items-center gap-2">
              {editing ? (
                <div className="flex items-center gap-2 w-full">
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="flex-1 px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                  />
                  <button
                    onClick={handleSave}
                    disabled={!newTitle.trim()}
                    className="text-green-500 dark:text-green-400 disabled:opacity-50"
                  >
                    <Save size={20} />
                  </button>
                  <button
                    onClick={() => {
                      setNewTitle(lessonTitle);
                      setEditing(false);
                    }}
                    className="text-gray-500 dark:text-gray-400"
                  >
                    <X size={20} />
                  </button>
                </div>
              ) : (
                <>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{lessonTitle}</p>
                  {isInstructor && (
                    <button
                      onClick={() => setEditing(true)}
                      className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                    >
                      <Edit2 size={16} />
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}