import React from 'react';
import { CheckCircle } from 'lucide-react';
import { LessonProgressProps } from '../../types/lesson';

export function LessonProgress({
  progress,
  isCompleted,
  canComplete,
  requiredPercentage
}: LessonProgressProps) {
  return (
    <div className="mb-4">
      <div className="flex items-center justify-between mb-1">
        <span className="text-sm text-gray-600 dark:text-gray-400">
          Video Progress: {progress}%
        </span>
        {canComplete && !isCompleted && (
          <span className="text-sm text-green-600 dark:text-green-400 flex items-center">
            <CheckCircle size={16} className="mr-1" />
            Ready to mark as complete
          </span>
        )}
      </div>
      <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
        <div 
          className={`h-full rounded-full ${
            progress >= requiredPercentage 
              ? 'bg-green-500 dark:bg-green-600' 
              : 'bg-blue-500 dark:bg-blue-600'
          }`}
          style={{ width: `${progress}%` }}
        />
      </div>
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
        You need to watch at least {requiredPercentage}% to mark as complete
      </p>
    </div>
  );
}