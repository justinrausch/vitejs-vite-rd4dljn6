import React, { useState } from 'react';
import { Edit2 } from 'lucide-react';
import { LessonNotesProps } from '../../types/lesson';

export function LessonNotes({
  notes,
  isInstructor,
  onSave
}: LessonNotesProps) {
  const [editing, setEditing] = useState(false);
  const [newNotes, setNewNotes] = useState(notes);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    try {
      setSaving(true);
      await onSave(newNotes);
      setEditing(false);
    } catch (err) {
      console.error('Error saving notes:', err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-medium text-gray-900 dark:text-white">Lecture Notes</h2>
        {isInstructor && !editing && (
          <button
            onClick={() => setEditing(true)}
            className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
          >
            <Edit2 size={16} />
          </button>
        )}
      </div>
      
      {editing ? (
        <div className="space-y-4">
          <textarea
            value={newNotes}
            onChange={(e) => setNewNotes(e.target.value)}
            className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400 min-h-[200px]"
            placeholder="Add lecture notes..."
          />
          <div className="flex justify-end gap-2">
            <button
              onClick={() => {
                setNewNotes(notes);
                setEditing(false);
              }}
              className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save Notes'}
            </button>
          </div>
        </div>
      ) : (
        <div className="prose dark:prose-invert prose-sm max-w-none">
          {notes ? (
            <div className="whitespace-pre-wrap">{notes}</div>
          ) : (
            <p className="text-gray-500 dark:text-gray-400">
              {isInstructor ? 'Add lecture notes to help your students learn better.' : 'No lecture notes available yet.'}
            </p>
          )}
        </div>
      )}
    </div>
  );
}