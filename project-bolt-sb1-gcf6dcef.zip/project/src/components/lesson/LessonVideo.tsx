import React, { useState } from 'react';
import { Upload } from 'lucide-react';
import { LessonVideoProps } from '../../types/lesson';
import { LessonVideoPlayer } from '../video/LessonVideoPlayer';
import { VideoUploader } from '../video/VideoUploader';

export function LessonVideo({
  lessonId,
  courseId,
  videoUrl,
  title,
  isInstructor,
  onVideoUpload,
  initialProgress = 0,
  initialTime = 0,
  onProgressUpdate,
  requiredWatchPercentage = 70,
  onRequiredWatchReached
}: LessonVideoProps) {
  const [showUploader, setShowUploader] = useState(false);

  const handleUpload = (url: string) => {
    onVideoUpload(url);
    setShowUploader(false);
  };

  if (isInstructor) {
    return (
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium text-gray-900 dark:text-white">Lesson Video</h2>
          <button
            onClick={() => setShowUploader(true)}
            className="flex items-center gap-2 px-3 py-1.5 bg-blue-500 text-white rounded-lg text-sm"
          >
            <Upload size={16} />
            Replace Video
          </button>
        </div>
        {showUploader ? (
          <div className="aspect-video bg-gray-100 dark:bg-gray-800 rounded-2xl flex items-center justify-center">
            <VideoUploader onUploadComplete={handleUpload} />
          </div>
        ) : videoUrl ? (
          <div className="relative aspect-video rounded-2xl overflow-hidden bg-black">
            <LessonVideoPlayer
              lessonId={lessonId}
              courseId={courseId}
              title={title}
              initialProgress={initialProgress}
              initialTime={initialTime}
              onProgressUpdate={onProgressUpdate}
              requiredWatchPercentage={requiredWatchPercentage}
              onRequiredWatchReached={onRequiredWatchReached}
            />
          </div>
        ) : (
          <div className="aspect-video bg-gray-100 dark:bg-gray-800 rounded-2xl flex items-center justify-center">
            <VideoUploader onUploadComplete={handleUpload} />
          </div>
        )}
      </div>
    );
  }

  if (!videoUrl) return null;

  return (
    <div className="relative aspect-video rounded-2xl overflow-hidden bg-black mb-6">
      <LessonVideoPlayer
        lessonId={lessonId}
        courseId={courseId}
        title={title}
        initialProgress={initialProgress}
        initialTime={initialTime}
        onProgressUpdate={onProgressUpdate}
        requiredWatchPercentage={requiredWatchPercentage}
        onRequiredWatchReached={onRequiredWatchReached}
      />
    </div>
  );
}