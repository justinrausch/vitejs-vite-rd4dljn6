import React from 'react';
import { Bookmark, Loader } from 'lucide-react';
import { LessonActionsProps } from '../../types/lesson';

export function LessonActions({
  isCompleted,
  isBookmarked,
  canComplete,
  onComplete,
  onBookmark,
  completing,
  bookmarking
}: LessonActionsProps) {
  return (
    <div className="flex gap-4 mb-8">
      <button
        onClick={onComplete}
        disabled={completing || (!isCompleted && !canComplete)}
        className={`flex-1 py-2 px-4 rounded-xl font-medium text-center ${
          isCompleted
            ? 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 border-2 border-green-600 dark:border-green-500'
            : canComplete
              ? 'bg-blue-500 dark:bg-blue-600 text-white'
              : 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
        }`}
      >
        {completing ? 'Updating...' : isCompleted ? 'Completed' : 'Complete'}
      </button>
      <button
        onClick={onBookmark}
        disabled={bookmarking}
        className={`w-12 h-12 flex items-center justify-center rounded-xl ${
          isBookmarked ? 'bg-yellow-50 dark:bg-yellow-900/20 text-yellow-600 dark:text-yellow-400' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400'
        }`}
      >
        {bookmarking ? (
          <Loader size={20} className="animate-spin" />
        ) : (
          <Bookmark
            size={20}
            className={isBookmarked ? 'fill-current' : ''}
          />
        )}
      </button>
    </div>
  );
}