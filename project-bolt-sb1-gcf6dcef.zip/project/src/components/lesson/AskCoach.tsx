import React, { useState } from 'react';
import { MessageCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface AskCoachProps {
  courseId: string;
  lessonId: string;
  userId: string;
  onQuestionSent: () => void;
}

export function AskCoach({ courseId, lessonId, userId, onQuestionSent }: AskCoachProps) {
  const [question, setQuestion] = useState('');
  const [sending, setSending] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!question.trim() || sending) return;
    
    try {
      setSending(true);
      
      const { error } = await supabase
        .from('coach_messages')
        .insert({
          course_id: courseId,
          student_id: userId,
          sender_id: userId,
          content: question.trim(),
          lesson_id: lessonId
        });
      
      if (error) throw error;
      
      setQuestion('');
      alert('Your question has been sent to the coach!');
      onQuestionSent();
    } catch (err) {
      console.error('Error sending question to coach:', err);
      alert('Failed to send question. Please try again.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm mb-8">
      <h2 className="font-medium mb-4 text-gray-900 dark:text-white flex items-center">
        <MessageCircle size={20} className="mr-2 text-blue-500 dark:text-blue-400" />
        Ask Your Coach About This Lesson
      </h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <textarea
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Have a question about this lesson? Ask your coach here..."
          className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400 min-h-[100px]"
        />
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={sending || !question.trim()}
            className="px-4 py-2 bg-blue-500 dark:bg-blue-600 text-white rounded-lg font-medium disabled:opacity-50"
          >
            {sending ? 'Sending...' : 'Send to Coach'}
          </button>
        </div>
      </form>
    </div>
  );
}