import React, { useState, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { Loader, Upload } from 'lucide-react';

interface ImageUploaderProps {
  onUploadComplete: (url: string) => void;
  folder?: string;
  className?: string;
  buttonText?: string;
  maxSizeMB?: number;
  id?: string;
}

export function ImageUploader({ 
  onUploadComplete, 
  folder = 'images', 
  className = '',
  buttonText = 'Upload Image',
  maxSizeMB = 5,
  id
}: ImageUploaderProps) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Generate unique ID if not provided
  const uploaderId = id || `image-upload-${Math.random().toString(36).substring(2)}`;

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size
    const fileSizeMB = file.size / (1024 * 1024);
    if (fileSizeMB > maxSizeMB) {
      setError(`File size exceeds ${maxSizeMB}MB limit`);
      return;
    }

    try {
      setUploading(true);
      setError(null);
      
      // Create a unique file path
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}-${Date.now()}.${fileExt}`;
      const filePath = `${folder}/${fileName}`;
      
      // Upload the file to Supabase Storage
      const { data, error: uploadError } = await supabase.storage
        .from('public')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });
      
      if (uploadError) throw uploadError;
      
      // Get the public URL
      const { data: urlData } = supabase.storage
        .from('public')
        .getPublicUrl(filePath);
      
      // Return the URL to the parent component
      onUploadComplete(urlData.publicUrl);
      
    } catch (err: any) {
      console.error('Error uploading image:', err);
      setError(err.message || 'Failed to upload image');
    } finally {
      setUploading(false);
      // Clear the file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className={className}>
      <div className="flex items-center justify-center">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleUpload}
          accept="image/*"
          className="hidden"
          id={uploaderId}
          disabled={uploading}
        />
        <label 
          htmlFor={uploaderId}
          className={`px-4 py-2 bg-blue-500 text-white rounded-lg cursor-pointer flex items-center justify-center hover:bg-blue-600 transition-colors ${uploading ? 'opacity-70 cursor-not-allowed' : ''}`}
        >
          {uploading ? (
            <>
              <Loader size={16} className="animate-spin mr-2" />
              Uploading...
            </>
          ) : (
            <>
              <Upload size={16} className="mr-2" />
              {buttonText}
            </>
          )}
        </label>
      </div>
      
      {error && (
        <p className="text-red-500 text-sm mt-2">{error}</p>
      )}
    </div>
  );
}