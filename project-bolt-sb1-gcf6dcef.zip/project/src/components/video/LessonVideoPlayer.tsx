import React, { useState, useEffect } from 'react';
import { getLessonVideo } from '../../services/videoService';
import { VideoPlayer } from './VideoPlayer';
import { saveVideoProgress } from '../../services/videoProgressService';
import { useAuth } from '../../contexts/AuthContext';

interface LessonVideoPlayerProps {
  lessonId: string;
  courseId: string;
  title: string;
  initialProgress?: number;
  initialTime?: number;
  onProgressUpdate?: (progress: number) => void;
  onRequiredWatchReached?: () => void;
  requiredWatchPercentage?: number;
}

export function LessonVideoPlayer({
  lessonId,
  courseId,
  title,
  initialProgress = 0,
  initialTime = 0,
  onProgressUpdate,
  onRequiredWatchReached,
  requiredWatchPercentage = 70
}: LessonVideoPlayerProps) {
  const { user } = useAuth();
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(initialProgress);
  const [hasReachedRequired, setHasReachedRequired] = useState(initialProgress >= requiredWatchPercentage);
  const [lastSavedProgress, setLastSavedProgress] = useState(initialProgress);
  const [saveTimer, setSaveTimer] = useState<NodeJS.Timeout | null>(null);

  useEffect(() => {
    fetchVideoUrl();
    return () => {
      if (saveTimer) clearTimeout(saveTimer);
    };
  }, [lessonId]);

  const fetchVideoUrl = async () => {
    try {
      setLoading(true);
      const url = await getLessonVideo(lessonId);
      setVideoUrl(url);
      
      if (!url) {
        setError('No video available for this lesson.');
      }
    } catch (err) {
      console.error('Error fetching video URL:', err);
      setError('Failed to load video. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleTimeUpdate = (currentTime: number, duration: number) => {
    if (duration === 0) return;
    
    const newProgress = Math.round((currentTime / duration) * 100);
    setProgress(newProgress);
    
    // Call the progress update callback
    onProgressUpdate?.(newProgress);
    
    // Check if we've reached the required watch percentage
    if (!hasReachedRequired && newProgress >= requiredWatchPercentage) {
      setHasReachedRequired(true);
      onRequiredWatchReached?.();
    }
    
    // Save progress periodically (throttled)
    if (newProgress > lastSavedProgress + 5 || newProgress === 100) {
      if (saveTimer) clearTimeout(saveTimer);
      
      const timer = setTimeout(() => {
        saveProgress(newProgress, currentTime);
        setLastSavedProgress(newProgress);
      }, 2000);
      
      setSaveTimer(timer);
    }
  };

  const saveProgress = async (progressValue: number, currentTime: number) => {
    if (!user) return;
    
    try {
      await saveVideoProgress(
        user.id,
        courseId,
        lessonId,
        progressValue,
        currentTime
      );
    } catch (err) {
      console.error('Error saving video progress:', err);
    }
  };

  if (loading) {
    return (
      <div className="aspect-video bg-gray-900 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!videoUrl) {
    return (
      <div className="aspect-video bg-gray-900 flex items-center justify-center">
        <div className="text-white text-center p-4">
          <p className="mb-2">Video unavailable</p>
          <p className="text-sm text-gray-400">
            {error || "The instructor needs to upload a video for this lesson."}
          </p>
        </div>
      </div>
    );
  }

  return (
    <VideoPlayer
      src={videoUrl}
      title={title}
      initialTime={initialTime}
      onTimeUpdate={handleTimeUpdate}
    />
  );
}