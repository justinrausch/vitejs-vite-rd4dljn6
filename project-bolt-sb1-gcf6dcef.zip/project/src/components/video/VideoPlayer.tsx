import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, SkipForward, SkipBack } from 'lucide-react';

interface VideoPlayerProps {
  src: string;
  title: string;
  poster?: string;
  onTimeUpdate?: (currentTime: number, duration: number) => void;
  onEnded?: () => void;
  initialTime?: number;
}

export function VideoPlayer({ 
  src, 
  title, 
  poster,
  onTimeUpdate,
  onEnded,
  initialTime = 0
}: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(initialTime);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [maxWatchedTime, setMaxWatchedTime] = useState(initialTime);
  const [attemptedSkip, setAttemptedSkip] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const playerRef = useRef<HTMLDivElement>(null);
  const controlsTimerRef = useRef<NodeJS.Timeout | null>(null);
  const [showControls, setShowControls] = useState(true);
  const progressBarRef = useRef<HTMLInputElement>(null);

  // Initialize the video
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = volume;
      
      // Set initial time if provided
      if (initialTime > 0) {
        videoRef.current.currentTime = initialTime;
        setMaxWatchedTime(initialTime);
      }
    }
  }, [initialTime]);

  // Handle metadata loaded (when duration becomes available)
  const handleMetadataLoaded = () => {
    if (!videoRef.current) return;
    setDuration(videoRef.current.duration);
    setIsLoading(false);
  };

  // Handle time update events
  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    
    const video = videoRef.current;
    const newTime = video.currentTime;
    
    // Update current time
    setCurrentTime(newTime);
    
    // Update max watched time if current time is greater
    if (newTime > maxWatchedTime) {
      setMaxWatchedTime(newTime);
    }
    
    // Calculate progress percentage
    if (video.duration) {
      const newProgress = Math.round((newTime / video.duration) * 100);
      setProgress(newProgress);
      
      // Call the onTimeUpdate callback if provided
      onTimeUpdate?.(newTime, video.duration);
    }
  };

  // Toggle play/pause
  const togglePlay = () => {
    if (!videoRef.current) return;
    
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    
    setIsPlaying(!isPlaying);
  };

  // Toggle mute
  const toggleMute = () => {
    if (!videoRef.current) return;
    
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  // Handle volume change
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
      setIsMuted(newVolume === 0);
    }
  };

  // Handle seeking
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!videoRef.current) return;
    
    const seekTime = parseFloat(e.target.value);
    
    // Prevent seeking forward beyond the max watched time
    if (seekTime > maxWatchedTime + 1) { // Add a small buffer for rounding errors
      videoRef.current.currentTime = maxWatchedTime;
      setCurrentTime(maxWatchedTime);
      setAttemptedSkip(true);
      
      // Reset the progress bar value to the max watched time
      if (progressBarRef.current) {
        progressBarRef.current.value = maxWatchedTime.toString();
      }
      
      // Hide the attempted skip message after 3 seconds
      setTimeout(() => {
        setAttemptedSkip(false);
      }, 3000);
      
      return;
    }
    
    // Allow seeking backward
    videoRef.current.currentTime = seekTime;
    setCurrentTime(seekTime);
    setAttemptedSkip(false);
  };

  // Format time (seconds to MM:SS)
  const formatTime = (timeInSeconds: number) => {
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!playerRef.current) return;
    
    if (!document.fullscreenElement) {
      playerRef.current.requestFullscreen().catch(err => {
        console.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
    } else {
      document.exitFullscreen();
    }
  };

  // Update fullscreen state
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  // Skip forward 10 seconds (only if within allowed range)
  const skipForward = () => {
    if (!videoRef.current) return;
    
    const newTime = currentTime + 10;
    
    // Only allow skipping forward if within the max watched time
    if (newTime <= maxWatchedTime + 1) { // Add a small buffer for rounding errors
      videoRef.current.currentTime = newTime;
    } else {
      setAttemptedSkip(true);
      
      // Hide the attempted skip message after 3 seconds
      setTimeout(() => {
        setAttemptedSkip(false);
      }, 3000);
    }
  };

  // Skip backward 10 seconds (always allowed)
  const skipBackward = () => {
    if (!videoRef.current) return;
    
    const newTime = Math.max(0, currentTime - 10);
    videoRef.current.currentTime = newTime;
  };

  // Auto-hide controls after inactivity
  const startControlsTimer = () => {
    if (controlsTimerRef.current) {
      clearTimeout(controlsTimerRef.current);
    }
    
    setShowControls(true);
    
    controlsTimerRef.current = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
      }
    }, 3000);
  };

  // Set up controls timer
  useEffect(() => {
    startControlsTimer();
    
    return () => {
      if (controlsTimerRef.current) {
        clearTimeout(controlsTimerRef.current);
      }
    };
  }, [isPlaying]);

  // Handle video ended event
  const handleEnded = () => {
    setIsPlaying(false);
    onEnded?.();
  };

  return (
    <div 
      ref={playerRef} 
      className="relative aspect-video bg-black group"
      onMouseMove={startControlsTimer}
      onTouchStart={startControlsTimer}
    >
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center z-10">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}
      
      <video
        ref={videoRef}
        src={src}
        poster={poster}
        className="w-full h-full"
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleMetadataLoaded}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={handleEnded}
        onClick={togglePlay}
        controlsList="nodownload"
        onContextMenu={(e) => e.preventDefault()}
        playsInline
      />
      
      {/* Title overlay */}
      <div 
        className={`absolute top-0 left-0 right-0 bg-gradient-to-b from-black/50 to-transparent p-4 transition-opacity duration-300 ${
          showControls ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <h3 className="text-white text-lg font-medium">{title}</h3>
      </div>
      
      {/* Skip warning message */}
      {attemptedSkip && (
        <div className="absolute top-1/4 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black/80 text-white px-4 py-2 rounded-lg text-sm">
          You cannot skip ahead in this video
        </div>
      )}
      
      {/* Controls overlay */}
      <div 
        className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/50 to-transparent p-4 transition-opacity duration-300 ${
          showControls ? 'opacity-100' : 'opacity-0'
        }`}
      >
        {/* Progress bar */}
        <input
          ref={progressBarRef}
          type="range"
          min="0"
          max={duration || 100}
          value={currentTime}
          onChange={handleSeek}
          className="w-full h-1 bg-gray-600 rounded-full appearance-none cursor-pointer"
          style={{
            background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${(currentTime / (duration || 1)) * 100}%, #4b5563 ${(currentTime / (duration || 1)) * 100}%, #4b5563 100%)`,
            // Add a highlight for the max watched section
            backgroundImage: `linear-gradient(to right, 
              #3b82f6 0%, 
              #3b82f6 ${(currentTime / (duration || 1)) * 100}%, 
              #4b5563 ${(currentTime / (duration || 1)) * 100}%, 
              #4b5563 ${(maxWatchedTime / (duration || 1)) * 100}%, 
              #1f2937 ${(maxWatchedTime / (duration || 1)) * 100}%, 
              #1f2937 100%)`
          }}
        />
        
        {/* Time and controls */}
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center space-x-4">
            <button onClick={togglePlay} className="text-white">
              {isPlaying ? <Pause size={20} /> : <Play size={20} />}
            </button>
            
            <button onClick={skipBackward} className="text-white">
              <SkipBack size={20} />
            </button>
            
            <button onClick={skipForward} className="text-white">
              <SkipForward size={20} />
            </button>
            
            <div className="flex items-center space-x-2">
              <button onClick={toggleMute} className="text-white">
                {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
              </button>
              
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={volume}
                onChange={handleVolumeChange}
                className="w-16 h-1 bg-gray-600 rounded-full appearance-none cursor-pointer"
              />
            </div>
            
            <span className="text-white text-sm">
              {formatTime(currentTime)} / {formatTime(duration)}
            </span>
          </div>
          
          <div className="flex items-center space-x-4">
            <span className="text-white text-sm">
              {progress}% watched
            </span>
            
            <button onClick={toggleFullscreen} className="text-white">
              <Maximize size={20} />
            </button>
          </div>
        </div>
      </div>
      
      {/* Big play button in the center when paused */}
      {!isPlaying && !isLoading && (
        <button
          onClick={togglePlay}
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white/20 rounded-full p-4 backdrop-blur-sm"
        >
          <Play size={32} fill="white" className="text-white ml-1" />
        </button>
      )}
    </div>
  );
}