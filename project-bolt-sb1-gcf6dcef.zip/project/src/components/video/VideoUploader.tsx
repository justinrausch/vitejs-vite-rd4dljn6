import React, { useState } from 'react';
import { Upload, Loader } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface VideoUploaderProps {
  onUploadComplete: (url: string) => void;
  folder?: string;
  maxSizeMB?: number;
}

export function VideoUploader({ 
  onUploadComplete, 
  folder = 'videos',
  maxSizeMB = 5120 // Changed from 500 to 5120 (5GB)
}: VideoUploaderProps) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size
    const fileSizeMB = file.size / (1024 * 1024);
    if (fileSizeMB > maxSizeMB) {
      setError(`File size exceeds ${maxSizeMB}MB limit`);
      return;
    }

    try {
      setUploading(true);
      setError(null);

      // Create a unique file path
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}-${Date.now()}.${fileExt}`;
      const filePath = `${folder}/${fileName}`;

      // Upload the file to Supabase Storage
      const { data, error: uploadError } = await supabase.storage
        .from('public')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        throw new Error(uploadError.message);
      }

      if (!data?.path) {
        throw new Error('Upload failed - no file path returned');
      }

      // Get the public URL
      const { data: urlData } = supabase.storage
        .from('public')
        .getPublicUrl(data.path);

      if (!urlData?.publicUrl) {
        throw new Error('Failed to get public URL for uploaded file');
      }

      // Return the URL to the parent component
      onUploadComplete(urlData.publicUrl);

    } catch (err) {
      console.error('Error uploading video:', err);
      setError(err instanceof Error ? err.message : 'Failed to upload video');
    } finally {
      setUploading(false);
      // Clear the file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className="w-full h-full flex flex-col items-center justify-center">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleUpload}
        accept="video/*"
        className="hidden"
        id="video-upload"
        disabled={uploading}
      />
      <label 
        htmlFor="video-upload"
        className={`flex flex-col items-center justify-center cursor-pointer ${
          uploading ? 'opacity-50 cursor-not-allowed' : 'hover:opacity-80'
        }`}
      >
        {uploading ? (
          <>
            <Loader size={48} className="text-blue-500 dark:text-blue-400 animate-spin mb-4" />
            <span className="text-gray-600 dark:text-gray-300">Uploading video...</span>
          </>
        ) : (
          <>
            <Upload size={48} className="text-blue-500 dark:text-blue-400 mb-4" />
            <span className="text-gray-600 dark:text-gray-300">Click to upload video</span>
            <span className="text-sm text-gray-500 dark:text-gray-400 mt-2">
              Maximum size: {maxSizeMB / 1024}GB
            </span>
          </>
        )}
      </label>

      {error && (
        <div className="mt-4 text-red-500 dark:text-red-400 text-sm text-center">
          {error}
        </div>
      )}
    </div>
  );
}