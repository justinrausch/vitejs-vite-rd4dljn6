import React, { useState, useEffect } from 'react';
import { Clock, CheckCircle, AlertTriangle, Search, Filter, RefreshCw, MessageCircle, Send } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { UserAvatar } from '../user/UserAvatar';

interface SupportTicket {
  id: string;
  user_id: string;
  subject: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved';
  created_at: string;
  user?: {
    username: string;
    avatar_url: string | null;
    email: string;
  };
}

interface TicketReply {
  id: string;
  ticket_id: string;
  user_id: string;
  message: string;
  created_at: string;
  user?: {
    username: string;
    avatar_url: string | null;
    is_admin?: boolean;
  };
}

export function SupportTickets() {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [ticketReplies, setTicketReplies] = useState<TicketReply[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'in_progress' | 'resolved'>('all');
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [replyText, setReplyText] = useState('');
  const [sendingReply, setSendingReply] = useState(false);
  const [loadingReplies, setLoadingReplies] = useState(false);

  useEffect(() => {
    fetchTickets();
  }, []);

  useEffect(() => {
    if (selectedTicket) {
      fetchTicketReplies(selectedTicket.id);
    }
  }, [selectedTicket]);

  const fetchTickets = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase
        .from('support_tickets')
        .select(`
          *,
          user:user_id (
            username,
            avatar_url,
            email
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setTickets(data || []);
    } catch (err) {
      console.error('Error fetching tickets:', err);
      setError('Failed to load support tickets');
    } finally {
      setLoading(false);
    }
  };

  const fetchTicketReplies = async (ticketId: string) => {
    try {
      setLoadingReplies(true);

      const { data, error } = await supabase
        .from('ticket_replies')
        .select(`
          *,
          user:user_id (
            username,
            avatar_url,
            is_admin
          )
        `)
        .eq('ticket_id', ticketId)
        .order('created_at', { ascending: true });

      if (error) throw error;

      setTicketReplies(data || []);
    } catch (err) {
      console.error('Error fetching ticket replies:', err);
    } finally {
      setLoadingReplies(false);
    }
  };

  const handleStatusChange = async (ticketId: string, newStatus: 'open' | 'in_progress' | 'resolved') => {
    try {
      const { error } = await supabase
        .from('support_tickets')
        .update({ status: newStatus })
        .eq('id', ticketId);

      if (error) throw error;

      // Update local state
      setTickets(prev => 
        prev.map(ticket => 
          ticket.id === ticketId 
            ? { ...ticket, status: newStatus } 
            : ticket
        )
      );

      if (selectedTicket && selectedTicket.id === ticketId) {
        setSelectedTicket(prev => prev ? { ...prev, status: newStatus } : null);
      }
    } catch (err) {
      console.error('Error updating ticket status:', err);
      alert('Failed to update ticket status');
    }
  };

  const handleSendReply = async () => {
    if (!selectedTicket || !replyText.trim() || !user) return;
    
    try {
      setSendingReply(true);
      
      // Insert reply
      const { data: replyData, error: replyError } = await supabase
        .from('ticket_replies')
        .insert({
          ticket_id: selectedTicket.id,
          user_id: user.id,
          message: replyText.trim()
        })
        .select(`
          *,
          user:user_id (
            username,
            avatar_url,
            is_admin
          )
        `)
        .single();
      
      if (replyError) throw replyError;
      
      // Update ticket status to in_progress if it was open
      if (selectedTicket.status === 'open') {
        await handleStatusChange(selectedTicket.id, 'in_progress');
      }
      
      // Add reply to state
      if (replyData) {
        setTicketReplies(prev => [...prev, replyData]);
      }
      
      // Reset form
      setReplyText('');
      
    } catch (error) {
      console.error('Error sending reply:', error);
      alert('Failed to send reply. Please try again.');
    } finally {
      setSendingReply(false);
    }
  };

  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = 
      ticket.subject.toLowerCase().includes(searchQuery.toLowerCase()) || 
      ticket.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.user?.username?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.user?.email?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || ticket.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return (
          <span className="px-2 py-1 bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-300 rounded-full text-xs font-medium flex items-center">
            <AlertTriangle size={12} className="mr-1" />
            Open
          </span>
        );
      case 'in_progress':
        return (
          <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 rounded-full text-xs font-medium flex items-center">
            <Clock size={12} className="mr-1" />
            In Progress
          </span>
        );
      case 'resolved':
        return (
          <span className="px-2 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 rounded-full text-xs font-medium flex items-center">
            <CheckCircle size={12} className="mr-1" />
            Resolved
          </span>
        );
      default:
        return null;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return 'just now';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} ${minutes === 1 ? 'minute' : 'minutes'} ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Support Tickets</h1>
        <button 
          onClick={fetchTickets}
          className="p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 rounded-full"
          title="Refresh tickets"
        >
          <RefreshCw size={20} className={loading ? "animate-spin" : ""} />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tickets List */}
        <div className="lg:col-span-1 bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white">Tickets</h2>
              <div className="flex items-center space-x-2">
                <Filter size={16} className="text-gray-400" />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="text-sm bg-gray-100 dark:bg-gray-700 border-none rounded-md focus:ring-blue-500 dark:text-white"
                >
                  <option value="all">All</option>
                  <option value="open">Open</option>
                  <option value="in_progress">In Progress</option>
                  <option value="resolved">Resolved</option>
                </select>
              </div>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="search"
                placeholder="Search tickets..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-100 dark:bg-gray-700 border-none rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
              />
            </div>
          </div>
          
          <div className="overflow-y-auto max-h-[calc(100vh-250px)]">
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : filteredTickets.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 dark:text-gray-400">No tickets found</p>
              </div>
            ) : (
              filteredTickets.map((ticket) => (
                <button
                  key={ticket.id}
                  onClick={() => setSelectedTicket(ticket)}
                  className={`w-full text-left p-4 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-750 ${
                    selectedTicket?.id === ticket.id ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <UserAvatar 
                        username={ticket.user?.username || 'User'}
                        avatarUrl={ticket.user?.avatar_url}
                        size="sm"
                      />
                      <div>
                        <h3 className="font-medium text-gray-900 dark:text-white">{ticket.subject}</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-1">
                          {ticket.user?.username || 'User'}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      {getStatusBadge(ticket.status)}
                      <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {formatDate(ticket.created_at)}
                      </span>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Ticket Details */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
          {selectedTicket ? (
            <div className="flex flex-col h-full">
              <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-medium text-gray-900 dark:text-white">{selectedTicket.subject}</h2>
                  {getStatusBadge(selectedTicket.status)}
                </div>
                <div className="flex items-center mt-2">
                  <UserAvatar 
                    username={selectedTicket.user?.username || 'User'}
                    avatarUrl={selectedTicket.user?.avatar_url}
                    size="sm"
                    className="mr-2"
                  />
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {selectedTicket.user?.username || 'User'}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {selectedTicket.user?.email || 'No email'}
                    </p>
                  </div>
                  <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">
                    {formatDate(selectedTicket.created_at)}
                  </span>
                </div>
              </div>
              
              <div className="p-4 flex-1 overflow-y-auto">
                <div className="bg-gray-50 dark:bg-gray-750 p-4 rounded-lg">
                  <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                    {selectedTicket.message}
                  </p>
                </div>
                
                {/* Replies */}
                {loadingReplies ? (
                  <div className="flex justify-center py-4">
                    <div className="w-6 h-6 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                  </div>
                ) : ticketReplies.length > 0 ? (
                  <div className="mt-6 space-y-4">
                    <h3 className="text-md font-medium text-gray-900 dark:text-white">Replies</h3>
                    {ticketReplies.map(reply => (
                      <div key={reply.id} className="bg-gray-50 dark:bg-gray-750 p-4 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center">
                            <UserAvatar 
                              username={reply.user?.username || 'User'}
                              avatarUrl={reply.user?.avatar_url}
                              size="xs"
                              className="mr-2"
                            />
                            <p className="text-sm font-medium text-gray-900 dark:text-white">
                              {reply.user?.username || 'User'}
                              {reply.user?.is_admin && (
                                <span className="ml-2 px-2 py-0.5 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 rounded-full text-xs">
                                  Admin
                                </span>
                              )}
                            </p>
                          </div>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {formatDate(reply.created_at)}
                          </span>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                          {reply.message}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : null}
                
                {/* Reply section */}
                <div className="mt-6">
                  <h3 className="text-md font-medium text-gray-900 dark:text-white mb-2">Reply</h3>
                  <textarea
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder="Type your reply here..."
                    className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white min-h-[120px] resize-none"
                  />
                  <div className="flex justify-between mt-4">
                    <div className="flex space-x-2">
                      <select
                        value={selectedTicket.status}
                        onChange={(e) => handleStatusChange(selectedTicket.id, e.target.value as any)}
                        className="px-3 py-2 bg-gray-100 dark:bg-gray-700 border-none rounded-md focus:ring-blue-500 text-sm dark:text-white"
                      >
                        <option value="open">Open</option>
                        <option value="in_progress">In Progress</option>
                        <option value="resolved">Resolved</option>
                      </select>
                    </div>
                    <button
                      onClick={handleSendReply}
                      disabled={!replyText.trim() || sendingReply}
                      className="px-4 py-2 bg-blue-500 text-white rounded-lg disabled:opacity-50 flex items-center"
                    >
                      {sendingReply ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send size={16} className="mr-2" />
                          Send Reply
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full py-12">
              <div className="bg-gray-100 dark:bg-gray-700 p-6 rounded-full mb-4">
                <MessageCircle size={48} className="text-gray-400 dark:text-gray-500" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                Select a ticket
              </h3>
              <p className="text-gray-500 dark:text-gray-400 text-center max-w-md">
                Choose a support ticket from the list to view details and respond to the user.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}