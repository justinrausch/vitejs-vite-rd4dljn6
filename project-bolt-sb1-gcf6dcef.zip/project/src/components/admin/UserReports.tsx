import React, { useState, useEffect } from 'react';
import { AlertTriangle, Search, Filter, RefreshCw, CheckCircle, XCircle, User } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { UserAvatar } from '../user/UserAvatar';

interface UserReport {
  id: string;
  reporter_id: string;
  reported_user_id: string;
  reason: string;
  details: string;
  status: 'pending' | 'reviewing' | 'resolved' | 'dismissed';
  created_at: string;
  reporter?: {
    username: string;
    avatar_url: string | null;
    email: string;
  };
  reported_user?: {
    username: string;
    avatar_url: string | null;
    email: string;
  };
}

export function UserReports() {
  const { user } = useAuth();
  const [reports, setReports] = useState<UserReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'reviewing' | 'resolved' | 'dismissed'>('all');
  const [selectedReport, setSelectedReport] = useState<UserReport | null>(null);
  const [updatingStatus, setUpdatingStatus] = useState(false);

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase
        .from('user_reports')
        .select(`
          *,
          reporter:reporter_id (
            username,
            avatar_url,
            email
          ),
          reported_user:reported_user_id (
            username,
            avatar_url,
            email
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setReports(data || []);
    } catch (err) {
      console.error('Error fetching user reports:', err);
      setError('Failed to load user reports');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (reportId: string, newStatus: 'pending' | 'reviewing' | 'resolved' | 'dismissed') => {
    try {
      setUpdatingStatus(true);

      const { error } = await supabase
        .from('user_reports')
        .update({ 
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', reportId);

      if (error) throw error;

      // Update local state
      setReports(prev => 
        prev.map(report => 
          report.id === reportId 
            ? { ...report, status: newStatus } 
            : report
        )
      );

      if (selectedReport && selectedReport.id === reportId) {
        setSelectedReport(prev => prev ? { ...prev, status: newStatus } : null);
      }
    } catch (err) {
      console.error('Error updating report status:', err);
      alert('Failed to update report status');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const filteredReports = reports.filter(report => {
    const matchesSearch = 
      report.reason.toLowerCase().includes(searchQuery.toLowerCase()) || 
      report.details?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.reporter?.username?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.reported_user?.username?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || report.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <span className="px-2 py-1 bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-300 rounded-full text-xs font-medium flex items-center">
            <AlertTriangle size={12} className="mr-1" />
            Pending
          </span>
        );
      case 'reviewing':
        return (
          <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 rounded-full text-xs font-medium flex items-center">
            <User size={12} className="mr-1" />
            Reviewing
          </span>
        );
      case 'resolved':
        return (
          <span className="px-2 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 rounded-full text-xs font-medium flex items-center">
            <CheckCircle size={12} className="mr-1" />
            Resolved
          </span>
        );
      case 'dismissed':
        return (
          <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300 rounded-full text-xs font-medium flex items-center">
            <XCircle size={12} className="mr-1" />
            Dismissed
          </span>
        );
      default:
        return null;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">User Reports</h1>
        <button 
          onClick={fetchReports}
          className="p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 rounded-full"
          title="Refresh reports"
        >
          <RefreshCw size={20} className={loading ? "animate-spin" : ""} />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Reports List */}
        <div className="lg:col-span-1 bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white">Reports</h2>
              <div className="flex items-center space-x-2">
                <Filter size={16} className="text-gray-400" />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="text-sm bg-gray-100 dark:bg-gray-700 border-none rounded-md focus:ring-blue-500 dark:text-white"
                >
                  <option value="all">All</option>
                  <option value="pending">Pending</option>
                  <option value="reviewing">Reviewing</option>
                  <option value="resolved">Resolved</option>
                  <option value="dismissed">Dismissed</option>
                </select>
              </div>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="search"
                placeholder="Search reports..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-100 dark:bg-gray-700 border-none rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
              />
            </div>
          </div>
          
          <div className="overflow-y-auto max-h-[calc(100vh-250px)]">
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : filteredReports.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 dark:text-gray-400">No reports found</p>
              </div>
            ) : (
              filteredReports.map((report) => (
                <button
                  key={report.id}
                  onClick={() => setSelectedReport(report)}
                  className={`w-full text-left p-4 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-750 ${
                    selectedReport?.id === report.id ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <UserAvatar 
                        username={report.reported_user?.username || 'User'}
                        avatarUrl={report.reported_user?.avatar_url}
                        size="sm"
                      />
                      <div>
                        <h3 className="font-medium text-gray-900 dark:text-white">
                          Report against @{report.reported_user?.username || 'User'}
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-1">
                          {report.reason}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      {getStatusBadge(report.status)}
                      <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {formatDate(report.created_at)}
                      </span>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Report Details */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
          {selectedReport ? (
            <div className="flex flex-col h-full">
              <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-medium text-gray-900 dark:text-white">Report Details</h2>
                  {getStatusBadge(selectedReport.status)}
                </div>
                <div className="flex items-center mt-2">
                  <UserAvatar 
                    username={selectedReport.reporter?.username || 'User'}
                    avatarUrl={selectedReport.reporter?.avatar_url}
                    size="sm"
                    className="mr-2"
                  />
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      Reported by: @{selectedReport.reporter?.username || 'User'}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {selectedReport.reporter?.email || 'No email'}
                    </p>
                  </div>
                  <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">
                    {formatDate(selectedReport.created_at)}
                  </span>
                </div>
              </div>
              
              <div className="p-4 flex-1 overflow-y-auto">
                <div className="mb-6">
                  <h3 className="text-md font-medium text-gray-900 dark:text-white mb-2">Reported User</h3>
                  <div className="bg-gray-50 dark:bg-gray-750 p-4 rounded-lg flex items-center">
                    <UserAvatar 
                      username={selectedReport.reported_user?.username || 'User'}
                      avatarUrl={selectedReport.reported_user?.avatar_url}
                      size="md"
                      className="mr-3"
                    />
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        @{selectedReport.reported_user?.username || 'User'}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {selectedReport.reported_user?.email || 'No email'}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-md font-medium text-gray-900 dark:text-white mb-2">Reason</h3>
                  <div className="bg-gray-50 dark:bg-gray-750 p-4 rounded-lg">
                    <p className="text-gray-700 dark:text-gray-300 font-medium">
                      {selectedReport.reason}
                    </p>
                  </div>
                </div>
                
                {selectedReport.details && (
                  <div className="mb-6">
                    <h3 className="text-md font-medium text-gray-900 dark:text-white mb-2">Details</h3>
                    <div className="bg-gray-50 dark:bg-gray-750 p-4 rounded-lg">
                      <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                        {selectedReport.details}
                      </p>
                    </div>
                  </div>
                )}
                
                <div className="mt-6">
                  <h3 className="text-md font-medium text-gray-900 dark:text-white mb-2">Actions</h3>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => handleStatusChange(selectedReport.id, 'reviewing')}
                      disabled={selectedReport.status === 'reviewing' || updatingStatus}
                      className={`px-4 py-2 rounded-lg text-sm font-medium ${
                        selectedReport.status === 'reviewing'
                          ? 'bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 cursor-not-allowed'
                          : 'bg-blue-500 text-white hover:bg-blue-600'
                      }`}
                    >
                      Mark as Reviewing
                    </button>
                    <button
                      onClick={() => handleStatusChange(selectedReport.id, 'resolved')}
                      disabled={selectedReport.status === 'resolved' || updatingStatus}
                      className={`px-4 py-2 rounded-lg text-sm font-medium ${
                        selectedReport.status === 'resolved'
                          ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 cursor-not-allowed'
                          : 'bg-green-500 text-white hover:bg-green-600'
                      }`}
                    >
                      Mark as Resolved
                    </button>
                    <button
                      onClick={() => handleStatusChange(selectedReport.id, 'dismissed')}
                      disabled={selectedReport.status === 'dismissed' || updatingStatus}
                      className={`px-4 py-2 rounded-lg text-sm font-medium ${
                        selectedReport.status === 'dismissed'
                          ? 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300 cursor-not-allowed'
                          : 'bg-gray-500 text-white hover:bg-gray-600'
                      }`}
                    >
                      Dismiss Report
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full py-12">
              <div className="bg-gray-100 dark:bg-gray-700 p-6 rounded-full mb-4">
                <User size={48} className="text-gray-400 dark:text-gray-500" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                Select a report
              </h3>
              <p className="text-gray-500 dark:text-gray-400 text-center max-w-md">
                Choose a user report from the list to view details and take action.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}