import React, { useState } from 'react';
import { X, Plus, Trash2 } from 'lucide-react';

interface PricingOption {
  id?: string;
  title: string;
  price: number;
  renewal_period: 'monthly' | 'yearly' | null;
  features: string[];
  lessons_access: boolean;
  community_access: boolean;
  coaching_access: boolean;
  rankings_access: boolean;
}

interface PricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (option: PricingOption) => void;
  initialOption?: PricingOption;
}

export function PricingModal({ isOpen, onClose, onSubmit, initialOption }: PricingModalProps) {
  const [title, setTitle] = useState(initialOption?.title || 'Monthly Plan');
  const [price, setPrice] = useState(initialOption?.price || 49.99);
  const [renewalPeriod, setRenewalPeriod] = useState<'monthly' | 'yearly' | null>(
    initialOption?.renewal_period || 'monthly'
  );
  const [features, setFeatures] = useState<string[]>(
    initialOption?.features || ['Full course access', 'Community access']
  );
  const [lessonsAccess, setLessonsAccess] = useState(initialOption?.lessons_access ?? true);
  const [communityAccess, setCommunityAccess] = useState(initialOption?.community_access ?? true);
  const [coachingAccess, setCoachingAccess] = useState(initialOption?.coaching_access ?? true);
  const [rankingsAccess, setRankingsAccess] = useState(initialOption?.rankings_access ?? true);
  const [newFeature, setNewFeature] = useState('');

  const handleAddFeature = () => {
    if (newFeature.trim()) {
      setFeatures([...features, newFeature.trim()]);
      setNewFeature('');
    }
  };

  const handleRemoveFeature = (index: number) => {
    setFeatures(features.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    onSubmit({
      id: initialOption?.id,
      title,
      price,
      renewal_period: renewalPeriod,
      features,
      lessons_access: lessonsAccess,
      community_access: communityAccess,
      coaching_access: coachingAccess,
      rankings_access: rankingsAccess
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            {initialOption ? 'Edit Pricing Option' : 'Add Pricing Option'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400">
            <X size={24} />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-700 border-none rounded-lg focus:ring-2 focus:ring-blue-500 dark:text-white"
              placeholder="e.g. Monthly Plan, Yearly Plan, Lifetime Access"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Price ($)
            </label>
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(parseFloat(e.target.value))}
              min="0"
              step="0.01"
              className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-700 border-none rounded-lg focus:ring-2 focus:ring-blue-500 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Renewal Period
            </label>
            <select
              value={renewalPeriod || ''}
              onChange={(e) => setRenewalPeriod(e.target.value as 'monthly' | 'yearly' | null)}
              className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-700 border-none rounded-lg focus:ring-2 focus:ring-blue-500 dark:text-white"
            >
              <option value="monthly">Monthly</option>
              <option value="yearly">Yearly</option>
              <option value="">One-time Payment</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Course Access
            </label>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={lessonsAccess}
                  onChange={(e) => setLessonsAccess(e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Skills & Lessons</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={communityAccess}
                  onChange={(e) => setCommunityAccess(e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Community</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={coachingAccess}
                  onChange={(e) => setCoachingAccess(e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Coaching</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={rankingsAccess}
                  onChange={(e) => setRankingsAccess(e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Rankings</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Display Features
            </label>
            <div className="space-y-2">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center">
                  <input
                    type="text"
                    value={feature}
                    onChange={(e) => {
                      const newFeatures = [...features];
                      newFeatures[index] = e.target.value;
                      setFeatures(newFeatures);
                    }}
                    className="flex-1 px-3 py-2 bg-gray-50 dark:bg-gray-700 border-none rounded-lg focus:ring-2 focus:ring-blue-500 dark:text-white"
                  />
                  <button
                    onClick={() => handleRemoveFeature(index)}
                    className="ml-2 text-gray-400 hover:text-red-500 dark:text-gray-500 dark:hover:text-red-400"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              ))}
              <div className="flex items-center">
                <input
                  type="text"
                  value={newFeature}
                  onChange={(e) => setNewFeature(e.target.value)}
                  placeholder="Add a feature..."
                  className="flex-1 px-3 py-2 bg-gray-50 dark:bg-gray-700 border-none rounded-lg focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-500"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newFeature.trim()) {
                      e.preventDefault();
                      handleAddFeature();
                    }
                  }}
                />
                <button
                  onClick={handleAddFeature}
                  disabled={!newFeature.trim()}
                  className="ml-2 p-2 text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300 disabled:opacity-50"
                >
                  <Plus size={18} />
                </button>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 mt-6">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              disabled={!title.trim() || price <= 0}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg disabled:opacity-50"
            >
              {initialOption ? 'Update' : 'Add'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}