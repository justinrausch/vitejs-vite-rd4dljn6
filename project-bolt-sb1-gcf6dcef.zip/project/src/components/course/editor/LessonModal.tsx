import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { supabase } from '../../../lib/supabase';

interface LessonModalProps {
  isOpen: boolean;
  onClose: () => void;
  chapterId: string;
  courseId: string; // Add courseId prop
  initialLesson?: {
    id: string;
    title: string;
    video_url?: string;
  };
  onSave: () => void;
}

export function LessonModal({ 
  isOpen, 
  onClose, 
  chapterId,
  courseId, // Add courseId parameter
  initialLesson,
  onSave 
}: LessonModalProps) {
  const [title, setTitle] = useState(initialLesson?.title || '');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setTitle(initialLesson?.title || '');
    }
  }, [isOpen, initialLesson]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || saving) return;

    try {
      setSaving(true);

      // Get the current highest position for this chapter
      const { data: existingLessons, error: positionError } = await supabase
        .from('course_lessons')
        .select('position')
        .eq('chapter_id', chapterId)
        .order('position', { ascending: false })
        .limit(1);

      if (positionError) throw positionError;

      const nextPosition = existingLessons && existingLessons.length > 0 
        ? existingLessons[0].position + 1 
        : 1;

      if (initialLesson) {
        // Update existing lesson
        const { error } = await supabase
          .from('course_lessons')
          .update({ title: title.trim() })
          .eq('id', initialLesson.id);

        if (error) throw error;
      } else {
        // Create new lesson
        const { error } = await supabase
          .from('course_lessons')
          .insert({
            title: title.trim(),
            chapter_id: chapterId,
            course_id: courseId, // Include courseId
            position: nextPosition
          });

        if (error) throw error;
      }

      onSave();
      onClose();
    } catch (err) {
      console.error('Error saving lesson:', err);
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            {initialLesson ? 'Edit Lesson' : 'New Lesson'}
          </h2>
          <button 
            onClick={onClose}
            className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
          >
            <X size={20} />
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label 
              htmlFor="title" 
              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
            >
              Lesson Title
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 border-none rounded-lg focus:ring-2 focus:ring-blue-500 dark:text-white"
              placeholder="Enter lesson title"
              autoFocus
            />
          </div>
          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!title.trim() || saving}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg disabled:opacity-50"
            >
              {saving ? 'Saving...' : initialLesson ? 'Save Changes' : 'Create Lesson'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}