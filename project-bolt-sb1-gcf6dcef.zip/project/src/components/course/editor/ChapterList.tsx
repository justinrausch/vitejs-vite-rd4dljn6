import React from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { Grip, Plus, Edit2, Trash2, Video } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface Lesson {
  id: string;
  title: string;
  video_url: string;
  position: number;
}

interface Chapter {
  id: string;
  title: string;
  position: number;
  lessons: Lesson[];
}

interface ChapterListProps {
  chapters: Chapter[];
  onAddChapter: () => void;
  onEditChapter: (chapterId: string) => void;
  onDeleteChapter: (chapterId: string) => void;
  onAddLesson: (chapterId: string) => void;
  onEditLesson: (chapterId: string, lessonId: string) => void;
  onDeleteLesson: (chapterId: string, lessonId: string) => void;
  onReorderChapters: (chapters: Chapter[]) => void;
  onReorderLessons: (chapterId: string, lessons: Lesson[]) => void;
}

export function ChapterList({
  chapters,
  onAddChapter,
  onEditChapter,
  onDeleteChapter,
  onAddLesson,
  onEditLesson,
  onDeleteLesson,
  onReorderChapters,
  onReorderLessons
}: ChapterListProps) {
  const handleDragEnd = (result: any) => {
    if (!result.destination) return;

    const { source, destination, type } = result;

    if (type === 'chapter') {
      const reorderedChapters = Array.from(chapters);
      const [removed] = reorderedChapters.splice(source.index, 1);
      reorderedChapters.splice(destination.index, 0, removed);

      // Update positions
      const updatedChapters = reorderedChapters.map((chapter, index) => ({
        ...chapter,
        position: index + 1
      }));

      onReorderChapters(updatedChapters);
    } else if (type === 'lesson') {
      const chapterId = source.droppableId;
      const chapter = chapters.find(c => c.id === chapterId);
      
      if (!chapter) return;

      const reorderedLessons = Array.from(chapter.lessons);
      const [removed] = reorderedLessons.splice(source.index, 1);
      reorderedLessons.splice(destination.index, 0, removed);

      // Update positions
      const updatedLessons = reorderedLessons.map((lesson, index) => ({
        ...lesson,
        position: index + 1
      }));

      onReorderLessons(chapterId, updatedLessons);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-medium text-gray-900 dark:text-white">Course Content</h2>
        <button
          onClick={onAddChapter}
          className="flex items-center text-blue-500 dark:text-blue-400 font-medium"
        >
          <Plus size={18} className="mr-1" />
          Add Chapter
        </button>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId={uuidv4()} type="chapter">
          {(provided) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className="space-y-4"
            >
              {chapters.map((chapter, index) => (
                <Draggable
                  key={chapter.id}
                  draggableId={chapter.id}
                  index={index}
                >
                  {(provided) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden"
                    >
                      <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center">
                        <div {...provided.dragHandleProps} className="mr-3 text-gray-400 cursor-move">
                          <Grip size={18} />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium text-gray-900 dark:text-white">
                            {chapter.title}
                          </h3>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {chapter.lessons.length} {chapter.lessons.length === 1 ? 'lesson' : 'lessons'}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => onEditChapter(chapter.id)}
                            className="p-2 text-gray-400 hover:text-blue-500 dark:hover:text-blue-400"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button
                            onClick={() => onDeleteChapter(chapter.id)}
                            className="p-2 text-gray-400 hover:text-red-500 dark:hover:text-red-400"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>

                      <Droppable droppableId={chapter.id} type="lesson">
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.droppableProps}
                            className="p-4 space-y-2"
                          >
                            {chapter.lessons.map((lesson, index) => (
                              <Draggable
                                key={lesson.id}
                                draggableId={lesson.id}
                                index={index}
                              >
                                {(provided) => (
                                  <div
                                    ref={provided.innerRef}
                                    {...provided.draggableProps}
                                    className="flex items-center bg-gray-50 dark:bg-gray-750 rounded-lg p-3"
                                  >
                                    <div {...provided.dragHandleProps} className="mr-3 text-gray-400 cursor-move">
                                      <Grip size={16} />
                                    </div>
                                    <div className="flex-1">
                                      <div className="flex items-center">
                                        <Video size={16} className="text-gray-400 mr-2" />
                                        <span className="text-gray-700 dark:text-gray-300">
                                          {lesson.title}
                                        </span>
                                      </div>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                      <button
                                        onClick={() => onEditLesson(chapter.id, lesson.id)}
                                        className="p-1 text-gray-400 hover:text-blue-500 dark:hover:text-blue-400"
                                      >
                                        <Edit2 size={16} />
                                      </button>
                                      <button
                                        onClick={() => onDeleteLesson(chapter.id, lesson.id)}
                                        className="p-1 text-gray-400 hover:text-red-500 dark:hover:text-red-400"
                                      >
                                        <Trash2 size={16} />
                                      </button>
                                    </div>
                                  </div>
                                )}
                              </Draggable>
                            ))}
                            {provided.placeholder}
                            <button
                              onClick={() => onAddLesson(chapter.id)}
                              className="w-full py-3 bg-gray-50 dark:bg-gray-750 text-blue-500 dark:text-blue-400 rounded-lg flex items-center justify-center font-medium hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                            >
                              <Plus size={18} className="mr-2" />
                              Add Lesson
                            </button>
                          </div>
                        )}
                      </Droppable>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
              {chapters.length === 0 && (
                <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-xl">
                  <p className="text-gray-500 dark:text-gray-400 mb-4">
                    No chapters yet. Add your first chapter to get started.
                  </p>
                  <button
                    onClick={onAddChapter}
                    className="px-6 py-3 bg-blue-500 text-white rounded-xl font-medium flex items-center mx-auto"
                  >
                    <Plus size={18} className="mr-2" />
                    Add First Chapter
                  </button>
                </div>
              )}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
}