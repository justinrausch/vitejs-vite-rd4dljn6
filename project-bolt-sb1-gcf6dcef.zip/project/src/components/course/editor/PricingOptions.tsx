import React, { useState } from 'react';
import { Plus, Trash2, Edit2, Check, X } from 'lucide-react';
import { PricingModal } from './PricingModal';

interface PricingOption {
  id?: string;
  title: string;
  price: number;
  renewal_period: 'monthly' | 'yearly' | null;
  features: string[];
  lessons_access: boolean;
  community_access: boolean;
  coaching_access: boolean;
  rankings_access: boolean;
}

interface PricingOptionsProps {
  options: PricingOption[];
  onAdd: (option: PricingOption) => void;
  onDelete: (index: number) => void;
  selectedIndex?: number;
  onSelectIndex?: (index: number) => void;
}

export function PricingOptions({ 
  options, 
  onAdd, 
  onDelete, 
  selectedIndex = 0, 
  onSelectIndex 
}: PricingOptionsProps) {
  const [showModal, setShowModal] = useState(false);
  const [editingOption, setEditingOption] = useState<PricingOption | null>(null);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);

  const handleAddOption = () => {
    setEditingOption(null);
    setEditingIndex(null);
    setShowModal(true);
  };

  const handleEditOption = (option: PricingOption, index: number) => {
    setEditingOption(option);
    setEditingIndex(index);
    setShowModal(true);
  };

  const handleSubmitOption = (option: PricingOption) => {
    if (editingIndex !== null) {
      // Update existing option
      const newOptions = [...options];
      newOptions[editingIndex] = option;
      onAdd(option); // This will replace the option at the index
      onDelete(editingIndex); // Remove the old option
    } else {
      // Add new option
      onAdd(option);
    }
    setEditingOption(null);
    setEditingIndex(null);
  };

  const getAccessBadges = (option: PricingOption) => {
    const badges = [];
    if (option.lessons_access) badges.push({ label: 'Skills', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400' });
    if (option.community_access) badges.push({ label: 'Community', color: 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400' });
    if (option.coaching_access) badges.push({ label: 'Coaching', color: 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400' });
    if (option.rankings_access) badges.push({ label: 'Rankings', color: 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400' });
    return badges;
  };

  return (
    <div>
      {options.length === 0 ? (
        <div className="text-center py-6 bg-gray-50 dark:bg-gray-700 rounded-lg">
          <p className="text-gray-500 dark:text-gray-400">No pricing options added yet</p>
          <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">
            Add pricing options to offer different plans for your course
          </p>
          <button
            onClick={handleAddOption}
            className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium flex items-center mx-auto"
          >
            <Plus size={16} className="mr-1" />
            Add Pricing Option
          </button>
        </div>
      ) : (
        <div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {options.map((option, index) => (
              <div
                key={index}
                className={`bg-white dark:bg-gray-800 rounded-lg border overflow-hidden shadow-sm ${
                  selectedIndex === index 
                    ? 'border-blue-500 ring-2 ring-blue-500/20' 
                    : 'border-gray-200 dark:border-gray-700'
                }`}
                onClick={() => onSelectIndex && onSelectIndex(index)}
              >
                <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                  <h3 className="font-medium text-lg text-gray-900 dark:text-white">{option.title}</h3>
                  {selectedIndex === index && (
                    <span className="px-2 py-0.5 bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-full text-xs">
                      Default
                    </span>
                  )}
                </div>
                <div className="p-4">
                  <div className="mt-1 flex items-baseline">
                    <span className="text-2xl font-bold text-gray-900 dark:text-white">${option.price}</span>
                    {option.renewal_period && (
                      <span className="ml-1 text-gray-500 dark:text-gray-400">
                        /{option.renewal_period === 'monthly' ? 'mo' : 'yr'}
                      </span>
                    )}
                  </div>
                  
                  {/* Access Features */}
                  <div className="mt-4">
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Access</h4>
                    <div className="flex flex-wrap gap-1">
                      {getAccessBadges(option).map((badge, i) => (
                        <span key={i} className={`px-2 py-1 rounded-full text-xs ${badge.color}`}>
                          {badge.label}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Display Features */}
                  {option.features.length > 0 && (
                    <div className="mt-4">
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Features</h4>
                      <ul className="space-y-1">
                        {option.features.map((feature, i) => (
                          <li key={i} className="flex items-start">
                            <Check size={14} className="text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-gray-700 dark:text-gray-300">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="mt-4 flex justify-end space-x-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEditOption(option, index);
                      }}
                      className="p-2 text-gray-400 hover:text-blue-500 dark:text-gray-500 dark:hover:text-blue-400 rounded-full"
                    >
                      <Edit2 size={18} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDelete(index);
                      }}
                      className="p-2 text-gray-400 hover:text-red-500 dark:text-gray-500 dark:hover:text-red-400 rounded-full"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-4 flex justify-center">
            <button
              onClick={handleAddOption}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium flex items-center"
            >
              <Plus size={16} className="mr-1" />
              Add Another Option
            </button>
          </div>
        </div>
      )}

      <PricingModal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          setEditingOption(null);
          setEditingIndex(null);
        }}
        onSubmit={handleSubmitOption}
        initialOption={editingOption || undefined}
      />
    </div>
  );
}