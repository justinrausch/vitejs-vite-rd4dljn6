import React, { useState } from 'react';
import { Edit2, Save, X } from 'lucide-react';
import { CHAR_LIMITS } from '../../../lib/constants';

interface CourseDescriptionProps {
  description: string;
  isEditing: boolean;
  onEdit: () => void;
  onChange: (description: string) => void;
}

export function CourseDescription({
  description,
  isEditing,
  onEdit,
  onChange
}: CourseDescriptionProps) {
  const [value, setValue] = useState(description);
  const charCount = value.length;
  const isOverLimit = charCount > CHAR_LIMITS.COURSE_DESCRIPTION;

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    if (newValue.length <= CHAR_LIMITS.COURSE_DESCRIPTION) {
      setValue(newValue);
      onChange(newValue);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-medium text-gray-900 dark:text-white">Course Description</h2>
        {!isEditing && (
          <button
            onClick={onEdit}
            className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
          >
            <Edit2 size={16} />
          </button>
        )}
      </div>
      
      {isEditing ? (
        <div className="space-y-4">
          <textarea
            value={value}
            onChange={handleChange}
            className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400 min-h-[200px] resize-none"
            placeholder="Describe your course..."
          />
          <div className="flex justify-between items-center text-sm">
            <span className={`${isOverLimit ? 'text-red-500' : 'text-gray-500'} dark:text-gray-400`}>
              {charCount}/{CHAR_LIMITS.COURSE_DESCRIPTION} characters
            </span>
          </div>
        </div>
      ) : (
        <div className="prose dark:prose-invert prose-sm max-w-none">
          {description || 'No description available yet.'}
        </div>
      )}
    </div>
  );
}