import React, { useState, useEffect, useRef } from 'react';
import { Send, Image } from 'lucide-react';
import { useAuth } from '../../../contexts/AuthContext';
import { supabase } from '../../../lib/supabase';
import { MessageList } from './MessageList';
import { MessageInput } from './MessageInput';
import { UserAvatar } from '../../user/UserAvatar';
import { formatDate } from '../../../lib/utils/date';

interface Message {
  id: string;
  content: string;
  created_at: string;
  sender_id: string;
  lesson_id?: string | null;
  lesson_title?: string | null;
  image_url?: string | null;
  sender: {
    username: string;
    avatar_url: string | null;
  };
}

interface StudentDashboardProps {
  courseId: string;
  instructorUsername: string;
  instructorAvatarUrl: string | null;
}

export function StudentDashboard({
  courseId,
  instructorUsername,
  instructorAvatarUrl
}: StudentDashboardProps) {
  const { user, userProfile } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [hasMoreMessages, setHasMoreMessages] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [oldestMessageDate, setOldestMessageDate] = useState<string | null>(null);
  const [processedMessageIds] = useState(new Set<string>());
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    if (user) {
      fetchInitialMessages();
      const subscription = setupRealtimeSubscription();
      return () => {
        subscription();
      };
    }
  }, [user]);

  // Scroll to bottom whenever messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchInitialMessages = async () => {
    if (!user) return;
    
    try {
      setLoading(true);

      const { data, error } = await supabase
        .from('coach_messages')
        .select(`
          id,
          content,
          created_at,
          sender_id,
          lesson_id,
          image_url,
          sender:sender_id (
            username,
            avatar_url
          ),
          course_lessons:lesson_id (
            title
          )
        `)
        .eq('course_id', courseId)
        .eq('student_id', user.id)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      const formattedMessages = data.map(msg => ({
        id: msg.id,
        content: msg.content,
        created_at: msg.created_at,
        sender_id: msg.sender_id,
        lesson_id: msg.lesson_id,
        lesson_title: msg.course_lessons?.title,
        image_url: msg.image_url,
        sender: {
          username: msg.sender.username,
          avatar_url: msg.sender.avatar_url
        }
      })).reverse();

      setMessages(formattedMessages);
      
      if (data.length > 0) {
        setOldestMessageDate(data[data.length - 1].created_at);
        setHasMoreMessages(data.length === 20);
      }

      data.forEach(msg => processedMessageIds.add(msg.id));

    } catch (err) {
      console.error('Error fetching messages:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchMoreMessages = async () => {
    if (!user || !oldestMessageDate || loadingMore) return;
    
    try {
      setLoadingMore(true);

      const { data, error } = await supabase
        .from('coach_messages')
        .select(`
          id,
          content,
          created_at,
          sender_id,
          lesson_id,
          image_url,
          sender:sender_id (
            username,
            avatar_url
          ),
          course_lessons:lesson_id (
            title
          )
        `)
        .eq('course_id', courseId)
        .eq('student_id', user.id)
        .lt('created_at', oldestMessageDate)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      const formattedMessages = data.map(msg => ({
        id: msg.id,
        content: msg.content,
        created_at: msg.created_at,
        sender_id: msg.sender_id,
        lesson_id: msg.lesson_id,
        lesson_title: msg.course_lessons?.title,
        image_url: msg.image_url,
        sender: {
          username: msg.sender.username,
          avatar_url: msg.sender.avatar_url
        }
      })).reverse();

      setMessages(prev => [...formattedMessages, ...prev]);
      
      if (data.length > 0) {
        setOldestMessageDate(data[data.length - 1].created_at);
        setHasMoreMessages(data.length === 20);
      } else {
        setHasMoreMessages(false);
      }

      data.forEach(msg => processedMessageIds.add(msg.id));

    } catch (err) {
      console.error('Error fetching more messages:', err);
    } finally {
      setLoadingMore(false);
    }
  };

  const setupRealtimeSubscription = () => {
    const subscription = supabase.channel(`student-messages-${courseId}-${user?.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'coach_messages',
          filter: `course_id=eq.${courseId}:student_id=eq.${user?.id}`
        },
        async (payload) => {
          if (processedMessageIds.has(payload.new.id)) {
            return;
          }

          processedMessageIds.add(payload.new.id);

          const { data: senderData } = await supabase
            .from('profiles')
            .select('username, avatar_url')
            .eq('id', payload.new.sender_id)
            .single();

          if (senderData) {
            const newMessage = {
              id: payload.new.id,
              content: payload.new.content,
              created_at: payload.new.created_at,
              sender_id: payload.new.sender_id,
              lesson_id: payload.new.lesson_id,
              lesson_title: null,
              image_url: payload.new.image_url,
              sender: {
                username: senderData.username,
                avatar_url: senderData.avatar_url
              }
            };

            setMessages(prev => [...prev, newMessage]);
            scrollToBottom();
          }
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    
    // Check if file is an image
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }
    
    // Check file size (limit to 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    setImageFile(file);
    
    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleImageUpload = async () => {
    if (!imageFile || !user) return;
    
    try {
      setSending(true);
      
      // Create a unique file path
      const fileExt = imageFile.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `coaching-media/${fileName}`;
      
      // Upload the file to Supabase Storage
      const { data, error: uploadError } = await supabase.storage
        .from('public')
        .upload(filePath, imageFile, {
          cacheControl: '3600',
          upsert: false
        });
      
      if (uploadError) throw uploadError;
      
      // Get the public URL
      const { data: urlData } = supabase.storage
        .from('public')
        .getPublicUrl(filePath);
      
      // Create the message with image URL
      const { error } = await supabase
        .from('coach_messages')
        .insert({
          course_id: courseId,
          student_id: user.id,
          sender_id: user.id,
          content: newMessage.trim() || ' ', // Ensure we have some content
          image_url: urlData.publicUrl
        });
      
      if (error) throw error;
      
      // Reset states
      setNewMessage('');
      setImageFile(null);
      setImagePreview(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      
    } catch (err) {
      console.error('Error sending message with image:', err);
      alert('Failed to send message. Please try again.');
    } finally {
      setSending(false);
    }
  };

  const sendTextMessage = async () => {
    if (!newMessage.trim() || !user || sending) return;
    
    const tempId = `temp-${Date.now()}`;
    const messageContent = newMessage.trim();
    
    // Create optimistic message
    const optimisticMessage: Message = {
      id: tempId,
      content: messageContent,
      created_at: new Date().toISOString(),
      sender_id: user.id,
      sender: {
        username: userProfile?.username || user.email?.split('@')[0] || 'You',
        avatar_url: userProfile?.avatar_url
      }
    };

    // Add optimistic message to state
    setMessages(prev => [...prev, optimisticMessage]);
    setNewMessage('');
    scrollToBottom();

    try {
      setSending(true);
      
      const { error, data } = await supabase
        .from('coach_messages')
        .insert({
          course_id: courseId,
          student_id: user.id,
          sender_id: user.id,
          content: messageContent
        })
        .select()
        .single();

      if (error) throw error;

      // Add the real message ID to processed set
      processedMessageIds.add(data.id);
      
      // Replace optimistic message with real one
      setMessages(prev => 
        prev.map(msg => 
          msg.id === tempId ? { ...msg, id: data.id } : msg
        )
      );

    } catch (err) {
      console.error('Error sending message:', err);
      // Remove optimistic message on error
      setMessages(prev => prev.filter(msg => msg.id !== tempId));
    } finally {
      setSending(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if ((!newMessage.trim() && !imageFile) || sending || uploadingImage) return;
    
    if (imageFile) {
      await handleImageUpload();
    } else {
      await sendTextMessage();
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleRemoveImage = () => {
    setImagePreview(null);
    setImageFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="h-full bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden flex flex-col">
      {/* Coach Info */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center">
          <UserAvatar 
            username={instructorUsername}
            avatarUrl={instructorAvatarUrl}
            size="md"
            className="mr-3"
          />
          <div>
            <h3 className="font-medium text-gray-900 dark:text-white">{instructorUsername}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">Your Coach</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <MessageList
        messages={messages}
        loading={loading}
        loadingMoreMessages={loadingMore}
        hasMoreMessages={hasMoreMessages}
        onLoadMoreMessages={fetchMoreMessages}
        currentUserId={user?.id || ''}
        courseId={courseId}
        formatMessageTime={formatDate}
        ref={{ messagesContainer: messagesContainerRef, messagesEnd: messagesEndRef }}
        onUserClick={() => {}}
        onDeleteMessage={() => {}}
        canDeleteMessage={() => false}
        isAdmin={() => false}
        deletingMessages={{}}
        debugInfo={null}
      />

      {/* Message Input */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        {imagePreview && (
          <div className="mb-2 relative">
            <div className="relative rounded-lg overflow-hidden\" style={{ maxHeight: '150px' }}>
              <img 
                src={imagePreview} 
                alt="Upload preview" 
                className="max-w-full h-auto max-h-[150px] object-contain bg-gray-100 dark:bg-gray-700"
              />
              <button
                onClick={handleRemoveImage}
                className="absolute top-2 right-2 bg-gray-800/70 text-white rounded-full p-1 hover:bg-gray-900/70"
              >
                <span>×</span>
              </button>
            </div>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageSelect}
            accept="image/*"
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
            disabled={sending || uploadingImage}
          >
            <Image size={20} />
          </button>
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full px-4 py-2 text-sm border-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400"
            disabled={sending || uploadingImage}
          />
          <button
            type="submit"
            disabled={sending || uploadingImage || (!newMessage.trim() && !imageFile)}
            className="p-2 text-blue-500 dark:text-blue-400 hover:text-blue-600 dark:hover:text-blue-300 disabled:opacity-50"
          >
            {sending || uploadingImage ? (
              <div className="w-5 h-5 border-2 border-blue-500 dark:border-blue-400 border-t-transparent rounded-full animate-spin" />
            ) : (
              <Send size={20} />
            )}
          </button>
        </form>
      </div>
    </div>
  );
}