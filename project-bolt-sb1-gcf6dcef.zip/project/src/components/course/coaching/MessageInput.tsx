import React, { useState, useRef } from 'react';
import { Image, Send } from 'lucide-react';
import { supabase } from '../../../lib/supabase';

interface MessageInputProps {
  value: string;
  onChange: (value: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  sending: boolean;
  courseId?: string;
}

export function MessageInput({ value, onChange, onSubmit, sending, courseId }: MessageInputProps) {
  const [uploadingImage, setUploadingImage] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    
    // Check if file is an image
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }
    
    // Check file size (limit to 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    setImageFile(file);
    
    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    setImagePreview(null);
    setImageFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmitWithImage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if ((!value.trim() && !imageFile) || sending || uploadingImage) return;
    
    if (imageFile) {
      try {
        setUploadingImage(true);
        
        // Create a unique file path
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = `coaching-media/${fileName}`;
        
        // Upload the file to Supabase Storage
        const { data, error: uploadError } = await supabase.storage
          .from('public')
          .upload(filePath, imageFile, {
            cacheControl: '3600',
            upsert: false
          });
        
        if (uploadError) throw uploadError;
        
        // Get the public URL
        const { data: urlData } = supabase.storage
          .from('public')
          .getPublicUrl(filePath);
        
        // Update the message with the image URL
        onChange(value + ` [Image: ${urlData.publicUrl}]`);
        
        // Reset the image state
        setImagePreview(null);
        setImageFile(null);
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
        
        // Submit the form
        onSubmit(e);
      } catch (err) {
        console.error('Error uploading image:', err);
        alert('Failed to upload image. Please try again.');
      } finally {
        setUploadingImage(false);
      }
    } else {
      // Just send the text message
      onSubmit(e);
    }
  };

  return (
    <div className="p-4 border-t border-gray-200 dark:border-gray-700">
      {imagePreview && (
        <div className="mb-2 relative">
          <div className="relative rounded-lg overflow-hidden\" style={{ maxHeight: '150px' }}>
            <img 
              src={imagePreview} 
              alt="Upload preview" 
              className="max-w-full h-auto max-h-[150px] object-contain bg-gray-100 dark:bg-gray-700"
            />
            <button
              onClick={handleRemoveImage}
              className="absolute top-2 right-2 bg-gray-800/70 text-white rounded-full p-1 hover:bg-gray-900/70"
            >
              <span>×</span>
            </button>
          </div>
        </div>
      )}
      
      <form onSubmit={handleSubmitWithImage} className="flex items-center gap-2">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleImageSelect}
          accept="image/*"
          className="hidden"
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="p-2 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
          disabled={sending || uploadingImage}
        >
          <Image size={20} />
        </button>
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Type your message..."
          className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full px-4 py-2 text-sm border-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400"
          disabled={sending || uploadingImage}
        />
        <button
          type="submit"
          disabled={sending || uploadingImage || (!value.trim() && !imageFile)}
          className="p-2 text-blue-500 dark:text-blue-400 hover:text-blue-600 dark:hover:text-blue-300 disabled:opacity-50"
        >
          {sending || uploadingImage ? (
            <div className="w-5 h-5 border-2 border-blue-500 dark:border-blue-400 border-t-transparent rounded-full animate-spin" />
          ) : (
            <Send size={20} />
          )}
        </button>
      </form>
    </div>
  );
}