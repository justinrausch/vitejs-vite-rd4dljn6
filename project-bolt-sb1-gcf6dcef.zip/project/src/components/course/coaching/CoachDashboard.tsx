import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Send, Image, ChevronRight, ChevronUp } from 'lucide-react';
import { useCoachingSystem } from '../../../hooks/useCoachingSystem';
import { UserAvatar } from '../../user/UserAvatar';
import { formatDate } from '../../../lib/utils/date';
import { useAuth } from '../../../contexts/AuthContext';
import { supabase } from '../../../lib/supabase';

interface CoachDashboardProps {
  courseId: string;
  instructorUsername: string;
  instructorAvatarUrl: string | null;
}

export function CoachDashboard({ 
  courseId,
  instructorUsername,
  instructorAvatarUrl 
}: CoachDashboardProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const [loadingMore, setLoadingMore] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  const {
    students,
    selectedStudent,
    messages,
    loading,
    sendingMessage,
    error,
    hasMoreMessages,
    setSelectedStudent,
    handleSendMessage,
    loadMoreMessages
  } = useCoachingSystem(courseId);

  // Scroll to bottom when messages change or student is selected
  useEffect(() => {
    scrollToBottom();
  }, [messages, selectedStudent]);

  const handleLoadMore = async () => {
    if (!loadingMore && hasMoreMessages) {
      setLoadingMore(true);
      await loadMoreMessages();
      setLoadingMore(false);
    }
  };

  const filteredStudents = students.filter(student => 
    student.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    
    // Check if file is an image
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }
    
    // Check file size (limit to 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    setImageFile(file);
    
    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    setImagePreview(null);
    setImageFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if ((!newMessage.trim() && !imageFile) || !selectedStudent) return;
    
    if (imageFile) {
      try {
        setUploadingImage(true);
        
        // Create a unique file path
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = `coaching-media/${fileName}`;
        
        // Upload the file to Supabase Storage
        const { data, error: uploadError } = await supabase.storage
          .from('public')
          .upload(filePath, imageFile, {
            cacheControl: '3600',
            upsert: false
          });
        
        if (uploadError) throw uploadError;
        
        // Get the public URL
        const { data: urlData } = supabase.storage
          .from('public')
          .getPublicUrl(filePath);
        
        // Send the message with image
        await supabase
          .from('coach_messages')
          .insert({
            course_id: courseId,
            student_id: selectedStudent.id,
            sender_id: user?.id,
            content: newMessage.trim() || ' ', // Ensure we have some content
            image_url: urlData.publicUrl
          });
        
        // Reset states
        setNewMessage('');
        setImageFile(null);
        setImagePreview(null);
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
        
        setTimeout(scrollToBottom, 100);
      } catch (err) {
        console.error('Error sending message with image:', err);
        alert('Failed to send message. Please try again.');
      } finally {
        setUploadingImage(false);
      }
    } else {
      // Send text-only message
      await handleSendMessage(newMessage, selectedStudent.id);
      setNewMessage('');
      setTimeout(scrollToBottom, 100);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 h-full gap-6">
      {/* Student List */}
      <div className="md:col-span-1 bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden flex flex-col">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-medium text-gray-900 dark:text-white">Students</h2>
          <div className="mt-2 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500" size={18} />
            <input
              type="search"
              placeholder="Search students..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-100 dark:bg-gray-700 border-none rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400"
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : filteredStudents.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">No students found</p>
            </div>
          ) : (
            filteredStudents.map((student) => (
              <button
                key={student.id}
                onClick={() => setSelectedStudent(student)}
                className={`w-full text-left p-4 flex items-center border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-750 ${
                  selectedStudent?.id === student.id ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                }`}
              >
                <div className="relative">
                  <UserAvatar 
                    username={student.username}
                    avatarUrl={student.avatar_url}
                    size="md"
                  />
                  {student.unread_count > 0 && (
                    <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                      {student.unread_count}
                    </div>
                  )}
                </div>
                <div className="ml-3 flex-1">
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-medium text-gray-900 dark:text-white">{student.username}</h3>
                    {student.last_message_at && (
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        {formatDate(student.last_message_at)}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 truncate">
                    {student.last_message_at ? 'Has messages' : 'No messages yet'}
                  </p>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Chat Area */}
      <div className="md:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden flex flex-col">
        {selectedStudent ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center">
              <UserAvatar 
                username={selectedStudent.username}
                avatarUrl={selectedStudent.avatar_url}
                size="md"
                className="mr-3"
              />
              <div>
                <h3 className="font-medium text-gray-900 dark:text-white">{selectedStudent.username}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Student</p>
              </div>
            </div>

            {/* Messages */}
            <div 
              ref={messagesContainerRef}
              className="flex-1 overflow-y-auto p-4 space-y-4"
            >
              {hasMoreMessages && (
                <div className="text-center mb-4">
                  <button
                    onClick={handleLoadMore}
                    disabled={loadingMore}
                    className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 disabled:opacity-50"
                  >
                    {loadingMore ? (
                      <div className="w-4 h-4 mr-2 border-2 border-gray-400 dark:border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <ChevronUp size={16} className="mr-2" />
                    )}
                    {loadingMore ? 'Loading...' : 'Load older messages'}
                  </button>
                </div>
              )}

              {loading ? (
                <div className="flex justify-center py-8">
                  <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center">
                  <p className="text-gray-500 dark:text-gray-400">No messages yet</p>
                  <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
                    Send a message to start a conversation
                  </p>
                </div>
              ) : (
                messages.map((message, index) => {
                  const isCoachMessage = message.sender_id === user?.id;
                  const showLessonInfo = message.lesson_id && message.lesson_title;
                  const isFirstMessage = index === 0 || 
                    new Date(message.created_at).toDateString() !== 
                    new Date(messages[index - 1].created_at).toDateString();
                  
                  return (
                    <div key={message.id}>
                      {isFirstMessage && (
                        <div className="flex justify-center my-4">
                          <span className="text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded-full">
                            {new Date(message.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      )}
                      
                      {showLessonInfo && (
                        <div className="flex justify-center my-2">
                          <div 
                            className="text-xs bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-full flex items-center cursor-pointer"
                            onClick={() => navigate(`/course/${courseId}/lesson/${message.lesson_id}`)}
                          >
                            <span>Lesson: {message.lesson_title}</span>
                            <ChevronRight size={14} className="ml-1" />
                          </div>
                        </div>
                      )}
                      
                      <div className={`flex ${isCoachMessage ? 'justify-end' : 'justify-start'}`}>
                        <div className={`flex ${isCoachMessage ? 'flex-row-reverse' : 'flex-row'} items-start gap-2 max-w-[80%]`}>
                          <UserAvatar 
                            username={message.sender.username}
                            avatarUrl={message.sender.avatar_url}
                            size="sm"
                          />
                          <div>
                            <div className={`flex items-baseline ${isCoachMessage ? 'justify-end' : 'justify-start'} mb-1 gap-4`}>
                              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                                {message.sender.username}
                              </span>
                              <span className="text-xs text-gray-500 dark:text-gray-400">
                                {formatDate(message.created_at)}
                              </span>
                            </div>
                            <div className={`rounded-lg p-3 ${
                              isCoachMessage 
                                ? 'bg-blue-500 text-white' 
                                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                            }`}>
                              {message.image_url && (
                                <div className="mb-2 rounded-lg overflow-hidden">
                                  <img 
                                    src={message.image_url} 
                                    alt="Shared image" 
                                    className="w-full h-auto max-h-48 object-cover"
                                  />
                                </div>
                              )}
                              <p className="break-words">{message.content}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-gray-200 dark:border-gray-700">
              {imagePreview && (
                <div className="mb-2 relative">
                  <div className="relative rounded-lg overflow-hidden\" style={{ maxHeight: '150px' }}>
                    <img 
                      src={imagePreview} 
                      alt="Upload preview" 
                      className="max-w-full h-auto max-h-[150px] object-contain bg-gray-100 dark:bg-gray-700"
                    />
                    <button
                      onClick={handleRemoveImage}
                      className="absolute top-2 right-2 bg-gray-800/70 text-white rounded-full p-1 hover:bg-gray-900/70"
                    >
                      <span>×</span>
                    </button>
                  </div>
                </div>
              )}
              
              <form onSubmit={handleSubmit} className="flex items-center gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageSelect}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
                  disabled={sendingMessage || uploadingImage}
                >
                  <Image size={20} />
                </button>
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full px-4 py-2 text-sm border-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400"
                  disabled={sendingMessage || uploadingImage}
                />
                <button
                  type="submit"
                  disabled={sendingMessage || uploadingImage || (!newMessage.trim() && !imageFile)}
                  className="p-2 text-blue-500 dark:text-blue-400 hover:text-blue-600 dark:hover:text-blue-300 disabled:opacity-50"
                >
                  {sendingMessage || uploadingImage ? (
                    <div className="w-5 h-5 border-2 border-blue-500 dark:border-blue-400 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Send size={20} />
                  )}
                </button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center p-4">
            <h3 className="text-xl font-medium text-gray-900 dark:text-white mb-2">Select a student</h3>
            <p className="text-gray-500 dark:text-gray-400 max-w-md">
              Choose a student from the list to view your conversation history and send messages.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}