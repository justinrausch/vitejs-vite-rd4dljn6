import React, { forwardRef, useState } from 'react';
import { ChevronUp, Trash2 } from 'lucide-react';
import { UserAvatar } from '../../user/UserAvatar';
import { AdminBadge } from '../../user/AdminBadge';
import { CoachBadge } from '../../user/CoachBadge';

interface ChatMessage {
  id: string;
  content: string;
  created_at: string;
  sender_id: string;
  sender: {
    username: string;
    avatar_url: string | null;
    is_coach?: boolean;
    email?: string;
  };
  lesson_id?: string;
  lesson_title?: string;
  image_url?: string | null;
}

interface MessageListProps {
  messages: ChatMessage[];
  loadingMoreMessages: boolean;
  hasMoreMessages: boolean;
  onLoadMoreMessages: () => void;
  onUserClick: (username: string) => void;
  onDeleteMessage: (messageId: string) => void;
  canDeleteMessage: (message: ChatMessage) => boolean;
  formatMessageTime: (timestamp: string) => string;
  isAdmin: (email?: string) => boolean;
  deletingMessages: Record<string, boolean>;
  debugInfo: string | null;
  currentUserId: string;
  courseId: string;
  loading?: boolean;
}

interface MessageListRefs {
  messagesContainer: React.RefObject<HTMLDivElement>;
  messagesEnd: React.RefObject<HTMLDivElement>;
}

export const MessageList = forwardRef<MessageListRefs, MessageListProps>(
  ({ 
    messages, 
    loadingMoreMessages, 
    hasMoreMessages, 
    onLoadMoreMessages, 
    onUserClick, 
    onDeleteMessage, 
    canDeleteMessage, 
    formatMessageTime, 
    isAdmin, 
    deletingMessages,
    debugInfo,
    currentUserId,
    loading = false
  }, ref) => {
    const defaultContainerRef = React.useRef<HTMLDivElement>(null);
    const defaultEndRef = React.useRef<HTMLDivElement>(null);
    
    const { 
      messagesContainer = defaultContainerRef, 
      messagesEnd = defaultEndRef 
    } = (ref as { current: MessageListRefs })?.current || {};

    // Scroll to bottom on mount and when messages change
    React.useEffect(() => {
      if (messagesEnd.current) {
        messagesEnd.current.scrollIntoView({ behavior: 'smooth' });
      }
    }, [messages]);

    // Handle scroll event to load more messages
    React.useEffect(() => {
      const container = messagesContainer.current;
      if (!container) return;

      const handleScroll = () => {
        if (container.scrollTop === 0 && hasMoreMessages && !loadingMoreMessages) {
          // Save current scroll position
          const scrollHeight = container.scrollHeight;
          
          // Load more messages
          onLoadMoreMessages();
          
          // After messages are loaded, restore scroll position
          setTimeout(() => {
            const newScrollHeight = container.scrollHeight;
            const diff = newScrollHeight - scrollHeight;
            container.scrollTop = diff;
          }, 100);
        }
      };

      container.addEventListener('scroll', handleScroll);
      return () => container.removeEventListener('scroll', handleScroll);
    }, [hasMoreMessages, loadingMoreMessages, onLoadMoreMessages]);

    const [expandedImages, setExpandedImages] = useState<Set<string>>(new Set());
    const [previewImage, setPreviewImage] = useState<string | null>(null);

    const toggleImageExpand = (messageId: string) => {
      setExpandedImages(prev => {
        const next = new Set(prev);
        if (next.has(messageId)) {
          next.delete(messageId);
        } else {
          next.add(messageId);
        }
        return next;
      });
    };

    const handleImageClick = (imageUrl: string, e: React.MouseEvent) => {
      e.stopPropagation();
      setPreviewImage(imageUrl);
    };

    return (
      <>
        <div 
          ref={messagesContainer}
          className="flex-1 overflow-y-auto p-4 space-y-4"
        >
          {hasMoreMessages && (
            <div className="text-center mb-4">
              <button
                onClick={onLoadMoreMessages}
                disabled={loadingMoreMessages}
                className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 disabled:opacity-50"
              >
                {loadingMoreMessages ? (
                  <div className="w-4 h-4 mr-2 border-2 border-gray-400 dark:border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <ChevronUp size={16} className="mr-2" />
                )}
                {loadingMoreMessages ? 'Loading...' : 'Load older messages'}
              </button>
            </div>
          )}
          
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <p className="text-gray-500 dark:text-gray-400">No messages yet</p>
              <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
                Send a message to start a conversation
              </p>
            </div>
          ) : (
            messages.map((message, index) => {
              if (!message?.sender?.username) {
                console.error('Invalid message format:', message);
                return null;
              }

              const isOwnMessage = message.sender_id === currentUserId;
              const canDelete = canDeleteMessage(message);
              const isImageExpanded = expandedImages.has(message.id);
              const isFirstMessage = index === 0 || 
                new Date(message.created_at).toDateString() !== 
                new Date(messages[index - 1].created_at).toDateString();
              
              return (
                <div key={message.id}>
                  {isFirstMessage && (
                    <div className="flex justify-center my-4">
                      <span className="text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded-full">
                        {new Date(message.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  )}
                  
                  {message.lesson_id && message.lesson_title && (
                    <div className="flex justify-center my-2">
                      <div className="text-xs bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-full">
                        <span>Lesson: {message.lesson_title}</span>
                      </div>
                    </div>
                  )}
                  
                  <div className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}>
                    <div className={`flex ${isOwnMessage ? 'flex-row-reverse' : 'flex-row'} items-start gap-2 max-w-[80%]`}>
                      <UserAvatar 
                        username={message.sender.username}
                        avatarUrl={message.sender.avatar_url}
                        size="sm"
                      />
                      <div>
                        <div className={`flex items-baseline ${isOwnMessage ? 'justify-end' : 'justify-start'} mb-1 gap-4`}>
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {message.sender.username}
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {formatMessageTime(message.created_at)}
                          </span>
                        </div>
                        <div className={`rounded-lg p-3 ${
                          isOwnMessage 
                            ? 'bg-blue-500 text-white' 
                            : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                        }`}>
                          {message.image_url && (
                            <div 
                              className={`mb-2 rounded-lg overflow-hidden cursor-pointer ${
                                isImageExpanded ? 'max-w-full' : 'max-w-[250px] max-h-[150px]'
                              }`}
                              onClick={() => toggleImageExpand(message.id)}
                            >
                              <img 
                                src={message.image_url} 
                                alt="Shared image" 
                                className={`rounded-lg ${isImageExpanded ? 'w-full' : 'max-h-[150px] object-cover'}`}
                                onClick={(e) => handleImageClick(message.image_url!, e)}
                              />
                            </div>
                          )}
                          {message.content && message.content.trim() !== ' ' && (
                            <p className="break-words">{message.content}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEnd} />
          
          {debugInfo && (
            <div className="mt-4 p-2 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-xs rounded">
              <p className="font-bold">Debug Info:</p>
              <p>{debugInfo}</p>
            </div>
          )}
        </div>

        {/* Full-screen image preview */}
        {previewImage && (
          <div 
            className="fixed inset-0 bg-black/80 flex items-center justify-center z-50"
            onClick={() => setPreviewImage(null)}
          >
            <div className="relative max-w-4xl max-h-[90vh] p-2">
              <button 
                className="absolute top-4 right-4 bg-black/50 text-white p-2 rounded-full hover:bg-black/70"
                onClick={() => setPreviewImage(null)}
              >
                <span className="text-xl">×</span>
              </button>
              <img 
                src={previewImage} 
                alt="Preview" 
                className="max-w-full max-h-[90vh] object-contain"
              />
            </div>
          </div>
        )}
      </>
    );
  }
);

MessageList.displayName = 'MessageList';