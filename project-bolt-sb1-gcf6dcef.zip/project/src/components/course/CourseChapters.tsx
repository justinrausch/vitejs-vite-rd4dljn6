import React, { useState } from 'react';
import { CheckCircle, BookmarkIcon, Loader, Plus, Video, Trash2 } from 'lucide-react';
import { Chapter } from '../../types/course';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import { DeleteConfirmationModal } from './DeleteConfirmationModal';

interface CourseChaptersProps {
  chapters: Chapter[];
  completedLessons: string[];
  bookmarkedLessons: string[];
  bookmarkLoading?: Record<string, boolean>;
  lessonProgress?: Record<string, number>;
  requiredWatchPercentage?: number;
  onLessonClick: (lessonId: string) => void;
  onToggleBookmark: (lessonId: string) => void;
  instructorId?: string;
  courseId?: string;
}

interface NewLesson {
  chapterId: string;
  title: string;
}

interface LessonToDelete {
  id: string;
  title: string;
}

interface ChapterToDelete {
  id: string;
  title: string;
}

export function CourseChapters({ 
  chapters, 
  completedLessons, 
  bookmarkedLessons, 
  bookmarkLoading = {},
  lessonProgress = {},
  requiredWatchPercentage = 70,
  onLessonClick, 
  onToggleBookmark,
  instructorId,
  courseId
}: CourseChaptersProps) {
  const { user } = useAuth();
  const [isAddingChapter, setIsAddingChapter] = useState(false);
  const [newChapterTitle, setNewChapterTitle] = useState('');
  const [addingChapterLoading, setAddingChapterLoading] = useState(false);
  const [addingLesson, setAddingLesson] = useState<NewLesson | null>(null);
  const [addingLessonLoading, setAddingLessonLoading] = useState(false);
  const [deletingLessons, setDeletingLessons] = useState<Record<string, boolean>>({});
  const [lessonToDelete, setLessonToDelete] = useState<LessonToDelete | null>(null);
  const [chapterToDelete, setChapterToDelete] = useState<ChapterToDelete | null>(null);
  const [deletingChapter, setDeletingChapter] = useState(false);
  
  const isInstructor = user?.id === instructorId;

  const handleAddChapter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseId || !newChapterTitle.trim() || addingChapterLoading) return;

    try {
      setAddingChapterLoading(true);
      
      // Calculate the next position
      const nextPosition = chapters.length + 1;
      
      // Insert the new chapter
      const { data, error } = await supabase
        .from('course_chapters')
        .insert({
          course_id: courseId,
          title: newChapterTitle.trim(),
          position: nextPosition
        })
        .select()
        .single();

      if (error) throw error;

      // Reset form
      setNewChapterTitle('');
      setIsAddingChapter(false);
      
      // Reload the page to show the new chapter
      window.location.reload();
      
    } catch (err) {
      console.error('Error adding chapter:', err);
      alert('Failed to add chapter. Please try again.');
    } finally {
      setAddingChapterLoading(false);
    }
  };

  const handleAddLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addingLesson || !addingLesson.title.trim() || addingLessonLoading || !courseId) return;

    try {
      setAddingLessonLoading(true);

      // Get the chapter
      const chapter = chapters.find(c => c.id === addingLesson.chapterId);
      if (!chapter) throw new Error('Chapter not found');

      // Calculate the next position
      const nextPosition = chapter.lessons.length + 1;

      // Insert the new lesson
      const { data, error } = await supabase
        .from('course_lessons')
        .insert({
          chapter_id: addingLesson.chapterId,
          course_id: courseId,
          title: addingLesson.title.trim(),
          position: nextPosition
        })
        .select()
        .single();

      if (error) throw error;

      // Reset form
      setAddingLesson(null);
      
      // Reload the page to show the new lesson
      window.location.reload();

    } catch (err) {
      console.error('Error adding lesson:', err);
      alert('Failed to add lesson. Please try again.');
    } finally {
      setAddingLessonLoading(false);
    }
  };

  const handleDeleteLesson = async () => {
    if (!isInstructor || !lessonToDelete) return;

    try {
      setDeletingLessons(prev => ({ ...prev, [lessonToDelete.id]: true }));

      const { error } = await supabase
        .from('course_lessons')
        .delete()
        .eq('id', lessonToDelete.id);

      if (error) throw error;

      // Reload the page to update the UI
      window.location.reload();
    } catch (err) {
      console.error('Error deleting lesson:', err);
      alert('Failed to delete lesson. Please try again.');
    } finally {
      setDeletingLessons(prev => ({ ...prev, [lessonToDelete.id]: false }));
      setLessonToDelete(null);
    }
  };

  const handleDeleteChapter = async () => {
    if (!isInstructor || !chapterToDelete) return;

    try {
      setDeletingChapter(true);

      const { error } = await supabase
        .from('course_chapters')
        .delete()
        .eq('id', chapterToDelete.id);

      if (error) throw error;

      // Reload the page to update the UI
      window.location.reload();
    } catch (err) {
      console.error('Error deleting chapter:', err);
      alert('Failed to delete chapter. Please try again.');
    } finally {
      setDeletingChapter(false);
      setChapterToDelete(null);
    }
  };

  return (
    <div className="space-y-4 p-4">
      {chapters.map((chapter) => {
        const completedCount = chapter.lessons.filter(lesson => 
          completedLessons.includes(lesson.id)
        ).length;
        const progress = (completedCount / chapter.lessons.length) * 100;

        return (
          <div key={chapter.id} className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-sm border border-[#e4e4e4] dark:border-gray-700">
            <div className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-gray-900 dark:text-white">{chapter.title}</h3>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {chapter.lessons.length} lessons
                  </span>
                  {isInstructor && (
                    <button
                      onClick={() => setChapterToDelete({ id: chapter.id, title: chapter.title })}
                      className="p-1 text-gray-400 dark:text-gray-500 hover:text-red-500 dark:hover:text-red-400"
                    >
                      <Trash2 size={16} />
                    </button>
                  )}
                </div>
              </div>
              <div className="relative h-1 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="absolute left-0 top-0 h-full bg-blue-500 rounded-full"
                  style={{ width: `${progress}%` }}
                />
              </div>
              {progress > 0 && (
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  {Math.round(progress)}% complete - keep it up!
                </p>
              )}
            </div>
            <div className="border-t border-gray-200 dark:border-gray-700">
              {chapter.lessons.map((lesson) => {
                const isCompleted = completedLessons.includes(lesson.id);
                const isBookmarked = bookmarkedLessons.includes(lesson.id);
                const isLoading = bookmarkLoading[lesson.id] || false;
                const isDeleting = deletingLessons[lesson.id] || false;
                const videoProgress = lessonProgress[lesson.id] || 0;
                const canComplete = videoProgress >= requiredWatchPercentage;
                
                return (
                  <div
                    key={lesson.id}
                    className="flex items-center justify-between p-4 hover:bg-gray-50 dark:hover:bg-gray-750"
                  >
                    <button
                      onClick={() => onLessonClick(lesson.id)}
                      className="flex items-center flex-1 text-left"
                    >
                      <div className="flex items-center">
                        {isCompleted ? (
                          <CheckCircle className="text-green-500 dark:text-green-400 w-5 h-5 mr-3" />
                        ) : (
                          <div className="relative w-5 h-5 mr-3">
                            <div className="w-5 h-5 border-2 border-gray-300 dark:border-gray-600 rounded-full" />
                            {videoProgress > 0 && (
                              <div 
                                className={`absolute inset-0.5 rounded-full ${
                                  canComplete ? 'bg-green-500/30 dark:bg-green-500/50' : 'bg-blue-500/30 dark:bg-blue-500/50'
                                }`}
                              />
                            )}
                          </div>
                        )}
                        <div>
                          <span className={isCompleted ? 'text-green-700 dark:text-green-400' : 'text-gray-700 dark:text-gray-300'}>
                            {lesson.title}
                          </span>
                          {!isCompleted && videoProgress > 0 && (
                            <div className="flex items-center mt-1">
                              <div className="w-16 h-1 bg-gray-200 dark:bg-gray-700 rounded-full mr-2">
                                <div 
                                  className={`h-full rounded-full ${
                                    canComplete ? 'bg-green-500' : 'bg-blue-500'
                                  }`}
                                  style={{ width: `${videoProgress}%` }}
                                />
                              </div>
                              <span className="text-xs text-gray-500 dark:text-gray-400">
                                {videoProgress}%
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </button>
                    <div className="flex items-center">
                      {!isInstructor && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (!isLoading) {
                              onToggleBookmark(lesson.id);
                            }
                          }}
                          className="p-2"
                          disabled={isLoading}
                        >
                          {isLoading ? (
                            <Loader size={16} className="text-gray-400 dark:text-gray-500 animate-spin" />
                          ) : (
                            <BookmarkIcon
                              className={`w-4 h-4 ${
                                isBookmarked ? 'text-yellow-500 dark:text-yellow-400 fill-current' : 'text-gray-400 dark:text-gray-500'
                              }`}
                            />
                          )}
                        </button>
                      )}
                      {isInstructor && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setLessonToDelete({ id: lesson.id, title: lesson.title });
                          }}
                          className="p-2 text-gray-400 dark:text-gray-500 hover:text-red-500 dark:hover:text-red-400"
                          disabled={isDeleting}
                        >
                          {isDeleting ? (
                            <Loader size={16} className="animate-spin" />
                          ) : (
                            <Trash2 size={16} />
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}

              {/* Add Lesson Button (only visible to course instructor) */}
              {isInstructor && (
                <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                  {addingLesson?.chapterId === chapter.id ? (
                    <form onSubmit={handleAddLesson} className="space-y-4">
                      <input
                        type="text"
                        value={addingLesson.title}
                        onChange={(e) => setAddingLesson({ ...addingLesson, title: e.target.value })}
                        placeholder="Enter lesson title..."
                        className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border-none rounded-lg focus:ring-2 focus:ring-blue-500 dark:text-white"
                        autoFocus
                      />
                      
                      <div className="flex justify-end space-x-3">
                        <button
                          type="button"
                          onClick={() => setAddingLesson(null)}
                          className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          disabled={!addingLesson.title.trim() || addingLessonLoading}
                          className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 flex items-center"
                        >
                          {addingLessonLoading ? (
                            <>
                              <Loader size={16} className="animate-spin mr-2" />
                              Adding...
                            </>
                          ) : (
                            <>
                              <Video size={16} className="mr-2" />
                              Add Lesson
                            </>
                          )}
                        </button>
                      </div>
                    </form>
                  ) : (
                    <button
                      onClick={() => setAddingLesson({ chapterId: chapter.id, title: ''})}
                      className="w-full py-2 bg-gray-50 dark:bg-gray-750 text-blue-500 dark:text-blue-400 rounded-lg flex items-center justify-center font-medium hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    >
                      <Plus size={16} className="mr-2" />
                      Add Lesson
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        );
      })}

      {/* Add Chapter Button and Form (only visible to course instructor) */}
      {isInstructor && (
        <div className="mt-6">
          {isAddingChapter ? (
            <form onSubmit={handleAddChapter} className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-[#e4e4e4] dark:border-gray-700">
              <input
                type="text"
                value={newChapterTitle}
                onChange={(e) => setNewChapterTitle(e.target.value)}
                placeholder="Enter chapter title..."
                className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border-none rounded-lg focus:ring-2 focus:ring-blue-500 dark:text-white mb-4"
                autoFocus
              />
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsAddingChapter(false)}
                  className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newChapterTitle.trim() || addingChapterLoading}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 flex items-center"
                >
                  {addingChapterLoading ? (
                    <>
                      <Loader size={16} className="animate-spin mr-2" />
                      Adding...
                    </>
                  ) : (
                    'Add Chapter'
                  )}
                </button>
              </div>
            </form>
          ) : (
            <button
              onClick={() => setIsAddingChapter(true)}
              className="w-full py-3 bg-gray-50 dark:bg-gray-800 text-blue-500 dark:text-blue-400 rounded-xl flex items-center justify-center font-medium hover:bg-gray-100 dark:hover:bg-gray-750 transition-colors border border-[#e4e4e4] dark:border-gray-700"
            >
              <Plus size={20} className="mr-2" />
              Add New Chapter
            </button>
          )}
        </div>
      )}

      {/* Delete Lesson Confirmation Modal */}
      <DeleteConfirmationModal
        isOpen={!!lessonToDelete}
        title="Delete Lesson"
        message={`Are you sure you want to delete "${lessonToDelete?.title}"? This action cannot be undone.`}
        onConfirm={handleDeleteLesson}
        onCancel={() => setLessonToDelete(null)}
        isDeleting={lessonToDelete ? deletingLessons[lessonToDelete.id] : false}
      />

      {/* Delete Chapter Confirmation Modal */}
      <DeleteConfirmationModal
        isOpen={!!chapterToDelete}
        title="Delete Chapter"
        message={`Are you sure you want to delete "${chapterToDelete?.title}"? This will also delete all lessons in this chapter. This action cannot be undone.`}
        onConfirm={handleDeleteChapter}
        onCancel={() => setChapterToDelete(null)}
        isDeleting={deletingChapter}
      />
    </div>
  );
}