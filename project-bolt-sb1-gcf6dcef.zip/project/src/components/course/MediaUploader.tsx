import React, { useState, useRef, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import { Loader, Upload, Image as ImageIcon, Video, X, Plus, Move } from 'lucide-react';
import { DragDropContext, Droppable, Draggable, DropResult } from 'react-beautiful-dnd';
import { v4 as uuidv4 } from 'uuid';

interface MediaItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail_url?: string;
  file?: File;
  uploading?: boolean;
  position: number;
}

interface MediaUploaderProps {
  courseId: string;
  initialMedia?: MediaItem[];
  onMediaChange: (media: MediaItem[]) => void;
  maxItems?: number;
}

export function MediaUploader({ 
  courseId, 
  initialMedia = [], 
  onMediaChange,
  maxItems = 6
}: MediaUploaderProps) {
  const [media, setMedia] = useState<MediaItem[]>(initialMedia || []);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initialize with initialMedia when it changes
  React.useEffect(() => {
    if (initialMedia && initialMedia.length > 0) {
      console.log("Initializing media uploader with:", initialMedia);
      setMedia(initialMedia);
    }
  }, [initialMedia]);

  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    // Check if adding these files would exceed the max
    if (media.length + files.length > maxItems) {
      setError(`You can only add up to ${maxItems} media items`);
      return;
    }

    setUploading(true);
    setError(null);

    const newMedia: MediaItem[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isVideo = file.type.startsWith('video/');
      const isImage = file.type.startsWith('image/');
      
      if (!isVideo && !isImage) {
        setError('Only image and video files are supported');
        continue;
      }
      
      // Create a stable unique ID for the item
      const tempId = `temp-${Date.now()}-${uuidv4()}`;
      const tempUrl = URL.createObjectURL(file);
      
      // Add to media array with temporary values
      newMedia.push({
        id: tempId,
        type: isVideo ? 'video' : 'image',
        url: tempUrl,
        file,
        uploading: true,
        position: media.length + i
      });
    }
    
    // Update state with new media items
    const updatedMedia = [...media, ...newMedia];
    setMedia(updatedMedia);
    onMediaChange(updatedMedia);
    
    // Upload each file
    for (const item of newMedia) {
      try {
        // Create a unique file path
        const fileExt = item.file!.name.split('.').pop();
        const fileName = `${Date.now()}-${uuidv4()}.${fileExt}`;
        const filePath = `courses/${courseId}/media/${fileName}`;
        
        // Upload the file
        const { data, error: uploadError } = await supabase.storage
          .from('public')
          .upload(filePath, item.file!, {
            cacheControl: '3600',
            upsert: false
          });
        
        if (uploadError) throw uploadError;
        
        // Get the public URL
        const { data: urlData } = supabase.storage
          .from('public')
          .getPublicUrl(filePath);
        
        // Generate thumbnail for videos
        let thumbnailUrl = undefined;
        if (item.type === 'video') {
          thumbnailUrl = 'https://via.placeholder.com/640x360?text=Video+Thumbnail';
        }
        
        // Update the media item with the real URL
        setMedia(prev => {
          const updated = prev.map(mediaItem => 
            mediaItem.id === item.id 
              ? { 
                  ...mediaItem, 
                  id: data!.path, // Use the storage path as the ID
                  url: urlData.publicUrl,
                  thumbnail_url: thumbnailUrl,
                  uploading: false,
                  file: undefined
                } 
              : mediaItem
          );
          onMediaChange(updated);
          return updated;
        });
      } catch (err) {
        console.error('Error uploading file:', err);
        
        // Mark the item as failed
        setMedia(prev => {
          const updated = prev.map(mediaItem => 
            mediaItem.id === item.id 
              ? { ...mediaItem, uploading: false } 
              : mediaItem
          );
          onMediaChange(updated);
          return updated;
        });
        
        setError('Failed to upload one or more files');
      }
    }
    
    setUploading(false);
    
    // Clear the file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, [media, maxItems, courseId, onMediaChange]);

  const handleRemoveMedia = useCallback((id: string) => {
    setMedia(prev => {
      const updated = prev.filter(item => item.id !== id)
        .map((item, index) => ({
          ...item,
          position: index
        }));
      onMediaChange(updated);
      return updated;
    });
  }, [onMediaChange]);

  const handleDragEnd = useCallback((result: DropResult) => {
    if (!result.destination) return;
    
    setMedia(prev => {
      const items = Array.from(prev);
      const [reorderedItem] = items.splice(result.source.index, 1);
      items.splice(result.destination!.index, 0, reorderedItem);
      
      // Update positions
      const updated = items.map((item, index) => ({
        ...item,
        position: index
      }));
      
      onMediaChange(updated);
      return updated;
    });
  }, [onMediaChange]);

  return (
    <div className="space-y-4">
      {error && (
        <div className="p-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-sm rounded-lg">
          {error}
        </div>
      )}
      
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="media-list" direction="horizontal">
          {(provided) => (
            <div 
              ref={provided.innerRef}
              {...provided.droppableProps}
              className="flex flex-wrap gap-4"
            >
              {media.map((item, index) => (
                <Draggable 
                  key={item.id} 
                  draggableId={item.id} 
                  index={index}
                  isDragDisabled={item.uploading}
                >
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className={`relative w-24 h-24 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 group ${
                        snapshot.isDragging ? 'shadow-lg' : ''
                      }`}
                    >
                      {item.type === 'image' ? (
                        <img 
                          src={item.url} 
                          alt="Course media" 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                          <Video className="text-white" size={24} />
                        </div>
                      )}
                      
                      {item.uploading && (
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                          <Loader className="text-white animate-spin" size={24} />
                        </div>
                      )}
                      
                      <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => handleRemoveMedia(item.id)}
                          className="bg-red-500 text-white rounded-full p-1"
                          title="Remove"
                          disabled={item.uploading}
                        >
                          <X size={14} />
                        </button>
                      </div>
                      
                      <div 
                        {...provided.dragHandleProps}
                        className="absolute bottom-1 left-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <div className="bg-gray-800/70 text-white rounded-full p-1" title="Drag to reorder">
                          <Move size={14} />
                        </div>
                      </div>
                      
                      {index === 0 && (
                        <div className="absolute bottom-1 right-1 bg-blue-500 text-white text-xs px-1 py-0.5 rounded">
                          Main
                        </div>
                      )}
                    </div>
                  )}
                </Draggable>
              ))}
              
              {media.length < maxItems && (
                <div className="w-24 h-24 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-700 flex flex-col items-center justify-center">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    accept="image/*,video/*"
                    className="hidden"
                    multiple
                  />
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                    className="flex flex-col items-center justify-center w-full h-full text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                  >
                    <Plus size={20} />
                    <span className="text-xs mt-1">Add</span>
                  </button>
                </div>
              )}
              
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
      
      <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
        <div>
          {media.length} of {maxItems} media items
        </div>
        <div className="flex items-center gap-2">
          <ImageIcon size={16} className="text-gray-400" />
          <span>Images</span>
          <Video size={16} className="text-gray-400 ml-2" />
          <span>Videos</span>
        </div>
      </div>
    </div>
  );
}