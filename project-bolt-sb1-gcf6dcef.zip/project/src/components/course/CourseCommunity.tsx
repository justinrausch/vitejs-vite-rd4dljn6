import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Users } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import { ChannelSelector } from './community/ChannelSelector';
import { MessageList } from './community/MessageList';
import { MessageInput } from './community/MessageInput';
import { MembersSidebar } from './community/MembersSidebar';
import { ChannelModal } from './community/ChannelModal';
import { DeleteChannelModal } from './community/DeleteChannelModal';
import { Channel, ChatMessage } from './community/types';

export function CourseCommunity({ courseId, onUserClick }: { courseId: string, onUserClick: (username: string) => void }) {
  const { user, userProfile } = useAuth();
  const navigate = useNavigate();
  const [selectedChannelId, setSelectedChannelId] = useState<string>('');
  const [channels, setChannels] = useState<Channel[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [sendingMessage, setSendingMessage] = useState(false);
  const [subscription, setSubscription] = useState<ReturnType<typeof supabase.channel> | null>(null);
  const [debugInfo, setDebugInfo] = useState<string | null>(null);
  const [loadingMoreMessages, setLoadingMoreMessages] = useState(false);
  const [hasMoreMessages, setHasMoreMessages] = useState(true);
  const [oldestMessageTimestamp, setOldestMessageTimestamp] = useState<string | null>(null);
  const [processedMessageIds] = useState<Set<string>>(new Set());
  const [deletingMessages, setDeletingMessages] = useState<Record<string, boolean>>({});
  const [members, setMembers] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loadingMembers, setLoadingMembers] = useState(true);
  const [showChannelModal, setShowChannelModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [editingChannel, setEditingChannel] = useState<Channel | null>(null);
  const [channelToDelete, setChannelToDelete] = useState<Channel | null>(null);
  const [isInstructor, setIsInstructor] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [replyTo, setReplyTo] = useState<{
    id: string;
    username: string;
    content: string;
  } | null>(null);
  const [messageCache, setMessageCache] = useState<Record<string, {
    messages: ChatMessage[];
    hasMore: boolean;
    oldestTimestamp: string | null;
  }>>({});
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const channelsContainerRef = useRef<HTMLDivElement>(null);

  // Fetch members
  useEffect(() => {
    const fetchMembers = async () => {
      try {
        setLoadingMembers(true);
        const { data: enrollments, error: enrollmentsError } = await supabase
          .from('enrollments')
          .select(`
            user_id,
            profiles!inner (
              id,
              username,
              avatar_url,
              is_coach,
              email
            )
          `)
          .eq('course_id', courseId);

        if (enrollmentsError) throw enrollmentsError;

        const membersList = enrollments.map(enrollment => ({
          id: enrollment.profiles.id,
          username: enrollment.profiles.username,
          avatar_url: enrollment.profiles.avatar_url,
          is_coach: enrollment.profiles.is_coach,
          email: enrollment.profiles.email
        }));

        setMembers(membersList);
      } catch (err) {
        console.error('Error fetching members:', err);
        setError('Failed to load members');
      } finally {
        setLoadingMembers(false);
      }
    };

    fetchMembers();
  }, [courseId]);

  // Check instructor status and fetch channels
  useEffect(() => {
    const checkInstructor = async () => {
      if (!user) return;
      try {
        const { data: course, error } = await supabase
          .from('courses')
          .select('instructor_id')
          .eq('id', courseId)
          .single();

        if (error) throw error;
        setIsInstructor(course.instructor_id === user.id);
      } catch (err) {
        console.error('Error checking instructor status:', err);
      }
    };

    const fetchChannels = async () => {
      try {
        const { data, error } = await supabase
          .from('chat_channels')
          .select('*')
          .eq('course_id', courseId)
          .order('name');

        if (error) throw error;
        setChannels(data);
        
        if (data.length > 0 && !selectedChannelId) {
          setSelectedChannelId(data[0].id);
        }
      } catch (err) {
        console.error('Error fetching channels:', err);
      }
    };

    checkInstructor();
    fetchChannels();
  }, [courseId, user]);

  // Handle channel selection and message loading
  useEffect(() => {
    if (selectedChannelId) {
      // If we have cached messages for this channel, use them
      if (messageCache[selectedChannelId]) {
        const cachedData = messageCache[selectedChannelId];
        setMessages(cachedData.messages);
        setHasMoreMessages(cachedData.hasMore);
        setOldestMessageTimestamp(cachedData.oldestTimestamp);
      } else {
        // Otherwise fetch new messages
        setMessages([]);
        setOldestMessageTimestamp(null);
        setHasMoreMessages(true);
        fetchMessages();
      }
      
      setupRealtimeSubscription();
    }

    return () => {
      if (subscription) {
        subscription.unsubscribe();
      }
    };
  }, [selectedChannelId]);

  const setupRealtimeSubscription = () => {
    if (!selectedChannelId) return;

    const newSubscription = supabase.channel(`chat-${selectedChannelId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `channel_id=eq.${selectedChannelId}`
        },
        async (payload) => {
          if (processedMessageIds.has(payload.new.id)) return;

          const { data: userData } = await supabase
            .from('profiles')
            .select('username, avatar_url, is_coach, email')
            .eq('id', payload.new.user_id)
            .single();

          if (userData) {
            const newMessage = {
              id: payload.new.id,
              content: payload.new.content,
              created_at: payload.new.created_at,
              user_id: payload.new.user_id,
              image_url: payload.new.image_url,
              user: userData,
              reactions: []
            };

            setMessages(prev => [...prev, newMessage]);
            processedMessageIds.add(payload.new.id);
            messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

            // Update cache
            setMessageCache(prev => ({
              ...prev,
              [selectedChannelId]: {
                ...prev[selectedChannelId],
                messages: [...(prev[selectedChannelId]?.messages || []), newMessage]
              }
            }));
          }
        }
      )
      .subscribe();

    setSubscription(newSubscription);
  };

  const fetchMessages = async () => {
    if (!selectedChannelId) return;
    
    try {
      setLoadingMoreMessages(true);

      let query = supabase
        .from('chat_messages')
        .select(`
          id,
          content,
          created_at,
          user_id,
          image_url,
          profiles:user_id (
            username,
            avatar_url,
            is_coach,
            email
          ),
          message_reactions (
            emoji,
            user_id
          )
        `)
        .eq('channel_id', selectedChannelId)
        .order('created_at', { ascending: false });

      if (oldestMessageTimestamp) {
        query = query.lt('created_at', oldestMessageTimestamp);
      }

      const { data, error } = await query.limit(15);

      if (error) throw error;
      
      if (data.length < 15) {
        setHasMoreMessages(false);
      }
      
      const formattedMessages = data.map(msg => {
        const reactions = msg.message_reactions.reduce((acc: any[], reaction: any) => {
          const existing = acc.find(r => r.emoji === reaction.emoji);
          if (existing) {
            existing.count++;
            if (reaction.user_id === user?.id) existing.reacted = true;
          } else {
            acc.push({
              emoji: reaction.emoji,
              count: 1,
              reacted: reaction.user_id === user?.id
            });
          }
          return acc;
        }, []);

        return {
          id: msg.id,
          content: msg.content,
          created_at: msg.created_at,
          user_id: msg.user_id,
          image_url: msg.image_url,
          user: {
            username: msg.profiles.username,
            avatar_url: msg.profiles.avatar_url,
            is_coach: msg.profiles.is_coach,
            email: msg.profiles.email
          },
          reactions
        };
      }).reverse();

      setMessages(prev => 
        oldestMessageTimestamp ? [...formattedMessages, ...prev] : formattedMessages
      );
      
      if (data.length > 0) {
        setOldestMessageTimestamp(data[data.length - 1].created_at);
      }

      data.forEach(msg => processedMessageIds.add(msg.id));

      // Update cache
      setMessageCache(prev => ({
        ...prev,
        [selectedChannelId]: {
          messages: oldestMessageTimestamp 
            ? [...formattedMessages, ...(prev[selectedChannelId]?.messages || [])]
            : formattedMessages,
          hasMore: data.length === 15,
          oldestTimestamp: data.length > 0 ? data[data.length - 1].created_at : null
        }
      }));

      if (!oldestMessageTimestamp) {
        messagesEndRef.current?.scrollIntoView();
      }
    } catch (err) {
      console.error('Error fetching messages:', err);
      setError('Failed to load messages');
    } finally {
      setLoadingMoreMessages(false);
    }
  };

  const handleLoadMoreMessages = async () => {
    if (loadingMoreMessages || !hasMoreMessages) return;
    await fetchMessages();
  };

  const handleSubmit = async (e: React.FormEvent, imageUrl?: string) => {
    e.preventDefault();
    if ((!newMessage.trim() && !imageUrl) || !selectedChannelId || !user) return;

    try {
      setSendingMessage(true);
      
      const { error } = await supabase
        .from('chat_messages')
        .insert({
          channel_id: selectedChannelId,
          content: newMessage.trim(),
          user_id: user.id,
          parent_id: replyTo?.id,
          image_url: imageUrl
        });

      if (error) throw error;
      
      setNewMessage('');
      setReplyTo(null);
    } catch (err) {
      console.error('Error sending message:', err);
      setError('Failed to send message');
    } finally {
      setSendingMessage(false);
    }
  };

  const handleAddReaction = async (messageId: string, emoji: string) => {
    if (!user) return;
    
    try {
      const { error } = await supabase
        .from('message_reactions')
        .insert({
          message_id: messageId,
          user_id: user.id,
          emoji
        });

      if (error) throw error;

      // Update local state
      setMessages(prev => prev.map(msg => {
        if (msg.id === messageId) {
          const existingReaction = msg.reactions.find((r: any) => r.emoji === emoji);
          if (existingReaction) {
            existingReaction.count++;
            existingReaction.reacted = true;
            return { ...msg, reactions: [...msg.reactions] };
          } else {
            return {
              ...msg,
              reactions: [...msg.reactions, { emoji, count: 1, reacted: true }]
            };
          }
        }
        return msg;
      }));

      // Update cache
      setMessageCache(prev => ({
        ...prev,
        [selectedChannelId]: {
          ...prev[selectedChannelId],
          messages: prev[selectedChannelId].messages.map(msg => {
            if (msg.id === messageId) {
              const existingReaction = msg.reactions.find((r: any) => r.emoji === emoji);
              if (existingReaction) {
                existingReaction.count++;
                existingReaction.reacted = true;
                return { ...msg, reactions: [...msg.reactions] };
              } else {
                return {
                  ...msg,
                  reactions: [...msg.reactions, { emoji, count: 1, reacted: true }]
                };
              }
            }
            return msg;
          })
        }
      }));
    } catch (err) {
      console.error('Error adding reaction:', err);
    }
  };

  const handleRemoveReaction = async (messageId: string, emoji: string) => {
    if (!user) return;
    
    try {
      const { error } = await supabase
        .from('message_reactions')
        .delete()
        .eq('message_id', messageId)
        .eq('user_id', user.id)
        .eq('emoji', emoji);

      if (error) throw error;

      // Update local state
      setMessages(prev => prev.map(msg => {
        if (msg.id === messageId) {
          return {
            ...msg,
            reactions: msg.reactions.map((r: any) => {
              if (r.emoji === emoji) {
                return {
                  ...r,
                  count: r.count - 1,
                  reacted: false
                };
              }
              return r;
            }).filter((r: any) => r.count > 0)
          };
        }
        return msg;
      }));

      // Update cache
      setMessageCache(prev => ({
        ...prev,
        [selectedChannelId]: {
          ...prev[selectedChannelId],
          messages: prev[selectedChannelId].messages.map(msg => {
            if (msg.id === messageId) {
              return {
                ...msg,
                reactions: msg.reactions.map((r: any) => {
                  if (r.emoji === emoji) {
                    return {
                      ...r,
                      count: r.count - 1,
                      reacted: false
                    };
                  }
                  return r;
                }).filter((r: any) => r.count > 0)
              };
            }
            return msg;
          })
        }
      }));
    } catch (err) {
      console.error('Error removing reaction:', err);
    }
  };

  const handleCreateChannel = async (name: string, description: string, isPrivate: boolean) => {
    try {
      const { data, error } = await supabase
        .from('chat_channels')
        .insert({
          course_id: courseId,
          name,
          description,
          is_private: isPrivate
        })
        .select()
        .single();

      if (error) throw error;
      setChannels(prev => [...prev, data]);
      setSelectedChannelId(data.id);
    } catch (err) {
      console.error('Error creating channel:', err);
      setError('Failed to create channel');
    }
  };

  const handleUpdateChannel = async (name: string, description: string, isPrivate: boolean) => {
    if (!editingChannel) return;

    try {
      const { error } = await supabase
        .from('chat_channels')
        .update({
          name,
          description,
          is_private: isPrivate
        })
        .eq('id', editingChannel.id);

      if (error) throw error;

      setChannels(prev => prev.map(channel => 
        channel.id === editingChannel.id
          ? { ...channel, name, description, is_private: isPrivate }
          : channel
      ));
    } catch (err) {
      console.error('Error updating channel:', err);
      setError('Failed to update channel');
    }
  };

  const handleDeleteChannel = async () => {
    if (!channelToDelete) return;

    try {
      const { error } = await supabase
        .from('chat_channels')
        .delete()
        .eq('id', channelToDelete.id);

      if (error) throw error;

      setChannels(prev => prev.filter(channel => channel.id !== channelToDelete.id));
      if (selectedChannelId === channelToDelete.id) {
        setSelectedChannelId(channels[0]?.id || '');
      }

      // Clear cache for deleted channel
      setMessageCache(prev => {
        const newCache = { ...prev };
        delete newCache[channelToDelete.id];
        return newCache;
      });
    } catch (err) {
      console.error('Error deleting channel:', err);
      setError('Failed to delete channel');
    } finally {
      setShowDeleteModal(false);
      setChannelToDelete(null);
    }
  };

  const handleDeleteMessage = async (messageId: string) => {
    try {
      setDeletingMessages(prev => ({ ...prev, [messageId]: true }));
      
      const { error } = await supabase
        .from('chat_messages')
        .delete()
        .eq('id', messageId);

      if (error) throw error;
      
      setMessages(prev => prev.filter(msg => msg.id !== messageId));

      // Update cache
      setMessageCache(prev => ({
        ...prev,
        [selectedChannelId]: {
          ...prev[selectedChannelId],
          messages: prev[selectedChannelId].messages.filter(msg => msg.id !== messageId)
        }
      }));
    } catch (err) {
      console.error('Error deleting message:', err);
    } finally {
      setDeletingMessages(prev => ({ ...prev, [messageId]: false }));
    }
  };

  const handleReply = (messageId: string) => {
    const message = messages.find(m => m.id === messageId);
    if (message) {
      setReplyTo({
        id: message.id,
        username: message.user.username,
        content: message.content
      });
    }
  };

  const canDeleteMessage = (message: any) => {
    if (!user) return false;
    return message.user_id === user.id || isInstructor;
  };

  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return 'just now';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes}m ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours}h ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  const isAdmin = (email?: string) => {
    return email === 'admin@example.com';
  };

  const currentChannel = channels.find(c => c.id === selectedChannelId);
  const canSendMessages = !currentChannel?.is_private || isInstructor;

  return (
    <div className="h-full flex">
      <div className="flex-1 flex flex-col bg-white dark:bg-gray-800 rounded-l-xl overflow-hidden">
        <ChannelSelector
          selectedChannel={selectedChannelId}
          onSelectChannel={setSelectedChannelId}
          channels={channels}
          isInstructor={isInstructor}
          onNewChannel={() => {
            setEditingChannel(null);
            setShowChannelModal(true);
          }}
          onEditChannel={(channel) => {
            setEditingChannel(channel);
            setShowChannelModal(true);
          }}
          onDeleteChannel={(channel) => {
            setChannelToDelete(channel);
            setShowDeleteModal(true);
          }}
          ref={channelsContainerRef}
        />

        <MessageList
          messages={messages}
          loadingMoreMessages={loadingMoreMessages}
          hasMoreMessages={hasMoreMessages}
          onLoadMoreMessages={handleLoadMoreMessages}
          onUserClick={onUserClick}
          onDeleteMessage={handleDeleteMessage}
          onAddReaction={handleAddReaction}
          onRemoveReaction={handleRemoveReaction}
          onReply={handleReply}
          canDeleteMessage={canDeleteMessage}
          formatMessageTime={formatMessageTime}
          isAdmin={isAdmin}
          ref={{ messagesContainer: messagesContainerRef, messagesEnd: messagesEndRef }}
          debugInfo={debugInfo}
          deletingMessages={deletingMessages}
          currentUserId={user?.id || ''}
          courseId={courseId}
        />

        <MessageInput
          value={newMessage}
          onChange={setNewMessage}
          onSend={handleSubmit}
          sending={sendingMessage}
          channelName={currentChannel?.name || ''}
          disabled={!canSendMessages}
          replyTo={replyTo}
          onCancelReply={() => setReplyTo(null)}
        />
      </div>

      <MembersSidebar
        members={members}
        loadingMembers={loadingMembers}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onUserClick={onUserClick}
        isAdmin={isAdmin}
      />

      <ChannelModal
        isOpen={showChannelModal}
        onClose={() => {
          setShowChannelModal(false);
          setEditingChannel(null);
        }}
        onSubmit={editingChannel ? handleUpdateChannel : handleCreateChannel}
        initialChannel={editingChannel}
        title={editingChannel ? 'Edit Channel' : 'New Channel'}
      />

      {channelToDelete && (
        <DeleteChannelModal
          isOpen={showDeleteModal}
          onClose={() => {
            setShowDeleteModal(false);
            setChannelToDelete(null);
          }}
          onConfirm={handleDeleteChannel}
          channel={channelToDelete}
        />
      )}
    </div>
  );
}