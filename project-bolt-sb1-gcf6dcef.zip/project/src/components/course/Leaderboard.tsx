import React, { useState, useEffect } from 'react';
import { Trophy } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { UserAvatar } from '../user/UserAvatar';
import { AdminBadge } from '../user/AdminBadge';
import { CoachBadge } from '../user/CoachBadge';
import { VerifiedBadge } from '../user/VerifiedBadge';
import { useAuth } from '../../contexts/AuthContext';

interface LeaderboardUser {
  id: string;
  username: string;
  avatar_url: string | null;
  is_coach: boolean;
  is_verified?: boolean;
  email: string;
  points: number;
  completed_lessons: number;
  level: number;
}

interface LeaderboardProps {
  courseId: string;
  onUserClick: (username: string) => void;
}

export function Leaderboard({ courseId, onUserClick }: LeaderboardProps) {
  const { user } = useAuth();
  const [users, setUsers] = useState<LeaderboardUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchLeaderboard();
  }, [courseId]);

  const fetchLeaderboard = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase
        .from('course_rankings')
        .select(`
          user_id,
          points,
          completed_lessons_count,
          level,
          profiles:user_id (
            username,
            avatar_url,
            is_coach,
            is_verified,
            email
          )
        `)
        .eq('course_id', courseId)
        .order('points', { ascending: false });

      if (error) throw error;

      const formattedUsers = data.map(item => ({
        id: item.user_id,
        username: item.profiles.username,
        avatar_url: item.profiles.avatar_url,
        is_coach: item.profiles.is_coach,
        is_verified: item.profiles.is_verified,
        email: item.profiles.email,
        points: item.points,
        completed_lessons: item.completed_lessons_count,
        level: item.level
      }));

      setUsers(formattedUsers);
    } catch (err) {
      console.error('Error fetching leaderboard:', err);
      setError('Failed to load leaderboard');
    } finally {
      setLoading(false);
    }
  };

  const isAdmin = (email: string) => {
    return email === 'gaspar@mastery.to' || email === 'justin@mastery.to';
  };

  const getRankIcon = (position: number) => {
    switch (position) {
      case 0:
        return <Trophy size={24} className="text-yellow-500" />;
      case 1:
        return <Trophy size={24} className="text-gray-400" />;
      case 2:
        return <Trophy size={24} className="text-amber-700" />;
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8 text-red-500 dark:text-red-400">
        {error}
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-medium text-gray-900 dark:text-white">Ranking</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {users.length} {users.length === 1 ? 'member' : 'members'} enrolled
            </p>
          </div>
          <Trophy className="text-yellow-500" size={24} />
        </div>

        <div className="mb-4 grid grid-cols-12 text-xs font-medium text-gray-500 dark:text-gray-400 px-2">
          <div className="col-span-1">Rank</div>
          <div className="col-span-7">Member</div>
          <div className="col-span-2 text-right">Points</div>
          <div className="col-span-2 text-right">Level</div>
        </div>

        <div className="space-y-2">
          {users.map((member, index) => {
            const isCurrentUser = member.id === user?.id;
            
            return (
              <div 
                key={member.id}
                className={`grid grid-cols-12 items-center p-3 rounded-lg ${
                  isCurrentUser 
                    ? 'bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800' 
                    : 'bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-750'
                }`}
              >
                <div className="col-span-1 flex items-center justify-center">
                  {index < 3 ? (
                    getRankIcon(index)
                  ) : (
                    <span className={`font-medium ${
                      isCurrentUser 
                        ? 'text-blue-600 dark:text-blue-400' 
                        : 'text-gray-500 dark:text-gray-400'
                    }`}>
                      {index + 1}
                    </span>
                  )}
                </div>
                
                <div className="col-span-7 flex items-center">
                  <div 
                    className="cursor-pointer"
                    onClick={() => onUserClick(member.username)}
                  >
                    <UserAvatar 
                      username={member.username}
                      avatarUrl={member.avatar_url}
                      size="sm"
                      className="mr-3"
                    />
                  </div>
                  <div>
                    <div className="flex items-center">
                      <p 
                        className={`font-medium cursor-pointer hover:text-blue-500 dark:hover:text-blue-400 ${
                          isCurrentUser 
                            ? 'text-blue-600 dark:text-blue-400' 
                            : 'text-gray-900 dark:text-white'
                        }`}
                        onClick={() => onUserClick(member.username)}
                      >
                        {member.username}
                        {isCurrentUser && <span className="ml-1 text-xs">(you)</span>}
                      </p>
                      {member.is_verified && <VerifiedBadge className="ml-1.5 -mt-0.5" />}
                      {member.is_coach && <CoachBadge className="ml-1" />}
                      {isAdmin(member.email) && <AdminBadge className="ml-1" />}
                    </div>
                    <p className={`text-xs ${
                      isCurrentUser 
                        ? 'text-blue-500 dark:text-blue-400' 
                        : 'text-gray-500 dark:text-gray-400'
                    }`}>
                      {member.completed_lessons} {member.completed_lessons === 1 ? 'lesson' : 'lessons'} completed
                    </p>
                  </div>
                </div>
                
                <div className="col-span-2 text-right">
                  <p className={`font-medium ${
                    isCurrentUser 
                      ? 'text-blue-600 dark:text-blue-400' 
                      : 'text-gray-900 dark:text-white'
                  }`}>
                    {member.points}
                  </p>
                </div>
                
                <div className="col-span-2 text-right">
                  <p className={`font-medium ${
                    isCurrentUser 
                      ? 'text-blue-600 dark:text-blue-400' 
                      : 'text-gray-900 dark:text-white'
                  }`}>
                    {member.level}
                  </p>
                </div>
              </div>
            );
          })}

          {users.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">No members yet</p>
            </div>
          )}
        </div>
      </div>

      <div className="mt-6 bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
        <h3 className="font-medium mb-4 text-gray-900 dark:text-white">How Points Work</h3>
        <div className="space-y-3 text-sm text-gray-600 dark:text-gray-300">
          <p>• Complete lessons to earn points (100 points per lesson)</p>
          <p>• Every 3 completed lessons increases your level</p>
          <p>• Top performers are featured on the leaderboard</p>
          <p>• Special badges are awarded to the top 3 performers</p>
        </div>
      </div>
    </div>
  );
}