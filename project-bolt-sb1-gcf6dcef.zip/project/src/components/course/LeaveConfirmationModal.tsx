import React from 'react';
import { LogOut, Loader } from 'lucide-react';

interface LeaveConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  isLeaving?: boolean;
}

export function LeaveConfirmationModal({
  isOpen,
  onClose,
  onConfirm,
  isLeaving = false
}: LeaveConfirmationModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md mx-4">
        <div className="flex items-start mb-4">
          <div className="flex-shrink-0">
            <LogOut className="h-6 w-6 text-red-500" />
          </div>
          <div className="ml-3">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">
              Leave Course
            </h3>
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              Are you sure you want to leave this course? You can always rejoin later, but your progress will be reset.
            </p>
          </div>
        </div>
        <div className="mt-6 flex justify-end gap-3">
          <button
            onClick={onClose}
            disabled={isLeaving}
            className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={isLeaving}
            className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 disabled:opacity-50 flex items-center"
          >
            {isLeaving ? (
              <>
                <Loader size={16} className="animate-spin mr-2" />
                Leaving...
              </>
            ) : (
              'Leave Course'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}