import React, { useState, useEffect } from 'react';
import { Star, Edit2 } from 'lucide-react';
import { Course } from '../../types/course';
import { UserAvatar } from '../user/UserAvatar';
import { VerifiedBadge } from '../user/VerifiedBadge';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { CourseReviewForm } from './CourseReviewForm';
import { formatTimeAgo } from '../../lib/utils/date';

interface CourseOverviewProps {
  course: Course;
  onUserClick: (username: string) => void;
}

interface Review {
  id: string;
  rating: number;
  content: string;
  created_at: string;
  updated_at: string;
  user: {
    username: string;
    avatar_url: string | null;
    is_verified?: boolean;
  };
}

export function CourseOverview({ course, onUserClick }: CourseOverviewProps) {
  const { user } = useAuth();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [userReview, setUserReview] = useState<Review | null>(null);
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [averageRating, setAverageRating] = useState(0);
  const [totalReviews, setTotalReviews] = useState(0);

  useEffect(() => {
    fetchReviews();
    if (user) {
      checkEnrollment();
    }
  }, [course.id, user]);

  const checkEnrollment = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('enrollments')
        .select('id')
        .eq('user_id', user.id)
        .eq('course_id', course.id)
        .maybeSingle();

      if (error) throw error;
      setIsEnrolled(!!data);
    } catch (err) {
      console.error('Error checking enrollment:', err);
      setIsEnrolled(false);
    }
  };

  const fetchReviews = async () => {
    try {
      setLoading(true);

      const { data: reviewsData, error: reviewsError } = await supabase
        .from('course_reviews')
        .select(`
          id,
          rating,
          content,
          created_at,
          updated_at,
          profiles:user_id (
            username,
            avatar_url,
            is_verified
          )
        `)
        .eq('course_id', course.id)
        .order('created_at', { ascending: false });

      if (reviewsError) throw reviewsError;

      const formattedReviews = reviewsData.map(review => ({
        id: review.id,
        rating: review.rating,
        content: review.content,
        created_at: review.created_at,
        updated_at: review.updated_at,
        user: {
          username: review.profiles.username,
          avatar_url: review.profiles.avatar_url,
          is_verified: review.profiles.is_verified
        }
      }));

      setReviews(formattedReviews);

      // Calculate average rating
      if (formattedReviews.length > 0) {
        const total = formattedReviews.reduce((sum, review) => sum + review.rating, 0);
        setAverageRating(total / formattedReviews.length);
        setTotalReviews(formattedReviews.length);
      }

      // Find user's review if they're logged in
      if (user) {
        const userReview = formattedReviews.find(
          review => review.user.username === user.user_metadata?.username
        );
        if (userReview) {
          setUserReview(userReview);
        }
      }
    } catch (err) {
      console.error('Error fetching reviews:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleReviewSubmitted = () => {
    fetchReviews();
    setShowReviewForm(false);
  };

  // Function to render stars
  const renderStars = (rating: number) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            size={16}
            className={`${
              star <= rating
                ? 'text-yellow-400 fill-current'
                : 'text-gray-300 dark:text-gray-600'
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6 p-4">
      {/* Course Description */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-[#e4e4e4] dark:border-gray-700">
        <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">About This Course</h2>
        <p className="text-gray-600 dark:text-gray-300 whitespace-pre-wrap">{course.description}</p>
        
        {/* Tags */}
        {course.tags && course.tags.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {course.tags.map((tag) => (
              <span 
                key={tag} 
                className="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-full text-sm"
              >
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* About the Coach */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-[#e4e4e4] dark:border-gray-700">
        <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">About the Coach</h2>
        <div className="flex items-start">
          <div 
            className="cursor-pointer"
            onClick={() => onUserClick(course.instructor.username)}
          >
            <UserAvatar 
              username={course.instructor.username}
              avatarUrl={course.instructor.avatar_url}
              size="lg"
            />
          </div>
          <div className="ml-4">
            <div className="flex items-center">
              <h3 
                className="font-medium text-gray-900 dark:text-white cursor-pointer hover:text-blue-500 dark:hover:text-blue-400"
                onClick={() => onUserClick(course.instructor.username)}
              >
                {course.instructor.username}
              </h3>
              {course.instructor.is_verified && (
                <VerifiedBadge className="ml-1.5 -mt-0.5" />
              )}
            </div>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
              {course.instructor.description || 'Professional athlete with over 5 years of experience'}
            </p>
          </div>
        </div>
      </div>

      {/* Course Details */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-[#e4e4e4] dark:border-gray-700">
        <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Course Details</h2>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-gray-600 dark:text-gray-400">Category</span>
            <span className="text-gray-900 dark:text-white font-medium">{course.category || 'General'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600 dark:text-gray-400">Chapters</span>
            <span className="text-gray-900 dark:text-white font-medium">{course.chapters.length}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600 dark:text-gray-400">Lessons</span>
            <span className="text-gray-900 dark:text-white font-medium">
              {course.chapters.reduce((total, chapter) => total + chapter.lessons.length, 0)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600 dark:text-gray-400">Members</span>
            <span className="text-gray-900 dark:text-white font-medium">{course.member_count || 0}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600 dark:text-gray-400">Created</span>
            <span className="text-gray-900 dark:text-white font-medium">
              {new Date(course.created_at).toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-[#e4e4e4] dark:border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-medium text-gray-900 dark:text-white">Reviews</h2>
          <div className="flex items-center">
            <div className="flex items-center mr-2">
              {renderStars(Math.round(averageRating))}
            </div>
            <span className="text-gray-600 dark:text-gray-400 text-sm">
              {averageRating.toFixed(1)} ({totalReviews})
            </span>
          </div>
        </div>

        {/* Write Review Section */}
        {isEnrolled && (
          <div className="mb-6">
            {showReviewForm || userReview ? (
              <div className="bg-gray-50 dark:bg-gray-750 rounded-lg p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-medium text-gray-900 dark:text-white">
                    {userReview ? 'Your Review' : 'Write a Review'}
                  </h3>
                  {userReview && !showReviewForm && (
                    <button 
                      onClick={() => setShowReviewForm(true)}
                      className="text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300"
                    >
                      <Edit2 size={18} />
                    </button>
                  )}
                </div>
                
                {showReviewForm ? (
                  <CourseReviewForm 
                    courseId={course.id} 
                    onReviewSubmitted={handleReviewSubmitted}
                    existingReview={userReview ? {
                      id: userReview.id,
                      rating: userReview.rating,
                      content: userReview.content
                    } : undefined}
                  />
                ) : userReview ? (
                  <div>
                    <div className="flex items-center mb-2">
                      {renderStars(userReview.rating)}
                      <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">
                        {formatTimeAgo(userReview.updated_at || userReview.created_at)}
                      </span>
                    </div>
                    <p className="text-gray-700 dark:text-gray-300">{userReview.content}</p>
                  </div>
                ) : null}
              </div>
            ) : (
              <button
                onClick={() => setShowReviewForm(true)}
                className="w-full py-3 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-lg font-medium hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors"
              >
                Write a Review
              </button>
            )}
          </div>
        )}

        {/* Reviews List */}
        <div className="space-y-6">
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : reviews.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">No reviews yet</p>
              {isEnrolled && !userReview && !showReviewForm && (
                <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
                  Be the first to review this course!
                </p>
              )}
            </div>
          ) : (
            reviews
              // Don't show the user's own review in the list since it's shown above
              .filter(review => !userReview || review.id !== userReview.id)
              .slice(0, 3) // Show only the first 3 reviews
              .map((review) => (
                <div key={review.id} className="border-b border-gray-200 dark:border-gray-700 last:border-0 pb-6 last:pb-0">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <UserAvatar
                        username={review.user.username}
                        avatarUrl={review.user.avatar_url}
                        size="sm"
                      />
                      <div>
                        <div className="flex items-center">
                          <button
                            onClick={() => onUserClick(review.user.username)}
                            className="font-medium text-gray-900 dark:text-white hover:text-blue-500 dark:hover:text-blue-400"
                          >
                            {review.user.username}
                          </button>
                          {review.user.is_verified && (
                            <VerifiedBadge className="ml-1.5 -mt-0.5" />
                          )}
                        </div>
                        <div className="flex items-center mt-1">
                          {renderStars(review.rating)}
                          <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">
                            {formatTimeAgo(review.updated_at || review.created_at)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="mt-3 text-gray-600 dark:text-gray-300 whitespace-pre-wrap">
                    {review.content}
                  </p>
                </div>
              ))
          )}

          {/* Show more reviews button */}
          {reviews.length > 3 && (
            <div className="text-center pt-2">
              <button
                onClick={() => {/* Implement view all reviews functionality */}}
                className="text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300 font-medium"
              >
                View all {reviews.length} reviews
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}