import React, { useRef, useState } from 'react';

type Tab = 'home' | 'skills' | 'community' | 'ranking' | 'coaching' | 'overview';

interface CourseTabsProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

export function CourseTabs({ activeTab, onTabChange }: CourseTabsProps) {
  const tabsRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const handleTabClick = (tab: Tab) => {
    onTabChange(tab);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!tabsRef.current) return;
    setIsDragging(true);
    setStartX(e.pageX - tabsRef.current.offsetLeft);
    setScrollLeft(tabsRef.current.scrollLeft);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !tabsRef.current) return;
    e.preventDefault();
    const x = e.pageX - tabsRef.current.offsetLeft;
    const walk = (x - startX) * 2;
    tabsRef.current.scrollLeft = scrollLeft - walk;
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (!tabsRef.current) return;
    setIsDragging(true);
    setStartX(e.touches[0].pageX - tabsRef.current.offsetLeft);
    setScrollLeft(tabsRef.current.scrollLeft);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || !tabsRef.current) return;
    const x = e.touches[0].pageX - tabsRef.current.offsetLeft;
    const walk = (x - startX) * 2;
    tabsRef.current.scrollLeft = scrollLeft - walk;
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  return (
    <div className="bg-white dark:bg-gray-800 sticky top-16 z-20">
      <div className="max-w-lg mx-auto">
        <div
          ref={tabsRef}
          className="flex border-b border-gray-200 dark:border-gray-700 overflow-x-auto scrollbar-hide touch-pan-x"
          style={{ scrollBehavior: 'smooth' }}
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseUp}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          {(['home', 'skills', 'community', 'ranking', 'coaching', 'overview'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => handleTabClick(tab)}
              className={`flex-none px-6 py-4 text-sm font-medium capitalize whitespace-nowrap ${
                activeTab === tab
                  ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400'
                  : 'text-gray-600 dark:text-gray-400'
              }`}
              style={{ touchAction: 'pan-x' }}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}