import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Star, StarHalf, Filter, ThumbsUp, MessageSquare, Flag } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { UserAvatar } from '../user/UserAvatar';
import { formatTimeAgo } from '../../lib/utils/date';
import { VerifiedBadge } from '../user/VerifiedBadge';

interface Review {
  id: string;
  rating: number;
  content: string;
  created_at: string;
  user: {
    username: string;
    avatar_url: string | null;
    is_verified?: boolean;
  };
}

interface ReviewsModalProps {
  courseId: string;
  isOpen: boolean;
  onClose: () => void;
  onUserClick: (username: string) => void;
}

export function ReviewsModal({ courseId, isOpen, onClose, onUserClick }: ReviewsModalProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'positive' | 'negative'>('all');
  const [averageRating, setAverageRating] = useState(0);
  const [ratingCounts, setRatingCounts] = useState<Record<number, number>>({});
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      fetchReviews();
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen, courseId]);
  
  // Close modal when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
        onClose();
      }
    };
    
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);

  const fetchReviews = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data: reviewsData, error: reviewsError } = await supabase
        .from('course_reviews')
        .select(`
          id,
          rating,
          content,
          created_at,
          profiles:user_id (
            username,
            avatar_url,
            is_verified
          )
        `)
        .eq('course_id', courseId)
        .order('created_at', { ascending: false });

      if (reviewsError) throw reviewsError;

      const formattedReviews = reviewsData.map(review => ({
        id: review.id,
        rating: review.rating,
        content: review.content,
        created_at: review.created_at,
        user: {
          username: review.profiles.username,
          avatar_url: review.profiles.avatar_url,
          is_verified: review.profiles.is_verified
        }
      }));

      setReviews(formattedReviews);

      // Calculate average rating and rating counts
      if (formattedReviews.length > 0) {
        const counts: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
        let total = 0;

        formattedReviews.forEach(review => {
          counts[review.rating] = (counts[review.rating] || 0) + 1;
          total += review.rating;
        });

        setRatingCounts(counts);
        setAverageRating(total / formattedReviews.length);
      }

    } catch (err) {
      console.error('Error fetching reviews:', err);
      setError('Failed to load reviews');
    } finally {
      setLoading(false);
    }
  };

  const filteredReviews = reviews.filter(review => {
    if (filter === 'positive') return review.rating >= 4;
    if (filter === 'negative') return review.rating <= 2;
    return true;
  });

  // Function to render stars with half-star support
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    // Add full stars
    for (let i = 1; i <= fullStars; i++) {
      stars.push(
        <Star 
          key={`full-${i}`} 
          size={16} 
          className="text-yellow-400 fill-current" 
        />
      );
    }
    
    // Add half star if needed
    if (hasHalfStar) {
      stars.push(
        <StarHalf 
          key="half" 
          size={16} 
          className="text-yellow-400 fill-current" 
        />
      );
    }
    
    // Add empty stars
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 1; i <= emptyStars; i++) {
      stars.push(
        <Star 
          key={`empty-${i}`} 
          size={16} 
          className="text-gray-300 dark:text-gray-600" 
        />
      );
    }
    
    return <div className="flex items-center">{stars}</div>;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div 
        ref={modalRef}
        className="bg-white dark:bg-gray-800 rounded-xl w-full max-w-3xl max-h-[90vh] overflow-hidden"
      >
        {/* Header */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Course Reviews</h2>
            <button
              onClick={onClose}
              className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
            >
              <X size={24} />
            </button>
          </div>

          {/* Rating Summary */}
          <div className="mt-4 flex items-center gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-900 dark:text-white">
                {averageRating.toFixed(1)}
              </div>
              <div className="flex items-center justify-center mt-1">
                {renderStars(Math.round(averageRating * 2) / 2)}
              </div>
              <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                {reviews.length} {reviews.length === 1 ? 'review' : 'reviews'}
              </div>
            </div>

            <div className="flex-1">
              {[5, 4, 3, 2, 1].map((rating) => {
                const count = ratingCounts[rating] || 0;
                const percentage = reviews.length ? (count / reviews.length) * 100 : 0;
                
                return (
                  <div key={rating} className="flex items-center gap-2 mb-1">
                    <div className="text-sm text-gray-600 dark:text-gray-400 w-3">
                      {rating}
                    </div>
                    <div className="flex-1 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-yellow-400"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400 w-12">
                      {count}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Filter */}
          <div className="flex items-center gap-2 mt-6">
            <Filter size={16} className="text-gray-400" />
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1 rounded-full text-sm ${
                filter === 'all'
                  ? 'bg-gray-900 text-white dark:bg-gray-700'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('positive')}
              className={`px-3 py-1 rounded-full text-sm ${
                filter === 'positive'
                  ? 'bg-gray-900 text-white dark:bg-gray-700'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              Positive
            </button>
            <button
              onClick={() => setFilter('negative')}
              className={`px-3 py-1 rounded-full text-sm ${
                filter === 'negative'
                  ? 'bg-gray-900 text-white dark:bg-gray-700'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              Critical
            </button>
          </div>
        </div>

        {/* Reviews List */}
        <div className="overflow-y-auto max-h-[calc(90vh-250px)]">
          <div className="p-6 space-y-6">
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : error ? (
              <div className="text-center py-8 text-red-500 dark:text-red-400">
                {error}
              </div>
            ) : filteredReviews.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 dark:text-gray-400">No reviews found</p>
              </div>
            ) : (
              filteredReviews.map((review) => (
                <div key={review.id} className="border-b border-gray-200 dark:border-gray-700 last:border-0 pb-6 last:pb-0">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <UserAvatar
                        username={review.user.username}
                        avatarUrl={review.user.avatar_url}
                        size="sm"
                      />
                      <div>
                        <div className="flex items-center">
                          <button
                            onClick={() => onUserClick(review.user.username)}
                            className="font-medium text-gray-900 dark:text-white hover:text-blue-500 dark:hover:text-blue-400"
                          >
                            {review.user.username}
                          </button>
                          {review.user.is_verified && (
                            <VerifiedBadge className="ml-1.5 -mt-0.5" />
                          )}
                        </div>
                        <div className="flex items-center mt-1">
                          {renderStars(review.rating)}
                          <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">
                            {formatTimeAgo(review.created_at)}
                          </span>
                        </div>
                      </div>
                    </div>
                    <button
                      title="Report review"
                      className="text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      <Flag size={16} />
                    </button>
                  </div>
                  <p className="mt-3 text-gray-600 dark:text-gray-300 whitespace-pre-wrap">
                    {review.content}
                  </p>
                  <div className="mt-4 flex items-center gap-4">
                    <button className="flex items-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200">
                      <ThumbsUp size={16} className="mr-1" />
                      <span className="text-sm">Helpful</span>
                    </button>
                    <button className="flex items-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200">
                      <MessageSquare size={16} className="mr-1" />
                      <span className="text-sm">Reply</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}