import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  MessageSquare, 
  Image as ImageIcon, 
  Video, 
  BarChart2, 
  Plus, 
  MoreVertical, 
  ThumbsUp, 
  MessageCircle, 
  Send, 
  Trash2, 
  Edit2, 
  X,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { UserAvatar } from '../user/UserAvatar';
import { formatTimeAgo } from '../../lib/utils/date';
import { v4 as uuidv4 } from 'uuid';

interface Post {
  id: string;
  course_id: string;
  user_id: string;
  content: string;
  media_url?: string | null;
  media_type?: 'image' | 'video' | null;
  created_at: string;
  updated_at?: string;
  likes_count: number;
  comments_count: number;
  post_type: 'announcement' | 'post' | 'poll';
  poll_options?: string[] | null;
  poll_results?: Record<string, number> | null;
  user: {
    username: string;
    avatar_url: string | null;
    is_coach?: boolean;
  };
  liked_by_user?: boolean;
}

interface Comment {
  id: string;
  post_id: string;
  user_id: string;
  content: string;
  created_at: string;
  parent_id?: string | null;
  user: {
    username: string;
    avatar_url: string | null;
    is_coach?: boolean;
  };
}

interface CourseHomeProps {
  courseId: string;
  isInstructor: boolean;
  onUserClick: (username: string) => void;
}

export function CourseHome({ courseId, isInstructor, onUserClick }: CourseHomeProps) {
  const { user, userProfile } = useAuth();
  const navigate = useNavigate();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showNewPostForm, setShowNewPostForm] = useState(false);
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostType, setNewPostType] = useState<'post' | 'announcement' | 'poll'>('post');
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);
  const [submittingPost, setSubmittingPost] = useState(false);
  const [expandedPostId, setExpandedPostId] = useState<string | null>(null);
  const [comments, setComments] = useState<Record<string, Comment[]>>({});
  const [loadingComments, setLoadingComments] = useState<Record<string, boolean>>({});
  const [newComment, setNewComment] = useState<Record<string, string>>({});
  const [submittingComment, setSubmittingComment] = useState<Record<string, boolean>>({});
  const [replyingTo, setReplyingTo] = useState<{postId: string, commentId: string, username: string} | null>(null);
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [editingPost, setEditingPost] = useState<Post | null>(null);
  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({});
  const [deletingPost, setDeletingPost] = useState<Record<string, boolean>>({});
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  useEffect(() => {
    fetchPosts();
  }, [courseId]);

  const fetchPosts = async () => {
    try {
      setLoading(true);
      setError(null);

      // Check if the course_posts table exists
      const { error: tableCheckError } = await supabase
        .from('course_posts')
        .select('id')
        .limit(1);

      // If the table doesn't exist yet, create a migration
      if (tableCheckError) {
        console.log('Course posts table does not exist yet. Creating sample data.');
        // Return sample data for now
        const samplePosts: Post[] = [
          {
            id: '1',
            course_id: courseId,
            user_id: 'instructor-id',
            content: 'Welcome to the course! This is where you\'ll find important announcements and updates.',
            created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
            likes_count: 5,
            comments_count: 2,
            post_type: 'announcement',
            user: {
              username: 'instructor',
              avatar_url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100',
              is_coach: true
            }
          },
          {
            id: '2',
            course_id: courseId,
            user_id: 'instructor-id',
            content: 'Just uploaded a new lesson on advanced techniques. Check it out in the Skills tab!',
            media_url: 'https://images.unsplash.com/photo-1682687982501-1e58ab814714?auto=format&fit=crop&q=80&w=1000',
            media_type: 'image',
            created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
            likes_count: 12,
            comments_count: 3,
            post_type: 'post',
            user: {
              username: 'instructor',
              avatar_url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100',
              is_coach: true
            }
          },
          {
            id: '3',
            course_id: courseId,
            user_id: 'instructor-id',
            content: 'What topic would you like to see covered next?',
            created_at: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
            likes_count: 8,
            comments_count: 5,
            post_type: 'poll',
            poll_options: ['More technical skills', 'Training routines', 'Equipment guides', 'Competition tips'],
            poll_results: {
              'More technical skills': 12,
              'Training routines': 8,
              'Equipment guides': 5,
              'Competition tips': 7
            },
            user: {
              username: 'instructor',
              avatar_url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100',
              is_coach: true
            }
          }
        ];
        
        setPosts(samplePosts);
        setLoading(false);
        return;
      }

      // Fetch posts from the database
      const { data, error } = await supabase
        .from('course_posts')
        .select(`
          *,
          profiles:user_id (
            username,
            avatar_url,
            is_coach
          )
        `)
        .eq('course_id', courseId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Check if the user has liked each post
      const postsWithLikeStatus = await Promise.all(
        (data || []).map(async (post) => {
          if (!user) return { ...post, user: post.profiles, liked_by_user: false };
          
          const { data: likeData, error: likeError } = await supabase
            .from('course_post_likes')
            .select('id')
            .eq('post_id', post.id)
            .eq('user_id', user.id)
            .maybeSingle();
            
          if (likeError) console.error('Error checking like status:', likeError);
          
          return {
            ...post,
            user: post.profiles,
            liked_by_user: !!likeData
          };
        })
      );

      setPosts(postsWithLikeStatus);
    } catch (err) {
      console.error('Error fetching posts:', err);
      setError('Failed to load posts');
    } finally {
      setLoading(false);
    }
  };

  const fetchComments = async (postId: string) => {
    try {
      setLoadingComments(prev => ({ ...prev, [postId]: true }));
      
      const { data, error } = await supabase
        .from('course_post_comments')
        .select(`
          *,
          profiles:user_id (
            username,
            avatar_url,
            is_coach
          )
        `)
        .eq('post_id', postId)
        .order('created_at', { ascending: true });
        
      if (error) throw error;
      
      const formattedComments = (data || []).map(comment => ({
        ...comment,
        user: comment.profiles
      }));
      
      setComments(prev => ({ ...prev, [postId]: formattedComments }));
    } catch (err) {
      console.error('Error fetching comments:', err);
    } finally {
      setLoadingComments(prev => ({ ...prev, [postId]: false }));
    }
  };

  const handleToggleComments = (postId: string) => {
    if (expandedPostId === postId) {
      setExpandedPostId(null);
    } else {
      setExpandedPostId(postId);
      if (!comments[postId]) {
        fetchComments(postId);
      }
    }
  };

  const handleToggleExpandComments = (postId: string) => {
    setExpandedComments(prev => ({
      ...prev,
      [postId]: !prev[postId]
    }));
  };

  const handleLikePost = async (postId: string) => {
    if (!user) {
      alert('Please sign in to like posts');
      return;
    }
    
    try {
      const post = posts.find(p => p.id === postId);
      if (!post) return;
      
      const isLiked = post.liked_by_user;
      
      // Optimistically update UI
      setPosts(prev => 
        prev.map(p => 
          p.id === postId 
            ? { 
                ...p, 
                likes_count: isLiked ? p.likes_count - 1 : p.likes_count + 1,
                liked_by_user: !isLiked
              } 
            : p
        )
      );
      
      if (isLiked) {
        // Unlike the post
        const { error } = await supabase
          .from('course_post_likes')
          .delete()
          .eq('post_id', postId)
          .eq('user_id', user.id);
          
        if (error) throw error;
      } else {
        // Like the post
        const { error } = await supabase
          .from('course_post_likes')
          .insert({
            post_id: postId,
            user_id: user.id
          });
          
        if (error) throw error;
      }
    } catch (err) {
      console.error('Error toggling like:', err);
      // Revert optimistic update on error
      fetchPosts();
    }
  };

  const handleSubmitComment = async (postId: string) => {
    if (!user || !newComment[postId]?.trim()) return;
    
    try {
      setSubmittingComment(prev => ({ ...prev, [postId]: true }));
      
      const commentData = {
        post_id: postId,
        user_id: user.id,
        content: newComment[postId].trim(),
        parent_id: replyingTo?.postId === postId ? replyingTo.commentId : null
      };
      
      const { data, error } = await supabase
        .from('course_post_comments')
        .insert(commentData)
        .select(`
          *,
          profiles:user_id (
            username,
            avatar_url,
            is_coach
          )
        `)
        .single();
        
      if (error) throw error;
      
      // Update comments state
      const formattedComment = {
        ...data,
        user: data.profiles
      };
      
      setComments(prev => ({
        ...prev,
        [postId]: [...(prev[postId] || []), formattedComment]
      }));
      
      // Update comment count on post
      setPosts(prev => 
        prev.map(p => 
          p.id === postId 
            ? { ...p, comments_count: p.comments_count + 1 } 
            : p
        )
      );
      
      // Clear input and reset reply state
      setNewComment(prev => ({ ...prev, [postId]: '' }));
      setReplyingTo(null);
    } catch (err) {
      console.error('Error submitting comment:', err);
    } finally {
      setSubmittingComment(prev => ({ ...prev, [postId]: false }));
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    
    // Check if file is an image or video
    if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
      alert('Please select an image or video file');
      return;
    }
    
    // Check file size (limit to 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    setMediaFile(file);
    
    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setMediaPreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveMedia = () => {
    setMediaPreview(null);
    setMediaFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleAddPollOption = () => {
    setPollOptions([...pollOptions, '']);
  };

  const handleRemovePollOption = (index: number) => {
    if (pollOptions.length <= 2) return; // Keep at least 2 options
    const newOptions = [...pollOptions];
    newOptions.splice(index, 1);
    setPollOptions(newOptions);
  };

  const handlePollOptionChange = (index: number, value: string) => {
    const newOptions = [...pollOptions];
    newOptions[index] = value;
    setPollOptions(newOptions);
  };

  const handleSubmitPost = async () => {
    if (!user || !newPostContent.trim()) return;
    
    if (newPostType === 'poll' && pollOptions.filter(opt => opt.trim()).length < 2) {
      alert('Please add at least 2 poll options');
      return;
    }
    
    try {
      setSubmittingPost(true);
      
      let mediaUrl = null;
      let mediaType = null;
      
      // Upload media if present
      if (mediaFile) {
        setUploadingMedia(true);
        
        // Create a unique file path
        const fileExt = mediaFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = `course-posts/${courseId}/${fileName}`;
        
        // Upload the file to Supabase Storage
        const { data, error: uploadError } = await supabase.storage
          .from('public')
          .upload(filePath, mediaFile, {
            cacheControl: '3600',
            upsert: false
          });
        
        if (uploadError) throw uploadError;
        
        // Get the public URL
        const { data: urlData } = supabase.storage
          .from('public')
          .getPublicUrl(filePath);
        
        mediaUrl = urlData.publicUrl;
        mediaType = mediaFile.type.startsWith('image/') ? 'image' : 'video';
        
        setUploadingMedia(false);
      }
      
      // Prepare post data
      const postData: any = {
        course_id: courseId,
        user_id: user.id,
        content: newPostContent.trim(),
        post_type: newPostType,
        media_url: mediaUrl,
        media_type: mediaType
      };
      
      // Add poll options if it's a poll
      if (newPostType === 'poll') {
        const filteredOptions = pollOptions.filter(opt => opt.trim());
        postData.poll_options = filteredOptions;
        postData.poll_results = {};
        filteredOptions.forEach(opt => {
          postData.poll_results[opt] = 0;
        });
      }
      
      // If editing a post
      if (editingPost) {
        const { error } = await supabase
          .from('course_posts')
          .update(postData)
          .eq('id', editingPost.id);
          
        if (error) throw error;
        
        // Update local state
        setPosts(prev => 
          prev.map(p => 
            p.id === editingPost.id 
              ? { ...p, ...postData, user: p.user } 
              : p
          )
        );
      } else {
        // Create new post
        const { data, error } = await supabase
          .from('course_posts')
          .insert(postData)
          .select(`
            *,
            profiles:user_id (
              username,
              avatar_url,
              is_coach
            )
          `);
          
        if (error) throw error;
        
        // Check if data exists and has at least one element
        if (data && data.length > 0) {
          // Add to local state
          const newPost = {
            ...data[0],
            user: data[0].profiles,
            likes_count: 0,
            comments_count: 0,
            liked_by_user: false
          };
          
          setPosts(prev => [newPost, ...prev]);
        } else {
          throw new Error('No data returned from post creation');
        }
      }
      
      // Reset form
      setNewPostContent('');
      setNewPostType('post');
      setPollOptions(['', '']);
      setMediaFile(null);
      setMediaPreview(null);
      setShowNewPostForm(false);
      setEditingPost(null);
      
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (err) {
      console.error('Error submitting post:', err);
      setError('Failed to submit post');
    } finally {
      setSubmittingPost(false);
      setUploadingMedia(false);
    }
  };

  const handleEditPost = (post: Post) => {
    setEditingPost(post);
    setNewPostContent(post.content);
    setNewPostType(post.post_type);
    
    if (post.media_url) {
      setMediaPreview(post.media_url);
    }
    
    if (post.poll_options) {
      setPollOptions(post.poll_options);
    }
    
    setShowNewPostForm(true);
  };

  const handleDeletePost = async (postId: string) => {
    try {
      setDeletingPost(prev => ({ ...prev, [postId]: true }));
      
      const { error } = await supabase
        .from('course_posts')
        .delete()
        .eq('id', postId);
        
      if (error) throw error;
      
      // Remove from local state
      setPosts(prev => prev.filter(p => p.id !== postId));
      setShowDeleteConfirm(null);
    } catch (err) {
      console.error('Error deleting post:', err);
      setError('Failed to delete post');
    } finally {
      setDeletingPost(prev => ({ ...prev, [postId]: false }));
    }
  };

  const handleVoteInPoll = async (postId: string, option: string) => {
    if (!user) {
      alert('Please sign in to vote');
      return;
    }
    
    try {
      const post = posts.find(p => p.id === postId);
      if (!post || !post.poll_results) return;
      
      // Check if user has already voted
      const { data: existingVote, error: checkError } = await supabase
        .from('course_poll_votes')
        .select('option')
        .eq('post_id', postId)
        .eq('user_id', user.id)
        .maybeSingle();
        
      if (checkError) throw checkError;
      
      // Optimistically update UI
      const newResults = { ...post.poll_results };
      
      if (existingVote) {
        // Change vote
        newResults[existingVote.option] = Math.max(0, (newResults[existingVote.option] || 0) - 1);
        newResults[option] = (newResults[option] || 0) + 1;
        
        // Update in database
        const { error } = await supabase
          .from('course_poll_votes')
          .update({ option })
          .eq('post_id', postId)
          .eq('user_id', user.id);
          
        if (error) throw error;
      } else {
        // New vote
        newResults[option] = (newResults[option] || 0) + 1;
        
        // Insert in database
        const { error } = await supabase
          .from('course_poll_votes')
          .insert({
            post_id: postId,
            user_id: user.id,
            option
          });
          
        if (error) throw error;
      }
      
      // Update post with new results
      const { error: updateError } = await supabase
        .from('course_posts')
        .update({ poll_results: newResults })
        .eq('id', postId);
        
      if (updateError) throw updateError;
      
      // Update local state
      setPosts(prev => 
        prev.map(p => 
          p.id === postId 
            ? { ...p, poll_results: newResults } 
            : p
        )
      );
    } catch (err) {
      console.error('Error voting in poll:', err);
    }
  };

  const renderPollResults = (post: Post) => {
    if (!post.poll_options || !post.poll_results) return null;
    
    const totalVotes = Object.values(post.poll_results).reduce((sum, count) => sum + count, 0);
    
    return (
      <div className="mt-3 space-y-2">
        {post.poll_options.map((option) => {
          const votes = post.poll_results?.[option] || 0;
          const percentage = totalVotes > 0 ? Math.round((votes / totalVotes) * 100) : 0;
          
          return (
            <div key={option} className="space-y-1">
              <div className="flex justify-between text-sm">
                <button 
                  onClick={() => handleVoteInPoll(post.id, option)}
                  className="text-left hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
                >
                  {option}
                </button>
                <span>{percentage}%</span>
              </div>
              <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-500 rounded-full"
                  style={{ width: `${percentage}%` }}
                />
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400">{votes} votes</p>
            </div>
          );
        })}
        <p className="text-sm text-gray-500 dark:text-gray-400 pt-2">
          {totalVotes} total votes
        </p>
      </div>
    );
  };

  return (
    <div className="p-4 space-y-6">
      {/* New Post Form */}
      {isInstructor && (
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
          {showNewPostForm ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                  {editingPost ? 'Edit Post' : 'Create New Post'}
                </h3>
                <button 
                  onClick={() => {
                    setShowNewPostForm(false);
                    setEditingPost(null);
                    setNewPostContent('');
                    setNewPostType('post');
                    setPollOptions(['', '']);
                    setMediaFile(null);
                    setMediaPreview(null);
                  }}
                  className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={() => setNewPostType('post')}
                  className={`px-3 py-1.5 rounded-lg text-sm ${
                    newPostType === 'post'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  Post
                </button>
                <button
                  onClick={() => setNewPostType('announcement')}
                  className={`px-3 py-1.5 rounded-lg text-sm ${
                    newPostType === 'announcement'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  Announcement
                </button>
                <button
                  onClick={() => setNewPostType('poll')}
                  className={`px-3 py-1.5 rounded-lg text-sm ${
                    newPostType === 'poll'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  Poll
                </button>
              </div>
              
              <textarea
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                placeholder={
                  newPostType === 'announcement' 
                    ? 'Share an important announcement...' 
                    : newPostType === 'poll'
                      ? 'Ask a question...'
                      : 'Share something with your students...'
                }
                className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400 min-h-[120px] resize-none"
              />
              
              {newPostType === 'poll' && (
                <div className="space-y-3">
                  <h4 className="font-medium text-gray-900 dark:text-white">Poll Options</h4>
                  {pollOptions.map((option, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={option}
                        onChange={(e) => handlePollOptionChange(index, e.target.value)}
                        placeholder={`Option ${index + 1}`}
                        className="flex-1 px-4 py-2 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                      />
                      {index > 1 && (
                        <button
                          onClick={() => handleRemovePollOption(index)}
                          className="text-red-500 hover:text-red-600 dark:text-red-400 dark:hover:text-red-300"
                        >
                          <X size={20} />
                        </button>
                      )}
                    </div>
                  ))}
                  <button
                    onClick={handleAddPollOption}
                    className="text-blue-500 dark:text-blue-400 hover:text-blue-600 dark:hover:text-blue-300 text-sm font-medium"
                  >
                    + Add Option
                  </button>
                </div>
              )}
              
              {newPostType !== 'poll' && (
                <>
                  {mediaPreview && (
                    <div className="relative">
                      {mediaFile?.type.startsWith('image/') ? (
                        <img 
                          src={mediaPreview} 
                          alt="Preview" 
                          className="max-h-64 rounded-lg object-contain bg-gray-100 dark:bg-gray-700"
                        />
                      ) : (
                        <video 
                          src={mediaPreview} 
                          controls 
                          className="max-h-64 w-full rounded-lg object-contain bg-gray-100 dark:bg-gray-700"
                        />
                      )}
                      <button
                        onClick={handleRemoveMedia}
                        className="absolute top-2 right-2 bg-gray-800/70 text-white p-1 rounded-full hover:bg-gray-900/70"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  )}
                  
                  <div className="flex items-center">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileSelect}
                      accept="image/*,video/*"
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                    >
                      <ImageIcon size={20} className="mr-1" />
                      <span>Add Media</span>
                    </button>
                  </div>
                </>
              )}
              
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => {
                    setShowNewPostForm(false);
                    setEditingPost(null);
                  }}
                  className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmitPost}
                  disabled={
                    submittingPost || 
                    !newPostContent.trim() || 
                    (newPostType === 'poll' && pollOptions.filter(opt => opt.trim()).length < 2)
                  }
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg disabled:opacity-50 flex items-center"
                >
                  {submittingPost ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      {editingPost ? 'Updating...' : 'Posting...'}
                    </>
                  ) : (
                    <>{editingPost ? 'Update' : 'Post'}</>
                  )}
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setShowNewPostForm(true)}
              className="w-full flex items-center justify-center space-x-2 py-3 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-650 transition-colors"
            >
              <Plus size={20} className="text-blue-500 dark:text-blue-400" />
              <span className="text-gray-700 dark:text-gray-300 font-medium">Create New Post</span>
            </button>
          )}
        </div>
      )}
      
      {/* Posts List */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : posts.length === 0 ? (
        <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-sm border border-gray-200 dark:border-gray-700 text-center">
          <MessageSquare size={48} className="mx-auto text-gray-400 dark:text-gray-600 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No posts yet</h3>
          <p className="text-gray-500 dark:text-gray-400">
            {isInstructor 
              ? 'Create your first post to share with your students!' 
              : 'The instructor hasn\'t posted anything yet.'}
          </p>
          {isInstructor && (
            <button
              onClick={() => setShowNewPostForm(true)}
              className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg"
            >
              Create First Post
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {posts.map((post) => (
            <div 
              key={post.id} 
              className={`bg-white dark:bg-gray-800 rounded-xl shadow-sm border ${
                post.post_type === 'announcement' 
                  ? 'border-blue-200 dark:border-blue-800/30' 
                  : 'border-gray-200 dark:border-gray-700'
              }`}
            >
              {/* Post Header */}
              <div className="p-4 flex justify-between items-start">
                <div className="flex items-center">
                  <UserAvatar 
                    username={post.user.username}
                    avatarUrl={post.user.avatar_url}
                    size="sm"
                    className="mr-3"
                  />
                  <div>
                    <div className="flex items-center">
                      <button
                        onClick={() => onUserClick(post.user.username)}
                        className="font-medium text-gray-900 dark:text-white hover:text-blue-500 dark:hover:text-blue-400"
                      >
                        {post.user.username}
                      </button>
                      {post.post_type === 'announcement' && (
                        <span className="ml-2 px-2 py-0.5 bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-full text-xs">
                          Announcement
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {formatTimeAgo(post.created_at)}
                      {post.updated_at && post.updated_at !== post.created_at && ' (edited)'}
                    </p>
                  </div>
                </div>
                
                {isInstructor && (
                  <div className="relative">
                    <button
                      onClick={() => setShowDeleteConfirm(post.id)}
                      className="text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 p-1"
                    >
                      <MoreVertical size={20} />
                    </button>
                    
                    {showDeleteConfirm === post.id && (
                      <div className="absolute right-0 mt-1 w-36 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-10">
                        <button
                          onClick={() => {
                            handleEditPost(post);
                            setShowDeleteConfirm(null);
                          }}
                          className="w-full text-left px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
                        >
                          <Edit2 size={16} className="mr-2" />
                          Edit
                        </button>
                        <button
                          onClick={() => handleDeletePost(post.id)}
                          disabled={deletingPost[post.id]}
                          className="w-full text-left px-4 py-2 text-red-500 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
                        >
                          {deletingPost[post.id] ? (
                            <>
                              <div className="w-4 h-4 border-2 border-red-500 dark:border-red-400 border-t-transparent rounded-full animate-spin mr-2"></div>
                              Deleting...
                            </>
                          ) : (
                            <>
                              <Trash2 size={16} className="mr-2" />
                              Delete
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              {/* Post Content */}
              <div className="px-4 pb-3">
                <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                  {post.content}
                </p>
                
                {/* Media */}
                {post.media_url && (
                  <div className="mt-3">
                    {post.media_type === 'image' ? (
                      <img 
                        src={post.media_url} 
                        alt="Post media" 
                        className="rounded-lg max-h-96 object-contain bg-gray-100 dark:bg-gray-700"
                      />
                    ) : post.media_type === 'video' ? (
                      <video 
                        src={post.media_url} 
                        controls 
                        className="rounded-lg max-h-96 w-full object-contain bg-gray-100 dark:bg-gray-700"
                      />
                    ) : null}
                  </div>
                )}
                
                {/* Poll */}
                {post.post_type === 'poll' && renderPollResults(post)}
              </div>
              
              {/* Post Actions */}
              <div className="px-4 py-3 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => handleLikePost(post.id)}
                    className={`flex items-center space-x-1 ${
                      post.liked_by_user
                        ? 'text-blue-500 dark:text-blue-400'
                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
                    }`}
                  >
                    <ThumbsUp size={18} className={post.liked_by_user ? 'fill-current' : ''} />
                    <span>{post.likes_count}</span>
                  </button>
                  
                  <button
                    onClick={() => handleToggleComments(post.id)}
                    className="flex items-center space-x-1 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                  >
                    <MessageCircle size={18} />
                    <span>{post.comments_count}</span>
                  </button>
                </div>
              </div>
              
              {/* Comments Section */}
              {expandedPostId === post.id && (
                <div className="px-4 py-3 border-t border-gray-200 dark:border-gray-700">
                  {/* Comment Input */}
                  <div className="flex items-center space-x-2 mb-4">
                    <UserAvatar 
                      username={userProfile?.username || 'User'}
                      avatarUrl={userProfile?.avatar_url}
                      size="xs"
                    />
                    <div className="flex-1 relative">
                      {replyingTo && replyingTo.postId === post.id && (
                        <div className="absolute -top-6 left-0 right-0 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 text-xs px-2 py-1 rounded flex items-center justify-between">
                          <span>Replying to @{replyingTo.username}</span>
                          <button 
                            onClick={() => setReplyingTo(null)}
                            className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                          >
                            <X size={14} />
                          </button>
                        </div>
                      )}
                      <input
                        type="text"
                        value={newComment[post.id] || ''}
                        onChange={(e) => setNewComment({ ...newComment, [post.id]: e.target.value })}
                        placeholder="Write a comment..."
                        className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-full border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                      />
                    </div>
                    <button
                      onClick={() => handleSubmitComment(post.id)}
                      disabled={!newComment[post.id]?.trim() || submittingComment[post.id]}
                      className="text-blue-500 dark:text-blue-400 disabled:opacity-50"
                    >
                      {submittingComment[post.id] ? (
                        <div className="w-5 h-5 border-2 border-blue-500 dark:border-blue-400 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Send size={20} />
                      )}
                    </button>
                  </div>
                  
                  {/* Comments List */}
                  {loadingComments[post.id] ? (
                    <div className="flex justify-center py-4">
                      <div className="w-6 h-6 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                    </div>
                  ) : comments[post.id]?.length === 0 ? (
                    <p className="text-center text-gray-500 dark:text-gray-400 py-2">
                      No comments yet. Be the first to comment!
                    </p>
                  ) : (
                    <div className="space-y-4">
                      {/* Group comments by parent_id */}
                      {(() => {
                        const topLevelComments = (comments[post.id] || []).filter(c => !c.parent_id);
                        const replies = (comments[post.id] || []).filter(c => c.parent_id);
                        
                        // Create a map of parent_id to replies
                        const replyMap: Record<string, Comment[]> = {};
                        replies.forEach(reply => {
                          if (!reply.parent_id) return;
                          if (!replyMap[reply.parent_id]) {
                            replyMap[reply.parent_id] = [];
                          }
                          replyMap[reply.parent_id].push(reply);
                        });
                        
                        // Only show a limited number of comments unless expanded
                        const visibleComments = expandedComments[post.id]
                          ? topLevelComments
                          : topLevelComments.slice(0, 3);
                        
                        return (
                          <>
                            {visibleComments.map((comment) => (
                              <div key={comment.id} className="space-y-2">
                                {/* Main comment */}
                                <div className="flex items-start space-x-2">
                                  <UserAvatar 
                                    username={comment.user.username}
                                    avatarUrl={comment.user.avatar_url}
                                    size="xs"
                                  />
                                  <div className="flex-1">
                                    <div className="bg-gray-100 dark:bg-gray-700 rounded-lg px-3 py-2">
                                      <div className="flex items-center">
                                        <button
                                          onClick={() => onUserClick(comment.user.username)}
                                          className="font-medium text-gray-900 dark:text-white hover:text-blue-500 dark:hover:text-blue-400 text-sm"
                                        >
                                          {comment.user.username}
                                        </button>
                                        {comment.user.is_coach && (
                                          <span className="ml-1 px-1.5 py-0.5 bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded text-xs">
                                            Coach
                                          </span>
                                        )}
                                      </div>
                                      <p className="text-gray-700 dark:text-gray-300 text-sm">
                                        {comment.content}
                                      </p>
                                    </div>
                                    <div className="flex items-center mt-1 space-x-3">
                                      <button
                                        onClick={() => setReplyingTo({
                                          postId: post.id,
                                          commentId: comment.id,
                                          username: comment.user.username
                                        })}
                                        className="text-xs text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                                      >
                                        Reply
                                      </button>
                                      <span className="text-xs text-gray-500 dark:text-gray-400">
                                        {formatTimeAgo(comment.created_at)}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                                
                                {/* Replies to this comment */}
                                {replyMap[comment.id] && replyMap[comment.id].length > 0 && (
                                  <div className="ml-8 space-y-2">
                                    {replyMap[comment.id].map((reply) => (
                                      <div key={reply.id} className="flex items-start space-x-2">
                                        <UserAvatar 
                                          username={reply.user.username}
                                          avatarUrl={reply.user.avatar_url}
                                          size="xs"
                                        />
                                        <div className="flex-1">
                                          <div className="bg-gray-100 dark:bg-gray-700 rounded-lg px-3 py-2">
                                            <div className="flex items-center">
                                              <button
                                                onClick={() => onUserClick(reply.user.username)}
                                                className="font-medium text-gray-900 dark:text-white hover:text-blue-500 dark:hover:text-blue-400 text-sm"
                                              >
                                                {reply.user.username}
                                              </button>
                                              {reply.user.is_coach && (
                                                <span className="ml-1 px-1.5 py-0.5 bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded text-xs">
                                                  Coach
                                                </span>
                                              )}
                                            </div>
                                            <p className="text-gray-700 dark:text-gray-300 text-sm">
                                              {reply.content}
                                            </p>
                                          </div>
                                          <div className="flex items-center mt-1 space-x-3">
                                            <button
                                              onClick={() => setReplyingTo({
                                                postId: post.id,
                                                commentId: comment.id, // Still reply to the parent comment
                                                username: reply.user.username
                                              })}
                                              className="text-xs text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                                            >
                                              Reply
                                            </button>
                                            <span className="text-xs text-gray-500 dark:text-gray-400">
                                              {formatTimeAgo(reply.created_at)}
                                            </span>
                                          </div>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            ))}
                            
                            {/* Show more/less comments button */}
                            {topLevelComments.length > 3 && (
                              <button
                                onClick={() => handleToggleExpandComments(post.id)}
                                className="text-blue-500 dark:text-blue-400 text-sm flex items-center mt-2"
                              >
                                {expandedComments[post.id] ? (
                                  <>
                                    <ChevronUp size={16} className="mr-1" />
                                    Show less
                                  </>
                                ) : (
                                  <>
                                    <ChevronDown size={16} className="mr-1" />
                                    Show {topLevelComments.length - 3} more comments
                                  </>
                                )}
                              </button>
                            )}
                          </>
                        );
                      })()}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}