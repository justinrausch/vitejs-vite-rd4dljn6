import React, { useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { CoachDashboard } from './coaching/CoachDashboard';
import { StudentDashboard } from './coaching/StudentDashboard';

interface CourseCoachingProps {
  instructorUsername: string;
  instructorAvatarUrl: string | null;
  courseId: string;
}

export function CourseCoaching({ 
  instructorUsername, 
  instructorAvatarUrl, 
  courseId 
}: CourseCoachingProps) {
  const { user, userProfile } = useAuth();
  const isCoach = userProfile?.is_coach || false;
  const isInstructor = userProfile?.username === instructorUsername;

  // Scroll to bottom when component mounts
  useEffect(() => {
    // Small delay to ensure content is rendered
    setTimeout(() => {
      const messagesEnd = document.querySelector('[data-messages-end="true"]');
      messagesEnd?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }, []);

  if (!user) {
    return (
      <div className="fixed inset-0 top-[8rem] z-10 flex items-center justify-center bg-white dark:bg-gray-800 rounded-xl">
        <div className="text-center p-6">
          <p className="text-gray-600 dark:text-gray-300 mb-4">Please sign in to access coaching features</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 top-[8rem] z-10">
      {isCoach && isInstructor ? (
        <CoachDashboard
          courseId={courseId}
          instructorUsername={instructorUsername}
          instructorAvatarUrl={instructorAvatarUrl}
        />
      ) : (
        <StudentDashboard
          courseId={courseId}
          instructorUsername={instructorUsername}
          instructorAvatarUrl={instructorAvatarUrl}
        />
      )}
    </div>
  );
}