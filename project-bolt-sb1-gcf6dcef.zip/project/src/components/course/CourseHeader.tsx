import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, Share2, MoreVertical, LogOut, BarChart2, Trash2, AlertTriangle, Edit } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { UserAvatar } from '../user/UserAvatar';
import { LeaveConfirmationModal } from './LeaveConfirmationModal';
import { VerifiedBadge } from '../user/VerifiedBadge';

interface CourseHeaderProps {
  title: string;
  instructorUsername: string;
  courseId: string;
  onBackClick: () => void;
  isInstructor?: boolean;
}

export function CourseHeader({ 
  title, 
  instructorUsername, 
  courseId, 
  onBackClick,
  isInstructor = false
}: CourseHeaderProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [showMenu, setShowMenu] = useState(false);
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isLeaving, setIsLeaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [instructorAvatar, setInstructorAvatar] = useState<string | null>(null);
  const [isVerified, setIsVerified] = useState(false);
  const [confirmationText, setConfirmationText] = useState('');
  const [deleteReason, setDeleteReason] = useState('');
  const [userPlan, setUserPlan] = useState<any>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchInstructorAvatar();
    if (user) {
      fetchUserPlan();
    }

    // Close menu when clicking outside
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [instructorUsername, user, courseId]);

  const fetchInstructorAvatar = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('avatar_url, is_verified')
        .eq('username', instructorUsername)
        .single();

      if (error) throw error;
      setInstructorAvatar(data.avatar_url);
      setIsVerified(data.is_verified || false);
    } catch (err) {
      console.error('Error fetching instructor avatar:', err);
    }
  };

  const fetchUserPlan = async () => {
    if (!user || !courseId) return;
    
    try {
      const { data, error } = await supabase
        .from('enrollments')
        .select(`
          plan_id,
          course_plans:plan_id (
            id,
            title,
            price,
            renewal_period
          )
        `)
        .eq('user_id', user.id)
        .eq('course_id', courseId)
        .maybeSingle();
        
      if (error) throw error;
      
      if (data && data.course_plans) {
        setUserPlan(data.course_plans);
      }
    } catch (err) {
      console.error('Error fetching user plan:', err);
    }
  };

  const handleLeaveCourse = async () => {
    if (!user) return;
    
    try {
      setIsLeaving(true);
      
      const { error } = await supabase
        .from('enrollments')
        .delete()
        .eq('user_id', user.id)
        .eq('course_id', courseId);
      
      if (error) throw error;
      
      navigate('/');
    } catch (err) {
      console.error('Error leaving course:', err);
      setIsLeaving(false);
      setShowLeaveModal(false);
    }
  };

  const handleDeleteCourse = async () => {
    if (!user || !isInstructor) return;
    
    // Verify that the confirmation text matches the course title
    if (confirmationText !== title) {
      alert("The course name you entered doesn't match. Please try again.");
      return;
    }
    
    // Verify that a reason was provided
    if (!deleteReason.trim()) {
      alert("Please provide a reason for deleting this course.");
      return;
    }
    
    try {
      setIsDeleting(true);
      
      // In a real application, you might want to log the reason for deletion
      console.log(`Course deletion reason: ${deleteReason}`);
      
      const { error } = await supabase
        .from('courses')
        .delete()
        .eq('id', courseId)
        .eq('instructor_id', user.id);
      
      if (error) throw error;
      
      navigate('/');
    } catch (err) {
      console.error('Error deleting course:', err);
      setIsDeleting(false);
      setShowDeleteModal(false);
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: title,
      text: `Check out this course: ${title}`,
      url: window.location.href,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
        setShowMenu(false);
      } else {
        throw new Error('Share API not supported');
      }
    } catch (err) {
      // Handle both permission denied and API not supported cases
      try {
        await navigator.clipboard.writeText(window.location.href);
        alert('Link copied to clipboard!');
        setShowMenu(false);
      } catch (clipboardErr) {
        console.error('Error copying to clipboard:', clipboardErr);
        alert('Unable to share or copy link. Please try manually copying the URL.');
      }
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 sticky top-0 z-30">
      <div className="max-w-lg mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          <div className="flex items-center">
            <button onClick={onBackClick} className="mr-4 text-gray-700 dark:text-gray-300">
              <ChevronLeft size={24} />
            </button>
            <div>
              <h1 className="text-lg font-medium text-gray-900 dark:text-white">{title}</h1>
              <div className="flex items-center">
                <span className="text-sm text-gray-500 dark:text-gray-400">by {instructorUsername}</span>
                {isVerified && <VerifiedBadge className="ml-1.5 -mt-0.5" />}
                {userPlan && (
                  <span className="ml-2 text-xs text-blue-500 dark:text-blue-400">
                    • {userPlan.title}
                  </span>
                )}
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="flex items-center space-x-2">
              {isInstructor && (
                <button
                  onClick={() => navigate(`/admin/course/${courseId}/analytics`)}
                  className="text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 p-2"
                  title="Analytics"
                >
                  <BarChart2 size={20} />
                </button>
              )}
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="text-gray-600 dark:text-gray-400 p-2"
              >
                <MoreVertical size={20} />
              </button>
            </div>
            {showMenu && (
              <div 
                ref={menuRef}
                className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-50"
              >
                <button
                  onClick={handleShare}
                  className="w-full text-left px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
                >
                  <Share2 size={16} className="mr-2" />
                  Share course
                </button>
                
                {isInstructor ? (
                  <>
                    <button
                      onClick={() => {
                        setShowMenu(false);
                        navigate(`/course/edit/${courseId}`);
                      }}
                      className="w-full text-left px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
                    >
                      <Edit size={16} className="mr-2" />
                      Edit course
                    </button>
                    <button
                      onClick={() => {
                        setShowMenu(false);
                        setShowDeleteModal(true);
                      }}
                      className="w-full text-left px-4 py-2 text-red-500 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
                    >
                      <Trash2 size={16} className="mr-2" />
                      Delete course
                    </button>
                  </>
                ) : (
                  <>
                    {userPlan && (
                      <div className="px-4 py-2 text-gray-700 dark:text-gray-300 border-b border-gray-200 dark:border-gray-700">
                        <div className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">Current Plan</div>
                        <div className="font-medium">{userPlan.title}</div>
                        <div className="text-sm">${userPlan.price}/{userPlan.renewal_period || 'one-time'}</div>
                      </div>
                    )}
                    <button
                      onClick={() => {
                        setShowMenu(false);
                        navigate(`/course/preview/${courseId}`);
                      }}
                      className="w-full text-left px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
                    >
                      <Edit size={16} className="mr-2" />
                      Change plan
                    </button>
                    <button
                      onClick={() => {
                        setShowMenu(false);
                        setShowLeaveModal(true);
                      }}
                      className="w-full text-left px-4 py-2 text-red-500 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
                    >
                      <LogOut size={16} className="mr-2" />
                      Leave course
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Leave Course Modal */}
      <LeaveConfirmationModal
        isOpen={showLeaveModal}
        onClose={() => setShowLeaveModal(false)}
        onConfirm={handleLeaveCourse}
        isLeaving={isLeaving}
      />

      {/* Delete Course Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex items-start mb-4">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-red-500" />
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                  Delete Course
                </h3>
                <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  This action <span className="font-bold">cannot be undone</span>. This will permanently delete the course, all its content, and remove all student enrollments.
                </p>
              </div>
            </div>
            
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Please type <span className="font-bold">{title}</span> to confirm:
              </label>
              <input
                type="text"
                value={confirmationText}
                onChange={(e) => setConfirmationText(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-red-500 focus:border-red-500 dark:bg-gray-700 dark:text-white"
                placeholder="Type course name here"
              />
            </div>
            
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Reason for deletion:
              </label>
              <textarea
                value={deleteReason}
                onChange={(e) => setDeleteReason(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-red-500 focus:border-red-500 dark:bg-gray-700 dark:text-white"
                placeholder="Please provide a reason for deleting this course"
                rows={3}
              />
            </div>
            
            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteModal(false)}
                disabled={isDeleting}
                className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteCourse}
                disabled={isDeleting || confirmationText !== title || !deleteReason.trim()}
                className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 disabled:opacity-50 flex items-center"
              >
                {isDeleting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Deleting...
                  </>
                ) : (
                  'Delete Course'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}