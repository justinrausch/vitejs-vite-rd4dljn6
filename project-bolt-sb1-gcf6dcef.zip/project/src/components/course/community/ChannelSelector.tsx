import React, { forwardRef, useState } from 'react';
import { Plus, Settings, Lock, Trash2 } from 'lucide-react';
import { useAuth } from '../../../contexts/AuthContext';
import { Channel } from './types';

interface ChannelSelectorProps {
  selectedChannel: string;
  onSelectChannel: (channelId: string) => void;
  channels: Channel[];
  isInstructor: boolean;
  onNewChannel?: () => void;
  onEditChannel?: (channel: Channel) => void;
  onDeleteChannel?: (channel: Channel) => void;
}

export const ChannelSelector = forwardRef<HTMLDivElement, ChannelSelectorProps>(
  ({ selectedChannel, onSelectChannel, channels, isInstructor, onNewChannel, onEditChannel, onDeleteChannel }, ref) => {
    return (
      <div className="bg-gray-50 dark:bg-gray-900 z-10 border-t border-gray-200 dark:border-gray-700">
        <div 
          ref={ref}
          className="flex gap-2 overflow-x-auto px-4 py-4 scrollbar-hide channel-buttons relative"
        >
          {channels.map((channel) => (
            <div key={channel.id} className="relative flex-shrink-0">
              <button
                onClick={() => onSelectChannel(channel.id)}
                className={`px-4 py-2.5 rounded-full text-sm font-medium whitespace-nowrap flex items-center gap-2 ${
                  selectedChannel === channel.id
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                {channel.name}
                {channel.is_private && <Lock size={14} className="text-current" />}
                {isInstructor && (
                  <div className="flex items-center gap-1">
                    {onEditChannel && (
                      <Settings
                        size={14}
                        className="cursor-pointer hover:text-gray-600 dark:hover:text-gray-200"
                        onClick={(e) => {
                          e.stopPropagation();
                          onEditChannel(channel);
                        }}
                      />
                    )}
                    {onDeleteChannel && channel.name.toLowerCase() !== 'general' && (
                      <Trash2
                        size={14}
                        className="cursor-pointer hover:text-red-500"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteChannel(channel);
                        }}
                      />
                    )}
                  </div>
                )}
              </button>
            </div>
          ))}
          
          {isInstructor && onNewChannel && (
            <button
              onClick={onNewChannel}
              className="px-4 py-2.5 rounded-full text-sm font-medium whitespace-nowrap flex items-center gap-2 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
            >
              <Plus size={16} />
              New Channel
            </button>
          )}
        </div>
      </div>
    );
  }
);

ChannelSelector.displayName = 'ChannelSelector';