import React, { forwardRef, useState } from 'react';
import { ChevronUp, Trash2, SmilePlus, CornerUpRight, ChevronDown, X } from 'lucide-react';
import { UserAvatar } from '../../user/UserAvatar';
import { AdminBadge } from '../../user/AdminBadge';
import { CoachBadge } from '../../user/CoachBadge';
import { VerifiedBadge } from '../../user/VerifiedBadge';
import { ReactionPicker } from './ReactionPicker';

interface ChatMessage {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
  parent_id?: string;
  reply_count?: number;
  image_url?: string | null;
  user: {
    username: string;
    avatar_url: string | null;
    is_coach?: boolean;
    is_verified?: boolean;
    email?: string;
  };
  reactions?: Reaction[];
}

interface MessageListProps {
  messages: ChatMessage[];
  loadingMoreMessages: boolean;
  hasMoreMessages: boolean;
  onLoadMoreMessages: () => void;
  onUserClick: (username: string) => void;
  onDeleteMessage: (messageId: string) => void;
  onAddReaction: (messageId: string, emoji: string) => void;
  onRemoveReaction: (messageId: string, emoji: string) => void;
  onReply: (messageId: string) => void;
  canDeleteMessage: (message: ChatMessage) => boolean;
  formatMessageTime: (timestamp: string) => string;
  isAdmin: (email?: string) => boolean;
  deletingMessages: Record<string, boolean>;
  debugInfo: string | null;
  currentUserId: string;
  courseId: string;
}

interface MessageListRefs {
  messagesContainer: React.RefObject<HTMLDivElement>;
  messagesEnd: React.RefObject<HTMLDivElement>;
}

export const MessageList = forwardRef<MessageListRefs, MessageListProps>(
  ({ 
    messages, 
    loadingMoreMessages, 
    hasMoreMessages, 
    onLoadMoreMessages, 
    onUserClick, 
    onDeleteMessage,
    onAddReaction,
    onRemoveReaction,
    onReply,
    canDeleteMessage, 
    formatMessageTime, 
    isAdmin, 
    deletingMessages,
    debugInfo,
    currentUserId
  }, ref) => {
    const defaultContainerRef = React.useRef<HTMLDivElement>(null);
    const defaultEndRef = React.useRef<HTMLDivElement>(null);
    
    const { 
      messagesContainer = defaultContainerRef, 
      messagesEnd = defaultEndRef 
    } = (ref as { current: MessageListRefs })?.current || {};

    const [showReactionPicker, setShowReactionPicker] = useState<string | null>(null);
    const [isScrolledToBottom, setIsScrolledToBottom] = useState(true);
    const [expandedThreads, setExpandedThreads] = useState<Set<string>>(new Set());
    const [expandedImages, setExpandedImages] = useState<Set<string>>(new Set());
    const [previewImage, setPreviewImage] = useState<string | null>(null);

    // Scroll to bottom on mount and when messages change
    React.useEffect(() => {
      if (isScrolledToBottom && messagesEnd.current) {
        messagesEnd.current.scrollIntoView({ behavior: 'smooth' });
      }
    }, [messages, isScrolledToBottom]);

    // Handle scroll event to load more messages
    React.useEffect(() => {
      const container = messagesContainer.current;
      if (!container) return;

      const handleScroll = () => {
        const isAtBottom = container.scrollHeight - container.scrollTop <= container.clientHeight + 100;
        setIsScrolledToBottom(isAtBottom);

        if (container.scrollTop === 0 && hasMoreMessages && !loadingMoreMessages) {
          const scrollHeight = container.scrollHeight;
          onLoadMoreMessages();
          setTimeout(() => {
            const newScrollHeight = container.scrollHeight;
            const diff = newScrollHeight - scrollHeight;
            container.scrollTop = diff;
          }, 100);
        }
      };

      container.addEventListener('scroll', handleScroll);
      return () => container.removeEventListener('scroll', handleScroll);
    }, [hasMoreMessages, loadingMoreMessages, onLoadMoreMessages]);

    const handleReactionClick = (messageId: string, emoji: string, reacted: boolean) => {
      if (reacted) {
        onRemoveReaction(messageId, emoji);
      } else {
        onAddReaction(messageId, emoji);
      }
    };

    const toggleThread = (messageId: string) => {
      setExpandedThreads(prev => {
        const next = new Set(prev);
        if (next.has(messageId)) {
          next.delete(messageId);
        } else {
          next.add(messageId);
        }
        return next;
      });
    };

    const toggleImageExpand = (messageId: string) => {
      setExpandedImages(prev => {
        const next = new Set(prev);
        if (next.has(messageId)) {
          next.delete(messageId);
        } else {
          next.add(messageId);
        }
        return next;
      });
    };

    const handleImageClick = (imageUrl: string, e: React.MouseEvent) => {
      e.stopPropagation();
      setPreviewImage(imageUrl);
    };

    const messageThreads = messages.reduce((acc, message) => {
      if (!message.parent_id) {
        if (!acc[message.id]) {
          acc[message.id] = {
            parent: message,
            replies: []
          };
        } else {
          acc[message.id].parent = message;
        }
      } else {
        if (!acc[message.parent_id]) {
          acc[message.parent_id] = {
            parent: null,
            replies: [message]
          };
        } else {
          acc[message.parent_id].replies.push(message);
        }
      }
      return acc;
    }, {} as Record<string, { parent: ChatMessage | null; replies: ChatMessage[] }>);

    const checkForMentions = (content: string) => {
      const mentionRegex = /@(\w+)/g;
      const matches = content.match(mentionRegex) || [];
      return matches.map(match => match.slice(1));
    };

    const isUserMentioned = (content: string) => {
      const mentions = checkForMentions(content);
      const currentUsername = messages.find(m => m.user_id === currentUserId)?.user.username;
      return currentUsername && mentions.includes(currentUsername);
    };

    const renderMessage = (message: ChatMessage, isReply = false) => {
      const isMentioned = isUserMentioned(message.content);
      const isCurrentUserMessage = message.user_id === currentUserId;
      const isParentMessage = messages.some(m => m.parent_id === message.id);
      const isImageExpanded = expandedImages.has(message.id);
      
      const messageContent = message.content.replace(/@(\w+)/g, (match, username) => {
        return `<span class="text-blue-500 dark:text-blue-400 font-medium cursor-pointer hover:underline" data-username="${username}">@${username}</span>`;
      });

      return (
        <div 
          key={message.id} 
          className={`flex items-start gap-3 group ${isReply ? 'ml-8 mt-2' : 'mt-4'} ${
            (isMentioned || (message.parent_id && isCurrentUserMessage)) 
              ? 'bg-blue-50/50 dark:bg-blue-900/20 p-3 rounded-lg -ml-3' 
              : ''
          }`}
        >
          <div 
            onClick={() => onUserClick(message.user.username)}
            className="cursor-pointer"
          >
            <UserAvatar 
              username={message.user.username}
              avatarUrl={message.user.avatar_url}
              size="xs"
              className="flex-shrink-0"
            />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-baseline gap-2 flex-wrap">
              <span 
                className="font-medium text-sm text-gray-900 dark:text-white cursor-pointer hover:underline"
                onClick={() => onUserClick(message.user.username)}
              >
                {message.user.username}
              </span>
              
              <div className="flex gap-1">
                {message.user.is_verified && <VerifiedBadge className="ml-0" />}
                {message.user.is_coach && <CoachBadge className="ml-0" />}
                {isAdmin(message.user.email) && <AdminBadge className="ml-0" />}
              </div>
              
              <span className="text-xs text-gray-500 dark:text-gray-400">
                {formatMessageTime(message.created_at)}
              </span>

              {message.parent_id && (
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  replied to{' '}
                  <span 
                    className="text-blue-500 dark:text-blue-400 cursor-pointer hover:underline"
                    onClick={() => {
                      const parentMessage = messages.find(m => m.id === message.parent_id);
                      if (parentMessage) {
                        onUserClick(parentMessage.user.username);
                      }
                    }}
                  >
                    @{messages.find(m => m.id === message.parent_id)?.user.username}
                  </span>
                </span>
              )}
            </div>
            <div className="relative">
              {/* Image content */}
              {message.image_url && (
                <div 
                  className={`mt-2 mb-2 rounded-lg overflow-hidden cursor-pointer ${
                    isImageExpanded ? 'max-w-full' : 'max-w-[300px] max-h-[200px]'
                  }`}
                  onClick={() => toggleImageExpand(message.id)}
                >
                  {message.image_url.toLowerCase().endsWith('.mp4') || 
                   message.image_url.toLowerCase().endsWith('.webm') || 
                   message.image_url.toLowerCase().endsWith('.mov') ? (
                    <video 
                      src={message.image_url} 
                      controls 
                      className={`rounded-lg ${isImageExpanded ? 'w-full' : 'max-h-[200px]'}`}
                    />
                  ) : (
                    <img 
                      src={message.image_url} 
                      alt="Shared media" 
                      className={`rounded-lg ${isImageExpanded ? 'w-full' : 'max-h-[200px] object-cover'}`}
                      onClick={(e) => handleImageClick(message.image_url!, e)}
                    />
                  )}
                </div>
              )}
              
              {/* Text content */}
              {message.content && message.content.trim() !== ' ' && (
                <p 
                  className="text-gray-700 dark:text-gray-300 text-sm mt-1 break-words"
                  dangerouslySetInnerHTML={{ 
                    __html: messageContent 
                  }}
                  onClick={(e) => {
                    const target = e.target as HTMLElement;
                    if (target.dataset.username) {
                      onUserClick(target.dataset.username);
                    }
                  }}
                />
              )}
              
              {message.reactions && message.reactions.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-1">
                  {message.reactions.map((reaction) => (
                    <button
                      key={reaction.emoji}
                      onClick={() => handleReactionClick(message.id, reaction.emoji, reaction.reacted)}
                      className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                        reaction.reacted
                          ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                      } hover:bg-opacity-80`}
                    >
                      <span className="mr-1">{reaction.emoji}</span>
                      <span>{reaction.count}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {!isReply && message.reply_count > 0 && (
              <button
                onClick={() => toggleThread(message.id)}
                className="mt-1 text-sm text-blue-500 dark:text-blue-400 hover:text-blue-600 dark:hover:text-blue-300 flex items-center"
              >
                {expandedThreads.has(message.id) ? (
                  <>
                    <ChevronUp size={16} className="mr-1" />
                    Hide {message.reply_count} {message.reply_count === 1 ? 'reply' : 'replies'}
                  </>
                ) : (
                  <>
                    <ChevronDown size={16} className="mr-1" />
                    Show {message.reply_count} {message.reply_count === 1 ? 'reply' : 'replies'}
                  </>
                )}
              </button>
            )}
          </div>
          
          <div className="flex items-center gap-1">
            {!isReply && (
              <button
                onClick={() => onReply(message.id)}
                className="opacity-0 group-hover:opacity-100 transition-opacity p-2 text-gray-400 hover:text-blue-500 dark:text-gray-500 dark:hover:text-blue-400 focus:opacity-100"
                title="Reply"
              >
                <CornerUpRight size={16} />
              </button>
            )}

            <div className="relative">
              <button
                onClick={() => setShowReactionPicker(message.id)}
                className="opacity-0 group-hover:opacity-100 transition-opacity p-2 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 focus:opacity-100"
              >
                <SmilePlus size={16} />
              </button>
              {showReactionPicker === message.id && (
                <ReactionPicker
                  onSelect={(emoji) => {
                    onAddReaction(message.id, emoji);
                    setShowReactionPicker(null);
                  }}
                  onClose={() => setShowReactionPicker(null)}
                />
              )}
            </div>
            
            {canDeleteMessage(message) && (
              <button
                onClick={() => onDeleteMessage(message.id)}
                disabled={deletingMessages[message.id]}
                className="opacity-0 group-hover:opacity-100 transition-opacity p-2 text-gray-400 hover:text-red-500 dark:text-gray-500 dark:hover:text-red-400 focus:opacity-100"
                aria-label="Delete message"
                title="Delete message"
              >
                {deletingMessages[message.id] ? (
                  <div className="w-4 h-4 border-2 border-red-500 dark:border-red-400 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Trash2 size={16} />
                )}
              </button>
            )}
          </div>
        </div>
      );
    };

    return (
      <>
        <div 
          ref={messagesContainer}
          className="flex-1 overflow-y-auto p-4 space-y-4"
        >
          {hasMoreMessages && (
            <div className="text-center mb-4">
              <button
                onClick={onLoadMoreMessages}
                disabled={loadingMoreMessages}
                className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 disabled:opacity-50"
              >
                {loadingMoreMessages ? (
                  <div className="w-4 h-4 mr-2 border-2 border-gray-400 dark:border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <ChevronUp size={16} className="mr-2" />
                )}
                {loadingMoreMessages ? 'Loading...' : 'Load older messages'}
              </button>
            </div>
          )}
          
          {messages.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">No messages yet</p>
              <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
                Send a message to start a conversation
              </p>
            </div>
          ) : (
            Object.values(messageThreads)
              .filter(thread => thread.parent && !thread.parent.parent_id)
              .map(thread => (
                <div key={thread.parent!.id}>
                  {renderMessage(thread.parent!)}
                  {expandedThreads.has(thread.parent!.id) && (
                    <div className="ml-4 border-l-2 border-gray-200 dark:border-gray-700">
                      {thread.replies
                        .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
                        .map(reply => renderMessage(reply, true))
                      }
                    </div>
                  )}
                </div>
              ))
          )}
          <div ref={messagesEnd} />
          
          {debugInfo && (
            <div className="mt-4 p-2 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-xs rounded">
              <p className="font-bold">Debug Info:</p>
              <p>{debugInfo}</p>
            </div>
          )}
        </div>

        {/* Full-screen image preview */}
        {previewImage && (
          <div 
            className="fixed inset-0 bg-black/80 flex items-center justify-center z-50"
            onClick={() => setPreviewImage(null)}
          >
            <div className="relative max-w-4xl max-h-[90vh] p-2">
              <button 
                className="absolute top-4 right-4 bg-black/50 text-white p-2 rounded-full hover:bg-black/70"
                onClick={() => setPreviewImage(null)}
              >
                <X size={24} />
              </button>
              <img 
                src={previewImage} 
                alt="Preview" 
                className="max-w-full max-h-[90vh] object-contain"
              />
            </div>
          </div>
        )}
      </>
    );
  }
);

MessageList.displayName = 'MessageList';