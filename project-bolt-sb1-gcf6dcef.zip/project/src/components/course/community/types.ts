export interface Channel {
  id: string;
  name: string;
  description?: string;
  is_private?: boolean;
}

export interface ChatMessage {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
  parent_id?: string;
  reply_count?: number;
  image_url?: string | null;
  user: {
    username: string;
    avatar_url: string | null;
    is_coach?: boolean;
    email?: string;
  };
  reactions?: Reaction[];
}

interface Reaction {
  emoji: string;
  count: number;
  reacted: boolean;
}

interface MessageListProps {
  messages: ChatMessage[];
  loadingMoreMessages: boolean;
  hasMoreMessages: boolean;
  onLoadMoreMessages: () => void;
  onUserClick: (username: string) => void;
  onDeleteMessage: (messageId: string) => void;
  onAddReaction: (messageId: string, emoji: string) => void;
  onRemoveReaction: (messageId: string, emoji: string) => void;
  onReply: (messageId: string) => void;
  canDeleteMessage: (message: ChatMessage) => boolean;
  formatMessageTime: (timestamp: string) => string;
  isAdmin: (email?: string) => boolean;
  deletingMessages: Record<string, boolean>;
  debugInfo: string | null;
  currentUserId: string;
  courseId: string;
}

interface MessageInputProps {
  value: string;
  onChange: (value: string) => void;
  onSend: (e: React.FormEvent, imageUrl?: string) => void;
  sending: boolean;
  channelName: string;
  disabled?: boolean;
  replyTo?: {
    id: string;
    username: string;
    content: string;
  } | null;
  onCancelReply?: () => void;
}

export interface MembersSidebarProps {
  members: Member[];
  loadingMembers: boolean;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onUserClick: (username: string) => void;
  onClose?: () => void;
  isAdmin: (email?: string) => boolean;
  isMobile?: boolean;
}

interface Member {
  id: string;
  username: string;
  avatar_url: string | null;
  is_coach?: boolean;
  email?: string;
}

interface ChannelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (name: string, description: string, isPrivate: boolean) => void;
  initialChannel?: Channel;
  title: string;
}