import React, { useEffect, useState } from 'react';
import { Lock } from 'lucide-react';
import { CHAR_LIMITS } from '../../../lib/constants';

interface ChannelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (name: string, description: string, isPrivate: boolean) => void;
  initialChannel?: {
    name: string;
    description?: string;
    is_private?: boolean;
  };
  title: string;
}

export function ChannelModal({ isOpen, onClose, onSubmit, initialChannel, title }: ChannelModalProps) {
  const [name, setName] = useState(initialChannel?.name || '');
  const [description, setDescription] = useState(initialChannel?.description || '');
  const [isPrivate, setIsPrivate] = useState(initialChannel?.is_private || false);
  const [nameError, setNameError] = useState('');
  const [descError, setDescError] = useState('');

  useEffect(() => {
    if (isOpen) {
      setName(initialChannel?.name || '');
      setDescription(initialChannel?.description || '');
      setIsPrivate(initialChannel?.is_private || false);
      setNameError('');
      setDescError('');
    }
  }, [isOpen, initialChannel]);

  const handleNameChange = (value: string) => {
    if (value.length <= CHAR_LIMITS.CHANNEL_NAME) {
      setName(value);
      setNameError('');
    } else {
      setNameError(`Channel name cannot exceed ${CHAR_LIMITS.CHANNEL_NAME} characters`);
    }
  };

  const handleDescriptionChange = (value: string) => {
    if (value.length <= CHAR_LIMITS.CHANNEL_DESCRIPTION) {
      setDescription(value);
      setDescError('');
    } else {
      setDescError(`Description cannot exceed ${CHAR_LIMITS.CHANNEL_DESCRIPTION} characters`);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
        <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">{title}</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Channel Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-gray-100 dark:bg-gray-700 border-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400"
              placeholder="Enter channel name"
            />
            {nameError && (
              <p className="mt-1 text-sm text-red-500">{nameError}</p>
            )}
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {name.length}/{CHAR_LIMITS.CHANNEL_NAME}
            </p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => handleDescriptionChange(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-gray-100 dark:bg-gray-700 border-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400 resize-none"
              rows={3}
              placeholder="Enter channel description"
            />
            {descError && (
              <p className="mt-1 text-sm text-red-500">{descError}</p>
            )}
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {description.length}/{CHAR_LIMITS.CHANNEL_DESCRIPTION}
            </p>
          </div>
          <div className="flex items-center">
            <input
              type="checkbox"
              id="private-channel"
              checked={isPrivate}
              onChange={(e) => setIsPrivate(e.target.checked)}
              className="h-4 w-4 text-blue-500 rounded border-gray-300 focus:ring-blue-500"
            />
            <label htmlFor="private-channel" className="ml-2 flex items-center text-sm text-gray-700 dark:text-gray-300">
              <Lock size={16} className="mr-1" />
              Coach-only messages
            </label>
          </div>
          <div className="flex justify-end gap-3 mt-6">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                if (!nameError && !descError) {
                  onSubmit(name, description, isPrivate);
                  onClose();
                }
              }}
              disabled={!name.trim() || !!nameError || !!descError}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg disabled:opacity-50"
            >
              {initialChannel ? 'Update' : 'Create'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}