import React, { useState, useRef, useEffect } from 'react';
import { ImageIcon, Send, Lock, X } from 'lucide-react';
import { supabase } from '../../../lib/supabase';

interface MessageInputProps {
  value: string;
  onChange: (value: string) => void;
  onSend: (e: React.FormEvent, imageUrl?: string) => void;
  sending: boolean;
  channelName: string;
  disabled?: boolean;
  replyTo?: {
    id: string;
    username: string;
    content: string;
  } | null;
  onCancelReply?: () => void;
}

export function MessageInput({ 
  value, 
  onChange, 
  onSend, 
  sending, 
  channelName, 
  disabled,
  replyTo,
  onCancelReply
}: MessageInputProps) {
  const [cursorPosition, setCursorPosition] = useState<number | null>(null);
  const [showMentionSuggestions, setShowMentionSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);

  useEffect(() => {
    if (replyTo && !value.includes(`@${replyTo.username}`)) {
      onChange(`@${replyTo.username} ${value}`);
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }
  }, [replyTo]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === '@') {
      setCursorPosition(e.currentTarget.selectionStart);
      setShowMentionSuggestions(true);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    
    // Check if file is an image or video
    if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
      alert('Please select an image or video file');
      return;
    }
    
    // Check file size (limit to 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    setImageFile(file);
    
    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    setImagePreview(null);
    setImageFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmitWithImage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if ((!value.trim() && !imageFile) || sending || uploadingImage) return;
    
    if (imageFile) {
      try {
        setUploadingImage(true);
        
        // Create a unique file path
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = `chat-media/${fileName}`;
        
        // Upload the file to Supabase Storage
        const { data, error: uploadError } = await supabase.storage
          .from('public')
          .upload(filePath, imageFile, {
            cacheControl: '3600',
            upsert: false
          });
        
        if (uploadError) throw uploadError;
        
        // Get the public URL
        const { data: urlData } = supabase.storage
          .from('public')
          .getPublicUrl(filePath);
        
        // Send the message with the image URL
        onSend(e, urlData.publicUrl);
        
        // Reset the image state
        setImagePreview(null);
        setImageFile(null);
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      } catch (err) {
        console.error('Error uploading image:', err);
        alert('Failed to upload image. Please try again.');
      } finally {
        setUploadingImage(false);
      }
    } else {
      // Just send the text message
      onSend(e);
    }
  };

  return (
    <div className="sticky bottom-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-4">
      {replyTo && (
        <div className="mb-2 flex items-start bg-gray-50 dark:bg-gray-700 rounded-lg p-2">
          <div className="flex-1 min-w-0">
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Replying to <span className="font-medium text-gray-900 dark:text-white">{replyTo.username}</span>
            </p>
            <p className="text-sm text-gray-700 dark:text-gray-300 truncate">{replyTo.content}</p>
          </div>
          <button
            onClick={onCancelReply}
            className="flex-shrink-0 ml-2 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
          >
            <X size={16} />
          </button>
        </div>
      )}

      {imagePreview && (
        <div className="mb-2 relative">
          <div className="relative rounded-lg overflow-hidden" style={{ maxHeight: '200px' }}>
            <img 
              src={imagePreview} 
              alt="Upload preview" 
              className="max-w-full h-auto max-h-[200px] object-contain bg-gray-100 dark:bg-gray-700"
            />
            <button
              onClick={handleRemoveImage}
              className="absolute top-2 right-2 bg-gray-800/70 text-white rounded-full p-1 hover:bg-gray-900/70"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      )}

      {disabled ? (
        <div className="flex items-center justify-center py-2 text-gray-500 dark:text-gray-400">
          <Lock size={16} className="mr-2" />
          Only coaches can send messages in this channel
        </div>
      ) : (
        <form onSubmit={handleSubmitWithImage} className="flex items-center gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageSelect}
            accept="image/*,video/*"
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
            disabled={uploadingImage || sending}
          >
            <ImageIcon size={20} />
          </button>
          <input
            ref={inputRef}
            type="text"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={replyTo ? `Reply to ${replyTo.username}...` : `Message #${channelName}`}
            className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full px-4 py-2 text-sm border-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400"
            disabled={uploadingImage || sending}
          />
          <button
            type="submit"
            disabled={sending || uploadingImage || (!value.trim() && !imageFile)}
            className="p-2 text-blue-500 dark:text-blue-400 hover:text-blue-600 dark:hover:text-blue-300 disabled:opacity-50"
          >
            {sending || uploadingImage ? (
              <div className="w-5 h-5 border-2 border-blue-500 dark:border-blue-400 border-t-transparent rounded-full animate-spin" />
            ) : (
              <Send size={20} />
            )}
          </button>
        </form>
      )}
    </div>
  );
}