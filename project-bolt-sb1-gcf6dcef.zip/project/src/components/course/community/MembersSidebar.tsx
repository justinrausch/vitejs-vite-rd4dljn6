import React from 'react';
import { Search, Users, X } from 'lucide-react';
import { UserAvatar } from '../../user/UserAvatar';
import { AdminBadge } from '../../user/AdminBadge';
import { CoachBadge } from '../../user/CoachBadge';
import { MembersSidebarProps } from './types';

export function MembersSidebar({
  members,
  loadingMembers,
  searchQuery,
  onSearchChange,
  onUserClick,
  onClose,
  isAdmin,
  isMobile = false
}: MembersSidebarProps) {
  const baseClasses = isMobile
    ? "fixed inset-0 bg-black/50 z-50 lg:hidden"
    : "w-80 bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 rounded-r-xl overflow-hidden hidden lg:flex lg:flex-col";

  const contentClasses = isMobile
    ? "absolute right-0 top-0 bottom-0 w-80 bg-white dark:bg-gray-800 shadow-xl animate-slide-in"
    : "";

  return (
    <div className={baseClasses}>
      <div className={contentClasses}>
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium text-gray-900 dark:text-white flex items-center">
                <Users size={20} className="mr-2" />
                Members ({members.length})
              </h3>
              {isMobile && (
                <button
                  onClick={onClose}
                  className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                >
                  <X size={20} />
                </button>
              )}
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500" size={16} />
              <input
                type="search"
                placeholder="Search members..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-gray-100 dark:bg-gray-700 border-none rounded-full text-sm focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-2">
            {loadingMembers ? (
              <div className="flex justify-center py-8">
                <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : members.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 dark:text-gray-400">No members found</p>
              </div>
            ) : (
              members.map((member) => (
                <button
                  key={member.id}
                  onClick={() => {
                    onUserClick(member.username);
                    if (isMobile && onClose) onClose();
                  }}
                  className="w-full text-left p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-750 flex items-center space-x-3"
                >
                  <UserAvatar 
                    username={member.username}
                    avatarUrl={member.avatar_url}
                    size="sm"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-gray-900 dark:text-white truncate">
                        {member.username}
                      </p>
                      <div className="flex gap-1">
                        {member.is_coach && <CoachBadge className="ml-0" />}
                        {isAdmin(member.email) && <AdminBadge className="ml-0" />}
                      </div>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}