function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function isValidUsername(username: string): boolean {
  // Only allow lowercase letters, numbers, and underscores
  const usernameRegex = /^[a-z0-9_]{3,30}$/;
  return usernameRegex.test(username);
}

function isValidPassword(password: string): boolean {
  return password.length >= 8;
}

function isValidUrl(url: string): boolean {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}

function validateTextLength(text: string, maxLength: number): boolean {
  return text.length <= maxLength;
}

function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

export function formatUsername(username: string): string {
  // Remove spaces and convert to lowercase
  return username.toLowerCase().replace(/\s+/g, '');
}