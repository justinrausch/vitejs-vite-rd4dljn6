import { supabase } from './supabase';

// Cache to store recent API responses
const apiCache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 60000; // 1 minute cache TTL

// Request queue to limit concurrent requests
const requestQueue: Array<() => Promise<void>> = [];
let isProcessingQueue = false;
const MAX_CONCURRENT_REQUESTS = 5;
let activeRequests = 0;

// Process the request queue
async function processQueue() {
  if (isProcessingQueue || requestQueue.length === 0 || activeRequests >= MAX_CONCURRENT_REQUESTS) {
    return;
  }

  isProcessingQueue = true;

  while (requestQueue.length > 0 && activeRequests < MAX_CONCURRENT_REQUESTS) {
    const request = requestQueue.shift();
    if (request) {
      activeRequests++;
      try {
        await request();
      } catch (error) {
        console.error('Error processing queued request:', error);
      } finally {
        activeRequests--;
      }
    }
  }

  isProcessingQueue = false;

  // If there are more requests and we have capacity, continue processing
  if (requestQueue.length > 0 && activeRequests < MAX_CONCURRENT_REQUESTS) {
    processQueue();
  }
}

// Generic API request function with caching, rate limiting, and queuing
export async function apiRequest<T>(
  method: 'GET' | 'POST' | 'PUT' | 'DELETE',
  endpoint: string,
  options?: {
    body?: any;
    params?: Record<string, any>;
    skipCache?: boolean;
    priority?: 'high' | 'normal' | 'low';
  }
): Promise<T> {
  const { body, params, skipCache = false, priority = 'normal' } = options || {};
  
  // Create a cache key based on the request details
  const cacheKey = `${method}:${endpoint}:${JSON.stringify(params)}:${JSON.stringify(body)}`;
  
  // Check cache for GET requests if not explicitly skipped
  if (method === 'GET' && !skipCache) {
    const cached = apiCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      return cached.data;
    }
  }

  // Create the request function
  const makeRequest = async (): Promise<T> => {
    let query = supabase.from(endpoint);

    // Apply method and parameters
    switch (method) {
      case 'GET':
        if (params) {
          // Apply filters, ordering, etc.
          Object.entries(params).forEach(([key, value]) => {
            if (key === 'select') {
              query = query.select(value as string);
            } else if (key === 'order') {
              const [column, direction] = (value as string).split(':');
              query = query.order(column, { ascending: direction === 'asc' });
            } else if (key === 'limit') {
              query = query.limit(value as number);
            } else if (key === 'eq') {
              const [column, val] = (value as string).split(':');
              query = query.eq(column, val);
            } else if (key === 'in') {
              const [column, values] = (value as string).split(':');
              query = query.in(column, (values as string).split(','));
            }
          });
        }
        break;
      case 'POST':
        query = query.insert(body);
        break;
      case 'PUT':
        if (params?.id) {
          query = query.update(body).eq('id', params.id);
        } else {
          throw new Error('ID is required for PUT requests');
        }
        break;
      case 'DELETE':
        if (params?.id) {
          query = query.delete().eq('id', params.id);
        } else {
          throw new Error('ID is required for DELETE requests');
        }
        break;
    }

    // Execute the query
    const { data, error } = await query;

    if (error) {
      console.error(`API request failed: ${method} ${endpoint}`, error);
      throw error;
    }

    // Cache successful GET responses
    if (method === 'GET') {
      apiCache.set(cacheKey, { data, timestamp: Date.now() });
    } else {
      // Invalidate related cache entries for non-GET requests
      for (const key of apiCache.keys()) {
        if (key.includes(endpoint)) {
          apiCache.delete(key);
        }
      }
    }

    return data as T;
  };

  // Add the request to the queue based on priority
  return new Promise<T>((resolve, reject) => {
    const requestFunction = async () => {
      try {
        const result = await makeRequest();
        resolve(result);
      } catch (error) {
        reject(error);
      }
    };

    if (priority === 'high') {
      // Add high priority requests to the front of the queue
      requestQueue.unshift(requestFunction);
    } else {
      // Add normal/low priority requests to the end of the queue
      requestQueue.push(requestFunction);
    }

    // Start processing the queue
    processQueue();
  });
}

// Clear the API cache
export function clearApiCache(): void {
  apiCache.clear();
}

// Invalidate specific cache entries
export function invalidateCache(endpoint: string): void {
  for (const key of apiCache.keys()) {
    if (key.includes(endpoint)) {
      apiCache.delete(key);
    }
  }
}