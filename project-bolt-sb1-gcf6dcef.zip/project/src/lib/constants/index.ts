// App constants
const APP_NAME = 'Action Sports Marketplace';
const APP_DESCRIPTION = 'Learn from the best athletes in action sports';

// Auth constants
const AUTH_COOKIE_NAME = 'sb-auth-token';
const AUTH_EXPIRY_DAYS = 30;

// Video constants
const REQUIRED_WATCH_PERCENTAGE = 70;
const VIDEO_QUALITY = 80;

// Image constants
const DEFAULT_IMAGE_QUALITY = 80;
const AVATAR_SIZES = {
  xs: 24,
  sm: 32,
  md: 40,
  lg: 64,
  xl: 96
} as const;

// Course constants
const COURSE_CATEGORIES = [
  'MTB',
  'BMX',
  'Skateboarding',
  'Surfing',
  'Snowboarding',
  'Skiing'
] as const;

// Character limits
export const CHAR_LIMITS = {
  COURSE_TITLE: 30,
  COURSE_TAGLINE: 60,
  COURSE_DESCRIPTION: 180,
  CHANNEL_NAME: 30,
  CHANNEL_DESCRIPTION: 200,
  USERNAME: 30,
  FULL_NAME: 30,
  PROFILE_DESCRIPTION: 150
} as const;

// Pagination constants
const DEFAULT_PAGE_SIZE = 20;
const DEFAULT_CHAT_PAGE_SIZE = 50;

// API endpoints
const API_ENDPOINTS = {
  COURSES: '/courses',
  LESSONS: '/lessons',
  USERS: '/users',
  CHAT: '/chat',
  RANKINGS: '/rankings'
} as const;