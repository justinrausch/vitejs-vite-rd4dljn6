import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Please click "Connect to Supabase" to set up your project.');
}

// Rate limiting configuration
const MAX_RETRIES = 3;
const INITIAL_BACKOFF_MS = 300;

// Create a custom fetch function with rate limiting and exponential backoff
const customFetch = async (url: string, options: RequestInit): Promise<Response> => {
  let retries = 0;
  let backoffTime = INITIAL_BACKOFF_MS;

  while (true) {
    try {
      const response = await fetch(url, options);
      
      // If the request was successful or it's not a rate limit error, return the response
      if (response.status !== 429) {
        return response;
      }
      
      // If we've reached the maximum number of retries, throw an error
      if (retries >= MAX_RETRIES) {
        throw new Error(`Request failed after ${MAX_RETRIES} retries due to rate limiting`);
      }
      
      // Calculate backoff time with exponential increase and some jitter
      backoffTime = backoffTime * 2 * (0.9 + Math.random() * 0.2);
      
      // Wait for the backoff period
      await new Promise(resolve => setTimeout(resolve, backoffTime));
      
      // Increment retry counter
      retries++;
    } catch (error) {
      if (retries >= MAX_RETRIES) {
        throw error;
      }
      
      // For network errors, also apply backoff
      backoffTime = backoffTime * 2 * (0.9 + Math.random() * 0.2);
      await new Promise(resolve => setTimeout(resolve, backoffTime));
      retries++;
    }
  }
};

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    storageKey: 'sb-auth-token',
    storage: localStorage,
    autoRefreshToken: true,
    detectSessionInUrl: true
  },
  db: {
    schema: 'public'
  },
  global: {
    headers: {
      'Prefer': 'return=minimal'
    },
    fetch: customFetch
  }
});