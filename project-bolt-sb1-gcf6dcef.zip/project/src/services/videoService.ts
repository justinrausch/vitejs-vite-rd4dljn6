import { supabase } from '../lib/supabase';

/**
 * Uploads a video file for a lesson
 */
async function uploadLessonVideo(
  courseId: string,
  lessonId: string,
  file: File
): Promise<string> {
  try {
    // Create a unique file path
    const fileExt = file.name.split('.').pop();
    const fileName = `${lessonId}-${Date.now()}.${fileExt}`;
    const filePath = `videos/${fileName}`;
    
    // Upload the file to Supabase Storage
    const { error: uploadError } = await supabase.storage
      .from('lessons')
      .upload(filePath, file);
    
    if (uploadError) throw uploadError;
    
    // Get the public URL
    const { data } = supabase.storage
      .from('lessons')
      .getPublicUrl(filePath);
    
    // Update the lesson with the new video URL
    const { error: updateError } = await supabase
      .from('course_lessons')
      .update({ video_url: data.publicUrl })
      .eq('id', lessonId)
      .eq('course_id', courseId);
    
    if (updateError) throw updateError;
    
    return data.publicUrl;
  } catch (error) {
    console.error('Error uploading video:', error);
    throw error;
  }
}

/**
 * Gets the video URL for a lesson
 */
export async function getLessonVideo(lessonId: string): Promise<string | null> {
  try {
    const { data, error } = await supabase
      .from('course_lessons')
      .select('video_url')
      .eq('id', lessonId)
      .single();

    if (error) throw error;
    return data?.video_url || null;
  } catch (error) {
    console.error('Error getting lesson video:', error);
    throw error;
  }
}

/**
 * Deletes a video from a lesson
 */
async function deleteLessonVideo(
  courseId: string,
  lessonId: string,
  videoUrl: string
): Promise<void> {
  try {
    // Extract the file path from the URL
    const url = new URL(videoUrl);
    const filePath = url.pathname.split('/').pop();
    
    if (!filePath) throw new Error('Invalid video URL');

    // Delete the file from storage
    const { error: deleteError } = await supabase.storage
      .from('lessons')
      .remove([`videos/${filePath}`]);
    
    if (deleteError) throw deleteError;
    
    // Update the lesson to remove the video URL
    const { error: updateError } = await supabase
      .from('course_lessons')
      .update({ video_url: null })
      .eq('id', lessonId)
      .eq('course_id', courseId);
    
    if (updateError) throw updateError;
  } catch (error) {
    console.error('Error deleting video:', error);
    throw error;
  }
}