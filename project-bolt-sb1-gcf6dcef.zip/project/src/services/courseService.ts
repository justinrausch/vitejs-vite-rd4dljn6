import { supabase } from '../lib/supabase';
import { CourseWithBasicInfo, Course } from '../types/course';

/**
 * Fetches all courses with basic information
 */
async function getAllCourses(): Promise<CourseWithBasicInfo[]> {
  try {
    const { data, error } = await supabase
      .from('courses')
      .select(`
        id,
        title,
        description,
        price,
        image_url,
        instructor_id,
        profiles!courses_instructor_id_fkey (
          id,
          username,
          avatar_url
        ),
        course_tags (
          tag
        )
      `);

    if (error) throw error;

    return data.map(course => ({
      id: course.id,
      title: course.title,
      description: course.description,
      price: course.price,
      image_url: course.image_url,
      instructor: {
        id: course.profiles.id,
        username: course.profiles.username,
        avatar_url: course.profiles.avatar_url
      },
      tags: course.course_tags.map((tag: any) => tag.tag)
    }));
  } catch (error) {
    console.error('Error fetching courses:', error);
    throw error;
  }
}

/**
 * Fetches a course by ID with full details
 */
export async function getCourseById(id: string): Promise<Course> {
  try {
    const { data, error } = await supabase
      .from('courses')
      .select(`
        *,
        profiles!courses_instructor_id_fkey (
          id,
          username,
          avatar_url,
          description,
          is_verified
        ),
        course_tags (
          tag
        ),
        course_chapters (
          id,
          title,
          position,
          course_lessons (
            id,
            title,
            video_url,
            position
          )
        ),
        course_plans (
          id,
          title,
          price,
          renewal_period,
          features,
          stripe_price_id
        )
      `)
      .eq('id', id)
      .single();

    if (error) throw error;

    // Get member count
    const { count: memberCount } = await supabase
      .from('enrollments')
      .select('*', { count: 'exact', head: true })
      .eq('course_id', id);

    return {
      ...data,
      instructor: data.profiles,
      tags: data.course_tags.map((t: any) => t.tag),
      chapters: data.course_chapters.map((chapter: any) => ({
        ...chapter,
        lessons: chapter.course_lessons
      })),
      plans: data.course_plans,
      member_count: memberCount || 0
    };
  } catch (error) {
    console.error('Error fetching course:', error);
    throw error;
  }
}

/**
 * Fetches completed lessons for a user in a course
 */
export async function getCompletedLessons(userId: string, courseId: string): Promise<string[]> {
  try {
    const { data, error } = await supabase
      .from('completed_lessons')
      .select('lesson_id')
      .eq('user_id', userId)
      .eq('course_id', courseId);

    if (error) throw error;
    return data?.map(item => item.lesson_id) || [];
  } catch (error) {
    console.error('Error fetching completed lessons:', error);
    return [];
  }
}

/**
 * Marks a lesson as completed
 */
export async function completeLesson(userId: string, courseId: string, lessonId: string): Promise<void> {
  try {
    // First check if the lesson is already completed
    const { data: existing, error: checkError } = await supabase
      .from('completed_lessons')
      .select('id')
      .eq('user_id', userId)
      .eq('lesson_id', lessonId)
      .maybeSingle();

    if (checkError) throw checkError;

    // If already completed, do nothing
    if (existing) return;

    // Insert new completion record
    const { error } = await supabase
      .from('completed_lessons')
      .insert({
        user_id: userId,
        course_id: courseId,
        lesson_id: lessonId,
        completed_at: new Date().toISOString()
      });

    if (error) throw error;
  } catch (err) {
    console.error('Error completing lesson:', err);
    throw err;
  }
}

/**
 * Marks a lesson as incomplete
 */
export async function uncompleteLesson(userId: string, courseId: string, lessonId: string): Promise<void> {
  try {
    // First get the completion record to ensure we have the course_id
    const { data: completion, error: fetchError } = await supabase
      .from('completed_lessons')
      .select('id')
      .eq('user_id', userId)
      .eq('lesson_id', lessonId)
      .eq('course_id', courseId)
      .single();

    if (fetchError) throw fetchError;

    if (!completion) {
      console.log('No completion record found to remove');
      return;
    }

    // Delete the completion record
    const { error } = await supabase
      .from('completed_lessons')
      .delete()
      .match({
        user_id: userId,
        lesson_id: lessonId,
        course_id: courseId
      });

    if (error) {
      console.error('Database error when uncompleting lesson:', error);
      throw error;
    }
  } catch (err) {
    console.error('Error uncompleting lesson:', err);
    throw err;
  }
}