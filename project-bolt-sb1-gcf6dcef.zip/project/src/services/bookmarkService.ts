import { supabase } from '../lib/supabase';

/**
 * Gets all bookmarked lessons for a user in a course
 */
export async function getBookmarkedLessons(userId: string, courseId: string): Promise<string[]> {
  try {
    const { data, error } = await supabase
      .from('bookmarked_lessons')
      .select('lesson_id')
      .eq('user_id', userId)
      .eq('course_id', courseId);

    if (error) throw error;
    return data?.map(item => item.lesson_id) || [];
  } catch (error) {
    console.error('Error fetching bookmarked lessons:', error);
    return [];
  }
}

/**
 * Bookmarks a lesson
 */
export async function bookmarkLesson(userId: string, courseId: string, lessonId: string): Promise<void> {
  try {
    // First check if already bookmarked
    const { data: existing, error: checkError } = await supabase
      .from('bookmarked_lessons')
      .select('id')
      .eq('user_id', userId)
      .eq('lesson_id', lessonId)
      .maybeSingle();

    if (checkError) throw checkError;

    // If already bookmarked, do nothing
    if (existing) return;

    // Add new bookmark
    const { error } = await supabase
      .from('bookmarked_lessons')
      .insert({
        user_id: userId,
        course_id: courseId,
        lesson_id: lessonId
      });

    if (error) throw error;
  } catch (error) {
    console.error('Error bookmarking lesson:', error);
    throw error;
  }
}

/**
 * Removes a lesson bookmark
 */
export async function unbookmarkLesson(userId: string, lessonId: string): Promise<void> {
  try {
    const { error } = await supabase
      .from('bookmarked_lessons')
      .delete()
      .match({
        user_id: userId,
        lesson_id: lessonId
      });

    if (error) throw error;
  } catch (error) {
    console.error('Error removing bookmark:', error);
    throw error;
  }
}