import { supabase } from '../lib/supabase';
import { LessonData } from '../types/lesson';

/**
 * Fetches a lesson by ID
 */
export async function fetchLessonById(lessonId: string): Promise<LessonData> {
  try {
    const { data, error } = await supabase
      .from('course_lessons')
      .select(`
        *,
        courses!inner (
          id,
          title
        )
      `)
      .eq('id', lessonId)
      .single();

    if (error) throw error;

    return {
      id: data.id,
      title: data.title,
      video_url: data.video_url,
      chapter_id: data.chapter_id,
      course_id: data.courses.id,
      course_title: data.courses.title,
      lecture_notes: data.lecture_notes
    };
  } catch (error) {
    console.error('Error fetching lesson:', error);
    throw error;
  }
}

/**
 * Checks if a user is the instructor of a course
 */
export async function checkInstructorStatus(userId: string, courseId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('courses')
      .select('instructor_id')
      .eq('id', courseId)
      .maybeSingle();

    if (error) throw error;
    return data?.instructor_id === userId;
  } catch (error) {
    console.error('Error checking instructor status:', error);
    return false;
  }
}

/**
 * Updates a lesson's title
 */
export async function updateLessonTitle(lessonId: string, title: string): Promise<void> {
  try {
    const { error } = await supabase
      .from('course_lessons')
      .update({ title })
      .eq('id', lessonId);

    if (error) throw error;
  } catch (error) {
    console.error('Error updating lesson title:', error);
    throw error;
  }
}

/**
 * Updates a lesson's notes
 */
export async function updateLessonNotes(lessonId: string, notes: string): Promise<void> {
  try {
    const { error } = await supabase
      .from('course_lessons')
      .update({ lecture_notes: notes })
      .eq('id', lessonId);

    if (error) throw error;
  } catch (error) {
    console.error('Error updating lesson notes:', error);
    throw error;
  }
}

/**
 * Updates a lesson's video URL
 */
export async function updateLessonVideo(lessonId: string, videoUrl: string): Promise<void> {
  try {
    const { error } = await supabase
      .from('course_lessons')
      .update({ video_url: videoUrl })
      .eq('id', lessonId);

    if (error) throw error;
  } catch (error) {
    console.error('Error updating lesson video:', error);
    throw error;
  }
}

/**
 * Checks if a lesson is completed by a user
 */
export async function checkLessonCompletion(userId: string, lessonId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('completed_lessons')
      .select('id')
      .eq('user_id', userId)
      .eq('lesson_id', lessonId)
      .maybeSingle();

    if (error) throw error;
    return !!data;
  } catch (error) {
    console.error('Error checking lesson completion:', error);
    return false;
  }
}

/**
 * Checks if a lesson is bookmarked by a user
 */
export async function checkLessonBookmark(userId: string, lessonId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('bookmarked_lessons')
      .select('id')
      .eq('user_id', userId)
      .eq('lesson_id', lessonId)
      .maybeSingle();

    if (error) throw error;
    return !!data;
  } catch (error) {
    console.error('Error checking lesson bookmark:', error);
    return false;
  }
}