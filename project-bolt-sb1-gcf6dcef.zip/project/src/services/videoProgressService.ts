import { supabase } from '../lib/supabase';

export async function saveVideoProgress(
  userId: string,
  courseId: string,
  lessonId: string,
  progress: number,
  watchedSeconds: number
): Promise<void> {
  try {
    // Round the progress and watchedSeconds to integers
    const roundedProgress = Math.round(progress);
    const roundedWatchedSeconds = Math.round(watchedSeconds);

    const { data: existing, error: checkError } = await supabase
      .from('lesson_progress')
      .select('id')
      .eq('user_id', userId)
      .eq('lesson_id', lessonId)
      .maybeSingle();

    if (checkError) throw checkError;

    if (existing) {
      // Update existing progress
      const { error: updateError } = await supabase
        .from('lesson_progress')
        .update({
          progress: roundedProgress,
          watched_seconds: roundedWatchedSeconds,
          last_watched_at: new Date().toISOString()
        })
        .eq('id', existing.id);

      if (updateError) throw updateError;
    } else {
      // Insert new progress
      const { error: insertError } = await supabase
        .from('lesson_progress')
        .insert({
          user_id: userId,
          course_id: courseId,
          lesson_id: lessonId,
          progress: roundedProgress,
          watched_seconds: roundedWatchedSeconds,
          last_watched_at: new Date().toISOString()
        });

      if (insertError) throw insertError;
    }
  } catch (error) {
    console.error('Error saving video progress:', error);
    throw error;
  }
}

export async function getVideoProgress(userId: string, lessonId: string) {
  try {
    const { data, error } = await supabase
      .from('lesson_progress')
      .select('progress, watched_seconds')
      .eq('user_id', userId)
      .eq('lesson_id', lessonId)
      .maybeSingle();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error getting video progress:', error);
    return null;
  }
}

export async function getLessonProgressForCourse(userId: string, courseId: string): Promise<Record<string, number>> {
  try {
    const { data, error } = await supabase
      .from('lesson_progress')
      .select('lesson_id, progress')
      .eq('user_id', userId)
      .eq('course_id', courseId);

    if (error) throw error;

    // Convert array of progress records to a map of lessonId -> progress
    return (data || []).reduce((acc, item) => {
      acc[item.lesson_id] = item.progress;
      return acc;
    }, {} as Record<string, number>);
  } catch (error) {
    console.error('Error getting lesson progress for course:', error);
    return {};
  }
}