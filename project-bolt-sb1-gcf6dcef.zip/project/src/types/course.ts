interface Lesson {
  id: string;
  title: string;
  video_url: string | null;
  position: number;
}

export interface Chapter {
  id: string;
  title: string;
  position: number;
  lessons: Lesson[];
}

interface Plan {
  id: string;
  title: string;
  price: number;
  renewal_period: string | null;
  features: string[];
  lessons_access: boolean;
  community_access: boolean;
  coaching_access: boolean;
  rankings_access: boolean;
}

interface CourseMedia {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail_url?: string;
  position: number;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  image_url: string;
  logo_url?: string | null;
  instructor: {
    id: string;
    username: string;
    avatar_url: string | null;
    description?: string;
    is_verified?: boolean;
    full_name?: string;
  };
  tags: string[];
  chapters: Chapter[];
  plans: Plan[];
  member_count?: number;
  disciplines?: string[];
  course_media?: CourseMedia[];
}

export type CourseWithBasicInfo = Pick<Course, 'id' | 'title' | 'description' | 'price' | 'image_url' | 'logo_url' | 'instructor'> & {
  tags: string[];
  member_count?: number;
  disciplines?: string[];
  averageRating?: number;
  reviewCount?: number;
};