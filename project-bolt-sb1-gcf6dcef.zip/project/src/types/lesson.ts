export interface LessonData {
  id: string;
  title: string;
  video_url: string | null;
  chapter_id: string;
  course_id: string;
  course_title: string;
  lecture_notes?: string;
}

export interface LessonHeaderProps {
  courseTitle: string;
  lessonTitle: string;
  isInstructor: boolean;
  onBack: () => void;
  onEdit: (newTitle: string) => void;
}

export interface LessonVideoProps {
  lessonId: string;
  courseId: string;
  videoUrl: string | null;
  title: string;
  isInstructor: boolean;
  onVideoUpload: (url: string) => void;
  initialProgress?: number;
  initialTime?: number;
  onProgressUpdate?: (progress: number) => void;
  requiredWatchPercentage?: number;
  onRequiredWatchReached?: () => void;
}

export interface LessonNotesProps {
  notes: string;
  isInstructor: boolean;
  onSave: (notes: string) => void;
}

export interface LessonProgressProps {
  progress: number;
  isCompleted: boolean;
  canComplete: boolean;
  requiredPercentage: number;
}

export interface LessonActionsProps {
  isCompleted: boolean;
  isBookmarked: boolean;
  canComplete: boolean;
  onComplete: () => void;
  onBookmark: () => void;
  completing: boolean;
  bookmarking: boolean;
}