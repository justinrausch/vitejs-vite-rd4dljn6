export interface UserProfile {
  id: string;
  username: string;
  full_name?: string;
  avatar_url?: string;
  description?: string;
  instagram?: string;
  youtube?: string;
  is_coach?: boolean;
  is_verified?: boolean;
  email?: string;
}