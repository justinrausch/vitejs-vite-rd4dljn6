export interface Notification {
  id: string;
  title: string;
  message: string;
  type: NotificationType;
  created_at: string;
  read: boolean;
  data?: {
    courseId?: string;
    lessonId?: string;
    userId?: string;
    commentId?: string;
    messageId?: string;
    username?: string;
    avatarUrl?: string | null;
  };
}

export type NotificationType = 
  // Course notifications
  | 'new_message'
  | 'new_lesson'
  | 'achievement'
  
  // System notifications
  | 'course_approved'
  | 'course_denied'
  | 'course_update_approved'
  | 'course_update_denied'
  
  // Social notifications
  | 'comment_like'
  | 'direct_message'
  | 'message_like';