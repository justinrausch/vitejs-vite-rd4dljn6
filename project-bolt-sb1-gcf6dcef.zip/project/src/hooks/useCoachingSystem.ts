import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface Student {
  id: string;
  username: string;
  avatar_url: string | null;
  last_message_at: string;
  unread_count: number;
}

interface Message {
  id: string;
  content: string;
  created_at: string;
  sender_id: string;
  lesson_id?: string;
  lesson_title?: string;
  sender: {
    username: string;
    avatar_url: string | null;
  };
  image_url?: string | null;
}

export function useCoachingSystem(courseId: string) {
  const { user } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [sendingMessage, setSendingMessage] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasMoreMessages, setHasMoreMessages] = useState(true);
  const [oldestMessageDate, setOldestMessageDate] = useState<string | null>(null);
  const [processedMessageIds] = useState(new Set<string>());

  const fetchStudents = useCallback(async () => {
    try {
      setLoading(true);
      const { data: enrollments, error: enrollmentsError } = await supabase
        .from('enrollments')
        .select(`
          user_id,
          profiles!inner (
            id,
            username,
            avatar_url
          )
        `)
        .eq('course_id', courseId);

      if (enrollmentsError) throw enrollmentsError;

      const studentsData = await Promise.all(
        enrollments.map(async (enrollment) => {
          // Use maybeSingle() instead of single() to handle no messages case
          const { data: latestMessage } = await supabase
            .from('coach_messages')
            .select('created_at')
            .eq('course_id', courseId)
            .eq('student_id', enrollment.user_id)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();

          const { count } = await supabase
            .from('coach_messages')
            .select('*', { count: 'exact', head: true })
            .eq('course_id', courseId)
            .eq('student_id', enrollment.user_id)
            .eq('sender_id', enrollment.user_id)
            .eq('read', false);

          return {
            id: enrollment.profiles.id,
            username: enrollment.profiles.username,
            avatar_url: enrollment.profiles.avatar_url,
            last_message_at: latestMessage?.created_at || '',
            unread_count: count || 0
          };
        })
      );

      setStudents(studentsData.sort((a, b) => {
        if (!a.last_message_at) return 1;
        if (!b.last_message_at) return -1;
        return new Date(b.last_message_at).getTime() - new Date(a.last_message_at).getTime();
      }));
    } catch (err) {
      console.error('Error fetching students:', err);
      setError('Failed to load students');
    } finally {
      setLoading(false);
    }
  }, [courseId]);

  const fetchMessages = useCallback(async (studentId: string, before?: string) => {
    try {
      setLoading(true);
      
      let query = supabase
        .from('coach_messages')
        .select(`
          id,
          content,
          created_at,
          sender_id,
          lesson_id,
          image_url,
          sender:sender_id (
            username,
            avatar_url
          ),
          course_lessons:lesson_id (
            title
          )
        `)
        .eq('course_id', courseId)
        .eq('student_id', studentId)
        .order('created_at', { ascending: false })
        .limit(15);

      if (before) {
        query = query.lt('created_at', before);
      }

      const { data, error } = await query;
      
      if (error) throw error;

      const formattedMessages = data.map(msg => ({
        id: msg.id,
        content: msg.content,
        created_at: msg.created_at,
        sender_id: msg.sender_id,
        lesson_id: msg.lesson_id,
        lesson_title: msg.course_lessons?.title,
        image_url: msg.image_url,
        sender: {
          username: msg.sender.username,
          avatar_url: msg.sender.avatar_url
        }
      })).reverse();

      if (before) {
        setMessages(prev => [...formattedMessages, ...prev]);
      } else {
        setMessages(formattedMessages);
      }

      setHasMoreMessages(data.length === 15);
      if (data.length > 0) {
        setOldestMessageDate(data[data.length - 1].created_at);
      }

      data.forEach(msg => processedMessageIds.add(msg.id));
    } catch (err) {
      console.error('Error fetching messages:', err);
      setError('Failed to load messages');
    } finally {
      setLoading(false);
    }
  }, [courseId]);

  useEffect(() => {
    if (user) {
      fetchStudents();
    }
  }, [user, fetchStudents]);

  useEffect(() => {
    if (selectedStudent) {
      fetchMessages(selectedStudent.id);
      setupRealtimeSubscription(selectedStudent.id);
    }
  }, [selectedStudent]);

  const setupRealtimeSubscription = (studentId: string) => {
    const subscription = supabase.channel(`coach-messages-${courseId}-${studentId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'coach_messages',
          filter: `course_id=eq.${courseId}:student_id=eq.${studentId}`
        },
        async (payload) => {
          if (processedMessageIds.has(payload.new.id)) {
            return;
          }

          processedMessageIds.add(payload.new.id);

          const { data: senderData } = await supabase
            .from('profiles')
            .select('username, avatar_url')
            .eq('id', payload.new.sender_id)
            .single();

          if (senderData) {
            const newMessage: Message = {
              id: payload.new.id,
              content: payload.new.content,
              created_at: payload.new.created_at,
              sender_id: payload.new.sender_id,
              lesson_id: payload.new.lesson_id,
              lesson_title: null,
              image_url: payload.new.image_url,
              sender: {
                username: senderData.username,
                avatar_url: senderData.avatar_url
              }
            };

            setMessages(prev => [...prev, newMessage]);
          }
        }
      )
      .subscribe();

    return () => subscription.unsubscribe();
  };

  const handleSendMessage = async (content: string, studentId: string) => {
    if (!user || !content.trim() || sendingMessage) return;
    
    const tempId = `temp-${Date.now()}`;
    const messageContent = content.trim();

    // Create optimistic message
    const optimisticMessage: Message = {
      id: tempId,
      content: messageContent,
      created_at: new Date().toISOString(),
      sender_id: user.id,
      sender: {
        username: user.user_metadata?.username || user.email?.split('@')[0] || 'Coach',
        avatar_url: user.user_metadata?.avatar_url
      }
    };

    // Add optimistic message
    setMessages(prev => [...prev, optimisticMessage]);
    
    try {
      setSendingMessage(true);
      
      const { data, error } = await supabase
        .from('coach_messages')
        .insert({
          course_id: courseId,
          student_id: studentId,
          sender_id: user.id,
          content: messageContent
        })
        .select()
        .single();

      if (error) throw error;

      // Add message ID to processed set
      processedMessageIds.add(data.id);
      
      // Replace optimistic message with real one
      setMessages(prev => 
        prev.map(msg => 
          msg.id === tempId ? { ...msg, id: data.id } : msg
        )
      );
      
      // Update student's last message time
      setStudents(prev => prev.map(student => 
        student.id === studentId 
          ? { ...student, last_message_at: new Date().toISOString() }
          : student
      ));
    } catch (err) {
      console.error('Error sending message:', err);
      // Remove optimistic message on error
      setMessages(prev => prev.filter(msg => msg.id !== tempId));
    } finally {
      setSendingMessage(false);
    }
  };

  const loadMoreMessages = async () => {
    if (!selectedStudent || !oldestMessageDate || !hasMoreMessages) return;
    await fetchMessages(selectedStudent.id, oldestMessageDate);
  };

  return {
    students,
    selectedStudent,
    messages,
    loading,
    sendingMessage,
    error,
    hasMoreMessages,
    setSelectedStudent,
    handleSendMessage,
    loadMoreMessages,
    refreshStudents: fetchStudents
  };
}