import { useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { useNotifications } from '../contexts/NotificationContext';

/**
 * Hook to handle real-time notifications
 */
export function useNotificationHandler() {
  const { user } = useAuth();
  const { refreshNotifications } = useNotifications();

  useEffect(() => {
    if (!user) return;

    // Set up real-time subscription for notifications
    const subscription = supabase
      .channel('public:notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          // Refresh notifications when a new one is created
          refreshNotifications();
          
          // Show browser notification if supported
          if (Notification.permission === 'granted') {
            const { title, message } = payload.new;
            new Notification(title, { body: message });
          }
        }
      )
      .subscribe();

    // Request notification permission if not already granted
    if (Notification.permission !== 'granted' && Notification.permission !== 'denied') {
      Notification.requestPermission();
    }

    return () => {
      subscription.unsubscribe();
    };
  }, [user, refreshNotifications]);

  return null;
}