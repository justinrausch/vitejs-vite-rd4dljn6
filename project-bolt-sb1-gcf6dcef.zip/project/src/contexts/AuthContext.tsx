import React, { createContext, useContext, useEffect, useState } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, fullName: string, username: string) => Promise<void>;
  signOut: () => Promise<void>;
  userProfile: {
    is_coach?: boolean;
    [key: string]: any;
  } | null;
  refreshUserProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<{ is_coach?: boolean; [key: string]: any } | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<Error | null>(null);

  useEffect(() => {
    // Handle OAuth redirect - this is critical for Google/Apple sign-in
    const handleOAuthRedirect = async () => {
      // Check if we have a hash in the URL (from OAuth redirect)
      if (window.location.hash) {
        const { data, error } = await supabase.auth.getSessionFromUrl({
          // Use the current site URL as the redirect URL
          redirectTo: window.location.origin
        });
        
        if (error) {
          console.error('Error recovering session:', error);
        } else if (data?.session) {
          // Successfully recovered session from URL
          setUser(data.session.user);
          await fetchUserProfile(data.session.user.id);
          
          // Clean up the URL by removing the hash
          window.history.replaceState({}, document.title, window.location.pathname);
        }
      }
    };

    // Initialize auth state from local storage if available
    const session = localStorage.getItem('sb-auth-token');
    if (session) {
      try {
        const parsedSession = JSON.parse(session);
        if (parsedSession?.user) {
          setUser(parsedSession.user);
          fetchUserProfile(parsedSession.user.id);
        }
      } catch (err) {
        console.error('Error parsing stored session:', err);
        localStorage.removeItem('sb-auth-token');
      }
    }

    // Check active sessions and sets the user
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchUserProfile(session.user.id);
      } else {
        setLoading(false);
      }
    });

    // Listen for changes on auth state
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchUserProfile(session.user.id);
      } else {
        setUserProfile(null);
        setLoading(false);
      }
    });

    // Handle OAuth redirect on initial load
    handleOAuthRedirect();

    return () => subscription.unsubscribe();
  }, []);

  const fetchUserProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();
      
      if (error) throw error;
      setUserProfile(data);
    } catch (error) {
      console.error('Error fetching user profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const refreshUserProfile = async () => {
    if (!user) return;
    await fetchUserProfile(user.id);
  };

  const signIn = async (email: string, password: string) => {
    try {
      setAuthError(null);
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
    } catch (err: any) {
      console.error('Sign in error:', err);
      setAuthError(err);
      throw err;
    }
  };

  const signUp = async (email: string, password: string, fullName: string, username: string) => {
    try {
      setAuthError(null);
      
      // First check if username is already taken
      const { data: existingUser, error: checkError } = await supabase
        .from('profiles')
        .select('username')
        .eq('username', username)
        .maybeSingle();
      
      if (checkError) throw checkError;
      
      if (existingUser) {
        throw new Error('Username is already taken. Please choose another one.');
      }
      
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
            username,
          },
        },
      });
      if (error) throw error;
    } catch (err: any) {
      console.error('Sign up error:', err);
      setAuthError(err);
      throw err;
    }
  };

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      localStorage.removeItem('sb-auth-token');
    } catch (err: any) {
      console.error('Sign out error:', err);
      setAuthError(err);
      throw err;
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut, userProfile, refreshUserProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}