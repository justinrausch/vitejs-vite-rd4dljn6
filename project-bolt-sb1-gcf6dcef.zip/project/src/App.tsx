import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { NotificationProvider } from './contexts/NotificationContext';
import { PageTransition } from './components/PageTransition';
import { Home } from './pages/Home';
import { Discover } from './pages/Discover';
import { CoursePreview } from './pages/CoursePreview';
import Course from './pages/Course';
import { Lesson } from './pages/Lesson';
import { Notifications } from './pages/Notifications';
import { Profile } from './pages/Profile';
import { UserProfile } from './pages/UserProfile';
import { Settings } from './pages/Settings';
import { EditProfile } from './pages/EditProfile';
import { ChangeEmail } from './pages/settings/ChangeEmail';
import { ChangePassword } from './pages/settings/ChangePassword';
import { Language } from './pages/settings/Language';
import { Notifications as NotificationSettings } from './pages/settings/Notifications';
import { Courses } from './pages/settings/Courses';
import { Timezone } from './pages/settings/Timezone';
import { Privacy } from './pages/settings/Privacy';
import { ConnectedAccounts } from './pages/settings/ConnectedAccounts';
import { Subscriptions } from './pages/settings/Subscriptions';
import { Help } from './pages/settings/Help';
import { DeleteAccount } from './pages/settings/DeleteAccount';
import { Login } from './pages/auth/Login';
import { Register } from './pages/auth/Register';
import { Navbar } from './components/Navbar';
import { VideoManagement } from './pages/admin/VideoManagement';
import { BucketManager } from './pages/admin/BucketManager';
import { AnalyticsDashboard } from './pages/admin/AnalyticsDashboard';
import { AdminPanel } from './pages/admin/AdminPanel';
import { UserManagement } from './pages/admin/UserManagement';
import { CreateCourse } from './pages/CreateCourse';
import { CourseEditor } from './pages/CourseEditor';
import { TermsAndConditions } from './pages/legal/TermsAndConditions';
import { PrivacyPolicy } from './pages/legal/PrivacyPolicy';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  const isCourseRoute = location.pathname.startsWith('/course/');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900">
        <div className="w-16 h-16 border-4 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <PageTransition>
        {children}
      </PageTransition>
      {!isCourseRoute && <Navbar />}
    </div>
  );
}

// Admin route with additional checks
function AdminRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const adminEmails = ['gaspar@mastery.to', 'justin@mastery.to', 'admin@example.com'];
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900">
        <div className="w-16 h-16 border-4 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user || !adminEmails.includes(user.email || '')) {
    return <Navigate to="/" />;
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <PageTransition>
        {children}
      </PageTransition>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <NotificationProvider>
          <BrowserRouter>
            <div className="min-h-screen bg-gray-100 dark:bg-gray-900 transition-colors">
              <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/terms" element={<TermsAndConditions />} />
                <Route path="/privacy" element={<PrivacyPolicy />} />
                <Route
                  path="/"
                  element={
                    <PrivateRoute>
                      <Home />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/discover"
                  element={
                    <PrivateRoute>
                      <Discover />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/course/preview/:id"
                  element={
                    <PrivateRoute>
                      <CoursePreview />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/course/:id"
                  element={
                    <PrivateRoute>
                      <Course />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/course/:courseId/lesson/:lessonId"
                  element={
                    <PrivateRoute>
                      <Lesson />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/notifications"
                  element={
                    <PrivateRoute>
                      <Notifications />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/profile"
                  element={
                    <PrivateRoute>
                      <Profile />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/user/:username"
                  element={
                    <PrivateRoute>
                      <UserProfile />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings"
                  element={
                    <PrivateRoute>
                      <Settings />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/edit-profile"
                  element={
                    <PrivateRoute>
                      <EditProfile />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/email"
                  element={
                    <PrivateRoute>
                      <ChangeEmail />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/password"
                  element={
                    <PrivateRoute>
                      <ChangePassword />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/language"
                  element={
                    <PrivateRoute>
                      <Language />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/notifications"
                  element={
                    <PrivateRoute>
                      <NotificationSettings />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/courses"
                  element={
                    <PrivateRoute>
                      <Courses />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/timezone"
                  element={
                    <PrivateRoute>
                      <Timezone />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/privacy"
                  element={
                    <PrivateRoute>
                      <Privacy />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/connected-accounts"
                  element={
                    <PrivateRoute>
                      <ConnectedAccounts />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/subscriptions"
                  element={
                    <PrivateRoute>
                      <Subscriptions />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/help"
                  element={
                    <PrivateRoute>
                      <Help />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/settings/delete-account"
                  element={
                    <PrivateRoute>
                      <DeleteAccount />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/admin/course/:courseId/videos"
                  element={
                    <PrivateRoute>
                      <VideoManagement />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/admin/course/:courseId/buckets"
                  element={
                    <PrivateRoute>
                      <BucketManager />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/admin/course/:courseId/analytics"
                  element={
                    <PrivateRoute>
                      <AnalyticsDashboard />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/admin"
                  element={
                    <AdminRoute>
                      <AdminPanel />
                    </AdminRoute>
                  }
                />
                <Route
                  path="/admin/users"
                  element={
                    <AdminRoute>
                      <UserManagement />
                    </AdminRoute>
                  }
                />
                <Route
                  path="/create-course"
                  element={
                    <PrivateRoute>
                      <CreateCourse />
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/course/edit/:id"
                  element={
                    <PrivateRoute>
                      <CourseEditor />
                    </PrivateRoute>
                  }
                />
              </Routes>
            </div>
          </BrowserRouter>
        </NotificationProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;