import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ChevronLeft, 
  ChevronRight, 
  Moon, 
  Bell, 
  Globe2, 
  Mail, 
  Lock, 
  Languages, 
  Clock, 
  Wallet,
  Shield,
  HelpCircle,
  Trash2
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { supabase } from '../lib/supabase';

export function Settings() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isDark, toggleTheme } = useTheme();

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/login');
  };

  const menuItems = [
    {
      section: 'Account',
      items: [
        { label: 'Email address', value: user?.email, route: '/settings/email' },
        { label: 'Password', route: '/settings/password' },
        { label: 'Language', route: '/settings/language' },
        { label: 'Timezone', route: '/settings/timezone' },
      ],
    },
    {
      section: 'Preferences',
      items: [
        {
          label: 'Dark Mode',
          action: toggleTheme,
          value: isDark ? 'On' : 'Off',
          icon: <Moon size={20} className="text-gray-400 dark:text-gray-500" />,
        },
        { 
          label: 'Notifications', 
          route: '/settings/notifications',
          icon: <Bell size={20} className="text-gray-400 dark:text-gray-500" />
        },
      ],
    },
    {
      section: 'Content',
      items: [
        { 
          label: 'Courses', 
          route: '/settings/courses',
          icon: <Globe2 size={20} className="text-gray-400 dark:text-gray-500" />
        },
        { 
          label: 'Subscriptions', 
          route: '/settings/subscriptions',
          icon: <Wallet size={20} className="text-gray-400 dark:text-gray-500" />
        },
      ],
    },
    {
      section: 'Privacy & Security',
      items: [
        { 
          label: 'Privacy Settings', 
          route: '/settings/privacy',
          icon: <Shield size={20} className="text-gray-400 dark:text-gray-500" />
        },
        { 
          label: 'Connected Accounts', 
          route: '/settings/connected-accounts',
          icon: <Globe2 size={20} className="text-gray-400 dark:text-gray-500" />
        },
      ],
    },
    {
      section: 'Support',
      items: [
        { 
          label: 'Help Center', 
          route: '/settings/help',
          icon: <HelpCircle size={20} className="text-gray-400 dark:text-gray-500" />
        },
        { 
          label: 'Delete Account', 
          route: '/settings/delete-account',
          icon: <Trash2 size={20} className="text-red-500 dark:text-red-400" />,
          className: 'text-red-500 dark:text-red-400'
        },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-24">
      <div className="max-w-lg mx-auto">
        {/* Header */}
        <div className="flex items-center px-4 py-6 border-b border-gray-200 dark:border-gray-800">
          <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Settings</h1>
        </div>

        {/* Settings Menu */}
        <div className="divide-y divide-gray-200 dark:divide-gray-800">
          {menuItems.map((section) => (
            <div key={section.section} className="py-4">
              <h2 className="px-4 text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                {section.section}
              </h2>
              <div className="divide-y divide-gray-200 dark:divide-gray-800">
                {section.items.map((item) => (
                  <button
                    key={item.label}
                    onClick={() => item.route ? navigate(item.route) : item.action?.()}
                    className={`w-full px-4 py-3 flex items-center justify-between text-left hover:bg-gray-50 dark:hover:bg-gray-800 ${item.className || ''}`}
                  >
                    <div className="flex items-center">
                      {item.icon}
                      <span className="text-base text-gray-900 dark:text-white ml-3">{item.label}</span>
                    </div>
                    <div className="flex items-center text-gray-400 dark:text-gray-500">
                      {item.value && (
                        <span className="mr-2 text-gray-500 dark:text-gray-400">{item.value}</span>
                      )}
                      <ChevronRight size={20} />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Sign Out Button */}
        <div className="px-4 py-6">
          <button
            onClick={handleSignOut}
            className="w-full py-3 text-red-600 dark:text-red-500 text-center font-medium"
          >
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}