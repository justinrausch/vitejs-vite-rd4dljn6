import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Menu, ArrowRight, Plus, Instagram, Youtube, Award, CheckCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { UserAvatar } from '../components/user/UserAvatar';
import { AdminBadge } from '../components/user/AdminBadge';
import { CoachBadge } from '../components/user/CoachBadge';
import { VerifiedBadge } from '../components/user/VerifiedBadge';
import { OptimizedImage } from '../components/media/OptimizedImage';
import { supabase } from '../lib/supabase';

const StravaIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
    <path d="M15.387 17.944l-2.089-4.116h-3.065L15.387 24l5.15-10.172h-3.066m-7.008-5.599l2.836 5.598h4.172L10.463 0l-7.027 13.828h4.172"/>
  </svg>
);

export function Profile() {
  const { user, userProfile, refreshUserProfile } = useAuth();
  const navigate = useNavigate();
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [createdCourses, setCreatedCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [createdCoursesLoading, setCreatedCoursesLoading] = useState(true);
  const [error, setError] = useState(null);
  const [applyingAsCoach, setApplyingAsCoach] = useState(false);
  const [coachApplication, setCoachApplication] = useState({
    experience: '',
    expertise: '',
    motivation: ''
  });
  const [submittingApplication, setSubmittingApplication] = useState(false);
  const [applicationSuccess, setApplicationSuccess] = useState(false);
  
  const isCoach = userProfile?.is_coach || false;
  
  const avatarUrl = userProfile?.avatar_url || user?.user_metadata?.avatar_url;
  const username = userProfile?.username || 
                  user?.user_metadata?.username || 
                  user?.email?.split('@')[0] || 
                  'User';
  const displayName = user?.user_metadata?.full_name || username;
  
  const isAdmin = user?.email === 'gaspar@mastery.to' || user?.email === 'justin@mastery.to';
  const isVerified = userProfile?.is_verified || false;

  useEffect(() => {
    if (user) {
      fetchEnrolledCourses();
      if (isCoach) {
        fetchCreatedCourses();
      }
    }
  }, [user, isCoach]);

  const fetchEnrolledCourses = async () => {
    try {
      const { data: enrollments, error: enrollmentsError } = await supabase
        .from('enrollments')
        .select(`
          course_id,
          courses (
            id,
            title,
            description,
            price,
            image_url,
            logo_url,
            instructor_id,
            profiles!courses_instructor_id_fkey (
              id,
              username,
              avatar_url,
              is_verified,
              full_name
            ),
            course_tags (
              tag
            )
          )
        `)
        .eq('user_id', user?.id);

      if (enrollmentsError) throw enrollmentsError;

      const formattedCourses = enrollments.map(enrollment => ({
        id: enrollment.courses.id,
        title: enrollment.courses.title,
        description: enrollment.courses.description,
        price: enrollment.courses.price,
        image_url: enrollment.courses.image_url,
        logo_url: enrollment.courses.logo_url,
        instructor: {
          id: enrollment.courses.profiles.id,
          username: enrollment.courses.profiles.username,
          avatar_url: enrollment.courses.profiles.avatar_url,
          is_verified: enrollment.courses.profiles.is_verified,
          full_name: enrollment.courses.profiles.full_name
        },
        tags: enrollment.courses.course_tags.map(tag => tag.tag)
      }));

      setEnrolledCourses(formattedCourses);
    } catch (err) {
      console.error('Error fetching enrolled courses:', err);
      setError('Failed to load your courses');
    } finally {
      setLoading(false);
    }
  };

  const fetchCreatedCourses = async () => {
    try {
      const { data: coursesData, error: coursesError } = await supabase
        .from('courses')
        .select(`
          id,
          title,
          description,
          price,
          image_url,
          logo_url,
          instructor_id,
          profiles!courses_instructor_id_fkey (
            id,
            username,
            avatar_url,
            is_verified,
            full_name
          ),
          course_tags (
            tag
          )
        `)
        .eq('instructor_id', user?.id);

      if (coursesError) throw coursesError;

      const formattedCourses = coursesData?.map(course => ({
        id: course.id,
        title: course.title,
        description: course.description,
        price: course.price,
        image_url: course.image_url,
        logo_url: course.logo_url,
        instructor: {
          id: course.profiles.id,
          username: course.profiles.username,
          avatar_url: course.profiles.avatar_url,
          is_verified: course.profiles.is_verified,
          full_name: course.profiles.full_name
        },
        tags: course.course_tags.map(tag => tag.tag)
      })) || [];

      setCreatedCourses(formattedCourses);
    } catch (err) {
      console.error('Error fetching created courses:', err);
    } finally {
      setCreatedCoursesLoading(false);
    }
  };

  const handleCoachApplicationSubmit = async (e) => {
    e.preventDefault();
    
    if (!user) return;
    
    try {
      setSubmittingApplication(true);
      
      // In a real app, this would send the application to an admin for review
      // For demo purposes, we'll just update the user's profile directly
      const { error } = await supabase
        .from('profiles')
        .update({
          is_coach: true,
          description: coachApplication.expertise // Store expertise as description
        })
        .eq('id', user.id);
      
      if (error) throw error;
      
      // Refresh user profile to get updated coach status
      await refreshUserProfile();
      
      setApplicationSuccess(true);
      setTimeout(() => {
        setApplyingAsCoach(false);
        setApplicationSuccess(false);
      }, 3000);
      
    } catch (err) {
      console.error('Error submitting coach application:', err);
      setError('Failed to submit application. Please try again.');
    } finally {
      setSubmittingApplication(false);
    }
  };

  const renderCourseList = (courses, isEnrolled) => {
    if (courses.length === 0) {
      return (
        <div className="text-center py-4">
          <p className="text-gray-500 dark:text-gray-400">
            {isEnrolled ? "You haven't joined any courses yet" : "You haven't created any courses yet"}
          </p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {courses.map((course) => (
          <div
            key={course.id}
            className={isEnrolled ? 
              "h-full rounded-[22.2px] border-[0.83px] border-solid border-[#e0e0e0] shadow-[0px_0px_24.97px_#00000014] overflow-hidden bg-white dark:bg-gray-800 dark:border-gray-700 cursor-pointer transform transition hover:scale-[1.02]" :
              "bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm cursor-pointer transform transition hover:scale-[1.02]"
            }
            onClick={() => navigate(isEnrolled ? `/course/${course.id}` : `/course/preview/${course.id}`)}
          >
            {isEnrolled ? (
              <>
                <div className="w-full aspect-[16/7] relative bg-cover bg-center rounded-[22.2px] rounded-b-none overflow-hidden">
                  <OptimizedImage
                    src={course.image_url || 'https://images.unsplash.com/photo-1576858574144-9ae1ebcf5ae5?auto=format&fit=crop&q=80'}
                    alt={course.title}
                    className="w-full h-full object-cover"
                    placeholderClassName="w-full h-full"
                    width={400}
                    quality={85}
                  />
                </div>
                
                <div className="p-4">
                  <div className="flex items-center mb-1">
                    <div className="flex items-center">
                      {course.logo_url ? (
                        <div className="relative mr-2">
                          <img 
                            src={course.logo_url} 
                            alt={`${course.title} logo`}
                            className="w-10 h-10 rounded-md object-cover flex-shrink-0"
                          />
                          <UserAvatar 
                            username={course.instructor.username}
                            avatarUrl={course.instructor.avatar_url}
                            size="xs"
                            className="w-6 h-6 absolute -bottom-1 -right-1 border-2 border-white dark:border-gray-800 rounded-full"
                          />
                        </div>
                      ) : (
                        <UserAvatar 
                          username={course.instructor.username}
                          avatarUrl={course.instructor.avatar_url}
                          size="sm"
                          className="w-10 h-10 mr-2"
                        />
                      )}
                    </div>
                    <div className="ml-2">
                      <h3 className="font-['Gabarito'] text-[19.1px] text-[#16161a] dark:text-white font-medium">
                        {course.title}
                      </h3>
                      <span className="font-['Gabarito'] text-[#7e7e87] dark:text-gray-400 text-[14px]">
                        {course.instructor.full_name || course.instructor.username}
                      </span>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex items-center">
                <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 flex-shrink-0 rounded-lg overflow-hidden m-2">
                  <OptimizedImage
                    src={course.image_url}
                    alt={course.title}
                    className="w-full h-full object-cover"
                    placeholderClassName="w-full h-full"
                    width={64}
                    quality={70}
                  />
                </div>
                <div className="p-3 flex-1">
                  <div className="flex items-center">
                    {course.logo_url && (
                      <img 
                        src={course.logo_url} 
                        alt={`${course.title} logo`}
                        className="w-5 h-5 mr-2 rounded-md object-cover"
                      />
                    )}
                    <h4 className="font-medium text-gray-900 dark:text-white text-sm">{course.title}</h4>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-1">
                    {course.description}
                  </p>
                  <div className="mt-1 flex items-center justify-between">
                    <span className="text-xs text-gray-600 dark:text-gray-400">
                      with {course.instructor.full_name || course.instructor.username}
                    </span>
                    {isEnrolled ? (
                      <span className="text-xs bg-blue-500 text-white px-2 py-0.5 rounded-full">
                        Joined
                      </span>
                    ) : (
                      <span className="text-xs font-medium text-blue-500 dark:text-blue-400">
                        ${course.price}/mo
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="pb-32">
      <div className="max-w-lg mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-normal text-gray-900 dark:text-white">
            {displayName}
          </h1>
          <button 
            onClick={() => navigate('/settings')}
            className="text-gray-600 dark:text-gray-300"
          >
            <Menu size={24} />
          </button>
        </div>

        {/* Profile Info */}
        <div className="text-center mb-8">
          <div className="mb-4 flex justify-center">
            <UserAvatar 
              username={username}
              avatarUrl={avatarUrl}
              size="xl"
            />
          </div>
          <div className="flex items-center justify-center mb-2">
            <h2 className="text-lg font-medium text-gray-900 dark:text-white">
              @{username}
            </h2>
            <div className="flex gap-2 ml-2">
              {isVerified && <VerifiedBadge />}
              {isCoach && <CoachBadge />}
              {isAdmin && <AdminBadge />}
            </div>
          </div>
          <button 
            onClick={() => navigate('/settings/edit-profile')}
            className="inline-block px-6 py-2 border border-gray-300 dark:border-gray-700 rounded-full text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 mb-4"
          >
            Edit profile
          </button>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            {user?.user_metadata?.description || 'No description yet'}
          </p>
          <div className="flex justify-center gap-4 mb-8">
            {user?.user_metadata?.instagram && (
              <a 
                href={`https://instagram.com/${user.user_metadata.instagram}`} 
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Instagram size={20} className="mr-1" />
                <span>@{user.user_metadata.instagram}</span>
              </a>
            )}
            {user?.user_metadata?.youtube && (
              <a 
                href={`https://youtube.com/@${user.user_metadata.youtube}`} 
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Youtube size={20} className="mr-1" />
                <span>@{user.user_metadata.youtube}</span>
              </a>
            )}
            {user?.user_metadata?.strava && (
              <a 
                href={`https://www.strava.com/athletes/${user.user_metadata.strava}`} 
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-[#FC4C02] dark:hover:text-[#FC4C02]"
                target="_blank"
                rel="noopener noreferrer"
              >
                <StravaIcon />
              </a>
            )}
          </div>
        </div>

        {/* Created Courses Section */}
        {isCoach && (
          <div className="mb-8 bg-gradient-to-br from-blue-50/80 to-blue-100/80 dark:from-blue-900/10 dark:to-blue-800/20 rounded-2xl p-6 border border-blue-100 dark:border-blue-800/30">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Created Courses</h3>
              <button 
                onClick={() => navigate('/create-course')}
                className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors"
              >
                <Plus size={16} className="mr-1" />
                Create
              </button>
            </div>
            {renderCourseList(createdCourses, false)}
          </div>
        )}

        {/* Coach Application Section (for non-coaches only) */}
        {!isCoach && !applyingAsCoach && !applicationSuccess && (
          <div className="mb-8 bg-gradient-to-br from-purple-50/80 to-purple-100/80 dark:from-purple-900/10 dark:to-purple-800/20 rounded-2xl p-6 border border-purple-100 dark:border-purple-800/30">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Become a Coach</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Share your expertise and earn by creating courses</p>
              </div>
              <Award className="text-purple-500 dark:text-purple-400" size={24} />
            </div>
            <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
              Join our community of coaches and share your knowledge with athletes around the world.
            </p>
            <button
              onClick={() => setApplyingAsCoach(true)}
              className="w-full py-3 bg-purple-500 hover:bg-purple-600 text-white rounded-xl font-medium transition-colors"
            >
              Apply to be a Coach
            </button>
          </div>
        )}

        {/* Coach Application Form */}
        {!isCoach && applyingAsCoach && !applicationSuccess && (
          <div className="mb-8 bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Coach Application</h3>
              <button
                onClick={() => setApplyingAsCoach(false)}
                className="text-gray-500 dark:text-gray-400"
              >
                &times;
              </button>
            </div>
            
            <form onSubmit={handleCoachApplicationSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Your Experience
                </label>
                <textarea
                  value={coachApplication.experience}
                  onChange={(e) => setCoachApplication({...coachApplication, experience: e.target.value})}
                  placeholder="Tell us about your experience in your sport or activity..."
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-purple-500 dark:text-white dark:placeholder-gray-400 min-h-[80px]"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Your Expertise
                </label>
                <textarea
                  value={coachApplication.expertise}
                  onChange={(e) => setCoachApplication({...coachApplication, expertise: e.target.value})}
                  placeholder="What specific skills or knowledge can you teach?"
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-purple-500 dark:text-white dark:placeholder-gray-400 min-h-[80px]"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Why do you want to be a coach?
                </label>
                <textarea
                  value={coachApplication.motivation}
                  onChange={(e) => setCoachApplication({...coachApplication, motivation: e.target.value})}
                  placeholder="Share your motivation for becoming a coach..."
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-purple-500 dark:text-white dark:placeholder-gray-400 min-h-[80px]"
                  required
                />
              </div>
              
              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setApplyingAsCoach(false)}
                  className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingApplication}
                  className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 disabled:opacity-50 flex items-center"
                >
                  {submittingApplication ? (
                    <>
                      <span className="mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      Submitting...
                    </>
                  ) : (
                    'Submit Application'
                  )}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Application Success Message */}
        {!isCoach && applicationSuccess && (
          <div className="mb-8 bg-green-50 dark:bg-green-900/20 rounded-2xl p-6 border border-green-100 dark:border-green-800/30">
            <div className="flex items-center mb-4">
              <CheckCircle className="text-green-500 dark:text-green-400 mr-3" size={24} />
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Application Submitted!</h3>
            </div>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Your application to become a coach has been submitted successfully. You can now create courses and start sharing your knowledge!
            </p>
          </div>
        )}

        {/* Subscribed Courses Section */}
        <div className="mb-8 bg-gradient-to-br from-blue-50/30 to-blue-100/30 dark:from-blue-900/0 dark:to-blue-800/5 rounded-2xl p-6 border border-blue-100/60 dark:border-blue-800/10">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Subscribed</h2>
          <div className="space-y-4">
            {enrolledCourses.map((course) => (
              <div
                key={course.id}
                className="h-full rounded-[22.2px] border-[0.83px] border-solid border-[#e0e0e0] shadow-[0px_0px_24.97px_#00000014] overflow-hidden bg-white dark:bg-gray-800 dark:border-gray-700 cursor-pointer transform transition hover:scale-[1.02]"
                onClick={() => navigate(`/course/${course.id}`)}
              >
                <div className="w-full aspect-[16/7] relative bg-cover bg-center rounded-[22.2px] rounded-b-none overflow-hidden">
                  <OptimizedImage
                    src={course.image_url || 'https://images.unsplash.com/photo-1576858574144-9ae1ebcf5ae5?auto=format&fit=crop&q=80'}
                    alt={course.title}
                    className="w-full h-full object-cover"
                    placeholderClassName="w-full h-full"
                    width={400}
                    quality={85}
                  />
                </div>
                
                <div className="p-4">
                  <div className="flex items-center mb-1">
                    <div className="flex items-center">
                      {course.logo_url ? (
                        <div className="relative mr-2">
                          <img 
                            src={course.logo_url} 
                            alt={`${course.title} logo`}
                            className="w-10 h-10 rounded-md object-cover flex-shrink-0"
                          />
                          <UserAvatar 
                            username={course.instructor.username}
                            avatarUrl={course.instructor.avatar_url}
                            size="xs"
                            className="w-6 h-6 absolute -bottom-1 -right-1 border-2 border-white dark:border-gray-800 rounded-full"
                          />
                        </div>
                      ) : (
                        <UserAvatar 
                          username={course.instructor.username}
                          avatarUrl={course.instructor.avatar_url}
                          size="sm"
                          className="w-10 h-10 mr-2"
                        />
                      )}
                    </div>
                    <div className="ml-2">
                      <h3 className="font-['Gabarito'] text-[19.1px] text-[#16161a] dark:text-white font-medium">
                        {course.title}
                      </h3>
                      <span className="font-['Gabarito'] text-[#7e7e87] dark:text-gray-400 text-[14px]">
                        {course.instructor.full_name || course.instructor.username}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            {enrolledCourses.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500 dark:text-gray-400 mb-4">You haven't joined any courses yet</p>
                <button
                  onClick={() => navigate('/discover')}
                  className="text-blue-500 dark:text-blue-400 font-medium hover:text-blue-600 dark:hover:text-blue-300"
                >
                  Browse courses →
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Find More Button */}
        <div className="mt-6">
          <button
            onClick={() => navigate('/discover')}
            className="w-full py-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors flex items-center justify-center group"
          >
            <span className="text-gray-700 dark:text-gray-300 font-medium mr-2 group-hover:text-blue-500 dark:group-hover:text-blue-400 transition-colors">
              Find more courses
            </span>
            <ArrowRight size={20} className="text-gray-500 dark:text-gray-400 group-hover:text-blue-500 dark:group-hover:text-blue-400 transition-colors" />
          </button>
        </div>
      </div>
    </div>
  );
}