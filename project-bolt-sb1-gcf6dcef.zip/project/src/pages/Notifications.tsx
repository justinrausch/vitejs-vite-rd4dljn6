import React, { useEffect } from 'react';
import { Bell, CheckCircle, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useNotifications } from '../contexts/NotificationContext';
import { NotificationItem } from '../components/NotificationItem';
import { Notification } from '../types/notification';

export function Notifications() {
  const navigate = useNavigate();
  const { 
    notifications, 
    unreadCount, 
    loading, 
    markAsRead, 
    markAllAsRead,
    refreshNotifications
  } = useNotifications();

  const handleNotificationClick = async (notification: Notification) => {
    // Mark as read
    if (!notification.read) {
      await markAsRead(notification.id);
    }
    
    // Navigate based on notification type and data
    switch (notification.type) {
      case 'new_message':
        if (notification.data?.courseId) {
          navigate(`/course/${notification.data.courseId}#coaching`);
        }
        break;
      case 'new_lesson':
        if (notification.data?.courseId && notification.data?.lessonId) {
          navigate(`/course/${notification.data.courseId}/lesson/${notification.data.lessonId}`);
        } else if (notification.data?.courseId) {
          navigate(`/course/${notification.data.courseId}#skills`);
        }
        break;
      case 'achievement':
        if (notification.data?.courseId) {
          navigate(`/course/${notification.data.courseId}#ranking`);
        }
        break;
      case 'course_approved':
      case 'course_denied':
      case 'course_update_approved':
      case 'course_update_denied':
        if (notification.data?.courseId) {
          navigate(`/course/${notification.data.courseId}`);
        } else {
          navigate('/profile');
        }
        break;
      case 'comment_like':
        if (notification.data?.courseId) {
          navigate(`/course/${notification.data.courseId}#home`);
        }
        break;
      case 'direct_message':
        if (notification.data?.courseId) {
          navigate(`/course/${notification.data.courseId}#coaching`);
        }
        break;
      case 'message_like':
        if (notification.data?.courseId) {
          navigate(`/course/${notification.data.courseId}#community`);
        }
        break;
      default:
        // Default action is to do nothing
        break;
    }
  };

  return (
    <div className="pb-20">
      <header className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-lg mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Notifications</h1>
            <div className="flex items-center space-x-3">
              {unreadCount > 0 && (
                <button
                  onClick={markAllAsRead}
                  className="flex items-center text-sm text-blue-500 dark:text-blue-400"
                >
                  <CheckCircle size={16} className="mr-1" />
                  Mark all as read
                </button>
              )}
              <button 
                onClick={refreshNotifications}
                className="p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 rounded-full"
                title="Refresh notifications"
              >
                <RefreshCw size={20} className={loading ? "animate-spin" : ""} />
              </button>
            </div>
          </div>
        </div>
      </header>
      
      <main className="max-w-lg mx-auto px-4 py-6">
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-12">
            <Bell size={48} className="mx-auto text-gray-300 dark:text-gray-600 mb-4" />
            <p className="text-gray-500 dark:text-gray-400">No notifications yet</p>
            <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
              We'll notify you when something important happens
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {notifications.map((notification) => (
              <NotificationItem
                key={notification.id}
                notification={notification}
                onClick={handleNotificationClick}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}