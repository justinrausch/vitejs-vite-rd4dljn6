import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, Instagram, Youtube, UserX, ArrowRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { UserAvatar } from '../components/user/UserAvatar';
import { AdminBadge } from '../components/user/AdminBadge';
import { CoachBadge } from '../components/user/CoachBadge';
import { VerifiedBadge } from '../components/user/VerifiedBadge';
import { UserProfile as UserProfileType } from '../types/user';
import { CourseWithBasicInfo } from '../types/course';
import { OptimizedImage } from '../components/media/OptimizedImage';
import { UserProfileMenu } from '../components/user/UserProfileMenu';

const StravaIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
    <path d="M15.387 17.944l-2.089-4.116h-3.065L15.387 24l5.15-10.172h-3.066m-7.008-5.599l2.836 5.598h4.172L10.463 0l-7.027 13.828h4.172"/>
  </svg>
);

export function UserProfile() {
  const { username } = useParams();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfileType | null>(null);
  const [enrolledCourses, setEnrolledCourses] = useState<CourseWithBasicInfo[]>([]);
  const [createdCourses, setCreatedCourses] = useState<CourseWithBasicInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notFound, setNotFound] = useState(false);
  
  const isAdmin = (email?: string) => {
    return email === 'gaspar@mastery.to' || email === 'justin@mastery.to';
  };

  const fetchUserProfile = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      setNotFound(false);

      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('id, username, avatar_url, description, instagram, youtube, strava, is_coach, is_verified, full_name, email')
        .eq('username', username)
        .maybeSingle();

      if (profileError) throw profileError;

      if (!profileData) {
        setNotFound(true);
        return;
      }

      setProfile(profileData);

      // Fetch enrolled courses
      const { data: enrollments, error: enrollmentsError } = await supabase
        .from('enrollments')
        .select('course_id')
        .eq('user_id', profileData.id);

      if (enrollmentsError) throw enrollmentsError;
      
      if (enrollments && enrollments.length > 0) {
        const courseIds = enrollments.map(e => e.course_id);
        
        const { data: coursesData, error: coursesError } = await supabase
          .from('courses')
          .select(`
            id,
            title,
            description,
            price,
            image_url,
            logo_url,
            instructor_id,
            profiles!courses_instructor_id_fkey (
              id,
              username,
              avatar_url
            ),
            course_tags (
              tag
            )
          `)
          .in('id', courseIds);
        
        if (coursesError) throw coursesError;
        
        const formattedEnrolledCourses = coursesData.map(course => ({
          id: course.id,
          title: course.title,
          description: course.description,
          price: course.price,
          image_url: course.image_url,
          logo_url: course.logo_url,
          instructor: {
            id: course.profiles.id,
            username: course.profiles.username,
            avatar_url: course.profiles.avatar_url
          },
          tags: course.course_tags.map(tag => tag.tag)
        }));

        setEnrolledCourses(formattedEnrolledCourses);
      }

      if (profileData.is_coach) {
        const { data: coursesData, error: coursesError } = await supabase
          .from('courses')
          .select(`
            id,
            title,
            description,
            price,
            image_url,
            logo_url,
            instructor_id,
            profiles!courses_instructor_id_fkey (
              id,
              username,
              avatar_url
            ),
            course_tags (
              tag
            )
          `)
          .eq('instructor_id', profileData.id);

        if (coursesError) throw coursesError;

        const formattedCreatedCourses = coursesData?.map(course => ({
          id: course.id,
          title: course.title,
          description: course.description,
          price: course.price,
          image_url: course.image_url,
          logo_url: course.logo_url,
          instructor: {
            id: course.profiles.id,
            username: course.profiles.username,
            avatar_url: course.profiles.avatar_url
          },
          tags: course.course_tags.map(tag => tag.tag)
        })) || [];

        setCreatedCourses(formattedCreatedCourses);
      }
    } catch (err) {
      console.error('Error fetching user profile:', err);
      setError('Failed to load user profile');
    } finally {
      setLoading(false);
    }
  }, [username]);

  useEffect(() => {
    fetchUserProfile();
  }, [fetchUserProfile]);

  const renderCourseList = (courses: CourseWithBasicInfo[], isEnrolled: boolean) => {
    if (courses.length === 0) {
      return (
        <div className="text-center py-4">
          <p className="text-gray-500 dark:text-gray-400">
            {isEnrolled ? "No joined courses" : "No created courses"}
          </p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {courses.map((course) => (
          <div
            key={course.id}
            className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm cursor-pointer transform transition hover:scale-[1.02]"
            onClick={() => navigate(isEnrolled ? `/course/${course.id}` : `/course/preview/${course.id}`)}
          >
            <div className="flex items-center">
              <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 flex-shrink-0 rounded-lg m-2 overflow-hidden">
                <OptimizedImage
                  src={course.image_url}
                  alt={course.title}
                  className="w-full h-full object-cover"
                  placeholderClassName="w-full h-full"
                  width={64}
                  quality={70}
                />
              </div>
              <div className="p-3 flex-1">
                <div className="flex items-center">
                  {course.logo_url && (
                    <img 
                      src={course.logo_url} 
                      alt={`${course.title} logo`}
                      className="w-5 h-5 mr-2 rounded-md object-cover"
                    />
                  )}
                  <h4 className="font-medium text-gray-900 dark:text-white text-sm">{course.title}</h4>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-1">
                  {course.description}
                </p>
                <div className="mt-1 flex items-center justify-between">
                  <span className="text-xs text-gray-600 dark:text-gray-400">
                    with {course.instructor.username}
                  </span>
                  {isEnrolled ? (
                    <span className="text-xs bg-blue-500 text-white px-2 py-0.5 rounded-full">
                      Joined
                    </span>
                  ) : (
                    <span className="text-xs font-medium text-blue-500 dark:text-blue-400">
                      ${course.price}/mo
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (notFound) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center px-4 py-6 border-b border-gray-200 dark:border-gray-800">
            <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
              <ChevronLeft size={24} />
            </button>
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Profile</h1>
          </div>
          
          <div className="flex flex-col items-center justify-center py-12 px-4">
            <UserX size={64} className="text-gray-400 dark:text-gray-600 mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              User not found
            </h2>
            <p className="text-gray-600 dark:text-gray-400 text-center mb-6">
              The user @{username} doesn't exist or has deleted their account.
            </p>
            <button
              onClick={() => navigate(-1)}
              className="text-blue-500 dark:text-blue-400 font-medium hover:text-blue-600 dark:hover:text-blue-300"
            >
              Go back
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            {error || "Failed to load user profile"}
          </p>
          <button
            onClick={() => navigate(-1)}
            className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
          >
            Go back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-20">
      <div className="max-w-lg mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Profile</h1>
          <UserProfileMenu userId={profile.id} username={profile.username} />
        </div>

        {/* Profile Info */}
        <div className="text-center mb-8">
          <div className="mb-4 flex justify-center">
            <UserAvatar 
              username={profile.username}
              avatarUrl={profile.avatar_url}
              size="xl"
            />
          </div>
          <div className="flex items-center justify-center mb-2">
            <h2 className="text-lg font-medium text-gray-900 dark:text-white">
              @{profile.username}
            </h2>
            <div className="flex gap-2 ml-2">
              {profile.is_verified && <VerifiedBadge />}
              {profile.is_coach && <CoachBadge />}
              {isAdmin(profile.email) && <AdminBadge />}
            </div>
          </div>
          {profile.full_name && profile.full_name !== profile.username && (
            <p className="text-gray-700 dark:text-gray-300 mb-2">{profile.full_name}</p>
          )}
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            {profile.description || 'No description available'}
          </p>
          <div className="flex justify-center gap-4 mb-8">
            {profile.instagram && (
              <a 
                href={`https://instagram.com/${profile.instagram}`} 
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Instagram size={20} className="mr-1" />
                <span>@{profile.instagram}</span>
              </a>
            )}
            {profile.youtube && (
              <a 
                href={`https://youtube.com/@${profile.youtube}`} 
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Youtube size={20} className="mr-1" />
                <span>@{profile.youtube}</span>
              </a>
            )}
            {profile.strava && (
              <a 
                href={`https://www.strava.com/athletes/${profile.strava}`} 
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-[#FC4C02] dark:hover:text-[#FC4C02]"
                target="_blank"
                rel="noopener noreferrer"
              >
                <StravaIcon />
                <span className="ml-1">@{profile.strava}</span>
              </a>
            )}
          </div>
        </div>

        {/* Created Courses Section */}
        {profile.is_coach && (
          <div className="mb-8 bg-gradient-to-br from-blue-50/80 to-blue-100/80 dark:from-blue-900/10 dark:to-blue-800/20 rounded-2xl p-6 border border-blue-100 dark:border-blue-800/30">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Created Courses</h3>
              <button 
                onClick={() => navigate('/discover')}
                className="text-blue-500 dark:text-blue-400 text-sm font-medium flex items-center hover:text-blue-600 dark:hover:text-blue-300 transition-colors"
              >
                See all <ArrowRight size={16} className="ml-1" />
              </button>
            </div>
            {renderCourseList(createdCourses, false)}
          </div>
        )}

        {/* Subscribed Courses Section */}
        <div className="mb-8 bg-gradient-to-br from-blue-50/30 to-blue-100/30 dark:from-blue-900/0 dark:to-blue-800/5 rounded-2xl p-6 border border-blue-100/60 dark:border-blue-800/10">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Subscribed</h3>
            <button 
              onClick={() => navigate('/discover')}
              className="text-blue-500 dark:text-blue-400 text-sm font-medium flex items-center hover:text-blue-600 dark:hover:text-blue-300 transition-colors"
            >
              See all <ArrowRight size={16} className="ml-1" />
            </button>
          </div>
          {renderCourseList(enrolledCourses, true)}
        </div>

        {/* Find More Button */}
        <button
          onClick={() => navigate('/discover')}
          className="w-full py-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors flex items-center justify-center group"
        >
          <span className="text-gray-700 dark:text-gray-300 font-medium mr-2 group-hover:text-blue-500 dark:group-hover:text-blue-400 transition-colors">
            Find more courses
          </span>
          <ArrowRight size={20} className="text-gray-500 dark:text-gray-400 group-hover:text-blue-500 dark:group-hover:text-blue-400 transition-colors" />
        </button>
      </div>
    </div>
  );
}