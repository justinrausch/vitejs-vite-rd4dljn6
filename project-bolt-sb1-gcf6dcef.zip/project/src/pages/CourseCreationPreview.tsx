import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Eye, Edit2, Save } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { CourseCard } from '../components/CourseCard';

interface CourseData {
  title: string;
  tagline: string;
  description: string;
  image_url: string | null;
  logo_url: string | null;
  sport: string;
  disciplines: string[];
}

interface PricingOption {
  title: string;
  price: number;
  renewal_period: 'monthly' | 'yearly' | null;
  features: string[];
}

interface CourseMedia {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail_url?: string;
  position: number;
}

export function CourseCreationPreview() {
  const navigate = useNavigate();
  const { user, userProfile } = useAuth();
  const [courseData, setCourseData] = useState<CourseData | null>(null);
  const [pricingOptions, setPricingOptions] = useState<PricingOption[]>([]);
  const [selectedPricingIndex, setSelectedPricingIndex] = useState(0);
  const [courseMedia, setCourseMedia] = useState<CourseMedia[]>([]);
  const [loading, setLoading] = useState(true);
  const [publishing, setPublishing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const savedData = sessionStorage.getItem('newCourseData');
    if (savedData) {
      try {
        const parsedData = JSON.parse(savedData);
        setCourseData(parsedData);
        
        if (parsedData.courseMedia && Array.isArray(parsedData.courseMedia)) {
          setCourseMedia(parsedData.courseMedia);
        }
        
        if (parsedData.pricingOptions && Array.isArray(parsedData.pricingOptions)) {
          setPricingOptions(parsedData.pricingOptions);
          
          if (typeof parsedData.selectedPricingIndex === 'number') {
            setSelectedPricingIndex(parsedData.selectedPricingIndex);
          }
        }
      } catch (err) {
        console.error("Error parsing session storage data:", err);
        setError('Failed to load course data');
      }
    } else {
      setError('No course data found. Please start over.');
    }
    setLoading(false);
  }, []);

  const handlePublish = async () => {
    if (!courseData || !user) return;

    try {
      setPublishing(true);
      setError(null);

      // Validate required fields
      if (!courseData.title || !courseData.tagline || !courseData.description) {
        setError('Please fill in all required fields');
        setPublishing(false);
        return;
      }

      // Use the first media item's URL as the course image if available
      const mainImageUrl = courseMedia.length > 0 ? courseMedia[0].url : null;

      if (!mainImageUrl) {
        setError('Please add at least one image for the course');
        setPublishing(false);
        return;
      }

      // Get the price from the selected pricing option
      const price = pricingOptions.length > 0 ? pricingOptions[selectedPricingIndex].price : 49.99;

      const courseInsertData = {
        title: courseData.title,
        tagline: courseData.tagline,
        description: courseData.description,
        image_url: mainImageUrl,
        logo_url: courseData.logo_url,
        price: price,
        sport: courseData.sport,
        disciplines: courseData.disciplines,
        instructor_id: user.id
      };

      // Create new course
      const { data: newCourse, error: courseError } = await supabase
        .from('courses')
        .insert([courseInsertData])
        .select()
        .single();

      if (courseError) throw courseError;
      if (!newCourse) throw new Error('Failed to create course');

      // Insert course media
      if (courseMedia.length > 0) {
        const mediaToInsert = courseMedia.map((media, index) => ({
          course_id: newCourse.id,
          type: media.type,
          url: media.url,
          thumbnail_url: media.thumbnail_url,
          position: index
        }));

        const { error: mediaError } = await supabase
          .from('course_media')
          .insert(mediaToInsert);

        if (mediaError) throw mediaError;
      }

      // Create pricing options if they exist
      if (pricingOptions.length > 0) {
        const plansToInsert = pricingOptions.map(option => ({
          course_id: newCourse.id,
          title: option.title,
          price: option.price,
          renewal_period: option.renewal_period,
          features: option.features
        }));

        const { error: plansError } = await supabase
          .from('course_plans')
          .insert(plansToInsert);

        if (plansError) throw plansError;
      }

      // Clear session storage
      sessionStorage.removeItem('newCourseData');

      // Navigate to the new course
      navigate(`/course/${newCourse.id}`);
    } catch (err: any) {
      console.error('Error publishing course:', err);
      setError(err.message || 'Failed to publish course');
    } finally {
      setPublishing(false);
    }
  };

  const handleEdit = () => {
    navigate('/course/edit/new');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!courseData) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">No Course Data Found</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-4">Please start the course creation process again.</p>
          <button
            onClick={() => navigate('/create-course')}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium"
          >
            Start Over
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 sticky top-0 z-10 shadow-sm">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center">
              <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
                <ChevronLeft size={24} />
              </button>
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
                Course Preview
              </h1>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={handleEdit}
                className="px-4 py-2 text-gray-700 dark:text-gray-300 rounded-lg font-medium flex items-center border border-gray-300 dark:border-gray-600"
              >
                <Edit2 size={18} className="mr-2" />
                Edit
              </button>
              <button
                onClick={handlePublish}
                disabled={publishing}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium flex items-center disabled:opacity-50"
              >
                <Save size={18} className="mr-2" />
                {publishing ? 'Publishing...' : 'Publish Course'}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        <div className="space-y-6">
          {/* Preview Notice */}
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <div className="flex items-center">
              <Eye size={20} className="text-blue-500 dark:text-blue-400 mr-3" />
              <div>
                <h3 className="font-medium text-blue-900 dark:text-blue-100">Course Preview</h3>
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  Review your course details below. You can edit any information before publishing.
                </p>
              </div>
            </div>
          </div>

          {/* Course Card Preview */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">How Your Course Will Appear</h2>
            
            <div className="flex justify-center">
              <div className="w-full max-w-sm">
                <CourseCard
                  course={{
                    id: 'preview',
                    title: courseData.title,
                    description: courseData.description,
                    price: pricingOptions.length > 0 ? pricingOptions[selectedPricingIndex].price : 49.99,
                    image_url: courseData.image_url,
                    logo_url: courseData.logo_url,
                    instructor: {
                      id: user?.id || 'preview',
                      username: userProfile?.username || 'username',
                      avatar_url: userProfile?.avatar_url,
                      is_verified: userProfile?.is_verified
                    },
                    tags: [],
                    disciplines: courseData.disciplines,
                    memberRank: 1,
                    reviewRank: 1
                  }}
                  showRating={true}
                />
              </div>
            </div>
          </div>

          {/* Course Details */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Course Details</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-gray-900 dark:text-white mb-1">Title</h3>
                <p className="text-gray-600 dark:text-gray-400">{courseData.title}</p>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-900 dark:text-white mb-1">Tagline</h3>
                <p className="text-gray-600 dark:text-gray-400">{courseData.tagline}</p>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-900 dark:text-white mb-1">Description</h3>
                <p className="text-gray-600 dark:text-gray-400">{courseData.description}</p>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-900 dark:text-white mb-1">Sport</h3>
                <p className="text-gray-600 dark:text-gray-400">{courseData.sport}</p>
              </div>
              
              {courseData.disciplines.length > 0 && (
                <div>
                  <h3 className="font-medium text-gray-900 dark:text-white mb-1">Disciplines</h3>
                  <div className="flex flex-wrap gap-2">
                    {courseData.disciplines.map((discipline) => (
                      <span
                        key={discipline}
                        className="px-3 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200 rounded-full text-sm"
                      >
                        {discipline}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Media Gallery */}
          {courseMedia.length > 0 && (
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Course Media</h2>
              
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {courseMedia.map((media, index) => (
                  <div key={media.id} className="relative aspect-video bg-gray-100 dark:bg-gray-700 rounded-lg overflow-hidden">
                    {media.type === 'image' ? (
                      <img
                        src={media.url}
                        alt={`Course media ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <video
                        src={media.url}
                        className="w-full h-full object-cover"
                        controls={false}
                        poster={media.thumbnail_url}
                      />
                    )}
                    {index === 0 && (
                      <div className="absolute top-2 left-2 bg-blue-500 text-white text-xs px-2 py-1 rounded">
                        Main Image
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Pricing Plans */}
          {pricingOptions.length > 0 && (
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Pricing Plans</h2>
              
              <div className="space-y-4">
                {pricingOptions.map((option, index) => (
                  <div
                    key={index}
                    className={`border rounded-lg p-4 ${
                      selectedPricingIndex === index
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                        : 'border-gray-200 dark:border-gray-700'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium text-gray-900 dark:text-white">{option.title}</h3>
                      <div className="text-right">
                        <div className="text-lg font-semibold text-gray-900 dark:text-white">
                          ${option.price}
                        </div>
                        {option.renewal_period && (
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            per {option.renewal_period.replace('ly', '')}
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      {option.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="text-sm text-gray-600 dark:text-gray-400">
                          • {feature}
                        </div>
                      ))}
                    </div>
                    
                    {selectedPricingIndex === index && (
                      <div className="mt-2 text-sm text-blue-600 dark:text-blue-400 font-medium">
                        Default plan
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}