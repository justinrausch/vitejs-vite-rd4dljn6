import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, AlertTriangle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { CourseWithBasicInfo } from '../types/course';
import { useAuth } from '../contexts/AuthContext';
import { CourseCard } from '../components/CourseCard';

interface CourseWithRanking extends CourseWithBasicInfo {
  memberRank?: number;
  reviewRank?: number;
  averageRating?: number;
  reviewCount?: number;
}

export function Discover() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [selectedTag, setSelectedTag] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [courses, setCourses] = useState<CourseWithRanking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [availableTags, setAvailableTags] = useState<string[]>(['All']);
  const [availableDisciplines, setAvailableDisciplines] = useState<string[]>([]);
  const [enrolledCourseIds, setEnrolledCourseIds] = useState<string[]>([]);
  const [courseCount, setCourseCount] = useState<number | null>(null);
  const tagsContainerRef = useRef<HTMLDivElement>(null);
  
  // State for drag scrolling
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const fetchEnrolledCourses = useCallback(async () => {
    if (!user) return;
    
    try {
      const { data: enrollments, error: enrollmentsError } = await supabase
        .from('enrollments')
        .select('course_id')
        .eq('user_id', user.id);

      if (enrollmentsError) throw enrollmentsError;

      setEnrolledCourseIds(enrollments?.map(e => e.course_id) || []);
    } catch (err) {
      console.error('Error fetching enrolled courses:', err);
    }
  }, [user]);

  const fetchDisciplines = useCallback(async () => {
    try {
      // Get all unique disciplines from courses
      const { data, error } = await supabase
        .from('courses')
        .select('disciplines');

      if (error) throw error;

      // Extract all unique disciplines
      const allDisciplines = new Set<string>();
      data.forEach(course => {
        if (course.disciplines && Array.isArray(course.disciplines)) {
          course.disciplines.forEach(discipline => {
            if (discipline) allDisciplines.add(discipline);
          });
        }
      });

      const disciplinesList = Array.from(allDisciplines).sort();
      setAvailableDisciplines(disciplinesList);
      setAvailableTags(['All', ...disciplinesList]);
    } catch (err) {
      console.error('Error fetching disciplines:', err);
      setError('Failed to load disciplines');
    }
  }, []);

  const fetchCourses = useCallback(async () => {
    try {
      setLoading(true);
      
      // Fetch courses with basic info
      const { data: coursesData, error: coursesError } = await supabase
        .from('courses')
        .select(`
          id,
          title,
          description,
          price,
          image_url,
          logo_url,
          instructor_id,
          member_count,
          disciplines,
          profiles!courses_instructor_id_fkey (
            id,
            username,
            avatar_url,
            is_coach,
            is_verified
          ),
          course_tags (
            tag
          ),
          course_plans (
            id,
            title,
            price,
            renewal_period,
            features
          )
        `);

      if (coursesError) throw coursesError;

      // Fetch review data for all courses
      const { data: reviewsData, error: reviewsError } = await supabase
        .from('course_reviews')
        .select('course_id, rating');

      if (reviewsError) throw reviewsError;

      // Calculate average ratings and review counts
      const reviewStats: Record<string, { total: number, count: number }> = {};
      reviewsData?.forEach(review => {
        if (!reviewStats[review.course_id]) {
          reviewStats[review.course_id] = { total: 0, count: 0 };
        }
        reviewStats[review.course_id].total += review.rating;
        reviewStats[review.course_id].count += 1;
      });

      // Format courses with rankings
      const formattedCourses: CourseWithRanking[] = coursesData.map(course => {
        // Get the first pricing plan or use the course price
        const firstPlan = course.course_plans && course.course_plans.length > 0 
          ? course.course_plans[0] 
          : null;
          
        // Calculate average rating
        const reviewStat = reviewStats[course.id];
        const averageRating = reviewStat ? reviewStat.total / reviewStat.count : 0;
        const reviewCount = reviewStat ? reviewStat.count : 0;

        return {
          id: course.id,
          title: course.title,
          description: course.description,
          price: firstPlan ? firstPlan.price : course.price,
          image_url: course.image_url,
          logo_url: course.logo_url,
          disciplines: course.disciplines || [],
          instructor: {
            id: course.profiles.id,
            username: course.profiles.username,
            avatar_url: course.profiles.avatar_url,
            is_coach: course.profiles.is_coach,
            is_verified: course.profiles.is_verified
          },
          tags: course.course_tags.map(tag => tag.tag),
          member_count: course.member_count || 0,
          averageRating,
          reviewCount
        };
      });

      // Calculate rankings
      const sortedByMembers = [...formattedCourses].sort((a, b) => (b.member_count || 0) - (a.member_count || 0));
      const sortedByRating = [...formattedCourses]
        .filter(course => (course.reviewCount || 0) >= 3) // Only consider courses with at least 3 reviews
        .sort((a, b) => (b.averageRating || 0) - (a.averageRating || 0));

      // Assign rankings
      sortedByMembers.forEach((course, index) => {
        formattedCourses.find(c => c.id === course.id)!.memberRank = index + 1;
      });

      sortedByRating.forEach((course, index) => {
        formattedCourses.find(c => c.id === course.id)!.reviewRank = index + 1;
      });

      setCourses(formattedCourses);
    } catch (err) {
      console.error('Error fetching courses:', err);
      setError('Failed to load courses');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    checkCourseCount();
    fetchCourses();
    fetchDisciplines();
    if (user) {
      fetchEnrolledCourses();
    }
  }, [user, fetchCourses, fetchDisciplines, fetchEnrolledCourses]);

  const checkCourseCount = useCallback(async () => {
    try {
      const { count, error } = await supabase
        .from('courses')
        .select('*', { count: 'exact', head: true });
      
      if (error) throw error;
      setCourseCount(count);
    } catch (err) {
      console.error('Error checking course count:', err);
    }
  }, []);

  const handleTagClick = (tag: string) => {
    setSelectedTag(tag);
    
    if (tagsContainerRef.current) {
      const container = tagsContainerRef.current;
      const tagElements = container.querySelectorAll('button');
      const selectedTagElement = Array.from(tagElements).find(el => el.textContent === tag);
      
      if (selectedTagElement) {
        const containerWidth = container.offsetWidth;
        const tagPosition = selectedTagElement.offsetLeft;
        const tagWidth = selectedTagElement.offsetWidth;
        
        const scrollPosition = tagPosition - (containerWidth / 2) + (tagWidth / 2);
        
        container.scrollTo({
          left: Math.max(0, scrollPosition),
          behavior: 'smooth'
        });
      }
    }
  };

  // Mouse event handlers for drag scrolling
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!tagsContainerRef.current) return;
    setIsDragging(true);
    setStartX(e.pageX - tagsContainerRef.current.offsetLeft);
    setScrollLeft(tagsContainerRef.current.scrollLeft);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !tagsContainerRef.current) return;
    e.preventDefault();
    const x = e.pageX - tagsContainerRef.current.offsetLeft;
    const walk = (x - startX) * 2;
    tagsContainerRef.current.scrollLeft = scrollLeft - walk;
  };

  // Touch event handlers for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    if (!tagsContainerRef.current) return;
    setIsDragging(true);
    setStartX(e.touches[0].pageX - tagsContainerRef.current.offsetLeft);
    setScrollLeft(tagsContainerRef.current.scrollLeft);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || !tagsContainerRef.current) return;
    const x = e.touches[0].pageX - tagsContainerRef.current.offsetLeft;
    const walk = (x - startX) * 2;
    tagsContainerRef.current.scrollLeft = scrollLeft - walk;
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  const filteredCourses = courses.filter(course => {
    // Filter out enrolled courses
    if (enrolledCourseIds.includes(course.id)) {
      return false;
    }

    const searchLower = searchQuery.toLowerCase();
    const matchesSearch = searchQuery === '' || 
      course.title.toLowerCase().includes(searchLower) ||
      course.description.toLowerCase().includes(searchLower) ||
      course.tags.some(tag => tag.toLowerCase().includes(searchLower));
    
    // Filter by discipline
    const matchesDiscipline = selectedTag === 'All' || 
      (course.disciplines && course.disciplines.includes(selectedTag));
    
    return matchesSearch && matchesDiscipline;
  });

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p className="text-red-600 dark:text-red-500 mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="text-blue-600 dark:text-blue-500 hover:text-blue-800 dark:hover:text-blue-400"
          >
            Try again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-20">
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-lg mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Discover</h1>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500" size={20} />
            <input
              type="search"
              placeholder="Search courses..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-100 dark:bg-gray-700 border-none rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400"
            />
          </div>
          
          <div 
            ref={tagsContainerRef}
            className="mt-4 flex gap-2 overflow-x-auto pb-2 scrollbar-hide touch-pan-x"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none', scrollBehavior: 'smooth' }}
            onMouseDown={handleMouseDown}
            onMouseUp={handleMouseUp}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseUp}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            {availableTags.map((tag) => (
              <button
                key={tag}
                onClick={() => handleTagClick(tag)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap flex-shrink-0 ${
                  selectedTag === tag
                    ? 'bg-black dark:bg-white text-white dark:text-black'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      <main className="max-w-lg mx-auto px-4 py-6">
        {courseCount === 0 && (
          <div className="mb-6 p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg flex items-start">
            <AlertTriangle className="text-yellow-500 dark:text-yellow-400 mr-3 flex-shrink-0 mt-0.5" size={20} />
            <div>
              <p className="text-yellow-700 dark:text-yellow-300 font-medium">No courses available</p>
              <p className="text-yellow-600 dark:text-yellow-400 text-sm mt-1">
                Check back soon for new courses.
              </p>
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-16 h-16 border-4 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <div className="space-y-6">
            {filteredCourses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                isEnrolled={enrolledCourseIds.includes(course.id)}
                showRating={true}
              />
            ))}
            {filteredCourses.length === 0 && courses.length > 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500 dark:text-gray-400">No courses found matching your criteria</p>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}