import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { LessonData } from '../types/lesson';
import { 
  fetchLessonById, 
  checkInstructorStatus,
  checkLessonCompletion,
  checkLessonBookmark,
  updateLessonTitle,
  updateLessonNotes,
  updateLessonVideo 
} from '../services/lessonService';
import { completeLesson, uncompleteLesson } from '../services/courseService';
import { bookmarkLesson, unbookmarkLesson } from '../services/bookmarkService';
import { getVideoProgress } from '../services/videoProgressService';
import {
  LessonHeader,
  LessonVideo,
  LessonProgress,
  LessonActions,
  LessonNotes,
  AskCoach
} from '../components/lesson';

export function Lesson() {
  const { courseId, lessonId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [lesson, setLesson] = useState<LessonData | null>(null);
  const [loading, setLoading] = useState(true);
  const [completing, setCompleting] = useState(false);
  const [bookmarking, setBookmarking] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [videoProgress, setVideoProgress] = useState(0);
  const [watchedSeconds, setWatchedSeconds] = useState(0);
  const [canComplete, setCanComplete] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isInstructor, setIsInstructor] = useState(false);
  
  // Required percentage to mark as complete (70%)
  const requiredWatchPercentage = 70;

  useEffect(() => {
    if (!courseId || !lessonId || !user) return;
    
    const initializeLesson = async () => {
      try {
        setLoading(true);
        const [lessonData, instructorStatus] = await Promise.all([
          fetchLessonById(lessonId),
          checkInstructorStatus(user.id, courseId)
        ]);
        
        setLesson(lessonData);
        setIsInstructor(instructorStatus);
        
        if (!instructorStatus) {
          await Promise.all([
            checkCompletion(),
            checkBookmark(),
            checkVideoProgress()
          ]);
        }
      } catch (err) {
        console.error('Error initializing lesson:', err);
        setError('Failed to load lesson');
      } finally {
        setLoading(false);
      }
    };

    initializeLesson();
  }, [courseId, lessonId, user]);

  const checkCompletion = async () => {
    if (!user || !lessonId) return;
    const isCompleted = await checkLessonCompletion(user.id, lessonId);
    setIsCompleted(isCompleted);
  };

  const checkBookmark = async () => {
    if (!user || !lessonId) return;
    const isBookmarked = await checkLessonBookmark(user.id, lessonId);
    setIsBookmarked(isBookmarked);
  };

  const checkVideoProgress = async () => {
    if (!user || !lessonId) return;
    
    try {
      const progress = await getVideoProgress(user.id, lessonId);
      
      if (progress) {
        setVideoProgress(progress.progress);
        setWatchedSeconds(progress.watchedSeconds);
        setCanComplete(progress.progress >= requiredWatchPercentage);
      }
    } catch (err) {
      console.error('Error checking video progress:', err);
    }
  };

  const handleComplete = async () => {
    if (!user || !lesson || !courseId) return;
    
    if (!isCompleted && !canComplete) {
      alert(`You need to watch at least ${requiredWatchPercentage}% of the video to mark it as complete.`);
      return;
    }

    try {
      setCompleting(true);
      if (isCompleted) {
        await uncompleteLesson(user.id, courseId, lesson.id);
        setIsCompleted(false);
      } else {
        await completeLesson(user.id, lesson.course_id, lesson.id);
        setIsCompleted(true);
      }
    } catch (err) {
      console.error('Error updating completion:', err);
    } finally {
      setCompleting(false);
    }
  };

  const handleBookmark = async () => {
    if (!user || !lesson) return;
    
    try {
      setBookmarking(true);
      
      if (isBookmarked) {
        await unbookmarkLesson(user.id, lesson.id);
        setIsBookmarked(false);
      } else {
        await bookmarkLesson(user.id, lesson.course_id, lesson.id);
        setIsBookmarked(true);
      }
    } catch (err) {
      console.error('Error toggling bookmark:', err);
    } finally {
      setBookmarking(false);
    }
  };

  const handleProgressUpdate = (progress: number) => {
    setVideoProgress(progress);
    if (progress >= requiredWatchPercentage && !canComplete) {
      setCanComplete(true);
    }
  };

  const handleTitleUpdate = async (newTitle: string) => {
    if (!lesson) return;
    
    try {
      await updateLessonTitle(lesson.id, newTitle);
      setLesson(prev => prev ? { ...prev, title: newTitle } : null);
    } catch (err) {
      console.error('Error updating title:', err);
      setError('Failed to update title');
    }
  };

  const handleNotesUpdate = async (newNotes: string) => {
    if (!lesson) return;
    
    try {
      await updateLessonNotes(lesson.id, newNotes);
      setLesson(prev => prev ? { ...prev, lecture_notes: newNotes } : null);
    } catch (err) {
      console.error('Error updating notes:', err);
      setError('Failed to update notes');
    }
  };

  const handleVideoUpdate = async (url: string) => {
    if (!lesson) return;
    
    try {
      await updateLessonVideo(lesson.id, url);
      setLesson(prev => prev ? { ...prev, video_url: url } : null);
    } catch (err) {
      console.error('Error updating video:', err);
      setError('Failed to update video');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-pulse text-gray-600 dark:text-gray-300">Loading...</div>
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 dark:text-gray-300">Lesson not found</p>
          <button
            onClick={() => navigate(`/course/${courseId}`)}
            className="mt-4 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
          >
            Back to course
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <LessonHeader
        courseTitle={lesson.course_title}
        lessonTitle={lesson.title}
        isInstructor={isInstructor}
        onBack={() => navigate(-1)}
        onEdit={handleTitleUpdate}
      />

      <div className="max-w-lg mx-auto px-4 py-6">
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        <LessonVideo
          lessonId={lesson.id}
          courseId={lesson.course_id}
          videoUrl={lesson.video_url}
          title={lesson.title}
          isInstructor={isInstructor}
          onVideoUpload={handleVideoUpdate}
          initialProgress={videoProgress}
          initialTime={watchedSeconds}
          onProgressUpdate={handleProgressUpdate}
          requiredWatchPercentage={requiredWatchPercentage}
          onRequiredWatchReached={() => setCanComplete(true)}
        />

        {!isInstructor && (
          <>
            <LessonProgress
              progress={videoProgress}
              isCompleted={isCompleted}
              canComplete={canComplete}
              requiredPercentage={requiredWatchPercentage}
            />

            <LessonActions
              isCompleted={isCompleted}
              isBookmarked={isBookmarked}
              canComplete={canComplete}
              onComplete={handleComplete}
              onBookmark={handleBookmark}
              completing={completing}
              bookmarking={bookmarking}
            />
          </>
        )}

        <LessonNotes
          notes={lesson.lecture_notes || ''}
          isInstructor={isInstructor}
          onSave={handleNotesUpdate}
        />

        {!isInstructor && user && (
          <AskCoach
            courseId={lesson.course_id}
            lessonId={lesson.id}
            userId={user.id}
            onQuestionSent={() => navigate(`/course/${lesson.course_id}#coaching`)}
          />
        )}
      </div>
    </div>
  );
}