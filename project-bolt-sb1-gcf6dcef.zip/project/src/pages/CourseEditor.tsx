import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, Plus, Image as ImageIcon, Edit2, Save, Trash2, X, Check } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { CHAR_LIMITS } from '../lib/constants';
import { MediaUploader } from '../components/course/MediaUploader';
import { ImageUploader } from '../components/ImageUploader';
import { CourseDescription } from '../components/course/editor/CourseDescription';
import { PricingOptions } from '../components/course/editor/PricingOptions';
import { DeleteConfirmation } from '../components/course/editor/DeleteConfirmation';
import { CourseCard } from '../components/CourseCard';

interface CourseData {
  id?: string;
  title: string;
  tagline: string;
  description: string;
  image_url: string | null;
  logo_url: string | null;
  sport: string;
  disciplines: string[];
}

interface PricingOption {
  id?: string;
  title: string;
  price: number;
  renewal_period: 'monthly' | 'yearly' | null;
  features: string[];
  lessons_access: boolean;
  community_access: boolean;
  coaching_access: boolean;
  rankings_access: boolean;
}

interface CourseMedia {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail_url?: string;
  position: number;
  file?: File;
  uploading?: boolean;
}

export function CourseEditor() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { user, userProfile } = useAuth();
  const [courseData, setCourseData] = useState<CourseData>({
    title: '',
    tagline: '',
    description: '',
    image_url: null,
    logo_url: null,
    sport: 'Mountain biking',
    disciplines: []
  });
  const [pricingOptions, setPricingOptions] = useState<PricingOption[]>([]);
  const [selectedPricingIndex, setSelectedPricingIndex] = useState(0);
  const [courseMedia, setCourseMedia] = useState<CourseMedia[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editingDescription, setEditingDescription] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [availableDisciplines] = useState([
    'Slopestyle',
    'Freeride',
    'Downhill',
    'Enduro',
    'Cross country',
    'Trail riding',
    'Dirt jumping',
    'Bike park',
    'Technical'
  ]);
  const [availableSports] = useState([
    'Mountain biking',
    'BMX',
    'Skateboarding',
    'Surfing',
    'Snowboarding',
    'Skiing'
  ]);

  const isNewCourse = id === 'new';

  useEffect(() => {
    if (!isNewCourse) {
      fetchCourseData();
    } else {
      const savedData = sessionStorage.getItem('newCourseData');
      if (savedData) {
        try {
          const parsedData = JSON.parse(savedData);
          console.log("Loaded data from session storage:", parsedData);
          setCourseData(parsedData);
          
          // If there's saved media data, restore it
          if (parsedData.courseMedia && Array.isArray(parsedData.courseMedia)) {
            console.log("Found course media in session storage:", parsedData.courseMedia);
            setCourseMedia(parsedData.courseMedia);
          }
          
          // If there's saved pricing options, restore them
          if (parsedData.pricingOptions && Array.isArray(parsedData.pricingOptions)) {
            console.log("Found pricing options in session storage:", parsedData.pricingOptions);
            setPricingOptions(parsedData.pricingOptions);
            
            // Restore selected pricing index if available
            if (typeof parsedData.selectedPricingIndex === 'number') {
              setSelectedPricingIndex(parsedData.selectedPricingIndex);
            }
          }
        } catch (err) {
          console.error("Error parsing session storage data:", err);
        }
      }
      setLoading(false);
    }
  }, [id, isNewCourse]);

  const fetchCourseData = async () => {
    try {
      const { data: courseData, error: courseError } = await supabase
        .from('courses')
        .select(`
          *,
          course_plans (
            id,
            title,
            price,
            renewal_period,
            features,
            lessons_access,
            community_access,
            coaching_access,
            rankings_access
          ),
          course_media (
            id,
            type,
            url,
            thumbnail_url,
            position
          )
        `)
        .eq('id', id)
        .single();

      if (courseError) throw courseError;

      if (courseData.instructor_id !== user?.id) {
        navigate('/');
        return;
      }

      setCourseData({
        id: courseData.id,
        title: courseData.title,
        tagline: courseData.tagline || '',
        description: courseData.description || '',
        image_url: courseData.image_url,
        logo_url: courseData.logo_url,
        sport: courseData.sport || 'Mountain biking',
        disciplines: courseData.disciplines || [],
      });

      // Set pricing options and default selected index
      if (courseData.course_plans && courseData.course_plans.length > 0) {
        setPricingOptions(courseData.course_plans);
        setSelectedPricingIndex(0); // Default to first plan
      } else {
        // Create a default pricing option if none exists
        setPricingOptions([{
          title: 'Monthly Plan',
          price: courseData.price || 49.99,
          renewal_period: 'monthly',
          features: ['Full course access', 'Community access'],
          lessons_access: true,
          community_access: true,
          coaching_access: true,
          rankings_access: true
        }]);
      }
      
      // Format course media
      if (courseData.course_media && courseData.course_media.length > 0) {
        console.log("Loaded course media from database:", courseData.course_media);
        const sortedMedia = [...courseData.course_media].sort((a, b) => a.position - b.position);
        setCourseMedia(sortedMedia);
      } else if (courseData.image_url) {
        // If no media but we have an image_url, create a media item from it
        console.log("No course media found, creating from image_url:", courseData.image_url);
        setCourseMedia([{
          id: 'main-image',
          type: 'image',
          url: courseData.image_url,
          position: 0
        }]);
      }
    } catch (err) {
      console.error('Error fetching course:', err);
      setError('Failed to load course data');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!courseData || !user) return;

    try {
      setSaving(true);
      setError(null);

      // Validate required fields
      if (!courseData.title.trim()) {
        setError('Course title is required');
        setSaving(false);
        return;
      }

      if (!courseData.tagline.trim()) {
        setError('Course tagline is required');
        setSaving(false);
        return;
      }

      if (!courseData.description.trim()) {
        setError('Course description is required');
        setSaving(false);
        return;
      }

      // Use the first media item's URL as the course image if available
      const mainImageUrl = courseMedia.length > 0 ? courseMedia[0].url : null;

      if (!mainImageUrl) {
        setError('Please add at least one image for the course');
        setSaving(false);
        return;
      }

      // Get the price from the selected pricing option
      const price = pricingOptions.length > 0 ? pricingOptions[selectedPricingIndex].price : 49.99;

      const courseInsertData = {
        title: courseData.title.trim(),
        tagline: courseData.tagline.trim(),
        description: courseData.description.trim(),
        image_url: mainImageUrl,
        logo_url: courseData.logo_url,
        price: price,
        sport: courseData.sport,
        disciplines: courseData.disciplines,
        instructor_id: user.id
      };

      console.log("Course data to save:", courseInsertData);

      if (isNewCourse) {
        // Create new course - use insert without select to avoid RLS issues
        const { error: courseError } = await supabase
          .from('courses')
          .insert([courseInsertData]);

        if (courseError) throw courseError;
        
        // Get the newly created course by querying for it
        const { data: newCourseData, error: fetchError } = await supabase
          .from('courses')
          .select('id')
          .eq('title', courseData.title)
          .eq('instructor_id', user.id)
          .order('created_at', { ascending: false })
          .limit(1);
            
        if (fetchError || !newCourseData || newCourseData.length === 0) {
          console.error("Could not find newly created course:", fetchError);
          // Navigate to home as fallback
          sessionStorage.removeItem('newCourseData');
          navigate('/');
          return;
        }
        
        const newCourse = newCourseData[0];
        console.log("Found newly created course:", newCourse);

        // Insert course media
        if (courseMedia.length > 0) {
          console.log("Inserting course media:", courseMedia.length, "items");
          const mediaToInsert = courseMedia.map((media, index) => ({
            course_id: newCourse.id,
            type: media.type,
            url: media.url,
            thumbnail_url: media.thumbnail_url,
            position: index
          }));

          const { error: mediaError } = await supabase
            .from('course_media')
            .insert(mediaToInsert);

          if (mediaError) {
            console.error("Error inserting course media:", mediaError);
            // Don't throw here - course was created successfully
          }
        }

        // Create pricing options if they exist
        if (pricingOptions.length > 0) {
          const plansToInsert = pricingOptions.map(option => ({
            course_id: newCourse.id,
            title: option.title,
            price: option.price,
            renewal_period: option.renewal_period,
            features: option.features,
            lessons_access: option.lessons_access,
            community_access: option.community_access,
            coaching_access: option.coaching_access,
            rankings_access: option.rankings_access
          }));

          const { error: plansError } = await supabase
            .from('course_plans')
            .insert(plansToInsert);

          if (plansError) {
            console.error("Error inserting course plans:", plansError);
            // Don't throw here - course was created successfully
          }
        }

        // Clear session storage
        sessionStorage.removeItem('newCourseData');

        // Navigate to the new course skills tab
        navigate(`/course/${newCourse.id}#skills`);
      } else {
        // Update existing course
        const { error: courseError } = await supabase
          .from('courses')
          .update(courseInsertData)
          .eq('id', id);

        if (courseError) throw courseError;

        // Update course media
        if (courseMedia.length > 0) {
          console.log("Updating course media for existing course");
          
          // First delete existing media
          const { error: deleteError } = await supabase
            .from('course_media')
            .delete()
            .eq('course_id', id);

          if (deleteError) {
            console.error("Error deleting existing course media:", deleteError);
          } else {
            // Then insert new media
            const mediaToInsert = courseMedia.map((media, index) => ({
              course_id: id,
              type: media.type,
              url: media.url,
              thumbnail_url: media.thumbnail_url,
              position: index
            }));

            const { error: mediaError } = await supabase
              .from('course_media')
              .insert(mediaToInsert);

            if (mediaError) {
              console.error("Error inserting updated course media:", mediaError);
            }
          }
        }

        // Update pricing options
        // First delete existing plans
        const { error: deletePlansError } = await supabase
          .from('course_plans')
          .delete()
          .eq('course_id', id);

        if (deletePlansError) {
          console.error("Error deleting existing plans:", deletePlansError);
        } else {
          // Then insert new plans
          if (pricingOptions.length > 0) {
            const plansToInsert = pricingOptions.map(option => ({
              course_id: id,
              title: option.title,
              price: option.price,
              renewal_period: option.renewal_period,
              features: option.features,
              lessons_access: option.lessons_access,
              community_access: option.community_access,
              coaching_access: option.coaching_access,
              rankings_access: option.rankings_access
            }));

            const { error: plansError } = await supabase
              .from('course_plans')
              .insert(plansToInsert);

            if (plansError) {
              console.error("Error inserting updated plans:", plansError);
            }
          }
        }

        // Navigate to the course skills tab
        navigate(`/course/${id}#skills`);
      }
    } catch (err: any) {
      console.error('Error saving course:', err);
      setError(err.message || 'Failed to save course');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteCourse = async () => {
    if (!courseData?.id || !user) return;

    try {
      setSaving(true);
      setError(null);

      const { error } = await supabase
        .from('courses')
        .delete()
        .eq('id', courseData.id)
        .eq('instructor_id', user.id);

      if (error) throw error;

      navigate('/');
    } catch (err: any) {
      console.error('Error deleting course:', err);
      setError(err.message || 'Failed to delete course');
    } finally {
      setSaving(false);
      setShowDeleteConfirm(false);
    }
  };

  const handleMediaChange = (media: CourseMedia[]) => {
    console.log("Media changed:", media);
    setCourseMedia(media);
    
    // Update the main image if there's at least one media item
    if (media.length > 0 && media[0].type === 'image') {
      setCourseData(prev => ({
        ...prev,
        image_url: media[0].url
      }));
    }

    // Save to session storage for new courses
    if (isNewCourse) {
      const currentData = {
        ...courseData,
        courseMedia: media,
        pricingOptions,
        selectedPricingIndex
      };
      sessionStorage.setItem('newCourseData', JSON.stringify(currentData));
    }
  };

  const handleLogoUpload = (url: string) => {
    setCourseData(prev => ({
      ...prev,
      logo_url: url
    }));
    
    // Save to session storage for new courses
    if (isNewCourse) {
      const currentData = {
        ...courseData,
        logo_url: url,
        courseMedia,
        pricingOptions,
        selectedPricingIndex
      };
      sessionStorage.setItem('newCourseData', JSON.stringify(currentData));
    }
  };

  const handleAddPricingOption = (option: PricingOption) => {
    const newOptions = [...pricingOptions, option];
    setPricingOptions(newOptions);
    
    // Save to session storage for new courses
    if (isNewCourse) {
      const currentData = {
        ...courseData,
        courseMedia,
        pricingOptions: newOptions,
        selectedPricingIndex
      };
      sessionStorage.setItem('newCourseData', JSON.stringify(currentData));
    }
  };

  const handleDeletePricingOption = (index: number) => {
    if (pricingOptions.length <= 1) {
      return; // Keep at least one pricing option
    }
    
    const newOptions = pricingOptions.filter((_, i) => i !== index);
    setPricingOptions(newOptions);
    
    // Update selected index if needed
    if (selectedPricingIndex >= newOptions.length) {
      setSelectedPricingIndex(newOptions.length - 1);
    }
    
    // Save to session storage for new courses
    if (isNewCourse) {
      const currentData = {
        ...courseData,
        courseMedia,
        pricingOptions: newOptions,
        selectedPricingIndex: selectedPricingIndex >= newOptions.length ? newOptions.length - 1 : selectedPricingIndex
      };
      sessionStorage.setItem('newCourseData', JSON.stringify(currentData));
    }
  };

  const toggleDiscipline = (discipline: string) => {
    setCourseData(prev => {
      const disciplines = prev.disciplines.includes(discipline)
        ? prev.disciplines.filter(d => d !== discipline)
        : [...prev.disciplines, discipline];
      return { ...prev, disciplines };
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 sticky top-0 z-10 shadow-sm">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center">
              <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
                <ChevronLeft size={24} />
              </button>
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
                {isNewCourse ? 'Create New Course' : 'Edit Course'}
              </h1>
            </div>
            <div className="flex items-center space-x-3">
              {!isNewCourse && (
                <button
                  onClick={() => setShowDeleteConfirm(true)}
                  className="px-4 py-2 text-red-500 dark:text-red-400 rounded-lg font-medium flex items-center"
                >
                  <Trash2 size={18} className="mr-2" />
                  Delete
                </button>
              )}
              <button
                onClick={handleSave}
                disabled={saving}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium flex items-center"
              >
                <Save size={18} className="mr-2" />
                {saving ? 'Saving...' : 'Publish'}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        <div className="space-y-6">
          {/* Basic Info */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Basic Information</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Course Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={courseData.title}
                  onChange={(e) => setCourseData({ ...courseData, title: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                  placeholder="e.g., Mountain Bike Fundamentals"
                  maxLength={CHAR_LIMITS.COURSE_TITLE}
                />
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  {courseData.title.length}/{CHAR_LIMITS.COURSE_TITLE} characters
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Tagline <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={courseData.tagline}
                  onChange={(e) => setCourseData({ ...courseData, tagline: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                  placeholder="e.g. Master essential MTB skills from scratch"
                  maxLength={CHAR_LIMITS.COURSE_TAGLINE}
                />
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  {courseData.tagline.length}/{CHAR_LIMITS.COURSE_TAGLINE} characters
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={courseData.description}
                  onChange={(e) => setCourseData({ ...courseData, description: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white dark:placeholder-gray-400 min-h-[120px] resize-none"
                  placeholder="Describe your course in detail..."
                  maxLength={CHAR_LIMITS.COURSE_DESCRIPTION}
                />
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  {courseData.description.length}/{CHAR_LIMITS.COURSE_DESCRIPTION} characters
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Sport
                </label>
                <select
                  value={courseData.sport}
                  onChange={(e) => setCourseData({ ...courseData, sport: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                >
                  {availableSports.map((sport) => (
                    <option key={sport} value={sport}>
                      {sport}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Disciplines
                </label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {availableDisciplines.map((discipline) => (
                    <button
                      key={discipline}
                      onClick={() => toggleDiscipline(discipline)}
                      className={`px-3 py-1.5 rounded-full text-sm ${
                        courseData.disciplines.includes(discipline)
                          ? 'bg-blue-500 text-white'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                      }`}
                    >
                      {discipline}
                      {courseData.disciplines.includes(discipline) && (
                        <Check size={14} className="inline-block ml-1" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Course Media */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Course Media</h2>
              <div className="text-sm text-gray-500 dark:text-gray-400">
                {courseMedia.length} of 6 media items
              </div>
            </div>
            
            <MediaUploader
              courseId={id || user?.id || 'temp'}
              initialMedia={courseMedia}
              onMediaChange={handleMediaChange}
              maxItems={6}
            />
            
            <div className="mt-4">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Add up to 6 images or videos to showcase your course. The first item will be used as the main course image.
              </p>
            </div>
          </div>

          {/* Course Logo */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Course Logo</h2>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center overflow-hidden mb-4">
                {courseData.logo_url ? (
                  <img
                    src={courseData.logo_url}
                    alt="Course Logo"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <ImageIcon size={32} className="text-gray-400 dark:text-gray-500" />
                )}
              </div>
              <div className="flex justify-center">
                <ImageUploader
                  id="course-logo-uploader"
                  onUploadComplete={handleLogoUpload}
                  buttonText={courseData.logo_url ? "Change Logo" : "Add Logo"}
                  folder="course-logos"
                />
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-4 text-center">
                Add a logo for your course. This will appear next to the title on the course card.
              </p>
            </div>
          </div>

          {/* Pricing Options */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Pricing Options</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {pricingOptions.length === 0 ? 'Add at least one pricing option' : ''}
              </p>
            </div>
            
            <PricingOptions
              options={pricingOptions}
              onAdd={handleAddPricingOption}
              onDelete={handleDeletePricingOption}
              selectedIndex={selectedPricingIndex}
              onSelectIndex={setSelectedPricingIndex}
            />
          </div>

          {/* Course Preview */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Course Preview</h2>
            
            <div className="flex justify-center">
              <div className="w-full max-w-sm">
                <CourseCard
                  course={{
                    id: courseData.id || 'preview',
                    title: courseData.title || 'Course Title',
                    description: courseData.description || 'Course Description',
                    price: pricingOptions.length > 0 ? pricingOptions[selectedPricingIndex].price : 49.99,
                    image_url: courseData.image_url,
                    logo_url: courseData.logo_url,
                    instructor: {
                      id: user?.id || 'preview',
                      username: userProfile?.username || 'username',
                      avatar_url: userProfile?.avatar_url,
                      is_verified: userProfile?.is_verified
                    },
                    tags: [],
                    disciplines: courseData.disciplines,
                    memberRank: 1,
                    reviewRank: 1
                  }}
                  showRating={true}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <DeleteConfirmation
          onConfirm={handleDeleteCourse}
          onCancel={() => setShowDeleteConfirm(false)}
        />
      )}
    </div>
  );
}