import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  BarChart2, 
  Settings, 
  Database, 
  FileText, 
  MessageSquare,
  ChevronLeft,
  Video,
  HardDrive,
  Shield,
  LogOut,
  Flag
} from 'lucide-react';
import { SupportTickets } from '../../components/admin/SupportTickets';
import { UserReports } from '../../components/admin/UserReports';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';

export function AdminPanel() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'dashboard' | 'users' | 'content' | 'support' | 'reports' | 'settings'>('dashboard');
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeCourses: 0,
    totalRevenue: 0,
    openTickets: 0,
    pendingReports: 0
  });
  const [loading, setLoading] = useState(true);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);

  useEffect(() => {
    fetchStats();
    fetchRecentActivity();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);
      
      // Get total users count
      const { count: userCount, error: userError } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });
      
      if (userError) throw userError;
      
      // Get active courses count
      const { count: courseCount, error: courseError } = await supabase
        .from('courses')
        .select('*', { count: 'exact', head: true });
      
      if (courseError) throw courseError;
      
      // Get open tickets count
      const { count: ticketCount, error: ticketError } = await supabase
        .from('support_tickets')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'open');
      
      if (ticketError) throw ticketError;
      
      // Get pending reports count
      const { count: reportCount, error: reportError } = await supabase
        .from('user_reports')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');
      
      if (reportError) throw reportError;
      
      // Calculate total revenue (in a real app, this would come from actual payment data)
      // For now, we'll estimate based on enrollments and average course price
      const { data: enrollments, error: enrollmentError } = await supabase
        .from('enrollments')
        .select('course_id');
      
      if (enrollmentError) throw enrollmentError;
      
      // Assuming average revenue of $50 per enrollment
      const estimatedRevenue = (enrollments?.length || 0) * 50;
      
      setStats({
        totalUsers: userCount || 0,
        activeCourses: courseCount || 0,
        totalRevenue: estimatedRevenue,
        openTickets: ticketCount || 0,
        pendingReports: reportCount || 0
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRecentActivity = async () => {
    try {
      // Get recent user registrations - using updated_at instead of created_at
      const { data: recentUsers, error: userError } = await supabase
        .from('profiles')
        .select('username, updated_at')
        .order('updated_at', { ascending: false })
        .limit(3);
      
      if (userError) throw userError;
      
      // Get recent courses
      const { data: recentCourses, error: courseError } = await supabase
        .from('courses')
        .select('title, created_at')
        .order('created_at', { ascending: false })
        .limit(3);
      
      if (courseError) throw courseError;
      
      // Get recent tickets
      const { data: recentTickets, error: ticketError } = await supabase
        .from('support_tickets')
        .select('subject, created_at')
        .order('created_at', { ascending: false })
        .limit(3);
      
      if (ticketError) throw ticketError;
      
      // Get recent reports
      const { data: recentReports, error: reportError } = await supabase
        .from('user_reports')
        .select(`
          reason, 
          created_at,
          reported_user:reported_user_id (
            username
          )
        `)
        .order('created_at', { ascending: false })
        .limit(3);
      
      if (reportError) throw reportError;
      
      // Combine and sort by date, using updated_at for profiles
      const activity = [
        ...(recentUsers || []).map(user => ({
          type: 'user',
          title: 'New user registered',
          detail: user.username,
          time: user.updated_at // Changed from created_at to updated_at
        })),
        ...(recentCourses || []).map(course => ({
          type: 'course',
          title: 'New course published',
          detail: course.title,
          time: course.created_at
        })),
        ...(recentTickets || []).map(ticket => ({
          type: 'ticket',
          title: 'New support ticket',
          detail: ticket.subject,
          time: ticket.created_at
        })),
        ...(recentReports || []).map(report => ({
          type: 'report',
          title: 'New user report',
          detail: `Report against @${report.reported_user?.username || 'user'}`,
          time: report.created_at
        }))
      ].sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime())
      .slice(0, 5);
      
      setRecentActivity(activity);
    } catch (error) {
      console.error('Error fetching recent activity:', error);
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return 'just now';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} ${minutes === 1 ? 'minute' : 'minutes'} ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} ${days === 1 ? 'day' : 'days'} ago`;
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-6">Dashboard</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-medium mb-2">Total Users</h3>
                <p className="text-3xl font-bold">{stats.totalUsers.toLocaleString()}</p>
                <p className="text-sm text-green-500 mt-2">Active accounts</p>
              </div>
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-medium mb-2">Active Courses</h3>
                <p className="text-3xl font-bold">{stats.activeCourses}</p>
                <p className="text-sm text-green-500 mt-2">Published courses</p>
              </div>
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-medium mb-2">Total Revenue</h3>
                <p className="text-3xl font-bold">${stats.totalRevenue.toLocaleString()}</p>
                <p className="text-sm text-green-500 mt-2">Estimated total</p>
              </div>
            </div>
            
            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-medium mb-4">Recent Activity</h3>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-start">
                      <div className={`p-2 rounded-full mr-3 ${
                        activity.type === 'user' 
                          ? 'bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' 
                          : activity.type === 'course'
                            ? 'bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400'
                            : activity.type === 'report'
                              ? 'bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400'
                              : 'bg-purple-100 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400'
                      }`}>
                        {activity.type === 'user' ? (
                          <Users size={16} />
                        ) : activity.type === 'course' ? (
                          <FileText size={16} />
                        ) : activity.type === 'report' ? (
                          <Flag size={16} />
                        ) : (
                          <MessageSquare size={16} />
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-medium">{activity.title}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{activity.detail}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{formatTimeAgo(activity.time)}</p>
                      </div>
                    </div>
                  ))}
                  
                  {recentActivity.length === 0 && (
                    <p className="text-gray-500 dark:text-gray-400 text-center py-4">No recent activity</p>
                  )}
                </div>
              </div>
              
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-medium mb-4">System Status</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">API</span>
                    <span className="px-2 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 rounded-full text-xs">Operational</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Database</span>
                    <span className="px-2 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 rounded-full text-xs">Operational</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Storage</span>
                    <span className="px-2 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 rounded-full text-xs">Operational</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Auth</span>
                    <span className="px-2 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 rounded-full text-xs">Operational</span>
                  </div>
                </div>
                
                <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
                  <h4 className="font-medium mb-2">Support & Reports</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Open tickets</span>
                      <span className="px-2 py-1 bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-300 rounded-full text-xs">{stats.openTickets}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Pending reports</span>
                      <span className="px-2 py-1 bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300 rounded-full text-xs">{stats.pendingReports}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      case 'users':
        return (
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold">User Management</h2>
              <button 
                onClick={() => navigate('/admin/users')}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm"
              >
                View All Users
              </button>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
              <p className="text-gray-500 dark:text-gray-400">
                Manage user accounts, permissions, and access controls.
              </p>
              
              <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gray-50 dark:bg-gray-750 p-4 rounded-lg">
                  <h3 className="font-medium mb-2">Active Users</h3>
                  <p className="text-2xl font-bold">{stats.totalUsers}</p>
                </div>
                <div className="bg-gray-50 dark:bg-gray-750 p-4 rounded-lg">
                  <h3 className="font-medium mb-2">Coaches</h3>
                  <p className="text-2xl font-bold">
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      "Loading..."
                    )}
                  </p>
                </div>
                <div className="bg-gray-50 dark:bg-gray-750 p-4 rounded-lg">
                  <h3 className="font-medium mb-2">New This Week</h3>
                  <p className="text-2xl font-bold">
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      "Loading..."
                    )}
                  </p>
                </div>
              </div>
            </div>
          </div>
        );
      case 'content':
        return (
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-6">Content Management</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                <div className="flex items-center mb-4">
                  <Video className="text-blue-500 mr-3" size={24} />
                  <h3 className="text-lg font-medium">Video Management</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Manage course videos, upload new content, and monitor video analytics.
                </p>
                <button 
                  onClick={() => {}}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm"
                >
                  Manage Videos
                </button>
              </div>
              
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                <div className="flex items-center mb-4">
                  <HardDrive className="text-purple-500 mr-3" size={24} />
                  <h3 className="text-lg font-medium">Storage Management</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Manage storage buckets, file uploads, and storage quotas.
                </p>
                <button 
                  onClick={() => {}}
                  className="px-4 py-2 bg-purple-500 text-white rounded-lg text-sm"
                >
                  Manage Storage
                </button>
              </div>
            </div>
          </div>
        );
      case 'support':
        return <SupportTickets />;
      case 'reports':
        return <UserReports />;
      case 'settings':
        return (
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-6">Admin Settings</h2>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-medium mb-4">Security Settings</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Two-Factor Authentication</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Require 2FA for all admin accounts</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">API Access</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Allow API access for third-party integrations</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Audit Logging</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Enable detailed audit logs for admin actions</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex">
      {/* Sidebar */}
      <div className="w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 hidden md:block">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center">
            <Shield className="text-blue-500 mr-2" size={24} />
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">Admin Panel</h1>
          </div>
        </div>
        <nav className="p-4">
          <ul className="space-y-2">
            <li>
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`w-full flex items-center p-2 rounded-lg ${
                  activeTab === 'dashboard'
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750'
                }`}
              >
                <BarChart2 size={20} className="mr-3" />
                Dashboard
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('users')}
                className={`w-full flex items-center p-2 rounded-lg ${
                  activeTab === 'users'
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750'
                }`}
              >
                <Users size={20} className="mr-3" />
                Users
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('content')}
                className={`w-full flex items-center p-2 rounded-lg ${
                  activeTab === 'content'
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750'
                }`}
              >
                <FileText size={20} className="mr-3" />
                Content
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('support')}
                className={`w-full flex items-center p-2 rounded-lg ${
                  activeTab === 'support'
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750'
                }`}
              >
                <MessageSquare size={20} className="mr-3" />
                Support
                {stats.openTickets > 0 && (
                  <span className="ml-auto bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {stats.openTickets}
                  </span>
                )}
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('reports')}
                className={`w-full flex items-center p-2 rounded-lg ${
                  activeTab === 'reports'
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750'
                }`}
              >
                <Flag size={20} className="mr-3" />
                User Reports
                {stats.pendingReports > 0 && (
                  <span className="ml-auto bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {stats.pendingReports}
                  </span>
                )}
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('settings')}
                className={`w-full flex items-center p-2 rounded-lg ${
                  activeTab === 'settings'
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750'
                }`}
              >
                <Settings size={20} className="mr-3" />
                Settings
              </button>
            </li>
            <li className="mt-8 pt-4 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={() => navigate('/')}
                className="w-full flex items-center p-2 rounded-lg text-red-500 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/10"
              >
                <LogOut size={20} className="mr-3" />
                Exit Admin Panel
              </button>
            </li>
          </ul>
        </nav>
      </div>

      {/* Mobile Header */}
      <div className="md:hidden bg-white dark:bg-gray-800 w-full border-b border-gray-200 dark:border-gray-700 fixed top-0 z-10">
        <div className="flex items-center justify-between p-4">
          <button onClick={() => navigate('/')} className="text-gray-700 dark:text-gray-300">
            <ChevronLeft size={24} />
          </button>
          <div className="flex items-center">
            <Shield className="text-blue-500 mr-2" size={20} />
            <h1 className="text-lg font-bold text-gray-900 dark:text-white">Admin Panel</h1>
          </div>
          <div className="w-6"></div> {/* Empty div for flex spacing */}
        </div>
        
        {/* Mobile Navigation */}
        <div className="flex overflow-x-auto scrollbar-hide">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex-1 py-2 px-3 text-center text-sm ${
              activeTab === 'dashboard'
                ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
                : 'text-gray-700 dark:text-gray-300'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`flex-1 py-2 px-3 text-center text-sm ${
              activeTab === 'users'
                ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
                : 'text-gray-700 dark:text-gray-300'
            }`}
          >
            Users
          </button>
          <button
            onClick={() => setActiveTab('support')}
            className={`flex-1 py-2 px-3 text-center text-sm ${
              activeTab === 'support'
                ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
                : 'text-gray-700 dark:text-gray-300'
            }`}
          >
            Support
            {stats.openTickets > 0 && (
              <span className="ml-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 inline-flex items-center justify-center">
                {stats.openTickets}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`flex-1 py-2 px-3 text-center text-sm ${
              activeTab === 'reports'
                ? 'border-b-2 border-blue-500 text-blue-600 dark:text-blue-400'
                : 'text-gray-700 dark:text-gray-300'
            }`}
          >
            Reports
            {stats.pendingReports > 0 && (
              <span className="ml-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 inline-flex items-center justify-center">
                {stats.pendingReports}
              </span>
            )}
          </button>
        </div>
        
        {/* Mobile Exit Button */}
        <div className="fixed bottom-4 right-4 z-50">
          <button
            onClick={() => navigate('/')}
            className="p-3 bg-red-500 text-white rounded-full shadow-lg"
            aria-label="Exit Admin Panel"
          >
            <LogOut size={24} />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 md:ml-64 md:mt-0 mt-24">
        {renderTabContent()}
      </div>
    </div>
  );
}