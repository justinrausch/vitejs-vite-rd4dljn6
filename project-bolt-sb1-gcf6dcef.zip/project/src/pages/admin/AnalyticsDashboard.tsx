import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, DollarSign, Users, TrendingUp, Clock } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { supabase } from '../../lib/supabase';

export function AnalyticsDashboard() {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [courseTitle, setCourseTitle] = useState('');
  const [stats, setStats] = useState({
    totalRevenue: 0,
    activeStudents: 0,
    completionRate: 0,
    avgWatchTime: 0
  });

  const [revenueData, setRevenueData] = useState([
    { month: 'Jan', revenue: 2400 },
    { month: 'Feb', revenue: 3600 },
    { month: 'Mar', revenue: 3200 },
    { month: 'Apr', revenue: 4500 },
    { month: 'May', revenue: 3800 },
    { month: 'Jun', revenue: 5200 }
  ]);

  const [engagementData, setEngagementData] = useState([
    { week: 'Week 1', students: 45 },
    { week: 'Week 2', students: 52 },
    { week: 'Week 3', students: 49 },
    { week: 'Week 4', students: 63 },
    { week: 'Week 5', students: 58 },
    { week: 'Week 6', students: 71 }
  ]);

  useEffect(() => {
    fetchCourseData();
  }, [courseId]);

  const fetchCourseData = async () => {
    if (!courseId) return;

    try {
      setLoading(true);
      setError(null);

      // Fetch course title
      const { data: course, error: courseError } = await supabase
        .from('courses')
        .select('title')
        .eq('id', courseId)
        .single();

      if (courseError) throw courseError;
      setCourseTitle(course.title);

      // Fetch enrollments count
      const { count: studentsCount } = await supabase
        .from('enrollments')
        .select('*', { count: 'exact', head: true })
        .eq('course_id', courseId);

      // Update stats
      setStats({
        totalRevenue: 12700,
        activeStudents: studentsCount || 0,
        completionRate: 68,
        avgWatchTime: 45
      });

    } catch (err) {
      console.error('Error fetching course data:', err);
      setError('Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center py-4">
            <button 
              onClick={() => navigate(`/course/${courseId}`)}
              className="mr-4 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100"
            >
              <ChevronLeft size={24} />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Analytics Dashboard</h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">{courseTitle}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Revenue</h3>
              <DollarSign className="text-green-500" size={20} />
            </div>
            <p className="mt-2 text-3xl font-semibold text-gray-900 dark:text-white">
              ${stats.totalRevenue.toLocaleString()}
            </p>
            <p className="mt-2 text-sm text-green-500">+12% from last month</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Active Students</h3>
              <Users className="text-blue-500" size={20} />
            </div>
            <p className="mt-2 text-3xl font-semibold text-gray-900 dark:text-white">
              {stats.activeStudents}
            </p>
            <p className="mt-2 text-sm text-blue-500">+8% from last month</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Completion Rate</h3>
              <TrendingUp className="text-purple-500" size={20} />
            </div>
            <p className="mt-2 text-3xl font-semibold text-gray-900 dark:text-white">
              {stats.completionRate}%
            </p>
            <p className="mt-2 text-sm text-purple-500">+5% from last month</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Avg. Watch Time</h3>
              <Clock className="text-orange-500" size={20} />
            </div>
            <p className="mt-2 text-3xl font-semibold text-gray-900 dark:text-white">
              {stats.avgWatchTime}min
            </p>
            <p className="mt-2 text-sm text-orange-500">+3% from last month</p>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Revenue Chart */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-6">Revenue Over Time</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={revenueData}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="month" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    stroke="#3B82F6"
                    fillOpacity={1}
                    fill="url(#colorRevenue)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Student Engagement Chart */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-6">Student Engagement</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={engagementData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="week" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip />
                  <Bar dataKey="students" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}