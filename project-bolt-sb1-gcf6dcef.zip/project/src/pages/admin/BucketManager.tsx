import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, Upload, Trash2, FolderOpen, File, RefreshCw } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';

interface Lesson {
  id: string;
  title: string;
  chapter_id: string;
  chapter_title: string;
}

interface FileObject {
  name: string;
  id: string;
  updated_at: string;
  size: number;
  bucketId: string;
}

export function BucketManager() {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [courseTitle, setCourseTitle] = useState('');
  const [selectedBucket, setSelectedBucket] = useState<string | null>(null);
  const [files, setFiles] = useState<FileObject[]>([]);
  const [uploading, setUploading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (!user) return;
    fetchCourseAndLessons();
  }, [user, courseId]);

  useEffect(() => {
    if (selectedBucket) {
      fetchFiles(selectedBucket);
    }
  }, [selectedBucket]);

  const fetchCourseAndLessons = async () => {
    try {
      setLoading(true);
      setError(null);

      // First check if the user is the instructor for this course
      const { data: courseData, error: courseError } = await supabase
        .from('courses')
        .select('id, title, instructor_id')
        .eq('id', courseId)
        .single();

      if (courseError) throw courseError;

      if (courseData.instructor_id !== user?.id) {
        throw new Error('You do not have permission to manage videos for this course');
      }

      setCourseTitle(courseData.title);

      // Fetch all lessons for this course
      const { data, error } = await supabase
        .from('course_lessons')
        .select(`
          id,
          title,
          chapter_id,
          course_chapters!inner (
            id,
            title,
            course_id
          )
        `)
        .eq('course_chapters.course_id', courseId)
        .order('course_chapters.position', { ascending: true })
        .order('position', { ascending: true });

      if (error) throw error;

      // Format the data
      const formattedLessons = data.map(lesson => ({
        id: lesson.id,
        title: lesson.title,
        chapter_id: lesson.chapter_id,
        chapter_title: lesson.course_chapters.title
      }));

      setLessons(formattedLessons);
      
      // Set the course bucket as the default selected bucket
      setSelectedBucket(`course_${courseId}`);
    } catch (err: any) {
      console.error('Error fetching course and lessons:', err);
      setError(err.message || 'Failed to load course data');
    } finally {
      setLoading(false);
    }
  };

  const fetchFiles = async (bucketId: string) => {
    try {
      setRefreshing(true);
      
      const { data, error } = await supabase.storage
        .from(bucketId)
        .list('', {
          limit: 100,
          offset: 0,
          sortBy: { column: 'name', order: 'asc' }
        });

      if (error) throw error;

      if (data) {
        setFiles(data.map(file => ({
          ...file,
          bucketId
        })));
      }
    } catch (err: any) {
      console.error('Error fetching files:', err);
      setError(`Failed to load files from bucket: ${err.message}`);
      setFiles([]);
    } finally {
      setRefreshing(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedBucket) return;
    
    const files = e.target.files;
    if (!files || files.length === 0) return;

    try {
      setUploading(true);
      setError(null);

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const filePath = file.name;

        const { error } = await supabase.storage
          .from(selectedBucket)
          .upload(filePath, file, {
            cacheControl: '3600',
            upsert: true
          });

        if (error) throw error;
      }

      // Refresh the file list
      fetchFiles(selectedBucket);
    } catch (err: any) {
      console.error('Error uploading file:', err);
      setError(`Failed to upload file: ${err.message}`);
    } finally {
      setUploading(false);
      // Clear the file input
      e.target.value = '';
    }
  };

  const handleDeleteFile = async (fileName: string, bucketId: string) => {
    if (!confirm(`Are you sure you want to delete ${fileName}?`)) return;

    try {
      const { error } = await supabase.storage
        .from(bucketId)
        .remove([fileName]);

      if (error) throw error;

      // Refresh the file list
      fetchFiles(bucketId);
    } catch (err: any) {
      console.error('Error deleting file:', err);
      setError(`Failed to delete file: ${err.message}`);
    }
  };

  const handleRefresh = () => {
    if (selectedBucket) {
      fetchFiles(selectedBucket);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileUrl = (fileName: string, bucketId: string) => {
    const { data } = supabase.storage
      .from(bucketId)
      .getPublicUrl(fileName);
    
    return data.publicUrl;
  };

  const handleSelectBucket = (bucketId: string) => {
    setSelectedBucket(bucketId);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center py-4">
            <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
              <ChevronLeft size={24} />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Bucket Manager</h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {courseTitle}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Sidebar with buckets */}
          <div className="md:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
              <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                <h2 className="text-lg font-medium text-gray-900 dark:text-white">Buckets</h2>
              </div>
              <div className="p-2">
                <button
                  onClick={() => handleSelectBucket(`course_${courseId}`)}
                  className={`w-full text-left p-3 rounded-lg flex items-center ${
                    selectedBucket === `course_${courseId}`
                      ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                      : 'hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  <FolderOpen size={20} className="mr-2" />
                  <span>Course Bucket</span>
                </button>
                
                <div className="mt-2 pl-2 border-l-2 border-gray-200 dark:border-gray-700">
                  <p className="px-3 py-2 text-sm font-medium text-gray-500 dark:text-gray-400">Lesson Buckets</p>
                  {lessons.map(lesson => (
                    <button
                      key={lesson.id}
                      onClick={() => handleSelectBucket(`lesson_${lesson.id}`)}
                      className={`w-full text-left p-2 rounded-lg flex items-center text-sm ${
                        selectedBucket === `lesson_${lesson.id}`
                          ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                          : 'hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300'
                      }`}
                    >
                      <FolderOpen size={16} className="mr-2" />
                      <div className="truncate">
                        <span>{lesson.title}</span>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{lesson.chapter_title}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Main content area */}
          <div className="md:col-span-3">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
              <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                <h2 className="text-lg font-medium text-gray-900 dark:text-white">
                  {selectedBucket === `course_${courseId}` 
                    ? 'Course Files' 
                    : selectedBucket?.startsWith('lesson_') 
                      ? `Lesson Files: ${lessons.find(l => `lesson_${l.id}` === selectedBucket)?.title || ''}` 
                      : 'Files'}
                </h2>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleRefresh}
                    disabled={refreshing}
                    className="p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 rounded-full"
                  >
                    <RefreshCw size={20} className={refreshing ? 'animate-spin' : ''} />
                  </button>
                  <label className="cursor-pointer">
                    <input
                      type="file"
                      className="hidden"
                      onChange={handleFileUpload}
                      multiple
                      disabled={uploading || !selectedBucket}
                    />
                    <div className={`px-4 py-2 bg-blue-500 text-white rounded-lg flex items-center space-x-2 hover:bg-blue-600 ${
                      uploading || !selectedBucket ? 'opacity-50 cursor-not-allowed' : ''
                    }`}>
                      <Upload size={18} />
                      <span>{uploading ? 'Uploading...' : 'Upload Files'}</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* File list */}
              <div className="p-4">
                {files.length === 0 ? (
                  <div className="text-center py-8">
                    <FolderOpen size={48} className="mx-auto text-gray-400 dark:text-gray-600 mb-4" />
                    <p className="text-gray-500 dark:text-gray-400">No files found in this bucket</p>
                    <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
                      Upload files using the button above
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                      <thead className="bg-gray-50 dark:bg-gray-750">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                            Name
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                            Size
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                            Last Modified
                          </th>
                          <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        {files.map((file) => (
                          <tr key={file.id} className="hover:bg-gray-50 dark:hover:bg-gray-750">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <File size={18} className="text-gray-400 dark:text-gray-500 mr-2" />
                                <span className="text-sm text-gray-900 dark:text-white">{file.name}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                              {formatFileSize(file.size)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                              {new Date(file.updated_at).toLocaleString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <div className="flex items-center justify-end space-x-2">
                                <a
                                  href={getFileUrl(file.name, file.bucketId)}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                                >
                                  View
                                </a>
                                <button
                                  onClick={() => handleDeleteFile(file.name, file.bucketId)}
                                  className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                                >
                                  <Trash2 size={16} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}