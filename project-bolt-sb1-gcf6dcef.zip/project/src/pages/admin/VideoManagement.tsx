import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, Video, AlertTriangle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { VideoUploader } from '../../components/video/VideoUploader';

interface Lesson {
  id: string;
  title: string;
  video_url: string | null;
  chapter_id: string;
  chapter: {
    id: string;
    title: string;
    course_id: string;
    course: {
      id: string;
      title: string;
    };
  };
}

export function VideoManagement() {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchLessons();
  }, [courseId]);

  const fetchLessons = async () => {
    try {
      setLoading(true);
      setError(null);

      // First get chapters to ensure correct ordering
      const { data: chapters, error: chaptersError } = await supabase
        .from('course_chapters')
        .select('id')
        .eq('course_id', courseId)
        .order('position', { ascending: true });

      if (chaptersError) throw chaptersError;

      // Then get lessons for each chapter
      const allLessons: Lesson[] = [];
      
      for (const chapter of chapters) {
        const { data: chapterLessons, error: lessonsError } = await supabase
          .from('course_lessons')
          .select(`
            id,
            title,
            video_url,
            chapter_id,
            course_chapters!inner (
              id,
              title,
              course_id,
              courses!inner (
                id,
                title
              )
            )
          `)
          .eq('chapter_id', chapter.id)
          .order('position', { ascending: true });

        if (lessonsError) throw lessonsError;

        allLessons.push(...chapterLessons.map(lesson => ({
          id: lesson.id,
          title: lesson.title,
          video_url: lesson.video_url,
          chapter_id: lesson.chapter_id,
          chapter: {
            id: lesson.course_chapters.id,
            title: lesson.course_chapters.title,
            course_id: lesson.course_chapters.course_id,
            course: {
              id: lesson.course_chapters.courses.id,
              title: lesson.course_chapters.courses.title
            }
          }
        })));
      }

      setLessons(allLessons);
    } catch (err) {
      console.error('Error fetching lessons:', err);
      setError('Failed to load lessons');
    } finally {
      setLoading(false);
    }
  };

  const handleUploadComplete = async (lessonId: string, videoUrl: string) => {
    setLessons(prev =>
      prev.map(lesson =>
        lesson.id === lessonId
          ? { ...lesson, video_url: videoUrl }
          : lesson
      )
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
          <div className="px-4 py-4">
            <div className="flex items-center">
              <button
                onClick={() => navigate(-1)}
                className="mr-4 text-gray-600 dark:text-gray-400"
              >
                <ChevronLeft size={24} />
              </button>
              <div>
                <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
                  Video Management
                </h1>
                {lessons[0]?.chapter.course && (
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {lessons[0].chapter.course.title}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : error ? (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 flex items-start">
              <AlertTriangle className="text-red-500 dark:text-red-400 mt-0.5 mr-3" size={20} />
              <div>
                <h3 className="text-red-800 dark:text-red-300 font-medium">Error</h3>
                <p className="text-red-600 dark:text-red-400 text-sm">{error}</p>
                <button
                  onClick={fetchLessons}
                  className="mt-2 text-sm text-red-700 dark:text-red-300 font-medium hover:text-red-800 dark:hover:text-red-200"
                >
                  Try again
                </button>
              </div>
            </div>
          ) : lessons.length === 0 ? (
            <div className="text-center py-8">
              <Video className="mx-auto text-gray-400 dark:text-gray-600 mb-4" size={48} />
              <p className="text-gray-500 dark:text-gray-400">No lessons found</p>
            </div>
          ) : (
            <div className="space-y-6">
              {lessons.map((lesson) => (
                <div
                  key={lesson.id}
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden"
                >
                  <div className="p-4">
                    <div className="mb-4">
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                        {lesson.title}
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Chapter: {lesson.chapter.title}
                      </p>
                    </div>

                    {lesson.video_url ? (
                      <div className="space-y-4">
                        <div className="aspect-video bg-black rounded-lg overflow-hidden">
                          <video
                            src={lesson.video_url}
                            controls
                            className="w-full h-full"
                            poster={lesson.video_url + '?poster=true'}
                          >
                            Your browser does not support the video tag.
                          </video>
                        </div>
                        <VideoUploader
                          lessonId={lesson.id}
                          courseId={courseId!}
                          onUploadComplete={(url) => handleUploadComplete(lesson.id, url)}
                        />
                      </div>
                    ) : (
                      <VideoUploader
                        lessonId={lesson.id}
                        courseId={courseId!}
                        onUploadComplete={(url) => handleUploadComplete(lesson.id, url)}
                      />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}