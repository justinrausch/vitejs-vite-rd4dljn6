import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ChevronLeft, 
  Search, 
  Filter, 
  CheckCircle, 
  XCircle, 
  Shield, 
  AlertTriangle,
  UserCheck,
  UserX,
  Mail,
  RefreshCw
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { UserAvatar } from '../../components/user/UserAvatar';

// Define admin emails - in a real app, this would be handled by a proper role system
const ADMIN_EMAILS = ['gaspar@mastery.to', 'justin@mastery.to', 'admin@example.com'];

interface User {
  id: string;
  username: string;
  email: string;
  avatar_url: string | null;
  is_coach: boolean;
  is_verified: boolean;
  created_at: string;
  last_active: string;
  status: 'active' | 'suspended' | 'banned';
}

export function UserManagement() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<User[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'suspended' | 'banned'>('all');
  const [roleFilter, setRoleFilter] = useState<'all' | 'user' | 'coach' | 'admin'>('all');
  const [verifiedFilter, setVerifiedFilter] = useState<'all' | 'verified' | 'unverified'>('all');
  
  // Check if user is admin
  useEffect(() => {
    if (user) {
      const userIsAdmin = ADMIN_EMAILS.includes(user.email || '');
      setIsAdmin(userIsAdmin);
      
      if (!userIsAdmin) {
        navigate('/');
      } else {
        fetchUsers();
      }
    } else {
      navigate('/login');
    }
  }, [user, navigate]);
  
  const fetchUsers = async () => {
    setLoading(true);
    try {
      // In a real app, this would be an actual database query
      // For this demo, we'll use mock data
      
      // Mock users
      const mockUsers: User[] = [
        {
          id: '1',
          username: 'johndoe',
          email: 'john@example.com',
          avatar_url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80',
          is_coach: false,
          is_verified: true,
          created_at: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
          last_active: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'active'
        },
        {
          id: '2',
          username: 'janedoe',
          email: 'jane@example.com',
          avatar_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80',
          is_coach: true,
          is_verified: true,
          created_at: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(),
          last_active: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'active'
        },
        {
          id: '3',
          username: 'spammer123',
          email: 'spam@example.com',
          avatar_url: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80',
          is_coach: false,
          is_verified: false,
          created_at: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
          last_active: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'banned'
        },
        {
          id: '4',
          username: 'suspendeduser',
          email: 'suspended@example.com',
          avatar_url: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&q=80',
          is_coach: false,
          is_verified: true,
          created_at: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(),
          last_active: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'suspended'
        },
        {
          id: '5',
          username: 'adminuser',
          email: 'admin@example.com',
          avatar_url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80',
          is_coach: true,
          is_verified: true,
          created_at: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString(),
          last_active: new Date(Date.now() - 0.5 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'active'
        }
      ];
      
      setUsers(mockUsers);
    } catch (error) {
      console.error('Error fetching users:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleVerifyUser = async (userId: string) => {
    // In a real app, this would update the database
    setUsers(prev => 
      prev.map(user => 
        user.id === userId 
          ? { ...user, is_verified: true } 
          : user
      )
    );
  };
  
  const handleUnverifyUser = async (userId: string) => {
    // In a real app, this would update the database
    setUsers(prev => 
      prev.map(user => 
        user.id === userId 
          ? { ...user, is_verified: false } 
          : user
      )
    );
  };
  
  const handleSuspendUser = async (userId: string) => {
    // In a real app, this would update the database
    setUsers(prev => 
      prev.map(user => 
        user.id === userId 
          ? { ...user, status: 'suspended' } 
          : user
      )
    );
  };
  
  const handleUnsuspendUser = async (userId: string) => {
    // In a real app, this would update the database
    setUsers(prev => 
      prev.map(user => 
        user.id === userId 
          ? { ...user, status: 'active' } 
          : user
      )
    );
  };
  
  const handleBanUser = async (userId: string) => {
    // In a real app, this would update the database
    setUsers(prev => 
      prev.map(user => 
        user.id === userId 
          ? { ...user, status: 'banned' } 
          : user
      )
    );
  };
  
  const handleUnbanUser = async (userId: string) => {
    // In a real app, this would update the database
    setUsers(prev => 
      prev.map(user => 
        user.id === userId 
          ? { ...user, status: 'active' } 
          : user
      )
    );
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  
  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return 'just now';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} ${minutes === 1 ? 'minute' : 'minutes'} ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} ${days === 1 ? 'day' : 'days'} ago`;
    }
  };
  
  // Filter users based on search query and filters
  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
      user.email.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || user.status === statusFilter;
    
    let matchesRole = true;
    if (roleFilter === 'admin') {
      matchesRole = ADMIN_EMAILS.includes(user.email);
    } else if (roleFilter === 'coach') {
      matchesRole = user.is_coach;
    } else if (roleFilter === 'user') {
      matchesRole = !user.is_coach && !ADMIN_EMAILS.includes(user.email);
    }
    
    const matchesVerified = 
      verifiedFilter === 'all' || 
      (verifiedFilter === 'verified' && user.is_verified) || 
      (verifiedFilter === 'unverified' && !user.is_verified);
    
    return matchesSearch && matchesStatus && matchesRole && matchesVerified;
  });
  
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle size={48} className="mx-auto text-red-500 mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Access Denied</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-4">You don't have permission to access this page.</p>
          <button 
            onClick={() => navigate('/')}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg"
          >
            Return to Home
          </button>
        </div>
      </div>
    );
  }
  
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center">
              <button 
                onClick={() => navigate('/admin')}
                className="mr-4 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100"
              >
                <ChevronLeft size={24} />
              </button>
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">User Management</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                onClick={fetchUsers}
                className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100"
                title="Refresh data"
              >
                <RefreshCw size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filters */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="search"
              placeholder="Search users..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
            />
          </div>
          
          <div className="flex flex-wrap items-center gap-2">
            <Filter size={18} className="text-gray-400" />
            
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active</option>
              <option value="suspended">Suspended</option>
              <option value="banned">Banned</option>
            </select>
            
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value as any)}
              className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
            >
              <option value="all">All Roles</option>
              <option value="admin">Admin</option>
              <option value="coach">Coach</option>
              <option value="user">User</option>
            </select>
            
            <select
              value={verifiedFilter}
              onChange={(e) => setVerifiedFilter(e.target.value as any)}
              className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
            >
              <option value="all">All Verification</option>
              <option value="verified">Verified</option>
              <option value="unverified">Unverified</option>
            </select>
          </div>
        </div>
        
        {/* Users Table */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-medium text-gray-900 dark:text-white">Users</h2>
          </div>
          
          {filteredUsers.length === 0 ? (
            <div className="p-6 text-center">
              <UserX className="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500" />
              <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-white">No users found</h3>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Try adjusting your search or filter to find what you're looking for.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-750">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      User
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Role
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Joined
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Last Active
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-gray-50 dark:hover:bg-gray-750">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <UserAvatar 
                            username={user.username}
                            avatarUrl={user.avatar_url}
                            size="sm"
                            className="mr-3"
                          />
                          <div>
                            <div className="text-sm font-medium text-gray-900 dark:text-white">{user.username}</div>
                            <div className="text-sm text-gray-500 dark:text-gray-400">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center space-x-1">
                          {ADMIN_EMAILS.includes(user.email) && (
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400">
                              Admin
                            </span>
                          )}
                          {user.is_coach && (
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400">
                              Coach
                            </span>
                          )}
                          {!user.is_coach && !ADMIN_EMAILS.includes(user.email) && (
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                              User
                            </span>
                          )}
                          {user.is_verified && (
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">
                              Verified
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          user.status === 'active' 
                            ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400' 
                            : user.status === 'suspended'
                            ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400'
                            : 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400'
                        }`}>
                          {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500 dark:text-gray-400">{formatDate(user.created_at)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500 dark:text-gray-400">{formatTimeAgo(user.last_active)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-2">
                          <div className="relative group">
                            <button
                              className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-300"
                              title="More actions"
                            >
                              •••
                            </button>
                            <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg border border-gray-200 dark:border-gray-700 hidden group-hover:block z-10">
                              <div className="py-1">
                                {!user.is_verified ? (
                                  <button
                                    onClick={() => handleVerifyUser(user.id)}
                                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750"
                                  >
                                    <CheckCircle size={16} className="mr-2 text-green-500" />
                                    Verify User
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => handleUnverifyUser(user.id)}
                                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750"
                                  >
                                    <XCircle size={16} className="mr-2 text-red-500" />
                                    Unverify User
                                  </button>
                                )}
                                
                                {user.status === 'active' ? (
                                  <button
                                    onClick={() => handleSuspendUser(user.id)}
                                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750"
                                  >
                                    <UserX size={16} className="mr-2 text-yellow-500" />
                                    Suspend User
                                  </button>
                                ) : user.status === 'suspended' ? (
                                  <button
                                    onClick={() => handleUnsuspendUser(user.id)}
                                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750"
                                  >
                                    <UserCheck size={16} className="mr-2 text-green-500" />
                                    Unsuspend User
                                  </button>
                                ) : null}
                                
                                {user.status !== 'banned' ? (
                                  <button
                                    onClick={() => handleBanUser(user.id)}
                                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750"
                                  >
                                    <Shield size={16} className="mr-2 text-red-500" />
                                    Ban User
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => handleUnbanUser(user.id)}
                                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750"
                                  >
                                    <Shield size={16} className="mr-2 text-green-500" />
                                    Unban User
                                  </button>
                                )}
                                
                                <button
                                  onClick={() => {}}
                                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-750"
                                >
                                  <Mail size={16} className="mr-2 text-blue-500" />
                                  Email User
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}