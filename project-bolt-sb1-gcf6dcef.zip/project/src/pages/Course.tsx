import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate, useParams } from 'react-router-dom';
import { LockIcon } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Course as CourseType } from '../types/course';
import { useAuth } from '../contexts/AuthContext';
import { CourseHeader } from '../components/course/CourseHeader';
import { CourseTabs } from '../components/course/CourseTabs';
import { CourseChapters } from '../components/course/CourseChapters';
import { CourseOverview } from '../components/course/CourseOverview';
import { Leaderboard } from '../components/course/Leaderboard';
import { CourseCoaching } from '../components/course/CourseCoaching';
import { CourseCommunity } from '../components/course/CourseCommunity';
import { CourseHome } from '../components/course/CourseHome';
import { getCourseById, getCompletedLessons } from '../services/courseService';
import { getBookmarkedLessons, bookmarkLesson, unbookmarkLesson } from '../services/bookmarkService';
import { getLessonProgressForCourse } from '../services/videoProgressService';

type Tab = 'home' | 'skills' | 'community' | 'ranking' | 'coaching' | 'overview';

function Course() {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { user, userProfile } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [course, setCourse] = useState<CourseType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);
  const [bookmarkedLessons, setBookmarkedLessons] = useState<string[]>([]);
  const [bookmarkLoading, setBookmarkLoading] = useState<Record<string, boolean>>({});
  const [lessonProgress, setLessonProgress] = useState<Record<string, number>>({});
  const [isInstructor, setIsInstructor] = useState(false);
  const [userPlan, setUserPlan] = useState<any>(null);

  useEffect(() => {
    if (id) {
      fetchCourse();
      if (user) {
        fetchCompletedLessons();
        fetchBookmarkedLessons();
        fetchLessonProgress();
        checkIfInstructor();
        fetchUserPlan();
      }
    }
  }, [id, user]);

  useEffect(() => {
    const hash = location.hash.replace('#', '');
    if (hash && ['home', 'skills', 'community', 'ranking', 'coaching', 'overview'].includes(hash as Tab)) {
      setActiveTab(hash as Tab);
    }
  }, [location.hash]);

  const fetchUserPlan = async () => {
    if (!user || !id) return;
    
    try {
      const { data, error } = await supabase
        .from('enrollments')
        .select(`
          plan_id,
          course_plans:plan_id (
            id,
            title,
            price,
            lessons_access,
            community_access,
            coaching_access,
            rankings_access
          )
        `)
        .eq('user_id', user.id)
        .eq('course_id', id)
        .maybeSingle();
        
      if (error) throw error;
      
      if (data && data.course_plans) {
        setUserPlan(data.course_plans);
      }
    } catch (err) {
      console.error('Error fetching user plan:', err);
    }
  };

  const checkIfInstructor = async () => {
    if (!user || !id) return;
    
    try {
      const { data, error } = await supabase
        .from('courses')
        .select('instructor_id')
        .eq('id', id)
        .single();
        
      if (error) throw error;
      setIsInstructor(data.instructor_id === user.id);
    } catch (err) {
      console.error('Error checking instructor status:', err);
    }
  };

  const fetchCourse = async () => {
    if (!id) return;
    
    try {
      setLoading(true);
      const courseData = await getCourseById(id);
      setCourse(courseData);
    } catch (err) {
      console.error('Error fetching course:', err);
      setError('Failed to load course details');
    } finally {
      setLoading(false);
    }
  };

  const fetchCompletedLessons = async () => {
    if (!user || !id) return;
    
    try {
      const lessonIds = await getCompletedLessons(user.id, id);
      setCompletedLessons(lessonIds);
    } catch (err) {
      console.error('Error fetching completed lessons:', err);
    }
  };

  const fetchBookmarkedLessons = async () => {
    if (!user || !id) return;
    
    try {
      const lessonIds = await getBookmarkedLessons(user.id, id);
      setBookmarkedLessons(lessonIds);
    } catch (err) {
      console.error('Error fetching bookmarked lessons:', err);
    }
  };
  
  const fetchLessonProgress = async () => {
    if (!user || !id) return;
    
    try {
      const progress = await getLessonProgressForCourse(user.id, id);
      setLessonProgress(progress);
    } catch (err) {
      console.error('Error fetching lesson progress:', err);
    }
  };

  const handleLessonClick = (lessonId: string) => {
    if (!id) return;
    navigate(`/course/${id}/lesson/${lessonId}`);
  };

  const toggleBookmark = async (lessonId: string) => {
    if (!user || !id || !course) return;
    
    try {
      setBookmarkLoading(prev => ({ ...prev, [lessonId]: true }));
      
      const isCurrentlyBookmarked = bookmarkedLessons.includes(lessonId);
      
      if (isCurrentlyBookmarked) {
        await unbookmarkLesson(user.id, lessonId);
        setBookmarkedLessons(prev => prev.filter(id => id !== lessonId));
      } else {
        await bookmarkLesson(user.id, id, lessonId);
        setBookmarkedLessons(prev => [...prev, lessonId]);
      }
    } catch (error) {
      console.error('Error toggling bookmark:', error);
    } finally {
      setBookmarkLoading(prev => ({ ...prev, [lessonId]: false }));
    }
  };

  const handleTabChange = (tab: Tab) => {
    setActiveTab(tab);
    window.history.replaceState(null, '', `${location.pathname}#${tab}`);
  };

  const handleBackClick = () => {
    navigate('/');
  };

  const handleUserClick = (username: string) => {
    navigate(`/user/${username}`);
  };

  // Check if user has access to the current tab
  const hasAccessToTab = (tab: Tab): boolean => {
    if (isInstructor) return true;
    if (!userPlan) return true; // Default to true if plan not loaded yet
    
    switch (tab) {
      case 'skills':
        return userPlan.lessons_access;
      case 'community':
        return userPlan.community_access;
      case 'ranking':
        return userPlan.rankings_access;
      case 'coaching':
        return userPlan.coaching_access;
      default:
        return true; // Home and overview are always accessible
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-pulse text-gray-600 dark:text-gray-300">Loading...</div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 dark:text-gray-300">Course not found</p>
          <button
            onClick={() => navigate('/discover')}
            className="mt-4 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
          >
            Back to Discover
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <CourseHeader 
        title={course.title} 
        instructorUsername={course.instructor.username}
        courseId={course.id}
        onBackClick={handleBackClick}
        isInstructor={isInstructor}
      />
      
      <CourseTabs activeTab={activeTab} onTabChange={handleTabChange} />

      <div className={`max-w-lg mx-auto ${activeTab === 'community' ? 'pt-0' : ''}`}>
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        {!hasAccessToTab(activeTab) ? (
          <div className="fixed inset-0 top-[8rem] z-10 flex items-center justify-center">
            <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-md p-8 rounded-xl text-center max-w-md">
              <LockIcon size={48} className="mx-auto text-gray-400 dark:text-gray-500 mb-4" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Feature Not Available
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                This feature is not included in your current plan. Upgrade to access {activeTab === 'skills' ? 'lessons' : activeTab}.
              </p>
              <button
                onClick={() => navigate(`/course/preview/${course.id}`)}
                className="px-6 py-2 bg-blue-500 text-white rounded-lg font-medium"
              >
                View Plans
              </button>
            </div>
          </div>
        ) : (
          <>
            {activeTab === 'home' && (
              <CourseHome 
                courseId={course.id}
                isInstructor={isInstructor}
                onUserClick={handleUserClick}
              />
            )}

            {activeTab === 'skills' && (
              <CourseChapters 
                chapters={course.chapters}
                completedLessons={completedLessons}
                bookmarkedLessons={bookmarkedLessons}
                bookmarkLoading={bookmarkLoading}
                lessonProgress={lessonProgress}
                requiredWatchPercentage={70}
                onLessonClick={handleLessonClick}
                onToggleBookmark={toggleBookmark}
                instructorId={course.instructor.id}
                courseId={course.id}
              />
            )}

            {activeTab === 'community' && (
              <div className="fixed inset-0 top-[8rem] z-10">
                <CourseCommunity 
                  courseId={course.id}
                  onUserClick={handleUserClick}
                />
              </div>
            )}

            {activeTab === 'ranking' && (
              <Leaderboard 
                courseId={course.id}
                onUserClick={handleUserClick}
              />
            )}

            {activeTab === 'coaching' && (
              <CourseCoaching 
                instructorUsername={course.instructor.username}
                instructorAvatarUrl={course.instructor.avatar_url}
                courseId={course.id}
              />
            )}

            {activeTab === 'overview' && (
              <CourseOverview 
                course={course} 
                onUserClick={handleUserClick}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default Course;