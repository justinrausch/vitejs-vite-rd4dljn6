import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Instagram, Youtube, MapPin, Globe, Calendar, Award } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { UserAvatar } from '../components/user/UserAvatar';
import { ImageUploader } from '../components/ImageUploader';
import { CHAR_LIMITS } from '../lib/constants';
import { formatUsername, isValidUsername } from '../lib/utils/validation';

interface FormData {
  name: string;
  username: string;
  description: string;
  location: string;
  instagram: string;
  youtube: string;
  strava: string;
  website: string;
}

export function EditProfile() {
  const navigate = useNavigate();
  const { user, userProfile, refreshUserProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState(userProfile?.avatar_url || user?.user_metadata?.avatar_url || null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState<FormData>({
    name: userProfile?.full_name || user?.user_metadata?.full_name || '',
    username: userProfile?.username || user?.user_metadata?.username || '',
    description: userProfile?.description || user?.user_metadata?.description || '',
    location: userProfile?.location || user?.user_metadata?.location || '',
    instagram: userProfile?.instagram || user?.user_metadata?.instagram || '',
    youtube: userProfile?.youtube || user?.user_metadata?.youtube || '',
    strava: userProfile?.strava || user?.user_metadata?.strava || '',
    website: userProfile?.website || user?.user_metadata?.website || ''
  });
  const [error, setError] = useState<string | null>(null);
  const [usernameError, setUsernameError] = useState<string | null>(null);

  const handleChange = (field: keyof FormData, value: string) => {
    const limits = {
      name: CHAR_LIMITS.FULL_NAME,
      username: CHAR_LIMITS.USERNAME,
      description: CHAR_LIMITS.PROFILE_DESCRIPTION
    };

    if (field in limits && value.length > limits[field as keyof typeof limits]) {
      return;
    }

    // Special handling for username
    if (field === 'username') {
      const formattedUsername = formatUsername(value);
      if (!isValidUsername(formattedUsername) && formattedUsername.length > 0) {
        setUsernameError('Username can only contain lowercase letters, numbers, and underscores');
      } else {
        setUsernameError(null);
      }
      setFormData(prev => ({ ...prev, username: formattedUsername }));
      return;
    }

    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    if (usernameError) {
      setError('Please fix the username errors before saving');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      const profileData = {
        avatar_url: avatarUrl,
        full_name: formData.name,
        username: formData.username,
        description: formData.description,
        location: formData.location,
        instagram: formData.instagram,
        youtube: formData.youtube,
        strava: formData.strava,
        website: formData.website
      };
      
      const { error: profileError } = await supabase
        .from('profiles')
        .update(profileData)
        .eq('id', user?.id);
      
      if (profileError) throw profileError;
      
      const { error: authError } = await supabase.auth.updateUser({
        data: profileData
      });

      if (authError) throw authError;
      
      await refreshUserProfile();
      navigate('/profile');
    } catch (err: any) {
      console.error('Error updating profile:', err);
      setError(err.message || 'Failed to update profile. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-32">
      {/* Fixed Header */}
      <div className="fixed top-0 left-0 right-0 bg-white dark:bg-gray-900 z-10">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between px-4 py-6 border-b border-gray-200 dark:border-gray-800">
            <div className="flex items-center">
              <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
                <ChevronLeft size={24} />
              </button>
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Edit Profile</h1>
            </div>
            <button
              onClick={handleSave}
              disabled={loading || !!usernameError}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium disabled:opacity-50"
            >
              {loading ? 'Saving...' : 'Save'}
            </button>
          </div>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="px-4 pt-24 pb-20 max-w-lg mx-auto">
        {/* Avatar */}
        <div className="text-center mb-6">
          <div className="inline-block">
            <UserAvatar 
              username={formData.username}
              avatarUrl={avatarUrl}
              size="xl"
            />
          </div>
          <div className="mt-4">
            <ImageUploader 
              onUploadComplete={setAvatarUrl}
              folder="avatars"
              buttonText="Change photo"
            />
          </div>
        </div>

        {/* Error message */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        {/* Form */}
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Name
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              maxLength={CHAR_LIMITS.FULL_NAME}
              className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-800 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
            />
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {formData.name.length}/{CHAR_LIMITS.FULL_NAME}
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Username
            </label>
            <input
              type="text"
              value={formData.username}
              onChange={(e) => handleChange('username', e.target.value)}
              maxLength={CHAR_LIMITS.USERNAME}
              className={`w-full px-4 py-2 bg-gray-50 dark:bg-gray-800 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white ${
                usernameError ? 'ring-2 ring-red-500' : ''
              }`}
            />
            {usernameError && (
              <p className="mt-1 text-sm text-red-500">{usernameError}</p>
            )}
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {formData.username.length}/{CHAR_LIMITS.USERNAME} - Only lowercase letters, numbers, and underscores
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Bio
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              maxLength={CHAR_LIMITS.PROFILE_DESCRIPTION}
              rows={3}
              className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-800 rounded-lg border-none focus:ring-2 focus:ring-blue-500 resize-none dark:text-white"
            />
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {formData.description.length}/{CHAR_LIMITS.PROFILE_DESCRIPTION}
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Location
            </label>
            <div className="flex items-center bg-gray-50 dark:bg-gray-800 rounded-lg px-4">
              <MapPin size={20} className="text-gray-400 dark:text-gray-500 mr-2" />
              <input
                type="text"
                value={formData.location}
                onChange={(e) => handleChange('location', e.target.value)}
                placeholder="Location"
                className="w-full py-2 bg-transparent border-none focus:ring-0 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Website
            </label>
            <div className="flex items-center bg-gray-50 dark:bg-gray-800 rounded-lg px-4">
              <Globe size={20} className="text-gray-400 dark:text-gray-500 mr-2" />
              <input
                type="text"
                value={formData.website}
                onChange={(e) => handleChange('website', e.target.value)}
                placeholder="https://yourwebsite.com"
                className="w-full py-2 bg-transparent border-none focus:ring-0 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Social Links
            </label>
            <div className="space-y-4">
              <div className="flex items-center bg-gray-50 dark:bg-gray-800 rounded-lg px-4">
                <Instagram size={20} className="text-gray-400 dark:text-gray-500 mr-2" />
                <input
                  type="text"
                  value={formData.instagram}
                  onChange={(e) => handleChange('instagram', e.target.value)}
                  placeholder="Instagram username"
                  className="w-full py-2 bg-transparent border-none focus:ring-0 dark:text-white"
                />
              </div>

              <div className="flex items-center bg-gray-50 dark:bg-gray-800 rounded-lg px-4">
                <Youtube size={20} className="text-gray-400 dark:text-gray-500 mr-2" />
                <input
                  type="text"
                  value={formData.youtube}
                  onChange={(e) => handleChange('youtube', e.target.value)}
                  placeholder="YouTube username"
                  className="w-full py-2 bg-transparent border-none focus:ring-0 dark:text-white"
                />
              </div>

              <div className="flex items-center bg-gray-50 dark:bg-gray-800 rounded-lg px-4">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" className="text-gray-400 dark:text-gray-500 mr-2">
                  <path d="M15.387 17.944l-2.089-4.116h-3.065L15.387 24l5.15-10.172h-3.066m-7.008-5.599l2.836 5.598h4.172L10.463 0l-7.027 13.828h4.172"/>
                </svg>
                <input
                  type="text"
                  value={formData.strava}
                  onChange={(e) => handleChange('strava', e.target.value)}
                  placeholder="Strava athlete ID"
                  className="w-full py-2 bg-transparent border-none focus:ring-0 dark:text-white"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}