import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, Play, Users, ChevronRight, ArrowRight, Star, StarHalf, Check } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Course } from '../types/course';
import { useAuth } from '../contexts/AuthContext';
import { OptimizedImage } from '../components/media/OptimizedImage';
import { UserAvatar } from '../components/user/UserAvatar';
import { ReviewsModal } from '../components/course/ReviewsModal';
import { VerifiedBadge } from '../components/user/VerifiedBadge';

interface CourseMedia {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail_url?: string;
  position: number;
}

interface CourseMember {
  id: string;
  username: string;
  avatar_url: string | null;
}

interface ReviewStats {
  averageRating: number;
  reviewCount: number;
}

export function CoursePreview() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [course, setCourse] = useState<Course | null>(null);
  const [loading, setLoading] = useState(true);
  const [enrolling, setEnrolling] = useState(false);
  const [unenrolling, setUnenrolling] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentPlanIndex, setCurrentPlanIndex] = useState(0);
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [currentMediaIndex, setCurrentMediaIndex] = useState(0);
  const [courseMedia, setCourseMedia] = useState<CourseMedia[]>([]);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [courseMembers, setCourseMembers] = useState<CourseMember[]>([]);
  const [reviewStats, setReviewStats] = useState<ReviewStats>({ averageRating: 0, reviewCount: 0 });
  const [showReviewsModal, setShowReviewsModal] = useState(false);
  const [userPlan, setUserPlan] = useState<any>(null);
  const carouselRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const checkEnrollment = useCallback(async () => {
    if (!user || !id) return;
    
    try {
      const { data, error } = await supabase
        .from('enrollments')
        .select(`
          id,
          plan_id,
          course_plans:plan_id (
            id,
            title,
            price,
            renewal_period
          )
        `)
        .eq('user_id', user.id)
        .eq('course_id', id)
        .maybeSingle();

      if (error) throw error;
      setIsEnrolled(!!data);
      
      if (data && data.course_plans) {
        setUserPlan(data.course_plans);
      }
    } catch (err) {
      console.error('Error checking enrollment:', err);
      setIsEnrolled(false);
    }
  }, [user, id]);

  const fetchCourseMembers = useCallback(async () => {
    if (!id) return;
    
    try {
      const { data, error } = await supabase
        .from('enrollments')
        .select(`
          user_id,
          profiles!inner (
            id,
            username,
            avatar_url
          )
        `)
        .eq('course_id', id)
        .limit(12);

      if (error) throw error;
      
      const members = data.map(item => ({
        id: item.profiles.id,
        username: item.profiles.username,
        avatar_url: item.profiles.avatar_url
      }));
      
      setCourseMembers(members);
    } catch (err) {
      console.error('Error fetching course members:', err);
    }
  }, [id]);

  const fetchReviewStats = useCallback(async () => {
    if (!id) return;
    
    try {
      // Get reviews data
      const { data, error } = await supabase
        .from('course_reviews')
        .select('rating')
        .eq('course_id', id);

      if (error) throw error;

      // Calculate average rating and count
      if (data && data.length > 0) {
        const total = data.reduce((sum, review) => sum + review.rating, 0);
        setReviewStats({
          averageRating: total / data.length,
          reviewCount: data.length
        });
      }
    } catch (err) {
      console.error('Error fetching review stats:', err);
    }
  }, [id]);

  const fetchCourse = useCallback(async () => {
    if (!id) return;
    
    try {
      setLoading(true);
      
      const { data: courseData, error: courseError } = await supabase
        .from('courses')
        .select(`
          *,
          profiles!courses_instructor_id_fkey (
            id,
            username,
            avatar_url,
            description,
            is_verified,
            full_name
          ),
          course_tags (
            tag
          ),
          course_chapters (
            id,
            title,
            position,
            course_lessons (
              id,
              title,
              video_url,
              position
            )
          ),
          course_plans (
            id,
            title,
            price,
            renewal_period,
            features,
            lessons_access,
            community_access,
            coaching_access,
            rankings_access,
            stripe_price_id
          ),
          course_media (
            id,
            type,
            url,
            thumbnail_url,
            position
          )
        `)
        .eq('id', id)
        .single();

      if (courseError) throw courseError;

      // Get member count
      const { count: memberCount } = await supabase
        .from('enrollments')
        .select('*', { count: 'exact', head: true })
        .eq('course_id', id);

      const formattedCourse: Course = {
        ...courseData,
        instructor: courseData.profiles,
        tags: courseData.course_tags.map((t: any) => t.tag),
        chapters: courseData.course_chapters.map((chapter: any) => ({
          ...chapter,
          lessons: chapter.course_lessons
        })),
        plans: courseData.course_plans,
        member_count: memberCount || 0
      };

      setCourse(formattedCourse);
      
      // Set up course media
      const media: CourseMedia[] = [];
      
      // Add media from course_media table
      if (courseData.course_media && courseData.course_media.length > 0) {
        // Sort by position
        const sortedMedia = [...courseData.course_media].sort((a, b) => a.position - b.position);
        media.push(...sortedMedia);
      } else if (courseData.image_url) {
        // Add main image if no media exists
        media.push({
          id: 'main-image',
          type: 'image',
          url: courseData.image_url,
          position: 0
        });
      }
      
      // If we have no media at all, add a default image
      if (media.length === 0) {
        media.push({
          id: 'default-image',
          type: 'image',
          url: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg',
          position: 0
        });
      }
      
      setCourseMedia(media);
    } catch (err) {
      console.error('Error fetching course:', err);
      setError('Failed to load course details');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchCourse();
    fetchCourseMembers();
    fetchReviewStats();
    if (user && id) {
      checkEnrollment();
    }
  }, [id, user, fetchCourse, checkEnrollment, fetchCourseMembers, fetchReviewStats]);

  const nextMedia = () => {
    if (isVideoPlaying && videoRef.current) {
      videoRef.current.pause();
      setIsVideoPlaying(false);
    }
    setCurrentMediaIndex((prev) => (prev + 1) % courseMedia.length);
  };

  const prevMedia = () => {
    if (isVideoPlaying && videoRef.current) {
      videoRef.current.pause();
      setIsVideoPlaying(false);
    }
    setCurrentMediaIndex((prev) => (prev - 1 + courseMedia.length) % courseMedia.length);
  };

  const toggleVideoPlay = () => {
    if (!videoRef.current) return;
    
    if (isVideoPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
    }
    
    setIsVideoPlaying(!isVideoPlaying);
  };

  const scrollToNextPlan = () => {
    if (!course || !course.plans || course.plans.length === 0) return;
    const nextIndex = (currentPlanIndex + 1) % course.plans.length;
    setCurrentPlanIndex(nextIndex);
    carouselRef.current?.children[nextIndex]?.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'start'
    });
  };

  const scrollToPrevPlan = () => {
    if (!course || !course.plans || course.plans.length === 0) return;
    const prevIndex = currentPlanIndex === 0 ? course.plans.length - 1 : currentPlanIndex - 1;
    setCurrentPlanIndex(prevIndex);
    carouselRef.current?.children[prevIndex]?.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'start'
    });
  };

  const handleSelectPlan = (index: number) => {
    setCurrentPlanIndex(index);
    carouselRef.current?.children[index]?.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'start'
    });
  };

  const handleJoinCourse = async () => {
    if (!course || !user || isEnrolled) return;

    try {
      setEnrolling(true);
      setError(null);
      
      const { error } = await supabase
        .from('enrollments')
        .insert({
          user_id: user.id,
          course_id: course.id,
          plan_id: course.plans && course.plans.length > 0 ? course.plans[currentPlanIndex].id : null
        });

      if (error) throw error;

      setIsEnrolled(true);
      navigate(`/course/${course.id}`);
    } catch (err) {
      console.error('Error enrolling in course:', err);
      setError('Failed to enroll in course. Please try again.');
    } finally {
      setEnrolling(false);
    }
  };

  const handleUnjoinCourse = async () => {
    if (!course || !user || !isEnrolled) return;

    try {
      setUnenrolling(true);
      setError(null);
      
      const { error } = await supabase
        .from('enrollments')
        .delete()
        .eq('user_id', user.id)
        .eq('course_id', course.id);
      
      if (error) throw error;
      
      setIsEnrolled(false);
    } catch (err) {
      console.error('Error unenrolling from course:', err);
      setError('Failed to leave course. Please try again.');
    } finally {
      setUnenrolling(false);
    }
  };

  const handleChangePlan = async () => {
    if (!course || !user || !isEnrolled) return;
    
    try {
      setEnrolling(true);
      setError(null);
      
      // Update the enrollment with the new plan
      const { error } = await supabase
        .from('enrollments')
        .update({
          plan_id: course.plans[currentPlanIndex].id
        })
        .eq('user_id', user.id)
        .eq('course_id', course.id);
      
      if (error) throw error;
      
      // Update local state
      setUserPlan(course.plans[currentPlanIndex]);
      
      // Show success message
      alert('Your plan has been updated successfully!');
      
      // Navigate to course page
      navigate(`/course/${course.id}`);
    } catch (err) {
      console.error('Error changing plan:', err);
      setError('Failed to change plan. Please try again.');
    } finally {
      setEnrolling(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-16 h-16 border-4 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p className="text-gray-600 dark:text-gray-300">Course not found</p>
          <button
            onClick={() => navigate('/discover')}
            className="mt-4 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
          >
            Back to Discover
          </button>
        </div>
      </div>
    );
  }

  // Make sure we have a valid selected plan
  const selectedPlanDetails = course.plans && course.plans.length > 0 
    ? course.plans[currentPlanIndex] 
    : { title: 'Basic Plan', price: course.price, renewal_period: 'monthly', features: ['Full course access'] };
  
  const memberCount = course.member_count || 0;

  // Instructor description
  const instructorDescription = course.instructor.description || 'Professional athlete with over 5 years of experience';

  // Split members for left and right sides evenly
  const halfLength = Math.ceil(courseMembers.length / 2);
  const leftMembers = courseMembers.slice(0, halfLength);
  const rightMembers = courseMembers.slice(halfLength);

  // Function to render stars with half-star support
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    // Add full stars
    for (let i = 1; i <= fullStars; i++) {
      stars.push(
        <Star key={`full-${i}`} size={20} className="text-amber-400" fill="currentColor" />
      );
    }
    
    // Add half star if needed
    if (hasHalfStar) {
      stars.push(
        <StarHalf key="half" size={20} className="text-amber-400" fill="currentColor" />
      );
    }
    
    // Add empty stars
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 1; i <= emptyStars; i++) {
      stars.push(
        <Star key={`empty-${i}`} size={20} className="text-gray-300 dark:text-gray-600" />
      );
    }
    
    return stars;
  };

  return (
    <div className="pb-32">
      {/* Header - Fixed and non-transparent */}
      <div className="bg-white dark:bg-gray-800 sticky top-0 z-50 shadow-sm">
        <div className="max-w-lg mx-auto px-4">
          <div className="flex items-center py-4">
            <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
              <ChevronLeft size={24} />
            </button>
            <div className="flex items-center">
              {course.logo_url && (
                <img 
                  src={course.logo_url} 
                  alt={`${course.title} logo`}
                  className="w-6 h-6 mr-2 rounded-md object-cover"
                />
              )}
              <h1 className="text-lg font-medium text-gray-900 dark:text-white">{course.title}</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4">
        {error && (
          <div className="mt-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        {/* 3D Media Slideshow */}
        <div className="mt-4 relative aspect-video overflow-hidden bg-black/5 rounded-xl">
          <div className="relative h-full w-full perspective-1000">
            {courseMedia.map((media, index) => {
              const isActive = index === currentMediaIndex;
              const isPrev = (index === currentMediaIndex - 1) || (currentMediaIndex === 0 && index === courseMedia.length - 1);
              const isNext = (index === currentMediaIndex + 1) || (currentMediaIndex === courseMedia.length - 1 && index === 0);
              
              let transformStyle = 'scale(0.8) translateX(0) rotateY(0) translateZ(0)';
              let zIndex = 0;
              let opacity = 0;
              
              if (isActive) {
                transformStyle = 'scale(1) translateX(0) rotateY(0) translateZ(0)';
                zIndex = 30;
                opacity = 1;
              } else if (isPrev) {
                transformStyle = 'scale(0.85) translateX(-100%) rotateY(15deg) translateZ(-100px)';
                zIndex = 20;
                opacity = 0.7;
              } else if (isNext) {
                transformStyle = 'scale(0.85) translateX(100%) rotateY(-15deg) translateZ(-100px)';
                zIndex = 20;
                opacity = 0.7;
              }
              
              return (
                <div
                  key={index}
                  className="absolute inset-0 transition-all duration-500 ease-in-out"
                  style={{
                    transform: transformStyle,
                    zIndex,
                    opacity
                  }}
                >
                  {media.type === 'image' ? (
                    <OptimizedImage
                      src={media.url}
                      alt={`Course media ${index + 1}`}
                      className="w-full h-full object-cover"
                      placeholderClassName="w-full h-full"
                      width={600}
                      quality={90}
                    />
                  ) : (
                    <div className="w-full h-full bg-black rounded-xl overflow-hidden">
                      <video
                        ref={isActive ? videoRef : null}
                        src={media.url}
                        poster={media.thumbnail_url}
                        className="w-full h-full object-cover"
                        onClick={isActive ? toggleVideoPlay : undefined}
                      />
                      {isActive && !isVideoPlaying && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <button 
                            onClick={toggleVideoPlay}
                            className="bg-white/20 backdrop-blur-sm rounded-full p-4"
                          >
                            <Play fill="white" className="text-white ml-1" size={32} />
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          
          {/* Only show navigation buttons if there's more than one media item */}
          {courseMedia.length > 1 && (
            <>
              <button
                onClick={prevMedia}
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white rounded-full p-2 z-40"
                aria-label="Previous media"
              >
                <ChevronLeft size={24} />
              </button>
              <button
                onClick={nextMedia}
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white rounded-full p-2 z-40"
                aria-label="Next media"
              >
                <ChevronRight size={24} />
              </button>
            </>
          )}
          
          {/* Media indicators - only show if there's more than one */}
          {courseMedia.length > 1 && (
            <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2 z-40">
              {courseMedia.map((_, index) => (
                <button
                  key={index}
                  onClick={() => {
                    if (isVideoPlaying && videoRef.current) {
                      videoRef.current.pause();
                      setIsVideoPlaying(false);
                    }
                    setCurrentMediaIndex(index);
                  }}
                  className={`w-2 h-2 rounded-full transition-all ${
                    index === currentMediaIndex 
                      ? 'bg-white w-4' 
                      : 'bg-white/50 hover:bg-white/80'
                  }`}
                  aria-label={`Go to media ${index + 1}`}
                />
              ))}
            </div>
          )}
          
          {/* Members count */}
          <div className="absolute bottom-4 right-4 z-40">
            <div className="flex items-center space-x-1 bg-black/50 rounded-full px-3 py-1">
              <Users size={14} className="text-white" />
              <span className="text-white text-sm">{memberCount} members</span>
            </div>
          </div>
        </div>

        {/* About This Course */}
        <div className="mt-6 bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-sm border border-blue-300/50 shadow-[0_0_15px_rgba(59,130,246,0.2)] relative overflow-hidden">
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-transparent to-blue-100/20 dark:to-blue-900/10"></div>
          
          <div className="relative z-10">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white text-center mb-3">About This Course</h3>
            <p className="text-gray-600 dark:text-gray-300 text-center">{course.description}</p>
            
            {/* Tags */}
            {course.tags && course.tags.length > 0 && (
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {course.tags.map((tag) => (
                  <span 
                    key={tag} 
                    className="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-full text-sm"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* About the Coach */}
        <div className="mt-6">
          <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-sm border border-blue-300/50 shadow-[0_0_15px_rgba(59,130,246,0.2)] relative overflow-hidden">
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-transparent to-blue-100/20 dark:to-blue-900/10"></div>
            
            <div className="relative z-10">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white text-center mb-4">About the coach</h3>
              <div className="flex flex-col items-center">
                <UserAvatar 
                  username={course.instructor.username}
                  avatarUrl={course.instructor.avatar_url}
                  size="lg"
                  className="mb-3"
                />
                <h4 className="font-medium text-gray-900 dark:text-white text-lg flex items-center">
                  {course.instructor.full_name || course.instructor.username}
                  {course.instructor.is_verified && (
                    <VerifiedBadge className="ml-1.5 -mt-0.5" />
                  )}
                </h4>
                <p className="text-gray-600 dark:text-gray-300 text-center mt-2 max-w-md">
                  {instructorDescription}
                </p>
                <button 
                  className="text-blue-500 dark:text-blue-400 mt-3 flex items-center"
                  onClick={() => navigate(`/user/${course.instructor.username}`)}
                >
                  view profile <ArrowRight size={16} className="ml-1" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Join Members Card */}
        <div className="mt-6 relative">
          <div className="rounded-3xl p-8 text-center relative overflow-hidden border border-amber-300/50 shadow-[0_0_15px_rgba(251,191,36,0.2)]">
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-transparent to-amber-100/20 dark:to-amber-900/10"></div>
            
            <div className="relative z-10">
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">
                Join {memberCount.toLocaleString()} people
              </h2>

              {/* Member avatars */}
              <div className="flex justify-center items-center mb-6 relative h-16">
                {/* Coach avatar in center */}
                <div className="absolute z-30 transform -translate-x-1/2 left-1/2">
                  <UserAvatar 
                    username={course.instructor.username}
                    avatarUrl={course.instructor.avatar_url}
                    size="lg"
                    className="border-4 border-white dark:border-gray-800"
                  />
                </div>
                
                {/* Only show member avatars if we have members other than the coach */}
                {courseMembers.length > 0 && (
                  <>
                    {/* Member avatars on left side */}
                    <div className="flex justify-end mr-8">
                      {leftMembers.map((member, index) => (
                        <div 
                          key={`left-${member.id}`}
                          className="relative" 
                          style={{ 
                            marginRight: `-12px`, 
                            zIndex: 20 - index,
                            transform: `scale(${1 - index * 0.05})`,
                            opacity: 1 - index * 0.1
                          }}
                        >
                          <UserAvatar 
                            username={member.username}
                            avatarUrl={member.avatar_url}
                            size="md"
                            className="border-2 border-white dark:border-gray-800"
                          />
                        </div>
                      ))}
                    </div>
                    
                    {/* Member avatars on right side */}
                    <div className="flex justify-start ml-8">
                      {rightMembers.map((member, index) => (
                        <div 
                          key={`right-${member.id}`}
                          className="relative" 
                          style={{ 
                            marginLeft: `-12px`, 
                            zIndex: 20 - index,
                            transform: `scale(${1 - index * 0.05})`,
                            opacity: 1 - index * 0.1
                          }}
                        >
                          <UserAvatar 
                            username={member.username}
                            avatarUrl={member.avatar_url}
                            size="md"
                            className="border-2 border-white dark:border-gray-800"
                          />
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>

              {/* Rating display */}
              <div className="mb-2">
                <div className="flex items-center justify-center gap-1 text-2xl font-semibold text-gray-900 dark:text-white">
                  {reviewStats.averageRating > 0 
                    ? `${reviewStats.averageRating.toFixed(2)} stars` 
                    : 'No reviews yet'}
                  {reviewStats.reviewCount > 0 && (
                    <span className="text-gray-500 dark:text-gray-400 font-normal">({reviewStats.reviewCount})</span>
                  )}
                </div>
                <div className="flex items-center justify-center text-amber-400 mt-1">
                  {renderStars(reviewStats.averageRating)}
                </div>
              </div>

              {/* View reviews button */}
              <button
                onClick={() => setShowReviewsModal(true)}
                className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 flex items-center justify-center gap-1 mx-auto font-medium mt-2"
              >
                view reviews <ArrowRight size={16} />
              </button>
            </div>
          </div>
        </div>

        {/* Course Content Preview */}
        <div className="mt-6">
          <h3 className="text-lg font-medium text-center mb-4 text-gray-900 dark:text-white">Course Content</h3>
          <div className="space-y-4 relative">
            <div className="space-y-4">
              {course.chapters.slice(0, 2).map((chapter) => (
                <div key={chapter.id} className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
                  <h4 className="font-medium mb-2 text-gray-900 dark:text-white">{chapter.title}</h4>
                  <div className="space-y-2">
                    {chapter.lessons.slice(0, 3).map((lesson) => (
                      <div
                        key={lesson.id}
                        className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400"
                      >
                        <span>{lesson.title}</span>
                        <ChevronRight size={16} />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            {/* Gradient overlay */}
            <div 
              className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-gray-100 dark:from-gray-900 to-transparent pointer-events-none"
              style={{ marginBottom: '-1rem' }}
            />
            {/* Lock overlay */}
            <div className="absolute bottom-0 left-0 right-0 flex items-center justify-center p-4 text-center">
              <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-full px-4 py-2 shadow-lg">
                <span className="text-sm text-gray-700 dark:text-gray-300 font-medium">
                  Join to unlock full course content
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Pricing Plans */}
        <div className="mt-6 mb-6">
          <h3 className="text-lg font-medium mb-4 text-center text-gray-900 dark:text-white">Choose your plan</h3>
          
          {/* Pricing carousel */}
          <div className="relative">
            <div
              ref={carouselRef}
              className="flex overflow-x-auto gap-4 pb-4 snap-x snap-mandatory hide-scrollbar"
              style={{ scrollSnapType: 'x mandatory', scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
              {course.plans && course.plans.length > 0 ? (
                course.plans.map((plan, index) => (
                  <div
                    key={plan.id}
                    className={`flex-none w-[85%] max-w-xs mx-auto snap-center rounded-xl overflow-hidden ${
                      currentPlanIndex === index 
                        ? 'border-2 border-blue-500 shadow-lg' 
                        : 'border border-gray-200 dark:border-gray-700'
                    }`}
                    onClick={() => handleSelectPlan(index)}
                  >
                    <div className="p-6 bg-white dark:bg-gray-800 relative">
                      {currentPlanIndex === index ? (
                        <div className="absolute top-2 right-2 bg-blue-500 text-white p-1 rounded-full">
                          <Check size={16} />
                        </div>
                      ) : (
                        <div className="absolute top-2 right-2 bg-gray-200 dark:bg-gray-700 p-1 rounded-full">
                          <div className="w-4 h-4"></div>
                        </div>
                      )}
                      <div className="mb-4">
                        <p className="text-gray-600 dark:text-gray-400">Renewal</p>
                        <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{plan.title}</h3>
                      </div>
                      <div className="mb-6">
                        <p className="text-4xl font-bold text-gray-900 dark:text-white">
                          ${plan.price}
                          <span className="text-lg font-normal text-gray-500 dark:text-gray-400">
                            {plan.renewal_period ? ` / ${plan.renewal_period}` : ''}
                          </span>
                        </p>
                      </div>
                      <ul className="space-y-3 mb-6">
                        {plan.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start">
                            <Check size={20} className="text-green-500 mr-2 flex-shrink-0" />
                            <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))
              ) : (
                <div className="flex-none w-[85%] max-w-xs mx-auto snap-center rounded-xl overflow-hidden border-2 border-blue-500 shadow-lg">
                  <div className="p-6 bg-white dark:bg-gray-800 relative">
                    <div className="absolute top-2 right-2 bg-blue-500 text-white p-1 rounded-full">
                      <Check size={16} />
                    </div>
                    <div className="mb-4">
                      <p className="text-gray-600 dark:text-gray-400">Renewal</p>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Basic Plan</h3>
                    </div>
                    <div className="mb-6">
                      <p className="text-4xl font-bold text-gray-900 dark:text-white">
                        ${course.price}
                        <span className="text-lg font-normal text-gray-500 dark:text-gray-400"> / monthly</span>
                      </p>
                    </div>
                    <ul className="space-y-3 mb-6">
                      <li className="flex items-start">
                        <Check size={20} className="text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-gray-700 dark:text-gray-300">Full course access</span>
                      </li>
                      <li className="flex items-start">
                        <Check size={20} className="text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-gray-700 dark:text-gray-300">Community access</span>
                      </li>
                      <li className="flex items-start">
                        <Check size={20} className="text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-gray-700 dark:text-gray-300">Monthly Q&A sessions</span>
                      </li>
                      <li className="flex items-start">
                        <Check size={20} className="text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-gray-700 dark:text-gray-300">800+ rider community</span>
                      </li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
            
            {course.plans && course.plans.length > 1 && (
              <>
                <button
                  onClick={scrollToPrevPlan}
                  className="absolute left-0 top-1/2 -translate-y-1/2 bg-white dark:bg-gray-800 rounded-full p-2 shadow-lg z-10"
                >
                  <ChevronLeft size={20} className="text-gray-700 dark:text-gray-300" />
                </button>
                <button
                  onClick={scrollToNextPlan}
                  className="absolute right-0 top-1/2 -translate-y-1/2 bg-white dark:bg-gray-800 rounded-full p-2 shadow-lg z-10"
                >
                  <ChevronRight size={20} className="text-gray-700 dark:text-gray-300" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Change Plan Button (only shown if enrolled) */}
        {isEnrolled && (
          <div className="mb-4 flex justify-center">
            <button
              onClick={handleChangePlan}
              disabled={enrolling}
              className="px-6 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 disabled:opacity-50 max-w-xs"
            >
              {enrolling ? 'Updating...' : 'Change Plan'}
            </button>
          </div>
        )}

        {/* Leave Course Button (only shown if enrolled) */}
        {isEnrolled && (
          <div className="mb-20 flex justify-center">
            <button
              onClick={handleUnjoinCourse}
              disabled={unenrolling}
              className="px-6 py-2 bg-red-500 text-white rounded-lg font-medium hover:bg-red-600 disabled:opacity-50 max-w-xs"
            >
              {unenrolling ? 'Leaving course...' : 'Leave course'}
            </button>
          </div>
        )}
      </div>

      {/* Fixed Bottom CTA */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t dark:border-gray-700 p-4 z-20">
        <div className="max-w-lg mx-auto flex justify-center">
          {isEnrolled ? (
            <button
              onClick={() => navigate(`/course/${course.id}`)}
              className="px-8 py-3 bg-blue-500 dark:bg-blue-600 text-white rounded-lg font-medium"
            >
              Go to course
            </button>
          ) : (
            <button
              onClick={handleJoinCourse}
              disabled={enrolling || !user}
              className="px-8 py-3 bg-blue-500 dark:bg-blue-600 text-white rounded-lg font-medium disabled:opacity-50"
            >
              {!user ? (
                'Sign in to join'
              ) : enrolling ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Joining...
                </div>
              ) : (
                `Join for $${selectedPlanDetails.price}${selectedPlanDetails.renewal_period ? ` / ${selectedPlanDetails.renewal_period}` : ''}`
              )}
            </button>
          )}
        </div>
      </div>

      {/* Reviews Modal */}
      <ReviewsModal
        courseId={course.id}
        isOpen={showReviewsModal}
        onClose={() => setShowReviewsModal(false)}
        onUserClick={(username) => navigate(`/user/${username}`)}
      />
    </div>
  );
}