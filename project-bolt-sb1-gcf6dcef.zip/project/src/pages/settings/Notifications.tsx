import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

export function Notifications() {
  const navigate = useNavigate();
  const [settings, setSettings] = useState({
    newCourses: true,
    courseUpdates: true,
    comments: true,
    mentions: true,
    directMessages: true,
    marketing: false,
  });

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-lg mx-auto">
        <div className="flex items-center px-4 py-6 border-b">
          <button onClick={() => navigate(-1)} className="mr-4">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-semibold">Notifications</h1>
        </div>

        <div className="p-4 space-y-6">
          <div>
            <h2 className="text-lg font-medium mb-4">Course Notifications</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">New Courses</p>
                  <p className="text-sm text-gray-500">Get notified about new course releases</p>
                </div>
                <button
                  onClick={() => toggleSetting('newCourses')}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.newCourses ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.newCourses ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Course Updates</p>
                  <p className="text-sm text-gray-500">Get notified about updates to your enrolled courses</p>
                </div>
                <button
                  onClick={() => toggleSetting('courseUpdates')}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.courseUpdates ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.courseUpdates ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-lg font-medium mb-4">Social Notifications</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Comments</p>
                  <p className="text-sm text-gray-500">Get notified when someone comments on your content</p>
                </div>
                <button
                  onClick={() => toggleSetting('comments')}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.comments ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.comments ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Mentions</p>
                  <p className="text-sm text-gray-500">Get notified when someone mentions you</p>
                </div>
                <button
                  onClick={() => toggleSetting('mentions')}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.mentions ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.mentions ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Direct Messages</p>
                  <p className="text-sm text-gray-500">Get notified about new direct messages</p>
                </div>
                <button
                  onClick={() => toggleSetting('directMessages')}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    settings.directMessages ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      settings.directMessages ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-lg font-medium mb-4">Marketing</h2>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Marketing Emails</p>
                <p className="text-sm text-gray-500">Receive emails about new features and special offers</p>
              </div>
              <button
                onClick={() => toggleSetting('marketing')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  settings.marketing ? 'bg-blue-600' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    settings.marketing ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}