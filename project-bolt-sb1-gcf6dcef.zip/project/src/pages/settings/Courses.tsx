import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, LogOut } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { OptimizedImage } from '../../components/OptimizedImage';
import { LeaveConfirmationModal } from '../../components/course/LeaveConfirmationModal';

interface Course {
  id: string;
  title: string;
  description: string;
  image_url: string;
  instructor: {
    username: string;
  };
}

export function Courses() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [isLeaving, setIsLeaving] = useState(false);

  useEffect(() => {
    fetchCourses();
  }, [user]);

  const fetchCourses = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      const { data: enrollments, error: enrollmentsError } = await supabase
        .from('enrollments')
        .select(`
          course_id,
          courses (
            id,
            title,
            description,
            image_url,
            instructor:profiles!courses_instructor_id_fkey (
              username
            )
          )
        `)
        .eq('user_id', user.id);

      if (enrollmentsError) throw enrollmentsError;

      const formattedCourses = enrollments.map(enrollment => ({
        ...enrollment.courses,
        instructor: enrollment.courses.instructor
      }));

      setCourses(formattedCourses);
    } catch (err) {
      console.error('Error fetching courses:', err);
      setError('Failed to load your courses');
    } finally {
      setLoading(false);
    }
  };

  const handleLeaveCourse = async () => {
    if (!selectedCourse || !user) return;

    try {
      setIsLeaving(true);
      setError(null);

      const { error } = await supabase
        .from('enrollments')
        .delete()
        .eq('user_id', user.id)
        .eq('course_id', selectedCourse.id);

      if (error) throw error;

      setCourses(prev => prev.filter(course => course.id !== selectedCourse.id));
      setShowLeaveModal(false);
      setSelectedCourse(null);
    } catch (err) {
      console.error('Error leaving course:', err);
      setError('Failed to leave course. Please try again.');
    } finally {
      setIsLeaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <div className="max-w-lg mx-auto">
        {/* Header */}
        <div className="flex items-center px-4 py-6 border-b border-gray-200 dark:border-gray-800">
          <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-white">My Courses</h1>
        </div>

        {/* Content */}
        <div className="p-4">
          {error && (
            <div className="mb-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg">
              {error}
            </div>
          )}

          {loading ? (
            <div className="flex justify-center py-8">
              <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : courses.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">You haven't joined any courses yet</p>
              <button
                onClick={() => navigate('/discover')}
                className="mt-4 text-blue-500 dark:text-blue-400 hover:text-blue-600 dark:hover:text-blue-300"
              >
                Browse courses
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {courses.map((course) => (
                <div
                  key={course.id}
                  className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm"
                >
                  <div className="flex items-center">
                    <div className="w-20 h-20 bg-gray-200 dark:bg-gray-700 flex-shrink-0 rounded-lg overflow-hidden m-2">
                      <OptimizedImage
                        src={course.image_url}
                        alt={course.title}
                        className="w-full h-full object-cover"
                        placeholderClassName="w-full h-full"
                        width={80}
                        quality={70}
                      />
                    </div>
                    <div className="p-3 flex-1">
                      <h4 className="font-medium text-gray-900 dark:text-white">{course.title}</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        with {course.instructor.username}
                      </p>
                      <div className="mt-2 flex items-center justify-between">
                        <button
                          onClick={() => navigate(`/course/${course.id}`)}
                          className="text-blue-500 dark:text-blue-400 text-sm hover:text-blue-600 dark:hover:text-blue-300"
                        >
                          Go to course →
                        </button>
                        <button
                          onClick={() => {
                            setSelectedCourse(course);
                            setShowLeaveModal(true);
                          }}
                          className="flex items-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                        >
                          <LogOut size={16} className="mr-1" />
                          <span className="text-sm">Leave</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <LeaveConfirmationModal
        isOpen={showLeaveModal}
        onClose={() => {
          setShowLeaveModal(false);
          setSelectedCourse(null);
        }}
        onConfirm={handleLeaveCourse}
        isLeaving={isLeaving}
      />
    </div>
  );
}