import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, AlertTriangle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';

export function DeleteAccount() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [confirmation, setConfirmation] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleDelete = async () => {
    if (confirmation !== 'DELETE') {
      setError('Please type DELETE to confirm');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // Delete the user's account
      const { error: deleteError } = await supabase.auth.admin.deleteUser(
        user?.id as string
      );

      if (deleteError) throw deleteError;

      // Sign out after successful deletion
      await supabase.auth.signOut();
      navigate('/login');
    } catch (err: any) {
      console.error('Error deleting account:', err);
      setError(err.message || 'Failed to delete account');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <div className="max-w-lg mx-auto">
        <div className="flex items-center px-4 py-6 border-b border-gray-200 dark:border-gray-800">
          <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Delete Account</h1>
        </div>

        <div className="p-4 space-y-6">
          <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="text-red-500 flex-shrink-0" size={24} />
              <div>
                <h3 className="text-lg font-medium text-red-800 dark:text-red-200">
                  Warning: This action cannot be undone
                </h3>
                <p className="mt-2 text-sm text-red-700 dark:text-red-300">
                  Deleting your account will:
                </p>
                <ul className="mt-2 text-sm text-red-700 dark:text-red-300 list-disc list-inside space-y-1">
                  <li>Permanently delete your profile and personal data</li>
                  <li>Remove access to all courses you've enrolled in</li>
                  <li>Cancel all active subscriptions</li>
                  <li>Delete all your progress and achievements</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <p className="text-gray-700 dark:text-gray-300">
              To confirm deletion, please type <strong>DELETE</strong> in the field below:
            </p>
            <input
              type="text"
              value={confirmation}
              onChange={(e) => setConfirmation(e.target.value)}
              className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-800 border-none rounded-lg focus:ring-2 focus:ring-red-500"
              placeholder="Type DELETE to confirm"
            />
            {error && (
              <p className="text-sm text-red-500 dark:text-red-400">{error}</p>
            )}
          </div>

          <button
            onClick={handleDelete}
            disabled={loading || confirmation !== 'DELETE'}
            className="w-full py-3 bg-red-500 text-white rounded-lg font-medium disabled:opacity-50"
          >
            {loading ? 'Deleting Account...' : 'Delete My Account'}
          </button>

          <button
            onClick={() => navigate(-1)}
            className="w-full py-3 text-gray-700 dark:text-gray-300 font-medium"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}