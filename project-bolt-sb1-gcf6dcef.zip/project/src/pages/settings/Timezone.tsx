import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

export function Timezone() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-lg mx-auto">
        <div className="flex items-center px-4 py-6 border-b">
          <button onClick={() => navigate(-1)} className="mr-4">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-semibold">Timezone</h1>
        </div>

        <div className="p-4">
          <p className="text-gray-500 text-center">
            Timezone settings coming soon!
          </p>
        </div>
      </div>
    </div>
  );
}