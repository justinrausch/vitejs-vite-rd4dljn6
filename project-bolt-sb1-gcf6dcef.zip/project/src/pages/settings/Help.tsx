import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, HelpCircle, MessageCircle, Book, Mail, Search, Send } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';

// Popular articles data
const popularArticles = [
  {
    id: 'getting-started',
    title: 'Getting Started Guide',
    content: `
      ## Overview
      
      Learn how to set up your account, navigate the app, and start using Mastery.
      
      ### Steps
      
      1. Create an account.
      2. Set up your profile.
      3. Explore content and features.
      4. Subscribe to a course.
      
      ### FAQs
      
      **How do I create an account?**
      
      To create an account, download the Mastery app or visit our website. Click "Create Account" enter your email, create a password, and follow the on-screen instructions.
      
      **How do I update my profile?**
      
      Navigate to "Profile" in the app, select "Edit Profile," make your changes, and save.
    `
  },
  {
    id: 'subscription-faqs',
    title: 'Subscription FAQs',
    content: `
      ## Overview
      
      Information on our subscription plans and billing cycles.
      
      ### Common Questions
      
      **How do I subscribe?**
      
      Go to "Discover," and browse from coaches on our platform, once you find one you like, tap on their channel, choose a plan, and enter your payment details.
      
      **How do I cancel my subscription?**
      
      Go to "Settings," navigate to "Subscription," and select "Cancel Subscription." Your access will continue until the end of the billing period.
      
      **Do you offer refunds?**
      
      Refunds are not typically offered, but exceptions may be made for special cases. Contact support for assistance.
    `
  },
  {
    id: 'video-playback-issues',
    title: 'Video Playback Issues',
    content: `
      ## Overview
      
      Troubleshooting tips for video loading, buffering, and quality issues.
      
      ### Solutions
      
      - Check internet connection.
      - Update the app.
      - Restart your device.
      - Clear cache and cookies.
      
      ### FAQs
      
      **Why is my video not loading?**
      
      Ensure you have a stable internet connection, update the app, and restart your device. If the issue persists, contact support.
      
      **How do I improve video quality?**
      
      Check your internet speed, close background apps, and adjust the video quality in "Settings."
    `
  },
  {
    id: 'payment-methods',
    title: 'Payment Methods',
    content: `
      ## Overview
      
      Learn about accepted payment methods and managing transactions.
      
      ### Payment Options
      
      - Credit/Debit Cards
      - PayPal
      
      ### FAQs
      
      **How do I update my payment method?**
      
      Go to "Settings," navigate to "Subscriptions" then tap "Payment Methods," and add or update your payment details.
      
      **Why was my payment declined?**
      
      Ensure your card has sufficient funds, check for expired cards, and contact your bank for more details.
      
      **How do I view my payment history?**
      
      Visit "Settings," go to "Subscriptions" and you'll see a list of past transactions.
    `
  },
  {
    id: 'account-security',
    title: 'Account Security',
    content: `
      ## Overview
      
      Tips to keep your account safe.
      
      ### Security Features
      
      - Two-Factor Authentication (2FA)
      - Password management
      - Recognizing phishing attempts
      
      ### FAQs
      
      **How do I reset my password?**
      
      Click "Forgot Password" on the login screen, enter your email, and follow the reset instructions.
      
      **How do I enable 2FA?**
      
      Go to "Settings," navigate to "Security," and enable Two-Factor Authentication.
      
      **What should I do if I suspect unauthorized access?**
      
      Change your password immediately, enable 2FA, and contact support to secure your account.
    `
  }
];

// Support ticket interface
interface SupportTicket {
  id?: string;
  user_id: string;
  subject: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved';
  created_at?: string;
}

interface TicketReply {
  id?: string;
  ticket_id: string;
  user_id: string;
  message: string;
  created_at?: string;
  user?: {
    username: string;
    avatar_url: string | null;
    is_admin?: boolean;
  };
}

export function Help() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArticle, setSelectedArticle] = useState<string | null>(null);
  const [showContactForm, setShowContactForm] = useState(false);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [userTickets, setUserTickets] = useState<SupportTicket[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [ticketReplies, setTicketReplies] = useState<TicketReply[]>([]);
  const [replyText, setReplyText] = useState('');
  const [sendingReply, setSendingReply] = useState(false);

  useEffect(() => {
    if (user) {
      fetchUserTickets();
    }
  }, [user]);

  useEffect(() => {
    if (selectedTicket) {
      fetchTicketReplies(selectedTicket.id!);
    }
  }, [selectedTicket]);

  const fetchUserTickets = async () => {
    if (!user) return;
    
    try {
      setLoadingTickets(true);
      
      const { data, error } = await supabase
        .from('support_tickets')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      setUserTickets(data || []);
    } catch (err) {
      console.error('Error fetching user tickets:', err);
    } finally {
      setLoadingTickets(false);
    }
  };

  const fetchTicketReplies = async (ticketId: string) => {
    try {
      const { data, error } = await supabase
        .from('ticket_replies')
        .select(`
          *,
          user:user_id (
            username,
            avatar_url,
            is_admin
          )
        `)
        .eq('ticket_id', ticketId)
        .order('created_at', { ascending: true });

      if (error) throw error;

      setTicketReplies(data || []);
    } catch (err) {
      console.error('Error fetching ticket replies:', err);
    }
  };

  // Filter articles based on search query
  const filteredArticles = popularArticles.filter(article => 
    article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    article.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Get the selected article content
  const articleContent = selectedArticle 
    ? popularArticles.find(a => a.id === selectedArticle)?.content 
    : null;

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      setSubmitError('You must be logged in to submit a ticket');
      return;
    }
    
    if (!ticketSubject.trim() || !ticketMessage.trim()) {
      setSubmitError('Please fill in all fields');
      return;
    }
    
    try {
      setSubmitting(true);
      setSubmitError(null);
      
      // Create the support ticket
      const newTicket: SupportTicket = {
        user_id: user.id,
        subject: ticketSubject.trim(),
        message: ticketMessage.trim(),
        status: 'open'
      };
      
      const { data, error } = await supabase
        .from('support_tickets')
        .insert(newTicket)
        .select();
      
      if (error) throw error;
      
      // Reset form and show success message
      setTicketSubject('');
      setTicketMessage('');
      setSubmitSuccess(true);
      
      // Refresh user tickets
      fetchUserTickets();
      
      // Hide success message after 3 seconds
      setTimeout(() => {
        setSubmitSuccess(false);
        setShowContactForm(false);
      }, 3000);
      
    } catch (error) {
      console.error('Error submitting ticket:', error);
      setSubmitError('Failed to submit ticket. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user || !selectedTicket || !replyText.trim()) {
      return;
    }
    
    try {
      setSendingReply(true);
      
      const newReply = {
        ticket_id: selectedTicket.id!,
        user_id: user.id,
        message: replyText.trim()
      };
      
      const { data, error } = await supabase
        .from('ticket_replies')
        .insert(newReply)
        .select(`
          *,
          user:user_id (
            username,
            avatar_url,
            is_admin
          )
        `);
      
      if (error) throw error;
      
      if (data) {
        setTicketReplies(prev => [...prev, ...data]);
        setReplyText('');
      }
      
    } catch (error) {
      console.error('Error sending reply:', error);
      alert('Failed to send reply. Please try again.');
    } finally {
      setSendingReply(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return (
          <span className="px-2 py-1 bg-yellow-100 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-300 rounded-full text-xs">
            Open
          </span>
        );
      case 'in_progress':
        return (
          <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 rounded-full text-xs">
            In Progress
          </span>
        );
      case 'resolved':
        return (
          <span className="px-2 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 rounded-full text-xs">
            Resolved
          </span>
        );
      default:
        return null;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <div className="max-w-lg mx-auto">
        <div className="flex items-center px-4 py-6 border-b border-gray-200 dark:border-gray-800">
          <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Help Center</h1>
        </div>

        <div className="p-4 space-y-6">
          {/* Back button when viewing an article */}
          {(selectedArticle || showContactForm || selectedTicket) && (
            <button 
              onClick={() => {
                setSelectedArticle(null);
                setShowContactForm(false);
                setSelectedTicket(null);
              }}
              className="flex items-center text-blue-500 dark:text-blue-400 mb-4"
            >
              <ChevronLeft size={20} className="mr-1" />
              Back to Help Center
            </button>
          )}

          {/* Article content */}
          {selectedArticle && !showContactForm && !selectedTicket && (
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                {popularArticles.find(a => a.id === selectedArticle)?.title}
              </h2>
              <div className="prose dark:prose-invert prose-sm max-w-none">
                {articleContent?.split('\n').map((line, index) => {
                  if (line.startsWith('## ')) {
                    return <h2 key={index} className="text-lg font-semibold mt-6 mb-3">{line.replace('## ', '')}</h2>;
                  } else if (line.startsWith('### ')) {
                    return <h3 key={index} className="text-md font-semibold mt-4 mb-2">{line.replace('### ', '')}</h3>;
                  } else if (line.startsWith('**')) {
                    return <p key={index} className="font-semibold mt-3 mb-1">{line.replace(/\*\*/g, '')}</p>;
                  } else if (line.startsWith('- ')) {
                    return <li key={index} className="ml-4 mb-1">{line.replace('- ', '')}</li>;
                  } else if (line.trim() === '') {
                    return <div key={index} className="h-2"></div>;
                  } else {
                    return <p key={index} className="mb-2">{line}</p>;
                  }
                })}
              </div>
              
              <div className="mt-8 border-t border-gray-200 dark:border-gray-700 pt-4">
                <p className="text-gray-600 dark:text-gray-400 text-sm">Was this article helpful?</p>
                <div className="flex space-x-2 mt-2">
                  <button className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg text-sm hover:bg-gray-200 dark:hover:bg-gray-600">
                    Yes, thanks!
                  </button>
                  <button 
                    onClick={() => setShowContactForm(true)}
                    className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg text-sm hover:bg-gray-200 dark:hover:bg-gray-600"
                  >
                    No, I need help
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Contact Support Form */}
          {showContactForm && !selectedTicket && (
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                Contact Support
              </h2>
              
              {submitSuccess ? (
                <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 text-green-700 dark:text-green-300">
                  <p className="font-medium">Ticket submitted successfully!</p>
                  <p className="text-sm mt-1">Our support team will get back to you as soon as possible.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmitTicket} className="space-y-4">
                  {submitError && (
                    <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3 text-red-700 dark:text-red-300 text-sm">
                      {submitError}
                    </div>
                  )}
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Subject
                    </label>
                    <input
                      type="text"
                      value={ticketSubject}
                      onChange={(e) => setTicketSubject(e.target.value)}
                      placeholder="Brief description of your issue"
                      className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Message
                    </label>
                    <textarea
                      value={ticketMessage}
                      onChange={(e) => setTicketMessage(e.target.value)}
                      placeholder="Please provide details about your issue..."
                      rows={5}
                      className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white resize-none"
                      required
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={submitting}
                      className="px-4 py-2 bg-blue-500 text-white rounded-lg flex items-center disabled:opacity-50"
                    >
                      {submitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Send size={16} className="mr-2" />
                          Submit Ticket
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Ticket Detail View */}
          {selectedTicket && (
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  {selectedTicket.subject}
                </h2>
                {getStatusBadge(selectedTicket.status)}
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-750 p-4 rounded-lg mb-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {selectedTicket.created_at ? formatDate(selectedTicket.created_at) : 'Recently'}
                  </span>
                </div>
                <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                  {selectedTicket.message}
                </p>
              </div>
              
              {/* Ticket Replies */}
              {ticketReplies.length > 0 && (
                <div className="mb-6">
                  <h3 className="font-medium text-gray-900 dark:text-white mb-3">Replies</h3>
                  <div className="space-y-4">
                    {ticketReplies.map(reply => (
                      <div key={reply.id} className="bg-gray-50 dark:bg-gray-750 p-4 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <div className="flex items-center">
                            {reply.user?.is_admin && (
                              <span className="px-2 py-0.5 bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 rounded-full text-xs mr-2">
                                Support Team
                              </span>
                            )}
                          </div>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {reply.created_at ? formatDate(reply.created_at) : 'Recently'}
                          </span>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                          {reply.message}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Reply Form */}
              <div>
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">Add Reply</h3>
                <form onSubmit={handleSendReply} className="space-y-4">
                  <textarea
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder="Type your reply here..."
                    rows={4}
                    className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white resize-none"
                    required
                  />
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={sendingReply || !replyText.trim()}
                      className="px-4 py-2 bg-blue-500 text-white rounded-lg flex items-center disabled:opacity-50"
                    >
                      {sendingReply ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send size={16} className="mr-2" />
                          Send Reply
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
          
          {/* User's existing tickets */}
          {!selectedArticle && !showContactForm && !selectedTicket && userTickets.length > 0 && (
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm mb-6">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Your Support Tickets</h3>
              <div className="space-y-3">
                {loadingTickets ? (
                  <div className="flex justify-center py-4">
                    <div className="w-6 h-6 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                  </div>
                ) : (
                  userTickets.map(ticket => (
                    <button
                      key={ticket.id}
                      onClick={() => setSelectedTicket(ticket)}
                      className="w-full bg-gray-50 dark:bg-gray-750 p-3 rounded-lg text-left hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <div className="flex justify-between items-center">
                        <h4 className="font-medium text-gray-800 dark:text-gray-200">{ticket.subject}</h4>
                        <div className="flex items-center">
                          {getStatusBadge(ticket.status)}
                        </div>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        {ticket.created_at ? formatDate(ticket.created_at) : 'Recently'}
                      </p>
                    </button>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Help Center Main Content */}
          {!selectedArticle && !showContactForm && !selectedTicket && (
            <>
              <div className="space-y-4">
                <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">How can we help?</h2>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="search"
                      placeholder="Search help articles..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full px-4 py-2 pl-10 bg-white dark:bg-gray-700 border-none rounded-lg focus:ring-2 focus:ring-blue-500 dark:text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => setShowContactForm(true)}
                    className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg text-left hover:bg-gray-100 dark:hover:bg-gray-750"
                  >
                    <MessageCircle className="text-blue-500 mb-2" size={24} />
                    <h3 className="font-medium text-gray-900 dark:text-white">Contact Support</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Get help from our team</p>
                  </button>

                  <button 
                    onClick={() => setSelectedArticle('getting-started')}
                    className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg text-left hover:bg-gray-100 dark:hover:bg-gray-750"
                  >
                    <Book className="text-blue-500 mb-2" size={24} />
                    <h3 className="font-medium text-gray-900 dark:text-white">Documentation</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Browse our guides</p>
                  </button>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white">Popular Articles</h3>
                  <div className="space-y-2">
                    {filteredArticles.map((article) => (
                      <button
                        key={article.id}
                        onClick={() => setSelectedArticle(article.id)}
                        className="w-full flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-750"
                      >
                        <span className="text-gray-700 dark:text-gray-300">{article.title}</span>
                        <ChevronRight size={20} className="text-gray-400" />
                      </button>
                    ))}
                    
                    {filteredArticles.length === 0 && (
                      <div className="text-center py-8">
                        <HelpCircle size={48} className="mx-auto text-gray-400 dark:text-gray-600 mb-4" />
                        <p className="text-gray-500 dark:text-gray-400">No articles found matching "{searchQuery}"</p>
                        <button 
                          onClick={() => setSearchQuery('')}
                          className="mt-2 text-blue-500 dark:text-blue-400"
                        >
                          Clear search
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Mail className="text-blue-500" size={24} />
                  <div>
                    <h3 className="font-medium text-gray-900 dark:text-white">Still need help?</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Our support team is ready to assist you
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowContactForm(true)}
                  className="w-full mt-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                >
                  Contact Support
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}