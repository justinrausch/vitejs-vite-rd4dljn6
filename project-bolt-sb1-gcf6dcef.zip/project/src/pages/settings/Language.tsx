import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Check } from 'lucide-react';

export function Language() {
  const navigate = useNavigate();
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  
  const languages = [
    'English',
    'Spanish',
    'French',
    'German',
    'Italian',
    'Portuguese',
    'Russian',
    'Japanese',
    'Korean',
    'Chinese (Simplified)',
  ];

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-lg mx-auto">
        <div className="flex items-center px-4 py-6 border-b">
          <button onClick={() => navigate(-1)} className="mr-4">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-semibold">Language</h1>
        </div>

        <div className="divide-y">
          {languages.map((language) => (
            <button
              key={language}
              onClick={() => setSelectedLanguage(language)}
              className="w-full px-4 py-4 flex items-center justify-between hover:bg-gray-50"
            >
              <span>{language}</span>
              {selectedLanguage === language && (
                <Check size={20} className="text-blue-600" />
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}