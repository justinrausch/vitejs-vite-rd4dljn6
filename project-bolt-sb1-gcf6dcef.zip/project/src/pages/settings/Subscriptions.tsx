import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, CreditCard, Calendar, Clock, AlertTriangle, CheckCircle, X, Plus, Loader } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';

interface PaymentMethod {
  id: string;
  type: 'card';
  last4: string;
  expMonth: number;
  expYear: number;
  brand: string;
  isDefault: boolean;
}

interface Subscription {
  id: string;
  course_id: string;
  course: {
    title: string;
    image_url: string;
    instructor: {
      username: string;
    };
  };
  plan: {
    title: string;
    price: number;
    renewal_period: string;
  };
  status: 'active' | 'canceled' | 'expired';
  next_billing_date: string;
  created_at: string;
  payment_method?: PaymentMethod;
}

export function Subscriptions() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [selectedSubscription, setSelectedSubscription] = useState<Subscription | null>(null);
  const [canceling, setCanceling] = useState(false);
  const [showAddCard, setShowAddCard] = useState(false);
  const [addingCard, setAddingCard] = useState(false);

  // Mock payment methods for demo
  const mockPaymentMethods: PaymentMethod[] = [
    {
      id: '1',
      type: 'card',
      last4: '4242',
      expMonth: 12,
      expYear: 2025,
      brand: 'visa',
      isDefault: true
    },
    {
      id: '2',
      type: 'card',
      last4: '1234',
      expMonth: 8,
      expYear: 2024,
      brand: 'mastercard',
      isDefault: false
    }
  ];

  useEffect(() => {
    fetchSubscriptions();
    // In a real app, you would fetch payment methods from your payment provider
    setPaymentMethods(mockPaymentMethods);
  }, [user]);

  const fetchSubscriptions = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      const { data: enrollments, error: enrollmentsError } = await supabase
        .from('enrollments')
        .select(`
          id,
          course_id,
          courses (
            id,
            title,
            image_url,
            profiles!courses_instructor_id_fkey (
              username
            ),
            course_plans (
              title,
              price,
              renewal_period
            )
          )
        `)
        .eq('user_id', user.id);

      if (enrollmentsError) throw enrollmentsError;

      const formattedSubscriptions = enrollments.map(enrollment => ({
        id: enrollment.id,
        course_id: enrollment.course_id,
        course: {
          title: enrollment.courses.title,
          image_url: enrollment.courses.image_url,
          instructor: {
            username: enrollment.courses.profiles.username
          }
        },
        plan: enrollment.courses.course_plans[0] || {
          title: 'Monthly Plan',
          price: 49.99,
          renewal_period: 'monthly'
        },
        status: 'active',
        next_billing_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        created_at: new Date().toISOString(),
        payment_method: mockPaymentMethods[0]
      }));

      setSubscriptions(formattedSubscriptions);
    } catch (err) {
      console.error('Error fetching subscriptions:', err);
      setError('Failed to load your subscriptions');
    } finally {
      setLoading(false);
    }
  };

  const handleCancelSubscription = async () => {
    if (!selectedSubscription) return;

    try {
      setCanceling(true);
      
      const { error: deleteError } = await supabase
        .from('enrollments')
        .delete()
        .eq('id', selectedSubscription.id);

      if (deleteError) throw deleteError;

      setSubscriptions(prev => 
        prev.filter(sub => sub.id !== selectedSubscription.id)
      );
      setShowCancelModal(false);
    } catch (err) {
      console.error('Error canceling subscription:', err);
      setError('Failed to cancel subscription');
    } finally {
      setCanceling(false);
      setSelectedSubscription(null);
    }
  };

  const handleAddCard = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setAddingCard(true);
      // Simulate adding a card
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const newCard: PaymentMethod = {
        id: Date.now().toString(),
        type: 'card',
        last4: '5555',
        expMonth: 12,
        expYear: 2026,
        brand: 'visa',
        isDefault: false
      };

      setPaymentMethods(prev => [...prev, newCard]);
      setShowAddCard(false);
    } catch (err) {
      setError('Failed to add card');
    } finally {
      setAddingCard(false);
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  const getCardIcon = (brand: string) => {
    switch (brand.toLowerCase()) {
      case 'visa':
        return '💳';
      case 'mastercard':
        return '💳';
      case 'amex':
        return '💳';
      default:
        return '💳';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-lg mx-auto">
        {/* Header */}
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
          <div className="px-4 py-6 flex items-center">
            <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
              <ChevronLeft size={24} />
            </button>
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Subscriptions</h1>
          </div>
        </div>

        <div className="p-4">
          {error && (
            <div className="mb-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg flex items-start">
              <AlertTriangle className="text-red-500 dark:text-red-400 mr-3 flex-shrink-0 mt-0.5" size={20} />
              <p className="text-red-700 dark:text-red-300">{error}</p>
            </div>
          )}

          {/* Payment Methods Section */}
          <div className="mb-8">
            <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Payment Methods</h2>
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
              {paymentMethods.map((method) => (
                <div
                  key={method.id}
                  className="p-4 flex items-center justify-between border-b border-gray-200 dark:border-gray-700 last:border-0"
                >
                  <div className="flex items-center">
                    <span className="text-2xl mr-3">{getCardIcon(method.brand)}</span>
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        {method.brand.charAt(0).toUpperCase() + method.brand.slice(1)} •••• {method.last4}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Expires {method.expMonth.toString().padStart(2, '0')}/{method.expYear}
                      </p>
                    </div>
                  </div>
                  {method.isDefault && (
                    <span className="text-xs bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 px-2 py-1 rounded-full">
                      Default
                    </span>
                  )}
                </div>
              ))}
              <button
                onClick={() => setShowAddCard(true)}
                className="w-full p-4 flex items-center justify-center text-blue-500 dark:text-blue-400 hover:bg-gray-50 dark:hover:bg-gray-750"
              >
                <Plus size={20} className="mr-2" />
                Add Payment Method
              </button>
            </div>
          </div>

          {/* Active Subscriptions */}
          <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Active Subscriptions</h2>
          
          {loading ? (
            <div className="flex justify-center py-12">
              <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : subscriptions.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-xl shadow-sm">
              <CreditCard size={48} className="mx-auto text-gray-400 dark:text-gray-600 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                No active subscriptions
              </h3>
              <p className="text-gray-500 dark:text-gray-400 mb-6">
                You don't have any active subscriptions at the moment.
              </p>
              <button
                onClick={() => navigate('/discover')}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
              >
                Browse Courses
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {subscriptions.map((subscription) => (
                <div
                  key={subscription.id}
                  className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded-lg overflow-hidden flex-shrink-0">
                        <img
                          src={subscription.course.image_url}
                          alt={subscription.course.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium text-gray-900 dark:text-white">
                          {subscription.course.title}
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          by {subscription.course.instructor.username}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <span className="px-2 py-1 text-xs rounded-full flex items-center bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-400">
                        <CheckCircle size={12} className="mr-1" />
                        Active
                      </span>
                    </div>
                  </div>

                  <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
                    <div className="flex items-center justify-between text-sm">
                      <div className="space-y-2">
                        <div className="flex items-center text-gray-500 dark:text-gray-400">
                          <Calendar size={16} className="mr-1" />
                          Next billing: {formatDate(subscription.next_billing_date)}
                        </div>
                        <div className="flex items-center text-gray-500 dark:text-gray-400">
                          <CreditCard size={16} className="mr-1" />
                          {subscription.payment_method?.brand.toUpperCase()} •••• {subscription.payment_method?.last4}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-gray-900 dark:text-white">
                          {formatPrice(subscription.plan.price)}/{subscription.plan.renewal_period}
                        </div>
                        <button
                          onClick={() => {
                            setSelectedSubscription(subscription);
                            setShowCancelModal(true);
                          }}
                          className="text-red-500 dark:text-red-400 text-sm font-medium hover:text-red-600 dark:hover:text-red-300 mt-2"
                        >
                          Cancel Subscription
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Cancel Subscription Modal */}
      {showCancelModal && selectedSubscription && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                Cancel Subscription
              </h3>
              <button
                onClick={() => {
                  setShowCancelModal(false);
                  setSelectedSubscription(null);
                }}
                className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
              >
                <X size={20} />
              </button>
            </div>
            <p className="text-gray-500 dark:text-gray-400 mb-4">
              Are you sure you want to cancel your subscription to{' '}
              <span className="font-medium text-gray-900 dark:text-white">
                {selectedSubscription.course.title}
              </span>
              ? You'll lose access to the course at the end of your current billing period.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowCancelModal(false);
                  setSelectedSubscription(null);
                }}
                disabled={canceling}
                className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg disabled:opacity-50"
              >
                Keep Subscription
              </button>
              <button
                onClick={handleCancelSubscription}
                disabled={canceling}
                className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 disabled:opacity-50 flex items-center"
              >
                {canceling ? (
                  <>
                    <Loader size={16} className="animate-spin mr-2" />
                    Canceling...
                  </>
                ) : (
                  'Cancel Subscription'
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Card Modal */}
      {showAddCard && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                Add Payment Method
              </h3>
              <button
                onClick={() => setShowAddCard(false)}
                className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
              >
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleAddCard}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Card Number
                  </label>
                  <input
                    type="text"
                    placeholder="1234 5678 9012 3456"
                    className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Expiry Date
                    </label>
                    <input
                      type="text"
                      placeholder="MM/YY"
                      className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      CVC
                    </label>
                    <input
                      type="text"
                      placeholder="123"
                      className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Name on Card
                  </label>
                  <input
                    type="text"
                    placeholder="John Doe"
                    className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                  />
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddCard(false)}
                  disabled={addingCard}
                  className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={addingCard}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 flex items-center"
                >
                  {addingCard ? (
                    <>
                      <Loader size={16} className="animate-spin mr-2" />
                      Adding Card...
                    </>
                  ) : (
                    'Add Card'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}