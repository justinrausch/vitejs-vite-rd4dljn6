import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Instagram, Youtube, Globe } from 'lucide-react';

const StravaIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
    <path d="M15.387 17.944l-2.089-4.116h-3.065L15.387 24l5.15-10.172h-3.066m-7.008-5.599l2.836 5.598h4.172L10.463 0l-7.027 13.828h4.172"/>
  </svg>
);

export function ConnectedAccounts() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <div className="max-w-lg mx-auto">
        <div className="flex items-center px-4 py-6 border-b border-gray-200 dark:border-gray-800">
          <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Connected Accounts</h1>
        </div>

        <div className="p-4 space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="flex items-center space-x-3">
                <Instagram size={24} className="text-pink-500" />
                <div>
                  <h3 className="text-gray-900 dark:text-white font-medium">Instagram</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Not connected</p>
                </div>
              </div>
              <button className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg text-sm">
                Connect
              </button>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="flex items-center space-x-3">
                <Youtube size={24} className="text-red-500" />
                <div>
                  <h3 className="text-gray-900 dark:text-white font-medium">YouTube</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Not connected</p>
                </div>
              </div>
              <button className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg text-sm">
                Connect
              </button>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div className="flex items-center space-x-3">
                <StravaIcon />
                <div>
                  <h3 className="text-gray-900 dark:text-white font-medium">Strava</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Not connected</p>
                </div>
              </div>
              <button className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg text-sm">
                Connect
              </button>
            </div>
          </div>

          <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
            <p className="text-sm text-yellow-800 dark:text-yellow-200">
              Connecting your social accounts helps us verify your identity and can unlock additional features.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}