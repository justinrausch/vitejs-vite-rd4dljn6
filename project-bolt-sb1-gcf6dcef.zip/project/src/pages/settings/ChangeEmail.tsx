import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Mail } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';

export function ChangeEmail() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [newEmail, setNewEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      // First verify the password
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user.email!,
        password
      });

      if (signInError) throw new Error('Invalid password');

      // Update email
      const { error: updateError } = await supabase.auth.updateUser({
        email: newEmail
      });

      if (updateError) throw updateError;

      setSuccess(true);
      setTimeout(() => navigate('/settings'), 2000);
    } catch (err: any) {
      console.error('Error updating email:', err);
      setError(err.message || 'Failed to update email');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-lg mx-auto">
        <div className="flex items-center px-4 py-6 border-b border-gray-200 dark:border-gray-800">
          <button onClick={() => navigate(-1)} className="mr-4 text-gray-700 dark:text-gray-300">
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Change Email</h1>
        </div>

        <div className="p-4">
          {error && (
            <div className="mb-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg">
              {error}
            </div>
          )}

          {success && (
            <div className="mb-4 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-600 dark:text-green-400 rounded-lg">
              Email updated successfully! Redirecting...
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Current Email
              </label>
              <div className="flex items-center bg-gray-100 dark:bg-gray-800 rounded-lg px-4 py-3">
                <Mail size={20} className="text-gray-400 dark:text-gray-500 mr-2" />
                <span className="text-gray-600 dark:text-gray-300">{user?.email}</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                New Email
              </label>
              <div className="flex items-center bg-gray-100 dark:bg-gray-800 rounded-lg px-4">
                <Mail size={20} className="text-gray-400 dark:text-gray-500 mr-2" />
                <input
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="Enter new email"
                  className="w-full py-3 bg-transparent border-none focus:ring-0 dark:text-white dark:placeholder-gray-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Confirm Password
              </label>
              <div className="flex items-center bg-gray-100 dark:bg-gray-800 rounded-lg px-4">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full py-3 bg-transparent border-none focus:ring-0 dark:text-white dark:placeholder-gray-400"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading || !newEmail || !password}
              className="w-full py-3 bg-blue-500 text-white rounded-lg font-medium disabled:opacity-50"
            >
              {loading ? 'Updating...' : 'Update Email'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}