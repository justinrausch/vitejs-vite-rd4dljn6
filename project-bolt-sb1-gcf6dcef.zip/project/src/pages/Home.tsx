import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, AlertTriangle, Clock, ArrowRight, Plus } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { CourseWithBasicInfo } from '../types/course';
import { OptimizedImage } from '../components/media/OptimizedImage';
import { UserAvatar } from '../components/user/UserAvatar';
import { VerifiedBadge } from '../components/user/VerifiedBadge';

interface RecentActivity {
  courseId: string;
  lessonId?: string;
  lessonTitle?: string;
  timestamp: string;
  course: CourseWithBasicInfo;
}

export function Home() {
  const { user, userProfile } = useAuth();
  const navigate = useNavigate();
  const [enrolledCourses, setEnrolledCourses] = useState<CourseWithBasicInfo[]>([]);
  const [createdCourses, setCreatedCourses] = useState<CourseWithBasicInfo[]>([]);
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [createdCoursesLoading, setCreatedCoursesLoading] = useState(true);
  const [recentLoading, setRecentLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [courseCount, setCourseCount] = useState<number | null>(null);
  const isCoach = userProfile?.is_coach || false;

  const checkCourseCount = useCallback(async () => {
    try {
      const { count, error } = await supabase
        .from('courses')
        .select('*', { count: 'exact', head: true });
      
      if (error) throw error;
      setCourseCount(count);
    } catch (err) {
      console.error('Error checking course count:', err);
    }
  }, []);

  const fetchEnrolledCourses = useCallback(async () => {
    if (!user) return;
    
    try {
      setError(null);
      const { data: enrollments, error: enrollmentsError } = await supabase
        .from('enrollments')
        .select(`
          course_id,
          courses (
            id,
            title,
            description,
            price,
            image_url,
            logo_url,
            instructor_id,
            profiles!courses_instructor_id_fkey (
              id,
              username,
              avatar_url,
              is_verified,
              full_name
            ),
            course_tags (
              tag
            )
          )
        `)
        .eq('user_id', user.id);

      if (enrollmentsError) throw enrollmentsError;

      const courses = enrollments?.map(enrollment => {
        const course = enrollment.courses;
        return {
          id: course.id,
          title: course.title,
          description: course.description,
          price: course.price,
          image_url: course.image_url,
          logo_url: course.logo_url,
          instructor: {
            id: course.profiles.id,
            username: course.profiles.username,
            avatar_url: course.profiles.avatar_url,
            is_verified: course.profiles.is_verified,
            full_name: course.profiles.full_name
          },
          tags: course.course_tags.map(tag => tag.tag)
        };
      });

      setEnrolledCourses(courses || []);
    } catch (err) {
      console.error('Error fetching enrolled courses:', err);
      setError('Failed to load your courses. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [user]);

  const fetchCreatedCourses = useCallback(async () => {
    if (!user || !isCoach) return;
    
    try {
      setCreatedCoursesLoading(true);
      
      const { data: coursesData, error: coursesError } = await supabase
        .from('courses')
        .select(`
          id,
          title,
          description,
          price,
          image_url,
          logo_url,
          instructor_id,
          profiles!courses_instructor_id_fkey (
            id,
            username,
            avatar_url,
            is_verified,
            full_name
          ),
          course_tags (
            tag
          )
        `)
        .eq('instructor_id', user.id);

      if (coursesError) throw coursesError;

      const formattedCourses = coursesData?.map(course => ({
        id: course.id,
        title: course.title,
        description: course.description,
        price: course.price,
        image_url: course.image_url,
        logo_url: course.logo_url,
        instructor: {
          id: course.profiles.id,
          username: course.profiles.username,
          avatar_url: course.profiles.avatar_url,
          is_verified: course.profiles.is_verified,
          full_name: course.profiles.full_name
        },
        tags: course.course_tags.map(tag => tag.tag)
      })) || [];

      setCreatedCourses(formattedCourses);
    } catch (err) {
      console.error('Error fetching created courses:', err);
    } finally {
      setCreatedCoursesLoading(false);
    }
  }, [user, isCoach]);

  const fetchRecentActivity = useCallback(async () => {
    if (!user) return;
    
    try {
      setRecentLoading(true);
      
      const { data: completedLessons, error: completedError } = await supabase
        .from('completed_lessons')
        .select(`
          lesson_id,
          course_id,
          completed_at,
          course_lessons:lesson_id (
            title
          ),
          courses:course_id (
            id,
            title,
            description,
            price,
            image_url,
            logo_url,
            instructor_id,
            profiles!courses_instructor_id_fkey (
              id,
              username,
              avatar_url,
              is_verified,
              full_name
            ),
            course_tags (
              tag
            )
          )
        `)
        .eq('user_id', user.id)
        .order('completed_at', { ascending: false })
        .limit(3);
      
      if (completedError) throw completedError;
      
      if (completedLessons && completedLessons.length > 0) {
        const activity = completedLessons.map(item => ({
          courseId: item.course_id,
          lessonId: item.lesson_id,
          lessonTitle: item.course_lessons?.title,
          timestamp: item.completed_at,
          course: {
            id: item.courses.id,
            title: item.courses.title,
            description: item.courses.description,
            price: item.courses.price,
            image_url: item.courses.image_url,
            logo_url: item.courses.logo_url,
            instructor: {
              id: item.courses.profiles.id,
              username: item.courses.profiles.username,
              avatar_url: item.courses.profiles.avatar_url,
              is_verified: item.courses.profiles.is_verified,
              full_name: item.courses.profiles.full_name
            },
            tags: item.courses.course_tags.map((tag: any) => tag.tag)
          }
        }));
        
        setRecentActivity(activity);
      } else if (enrolledCourses.length > 0) {
        const activity = enrolledCourses.slice(0, 3).map(course => ({
          courseId: course.id,
          timestamp: new Date().toISOString(),
          course
        }));
        
        setRecentActivity(activity);
      } else {
        setRecentActivity([]);
      }
    } catch (err) {
      console.error('Error fetching recent activity:', err);
      
      if (enrolledCourses.length > 0) {
        const activity = enrolledCourses.slice(0, 3).map(course => ({
          courseId: course.id,
          timestamp: new Date().toISOString(),
          course
        }));
        
        setRecentActivity(activity);
      }
    } finally {
      setRecentLoading(false);
    }
  }, [user, enrolledCourses]);

  useEffect(() => {
    checkCourseCount();
    if (user) {
      fetchEnrolledCourses();
      if (isCoach) {
        fetchCreatedCourses();
      }
    } else {
      setLoading(false);
    }
  }, [user, isCoach, checkCourseCount, fetchEnrolledCourses, fetchCreatedCourses]);

  useEffect(() => {
    if (user && enrolledCourses.length > 0) {
      fetchRecentActivity();
    } else {
      setRecentLoading(false);
    }
  }, [user, enrolledCourses, fetchRecentActivity]);

  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return 'just now';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} ${minutes === 1 ? 'minute' : 'minutes'} ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} ${days === 1 ? 'day' : 'days'} ago`;
    }
  };

  if (loading && createdCoursesLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-16 h-16 border-4 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="pb-20">
      <div className="max-w-lg mx-auto px-4 py-6">
        <h1 className="text-2xl font-medium text-gray-900 dark:text-white mb-6">
          Hi, {userProfile?.full_name || user?.user_metadata?.full_name || 'there'}
        </h1>

        {courseCount === 0 && (
          <div className="mb-6 p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg flex items-start">
            <AlertTriangle className="text-yellow-500 dark:text-yellow-400 mr-3 flex-shrink-0 mt-0.5" size={20} />
            <div>
              <p className="text-yellow-700 dark:text-yellow-300 font-medium">No courses available</p>
              <p className="text-yellow-600 dark:text-yellow-400 text-sm mt-1">
                Check back soon for new courses.
              </p>
            </div>
          </div>
        )}

        {isCoach && (
          <div className="mb-8 bg-gradient-to-br from-blue-50/80 to-blue-100/80 dark:from-blue-900/10 dark:to-blue-800/20 rounded-2xl p-6 border border-blue-100 dark:border-blue-800/30">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Created Courses</h2>
              <button 
                onClick={() => navigate('/create-course')}
                className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors"
              >
                <Plus size={16} className="mr-1" />
                Create
              </button>
            </div>
            {createdCoursesLoading ? (
              <div className="flex justify-center py-4">
                <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : createdCourses.length === 0 ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 text-center">
                <p className="text-gray-500 dark:text-gray-400 mb-4">You haven't created any courses yet</p>
                <button
                  onClick={() => navigate('/create-course')}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium flex items-center mx-auto"
                >
                  <Plus size={16} className="mr-1" />
                  Create your first course
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {createdCourses.map((course) => (
                  <div
                    key={course.id}
                    className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm cursor-pointer transform transition hover:scale-[1.02]"
                    onClick={() => navigate(`/course/${course.id}`)}
                  >
                    <div className="flex items-center">
                      <div className="w-20 h-20 bg-gray-200 dark:bg-gray-700 flex-shrink-0 rounded-lg overflow-hidden m-2">
                        <OptimizedImage
                          src={course.image_url}
                          alt={course.title}
                          className="w-full h-full object-cover"
                          placeholderClassName="w-full h-full"
                          width={80}
                          quality={70}
                        />
                      </div>
                      <div className="p-3 flex-1">
                        <div className="flex items-center">
                          {course.logo_url && (
                            <img 
                              src={course.logo_url} 
                              alt={`${course.title} logo`}
                              className="w-5 h-5 mr-2 rounded-md object-cover"
                            />
                          )}
                          <h4 className="font-medium text-gray-900 dark:text-white">{course.title}</h4>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-1 mt-1">{course.description}</p>
                        <div className="mt-1 flex items-center justify-between">
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            ${course.price}/mo
                          </span>
                          <span className="text-xs bg-blue-500 text-white px-2 py-0.5 rounded-full">
                            Coach
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {recentActivity.length > 0 && (
          <div className="mb-8 bg-gradient-to-br from-blue-50/50 to-blue-100/50 dark:from-blue-900/5 dark:to-blue-800/10 rounded-2xl p-6 border border-blue-100/80 dark:border-blue-800/20">
            <div className="flex items-center mb-4">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Jump Back In</h2>
            </div>
            <div className="space-y-4">
              {recentLoading ? (
                <div className="flex justify-center py-4">
                  <div className="w-8 h-8 border-2 border-blue-500 dark:border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : (
                recentActivity.map((activity) => (
                  <div
                    key={`${activity.courseId}-${activity.lessonId || 'course'}`}
                    className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden cursor-pointer"
                    onClick={() => navigate(activity.lessonId 
                      ? `/course/${activity.courseId}/lesson/${activity.lessonId}` 
                      : `/course/${activity.courseId}`
                    )}
                  >
                    <div className="flex items-center">
                      <div className="w-20 h-20 bg-gray-200 dark:bg-gray-700 flex-shrink-0 rounded-lg overflow-hidden m-2">
                        <OptimizedImage
                          src={activity.course.image_url}
                          alt={activity.course.title}
                          className="w-full h-full object-cover"
                          placeholderClassName="w-full h-full"
                          width={80}
                          quality={70}
                        />
                      </div>
                      <div className="p-3 flex-1">
                        <div className="flex items-center">
                          {activity.course.logo_url && (
                            <img 
                              src={activity.course.logo_url} 
                              alt={`${activity.course.title} logo`}
                              className="w-5 h-5 mr-2 rounded-md object-cover"
                            />
                          )}
                          <h4 className="font-medium text-gray-900 dark:text-white">{activity.course.title}</h4>
                        </div>
                        <div className="flex items-center justify-between mt-1">
                          <div className="flex items-center">
                            <span className="text-sm text-gray-600 dark:text-gray-400">
                              with {activity.course.instructor.full_name || activity.course.instructor.username}
                            </span>
                            {activity.course.instructor.is_verified && (
                              <VerifiedBadge className="ml-1.5 -mt-0.5" />
                            )}
                          </div>
                          <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                            <Clock size={12} className="mr-1" />
                            {formatTimeAgo(activity.timestamp)}
                          </div>
                        </div>
                        <div className="mt-1">
                          <span className="text-sm text-blue-500 dark:text-blue-400">
                            {activity.lessonId 
                              ? `Continue: ${activity.lessonTitle || 'lesson'}` 
                              : 'Continue course'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {enrolledCourses.length > 0 ? (
          <div className="mb-8 bg-gradient-to-br from-blue-50/30 to-blue-100/30 dark:from-blue-900/0 dark:to-blue-800/5 rounded-2xl p-6 border border-blue-100/60 dark:border-blue-800/10">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Subscribed</h2>
            <div className="space-y-4">
              {enrolledCourses.map((course) => (
                <div
                  key={course.id}
                  className="h-full rounded-[22.2px] border-[0.83px] border-solid border-[#e0e0e0] shadow-[0px_0px_24.97px_#00000014] overflow-hidden bg-white dark:bg-gray-800 dark:border-gray-700 cursor-pointer transform transition hover:scale-[1.02]"
                  onClick={() => navigate(`/course/${course.id}`)}
                >
                  <div className="w-full aspect-[16/7] relative bg-cover bg-center rounded-[22.2px] rounded-b-none overflow-hidden">
                    <OptimizedImage
                      src={course.image_url || 'https://images.unsplash.com/photo-1576858574144-9ae1ebcf5ae5?auto=format&fit=crop&q=80'}
                      alt={course.title}
                      className="w-full h-full object-cover"
                      placeholderClassName="w-full h-full"
                      width={400}
                      quality={85}
                    />
                  </div>
                  
                  <div className="p-4">
                    <div className="flex items-center mb-1">
                      <div className="flex items-center">
                        {course.logo_url ? (
                          <div className="relative mr-2">
                            <img 
                              src={course.logo_url} 
                              alt={`${course.title} logo`}
                              className="w-10 h-10 rounded-md object-cover flex-shrink-0"
                            />
                            <UserAvatar 
                              username={course.instructor.username}
                              avatarUrl={course.instructor.avatar_url}
                              size="xs"
                              className="w-6 h-6 absolute -bottom-1 -right-1 border-2 border-white dark:border-gray-800 rounded-full"
                            />
                          </div>
                        ) : (
                          <UserAvatar 
                            username={course.instructor.username}
                            avatarUrl={course.instructor.avatar_url}
                            size="sm"
                            className="w-10 h-10 mr-2"
                          />
                        )}
                      </div>
                      <div className="ml-2">
                        <h3 className="font-['Gabarito'] text-[19.1px] text-[#16161a] dark:text-white font-medium">
                          {course.title}
                        </h3>
                        <span className="font-['Gabarito'] text-[#7e7e87] dark:text-gray-400 text-[14px]">
                          {course.instructor.full_name || course.instructor.username}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-500 dark:text-gray-400 mb-4">You haven't joined any courses yet</p>
            <button
              onClick={() => navigate('/discover')}
              className="text-blue-500 dark:text-blue-400 font-medium hover:text-blue-600 dark:hover:text-blue-300"
            >
              Browse courses →
            </button>
          </div>
        )}

        <div className="mt-6">
          <button
            onClick={() => navigate('/discover')}
            className="w-full py-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors flex items-center justify-center group"
          >
            <span className="text-gray-700 dark:text-gray-300 font-medium mr-2 group-hover:text-blue-500 dark:group-hover:text-blue-400 transition-colors">
              Find more courses
            </span>
            <ArrowRight size={20} className="text-gray-500 dark:text-gray-400 group-hover:text-blue-500 dark:group-hover:text-blue-400 transition-colors" />
          </button>
        </div>
      </div>
    </div>
  );
}