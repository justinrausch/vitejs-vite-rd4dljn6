import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Plus, Image as ImageIcon, X, Check, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { CHAR_LIMITS } from '../lib/constants';
import { ImageUploader } from '../components/ImageUploader';
import { MediaUploader } from '../components/course/MediaUploader';

interface CourseFormData {
  title: string;
  tagline: string;
  description: string;
  image_url: string | null;
  logo_url: string | null;
  sport: string;
  disciplines: string[];
}

interface CourseMedia {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail_url?: string;
  position: number;
}

interface PricingOption {
  id?: string;
  title: string;
  price: number;
  renewal_period: 'monthly' | 'yearly' | null;
  features: string[];
  lessons_access: boolean;
  community_access: boolean;
  coaching_access: boolean;
  rankings_access: boolean;
}

const initialFormData: CourseFormData = {
  title: '',
  tagline: '',
  description: '',
  image_url: null,
  logo_url: null,
  sport: 'Mountain biking',
  disciplines: []
};

const availableDisciplines = [
  'Slopestyle',
  'Freeride',
  'Downhill',
  'Enduro',
  'Cross country',
  'Trail riding',
  'Dirt jumping',
  'Bike park',
  'Technical'
];

export function CreateCourse() {
  const navigate = useNavigate();
  const { user, userProfile } = useAuth();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<CourseFormData>(initialFormData);
  const [courseMedia, setCourseMedia] = useState<CourseMedia[]>([]);
  const [pricingOptions, setPricingOptions] = useState<PricingOption[]>([
    {
      title: 'Monthly Plan',
      price: 49.99,
      renewal_period: 'monthly',
      features: ['Full course access', 'Community access'],
      lessons_access: true,
      community_access: true,
      coaching_access: true,
      rankings_access: true
    }
  ]);
  const [selectedPricingIndex, setSelectedPricingIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [newFeature, setNewFeature] = useState('');

  // Check if user is a coach
  const isCoach = userProfile?.is_coach || false;

  // If user is not a coach, redirect to home
  React.useEffect(() => {
    if (user && !isCoach) {
      navigate('/');
    }
  }, [user, isCoach, navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    // Check character limits
    const limits: { [key: string]: number } = {
      title: CHAR_LIMITS.COURSE_TITLE,
      tagline: CHAR_LIMITS.COURSE_TAGLINE,
      description: CHAR_LIMITS.COURSE_DESCRIPTION
    };

    if (name in limits && value.length > limits[name]) {
      return;
    }

    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleNextStep = () => {
    if (step < 7) {
      setStep(step + 1);
    } else {
      // Save form data to session storage
      const dataToSave = {
        ...formData,
        courseMedia: courseMedia,
        pricingOptions: pricingOptions,
        selectedPricingIndex: selectedPricingIndex
      };
      sessionStorage.setItem('newCourseData', JSON.stringify(dataToSave));
      
      // Navigate to course editor
      navigate('/course/edit/new');
    }
  };

  const handlePrevStep = () => {
    if (step === 1) {
      navigate('/profile');
    } else {
      setStep(step - 1);
    }
  };

  const toggleDiscipline = (discipline: string) => {
    setFormData(prev => {
      const disciplines = prev.disciplines.includes(discipline)
        ? prev.disciplines.filter(d => d !== discipline)
        : [...prev.disciplines, discipline];
      return { ...prev, disciplines };
    });
  };

  const handleLogoUpload = (url: string) => {
    setFormData(prev => ({
      ...prev,
      logo_url: url
    }));
  };

  const handleImageUpload = (url: string) => {
    setFormData(prev => ({
      ...prev,
      image_url: url
    }));
    
    // Also add this as the first media item
    if (courseMedia.length === 0) {
      setCourseMedia([{
        id: `main-${Date.now()}`,
        type: 'image',
        url: url,
        position: 0
      }]);
    } else {
      // Replace the first item
      setCourseMedia(prev => [
        {
          ...prev[0],
          url: url
        },
        ...prev.slice(1)
      ]);
    }
  };

  const handleMediaChange = (media: CourseMedia[]) => {
    setCourseMedia(media);
    
    // Update the main image if there's at least one media item
    if (media.length > 0 && media[0].type === 'image') {
      setFormData(prev => ({
        ...prev,
        image_url: media[0].url
      }));
    }
  };

  const handleAddPricingOption = () => {
    setPricingOptions([
      ...pricingOptions,
      {
        title: 'New Plan',
        price: 49.99,
        renewal_period: 'monthly',
        features: ['Full course access', 'Community access'],
        lessons_access: true,
        community_access: true,
        coaching_access: true,
        rankings_access: true
      }
    ]);
  };

  const handleUpdatePricingOption = (index: number, field: string, value: any) => {
    const updatedOptions = [...pricingOptions];
    updatedOptions[index] = {
      ...updatedOptions[index],
      [field]: value
    };
    setPricingOptions(updatedOptions);
  };

  const handleRemovePricingOption = (index: number) => {
    if (pricingOptions.length <= 1) {
      return; // Keep at least one pricing option
    }
    
    const newOptions = pricingOptions.filter((_, i) => i !== index);
    setPricingOptions(newOptions);
    
    // Update selected index if needed
    if (selectedPricingIndex >= newOptions.length) {
      setSelectedPricingIndex(newOptions.length - 1);
    }
  };

  const handleAddFeature = (index: number) => {
    if (!newFeature.trim()) return;
    
    const updatedOptions = [...pricingOptions];
    updatedOptions[index] = {
      ...updatedOptions[index],
      features: [...updatedOptions[index].features, newFeature.trim()]
    };
    
    setPricingOptions(updatedOptions);
    setNewFeature('');
  };

  const handleRemoveFeature = (optionIndex: number, featureIndex: number) => {
    const updatedOptions = [...pricingOptions];
    const updatedFeatures = [...updatedOptions[optionIndex].features];
    updatedFeatures.splice(featureIndex, 1);
    
    updatedOptions[optionIndex] = {
      ...updatedOptions[optionIndex],
      features: updatedFeatures
    };
    
    setPricingOptions(updatedOptions);
  };

  const validateStep = () => {
    switch (step) {
      case 1:
        return formData.title.trim() !== '' && formData.title.length <= CHAR_LIMITS.COURSE_TITLE;
      case 2:
        return formData.tagline.trim() !== '' && formData.tagline.length <= CHAR_LIMITS.COURSE_TAGLINE;
      case 3:
        return formData.description.trim() !== '' && formData.description.length <= CHAR_LIMITS.COURSE_DESCRIPTION;
      case 4:
        return formData.sport !== '';
      case 5:
        return formData.disciplines.length > 0;
      case 6:
        return formData.image_url !== null;
      case 7:
        return pricingOptions.length > 0;
      default:
        return true;
    }
  };

  const renderProgressBar = () => {
    const progress = ((step - 1) / 6) * 100;
    return (
      <div className="w-full h-1 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
        <div 
          className="h-full bg-blue-500 transition-all duration-300 ease-in-out"
          style={{ width: `${progress}%` }}
        />
      </div>
    );
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <div className="text-center">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Let's start get started!
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Start off by giving your course a name
            </p>
            <div>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                placeholder="Beginner mountain biking"
                className="form-input text-center text-lg"
                autoFocus
                maxLength={CHAR_LIMITS.COURSE_TITLE}
              />
              <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                {formData.title.length}/{CHAR_LIMITS.COURSE_TITLE} characters
              </p>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="text-center">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Your tagline
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              A short phrase explaining what you help people do
            </p>
            <div>
              <input
                type="text"
                name="tagline"
                value={formData.tagline}
                onChange={handleInputChange}
                placeholder="Become a faster mountain..."
                className="form-input text-center text-lg"
                autoFocus
                maxLength={CHAR_LIMITS.COURSE_TAGLINE}
              />
              <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                {formData.tagline.length}/{CHAR_LIMITS.COURSE_TAGLINE} characters
              </p>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="text-center">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Course Description
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Describe what students will learn in your course
            </p>
            <div>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                placeholder="In this course, you'll learn..."
                className="form-input text-center"
                rows={4}
                autoFocus
                maxLength={CHAR_LIMITS.COURSE_DESCRIPTION}
              />
              <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                {formData.description.length}/{CHAR_LIMITS.COURSE_DESCRIPTION} characters
              </p>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              What sport is this course about?
            </h2>
            <div className="mt-6 space-y-4">
              <button
                onClick={() => setFormData(prev => ({ ...prev, sport: 'Mountain biking' }))}
                className={`w-full p-4 rounded-xl border-2 transition-colors ${
                  formData.sport === 'Mountain biking'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-200 dark:border-gray-700'
                }`}
              >
                <span className="font-medium text-gray-900 dark:text-white">Mountain biking</span>
              </button>
              <button
                onClick={() => setFormData(prev => ({ ...prev, sport: 'BMX' }))}
                className={`w-full p-4 rounded-xl border-2 transition-colors ${
                  formData.sport === 'BMX'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-200 dark:border-gray-700'
                }`}
              >
                <span className="font-medium text-gray-900 dark:text-white">BMX</span>
              </button>
              <button
                onClick={() => setFormData(prev => ({ ...prev, sport: 'Skateboarding' }))}
                className={`w-full p-4 rounded-xl border-2 transition-colors ${
                  formData.sport === 'Skateboarding'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-200 dark:border-gray-700'
                }`}
              >
                <span className="font-medium text-gray-900 dark:text-white">Skateboarding</span>
              </button>
              <button
                onClick={() => setFormData(prev => ({ ...prev, sport: 'Surfing' }))}
                className={`w-full p-4 rounded-xl border-2 transition-colors ${
                  formData.sport === 'Surfing'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-200 dark:border-gray-700'
                }`}
              >
                <span className="font-medium text-gray-900 dark:text-white">Surfing</span>
              </button>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="text-center">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              What disciplines does this cover?
            </h2>
            <div className="mt-6 flex flex-wrap gap-2">
              {availableDisciplines.map(discipline => (
                <button
                  key={discipline}
                  onClick={() => toggleDiscipline(discipline)}
                  className={`px-4 py-2 rounded-full border transition-colors ${
                    formData.disciplines.includes(discipline)
                      ? 'bg-blue-500 border-blue-500 text-white'
                      : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  {discipline}
                  {formData.disciplines.includes(discipline) && (
                    <span className="ml-2">✓</span>
                  )}
                </button>
              ))}
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">
              Can select more than one
            </p>
          </div>
        );

      case 6:
        return (
          <div className="text-center">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Add a main course image
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              This will be the first image people see
            </p>
            <div className="flex flex-col items-center">
              <div className="w-full aspect-video rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center mb-4 overflow-hidden">
                {formData.image_url ? (
                  <img
                    src={formData.image_url}
                    alt="Course Cover"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <ImageIcon size={48} className="text-gray-400 dark:text-gray-500" />
                )}
              </div>
              <div className="flex justify-center">
                <ImageUploader
                  id="main-course-image"
                  onUploadComplete={handleImageUpload}
                  buttonText={formData.image_url ? "Change Image" : "Upload Image"}
                  folder="course-covers"
                />
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">
                Recommended size: 1280x720 pixels (16:9 ratio)
              </p>
              
              <div className="mt-8">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                  Add additional media (optional)
                </h3>
                <MediaUploader 
                  courseId={user?.id || 'temp'}
                  initialMedia={courseMedia}
                  onMediaChange={handleMediaChange}
                  maxItems={6}
                />
              </div>
              
              <div className="mt-8 flex flex-col items-center">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                  Course Logo (optional)
                </h3>
                <div className="w-20 h-20 rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center mb-4 overflow-hidden">
                  {formData.logo_url ? (
                    <img
                      src={formData.logo_url}
                      alt="Course Logo"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <ImageIcon size={32} className="text-gray-400 dark:text-gray-500" />
                  )}
                </div>
                <div className="flex justify-center">
                  <ImageUploader
                    id="course-logo"
                    onUploadComplete={handleLogoUpload}
                    buttonText={formData.logo_url ? "Change Logo" : "Add Logo"}
                    folder="course-logos"
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 7:
        return (
          <div className="text-center">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Pricing Options
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Set up pricing plans for your course
            </p>
            
            <div className="space-y-6">
              {pricingOptions.map((option, index) => (
                <div 
                  key={index} 
                  className={`bg-white dark:bg-gray-800 rounded-lg border-2 p-4 ${
                    selectedPricingIndex === index 
                      ? 'border-blue-500 shadow-md' 
                      : 'border-gray-200 dark:border-gray-700'
                  }`}
                >
                  <div className="flex justify-between items-center mb-3">
                    <input
                      type="text"
                      value={option.title}
                      onChange={(e) => handleUpdatePricingOption(index, 'title', e.target.value)}
                      className="font-medium text-lg bg-transparent border-none focus:ring-0 text-gray-900 dark:text-white"
                      placeholder="Plan Title"
                    />
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedPricingIndex(index)}
                        className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                          selectedPricingIndex === index 
                            ? 'border-blue-500 bg-blue-500' 
                            : 'border-gray-300 dark:border-gray-600'
                        }`}
                      >
                        {selectedPricingIndex === index && (
                          <div className="w-2 h-2 rounded-full bg-white" />
                        )}
                      </button>
                      {pricingOptions.length > 1 && (
                        <button
                          onClick={() => handleRemovePricingOption(index)}
                          className="text-red-500 hover:text-red-600"
                        >
                          <X size={18} />
                        </button>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-end gap-3 mb-3">
                    <div>
                      <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                        Price ($)
                      </label>
                      <input
                        type="number"
                        value={option.price}
                        onChange={(e) => handleUpdatePricingOption(index, 'price', parseFloat(e.target.value) || 0)}
                        min="0"
                        step="0.01"
                        className="w-24 px-2 py-1 bg-gray-50 dark:bg-gray-700 rounded border-none focus:ring-1 focus:ring-blue-500 dark:text-white"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">
                        Period
                      </label>
                      <select
                        value={option.renewal_period || ''}
                        onChange={(e) => handleUpdatePricingOption(
                          index, 
                          'renewal_period', 
                          e.target.value === '' ? null : e.target.value
                        )}
                        className="px-2 py-1 bg-gray-50 dark:bg-gray-700 rounded border-none focus:ring-1 focus:ring-blue-500 dark:text-white"
                      >
                        <option value="monthly">Monthly</option>
                        <option value="yearly">Yearly</option>
                        <option value="">One-time</option>
                      </select>
                    </div>
                    
                    {selectedPricingIndex === index && (
                      <div className="ml-auto text-sm text-blue-500 dark:text-blue-400 font-medium">
                        Default plan
                      </div>
                    )}
                  </div>

                  {/* Access Features */}
                  <div className="mb-3">
                    <label className="block text-sm text-gray-500 dark:text-gray-400 mb-2">
                      Course Access
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={option.lessons_access}
                          onChange={(e) => handleUpdatePricingOption(index, 'lessons_access', e.target.checked)}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                        />
                        <span className="text-sm text-gray-700 dark:text-gray-300">Skills</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={option.community_access}
                          onChange={(e) => handleUpdatePricingOption(index, 'community_access', e.target.checked)}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                        />
                        <span className="text-sm text-gray-700 dark:text-gray-300">Community</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={option.coaching_access}
                          onChange={(e) => handleUpdatePricingOption(index, 'coaching_access', e.target.checked)}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                        />
                        <span className="text-sm text-gray-700 dark:text-gray-300">Coaching</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={option.rankings_access}
                          onChange={(e) => handleUpdatePricingOption(index, 'rankings_access', e.target.checked)}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                        />
                        <span className="text-sm text-gray-700 dark:text-gray-300">Rankings</span>
                      </label>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm text-gray-500 dark:text-gray-400 mb-2">
                      Display Features
                    </label>
                    <div className="space-y-2 mb-3">
                      {option.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center">
                          <input
                            type="text"
                            value={feature}
                            onChange={(e) => {
                              const updatedFeatures = [...option.features];
                              updatedFeatures[featureIndex] = e.target.value;
                              handleUpdatePricingOption(index, 'features', updatedFeatures);
                            }}
                            className="flex-1 px-3 py-2 bg-gray-50 dark:bg-gray-700 rounded border-none focus:ring-1 focus:ring-blue-500 dark:text-white"
                          />
                          <button
                            onClick={() => handleRemoveFeature(index, featureIndex)}
                            className="ml-2 p-2 text-red-500 hover:text-red-600"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex items-center mt-2">
                      <input
                        type="text"
                        value={newFeature}
                        onChange={(e) => setNewFeature(e.target.value)}
                        placeholder="Add a new feature..."
                        className="flex-1 px-3 py-2 bg-gray-50 dark:bg-gray-700 rounded-l border-none focus:ring-1 focus:ring-blue-500 dark:text-white"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && newFeature.trim()) {
                            e.preventDefault();
                            handleAddFeature(index);
                          }
                        }}
                      />
                      <button
                        onClick={() => handleAddFeature(index)}
                        disabled={!newFeature.trim()}
                        className="px-3 py-2 bg-blue-500 text-white rounded-r disabled:opacity-50"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
              
              <button
                onClick={handleAddPricingOption}
                className="w-full py-3 bg-gray-50 dark:bg-gray-700 text-blue-500 dark:text-blue-400 rounded-lg flex items-center justify-center font-medium hover:bg-gray-100 dark:hover:bg-gray-650"
              >
                <Plus size={18} className="mr-2" />
                Add Another Plan
              </button>
            </div>
            
            <div className="mt-8">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Course Preview
              </h3>
              
              <div className="h-full rounded-[22.2px] border-[0.83px] border-solid border-[#e0e0e0] shadow-[0px_0px_24.97px_#00000014] overflow-hidden bg-white dark:bg-gray-800 dark:border-gray-700">
                <div className="w-full aspect-[16/7] relative bg-cover bg-center rounded-[22.2px] rounded-b-none overflow-hidden">
                  <img
                    src={formData.image_url || 'https://images.unsplash.com/photo-1576858574144-9ae1ebcf5ae5?auto=format&fit=crop&q=80'}
                    alt={formData.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-[17px] right-4">
                    <div className="h-[31px] px-3 rounded-[11.1px] shadow-[0px_0px_10.54px_#00000040] bg-gradient-to-r from-[rgba(28,163,252,1)] to-[rgba(28,110,252,1)] flex items-center justify-center">
                      <span className="font-['Gabarito'] text-white text-[15.8px] whitespace-nowrap">
                        ${pricingOptions[selectedPricingIndex].price}/{pricingOptions[selectedPricingIndex].renewal_period === 'monthly' ? 'mo' : pricingOptions[selectedPricingIndex].renewal_period === 'yearly' ? 'yr' : 'one-time'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-white dark:bg-gray-800">
                  <div className="flex items-center flex-wrap gap-2">
                    {formData.logo_url && (
                      <img 
                        src={formData.logo_url} 
                        alt={`${formData.title} logo`}
                        className="w-7 h-7 rounded-md object-cover flex-shrink-0"
                      />
                    )}

                    <h3 className="font-['Gabarito'] text-[19.1px] text-[#16161a] dark:text-white font-medium flex-grow min-w-[150px]">
                      {formData.title || 'Course Title'}
                    </h3>
                  </div>
                </div>

                <div className="mt-1 border-t border-[#e0e0e0] dark:border-gray-700 bg-white dark:bg-gray-800">
                  <div className="p-3 flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center flex-shrink-0">
                      <div className="w-7 h-7 bg-blue-500 rounded-full flex items-center justify-center text-white">
                        {userProfile?.username?.[0]?.toUpperCase() || 'U'}
                      </div>
                      <span className="font-['Gabarito'] text-[#7e7e87] dark:text-gray-400 text-[14.8px] ml-2">
                        {userProfile?.username || 'username'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-lg mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <button 
            onClick={handlePrevStep} 
            className="text-gray-600 dark:text-gray-400 mr-4"
          >
            <ChevronLeft size={24} />
          </button>
          {renderProgressBar()}
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg">
            {error}
          </div>
        )}

        <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-sm">
          {renderStepContent()}
        </div>

        <div className="mt-8 pb-24">
          <button
            onClick={handleNextStep}
            disabled={loading || !validateStep()}
            className="w-full py-3 bg-blue-500 text-white rounded-xl font-medium disabled:opacity-50"
          >
            {loading ? 'Creating...' : step === 7 ? 'Continue to Editor' : 'Next'}
          </button>
        </div>
      </div>
    </div>
  );
}