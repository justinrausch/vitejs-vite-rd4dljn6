import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { MountainLogo } from '../../components/MountainLogo';

export function PrivacyPolicy() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <button 
            onClick={() => navigate(-1)} 
            className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100"
          >
            <ChevronLeft size={20} className="mr-1" />
            <span>Back</span>
          </button>
          <div className="flex items-center">
            <MountainLogo className="w-8 h-8 mr-2" />
            <span className="text-xl font-bold text-gray-900 dark:text-white">Mastery</span>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Privacy Policy</h1>
          
          <div className="prose dark:prose-invert prose-sm sm:prose max-w-none">
            <p>Last updated: June 10, 2025</p>
            
            <h2>1. Introduction</h2>
            <p>
              At Mastery, we respect your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our website, mobile application, and services (collectively, the "Services").
            </p>
            <p>
              Please read this Privacy Policy carefully. If you do not agree with the terms of this Privacy Policy, please do not access the Services.
            </p>
            
            <h2>2. Information We Collect</h2>
            <p>
              We collect information that you provide directly to us, information we obtain automatically when you use our Services, and information from third-party sources.
            </p>
            
            <h3>2.1 Information You Provide</h3>
            <p>
              We may collect the following types of information when you register, use our Services, or communicate with us:
            </p>
            <ul>
              <li>Account information (name, email address, username, password)</li>
              <li>Profile information (profile picture, bio, location)</li>
              <li>Content you create, share, or post</li>
              <li>Communications with us or other users</li>
              <li>Payment information (processed by our payment providers)</li>
              <li>Survey responses and feedback</li>
            </ul>
            
            <h3>2.2 Information We Collect Automatically</h3>
            <p>
              When you use our Services, we may automatically collect:
            </p>
            <ul>
              <li>Device information (IP address, browser type, operating system)</li>
              <li>Usage data (pages visited, time spent, links clicked)</li>
              <li>Location information (with your permission)</li>
              <li>Cookies and similar tracking technologies</li>
            </ul>
            
            <h2>3. How We Use Your Information</h2>
            <p>
              We use the information we collect to:
            </p>
            <ul>
              <li>Provide, maintain, and improve our Services</li>
              <li>Process transactions and manage your account</li>
              <li>Send you technical notices, updates, and support messages</li>
              <li>Respond to your comments and questions</li>
              <li>Personalize your experience</li>
              <li>Monitor and analyze trends, usage, and activities</li>
              <li>Detect, prevent, and address technical issues</li>
              <li>Comply with legal obligations</li>
            </ul>
            
            <h2>4. Sharing Your Information</h2>
            <p>
              We may share your information with:
            </p>
            <ul>
              <li>Service providers who perform services on our behalf</li>
              <li>Partners with whom we offer co-branded services or promotions</li>
              <li>Other users, when you share content or interact with them</li>
              <li>In response to legal process or to comply with law</li>
              <li>To protect the rights, property, and safety of our users and the public</li>
              <li>In connection with a business transfer (merger, acquisition, etc.)</li>
            </ul>
            
            <h2>5. Your Choices</h2>
            <p>
              You have several choices regarding the use of your information:
            </p>
            <ul>
              <li>Account Information: You can update your account information through your account settings</li>
              <li>Marketing Communications: You can opt out of marketing emails</li>
              <li>Cookies: You can manage cookie preferences through your browser settings</li>
              <li>Data Access and Portability: You can request a copy of your data</li>
              <li>Deletion: You can request deletion of your account and data</li>
            </ul>
            
            <h2>6. Data Security</h2>
            <p>
              We implement appropriate technical and organizational measures to protect your personal information. However, no method of transmission over the Internet or electronic storage is 100% secure, so we cannot guarantee absolute security.
            </p>
            
            <h2>7. Children's Privacy</h2>
            <p>
              Our Services are not intended for children under 13 years of age. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us.
            </p>
            
            <h2>8. International Data Transfers</h2>
            <p>
              Your information may be transferred to, and processed in, countries other than the country in which you reside. These countries may have data protection laws that are different from the laws of your country.
            </p>
            
            <h2>9. Changes to This Privacy Policy</h2>
            <p>
              We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date.
            </p>
            
            <h2>10. Contact Us</h2>
            <p>
              If you have any questions about this Privacy Policy, please contact us at privacy@mastery.to.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}