import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { MountainLogo } from '../../components/MountainLogo';

export function TermsAndConditions() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <button 
            onClick={() => navigate(-1)} 
            className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100"
          >
            <ChevronLeft size={20} className="mr-1" />
            <span>Back</span>
          </button>
          <div className="flex items-center">
            <MountainLogo className="w-8 h-8 mr-2" />
            <span className="text-xl font-bold text-gray-900 dark:text-white">Mastery</span>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Terms and Conditions</h1>
          
          <div className="prose dark:prose-invert prose-sm sm:prose max-w-none">
            <p>Last updated: June 10, 2025</p>
            
            <h2>1. Introduction</h2>
            <p>
              Welcome to Mastery ("we," "our," or "us"). These Terms and Conditions govern your use of our website, mobile application, and services (collectively, the "Services").
            </p>
            <p>
              By accessing or using our Services, you agree to be bound by these Terms. If you disagree with any part of the terms, you may not access the Services.
            </p>
            
            <h2>2. Accounts</h2>
            <p>
              When you create an account with us, you must provide accurate, complete, and current information. You are responsible for safeguarding the password and for all activities that occur under your account.
            </p>
            <p>
              You agree not to disclose your password to any third party. You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account.
            </p>
            
            <h2>3. Content</h2>
            <p>
              Our Services allow you to post, link, store, share and otherwise make available certain information, text, graphics, videos, or other material ("Content"). You are responsible for the Content that you post, including its legality, reliability, and appropriateness.
            </p>
            <p>
              By posting Content, you grant us the right to use, modify, publicly perform, publicly display, reproduce, and distribute such Content on and through our Services. You retain any and all of your rights to any Content you submit, post, or display on or through the Services and you are responsible for protecting those rights.
            </p>
            
            <h2>4. Subscriptions and Payments</h2>
            <p>
              Some parts of the Services are billed on a subscription basis. You will be billed in advance on a recurring and periodic basis, depending on the type of subscription plan you select.
            </p>
            <p>
              At the end of each period, your subscription will automatically renew under the same conditions unless you cancel it or we cancel it. You may cancel your subscription at any time through your account settings.
            </p>
            
            <h2>5. Refunds</h2>
            <p>
              Certain refund requests for subscriptions may be considered on a case-by-case basis and granted at our sole discretion. We are not obligated to provide a refund for any subscription.
            </p>
            
            <h2>6. Intellectual Property</h2>
            <p>
              The Services and their original content (excluding Content provided by users), features, and functionality are and will remain the exclusive property of Mastery and its licensors. The Services are protected by copyright, trademark, and other laws of both the United States and foreign countries.
            </p>
            <p>
              Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of Mastery.
            </p>
            
            <h2>7. Termination</h2>
            <p>
              We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.
            </p>
            <p>
              Upon termination, your right to use the Services will immediately cease. If you wish to terminate your account, you may simply discontinue using the Services or delete your account.
            </p>
            
            <h2>8. Limitation of Liability</h2>
            <p>
              In no event shall Mastery, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Services.
            </p>
            
            <h2>9. Changes</h2>
            <p>
              We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material, we will try to provide at least 30 days' notice prior to any new terms taking effect.
            </p>
            <p>
              By continuing to access or use our Services after those revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, please stop using the Services.
            </p>
            
            <h2>10. Contact Us</h2>
            <p>
              If you have any questions about these Terms, please contact us at support@mastery.to.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}