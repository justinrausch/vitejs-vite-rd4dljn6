import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { MountainLogo } from '../../components/MountainLogo';
import { supabase } from '../../lib/supabase';
import { formatUsername, isValidUsername } from '../../lib/utils/validation';

export function Register() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    email: '',
    fullName: '',
    username: '',
    password: '',
    confirmPassword: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState<string | null>(null);
  const [usernameError, setUsernameError] = useState<string | null>(null);
  const [checkingUsername, setCheckingUsername] = useState(false);
  const navigate = useNavigate();
  const { signUp } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (currentStep < 3) {
      if (currentStep === 2) {
        // Validate username before proceeding
        if (!await validateUsername()) {
          return;
        }
      }
      setCurrentStep(currentStep + 1);
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    try {
      setError('');
      setLoading(true);
      await signUp(formData.email, formData.password, formData.fullName, formData.username);
      navigate('/');
    } catch (err: any) {
      console.error('Sign up error:', err);
      setError(err.message || 'Failed to create an account');
    } finally {
      setLoading(false);
    }
  };

  const validateUsername = async (): Promise<boolean> => {
    if (!formData.username) {
      setUsernameError('Username is required');
      return false;
    }
    
    if (!isValidUsername(formData.username)) {
      setUsernameError('Username can only contain lowercase letters, numbers, and underscores');
      return false;
    }
    
    try {
      setCheckingUsername(true);
      
      // Check if username already exists
      const { data, error } = await supabase
        .from('profiles')
        .select('username')
        .eq('username', formData.username)
        .maybeSingle();
      
      if (error) throw error;
      
      if (data) {
        setUsernameError('Username is already taken');
        return false;
      }
      
      setUsernameError(null);
      return true;
    } catch (err) {
      console.error('Error checking username:', err);
      setUsernameError('Error checking username availability');
      return false;
    } finally {
      setCheckingUsername(false);
    }
  };

  const handleGoogleSignUp = async () => {
    try {
      setError('');
      setSocialLoading('google');
      
      // Get the current site URL for the redirect
      const redirectTo = window.location.origin;
      
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo
        }
      });
      
      if (error) throw error;
      
      // No need to navigate - the OAuth flow will handle redirection
    } catch (err: any) {
      console.error('Google sign up error:', err);
      setError(err.message || 'Failed to sign up with Google');
      setSocialLoading(null);
    }
  };

  const handleAppleSignUp = async () => {
    try {
      setError('');
      setSocialLoading('apple');
      
      // Get the current site URL for the redirect
      const redirectTo = window.location.origin;
      
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'apple',
        options: {
          redirectTo
        }
      });
      
      if (error) throw error;
      
      // No need to navigate - the OAuth flow will handle redirection
    } catch (err: any) {
      console.error('Apple sign up error:', err);
      setError(err.message || 'Failed to sign up with Apple');
      setSocialLoading(null);
    }
  };

  const handleUsernameChange = async (value: string) => {
    const formatted = formatUsername(value);
    setFormData(prev => ({ ...prev, username: formatted }));
    
    if (formatted.length > 0) {
      if (!isValidUsername(formatted)) {
        setUsernameError('Username can only contain lowercase letters, numbers, and underscores');
      } else {
        setUsernameError(null);
      }
    } else {
      setUsernameError(null);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <div>
              <input
                id="email"
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="Your email"
                className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:text-white text-sm"
              />
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-4">
            <div>
              <input
                id="fullName"
                type="text"
                required
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                placeholder="Full Name"
                className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:text-white text-sm"
              />
            </div>
            <div>
              <input
                id="username"
                type="text"
                required
                value={formData.username}
                onChange={(e) => handleUsernameChange(e.target.value)}
                placeholder="Username"
                className={`w-full px-4 py-3 rounded-lg border ${
                  usernameError ? 'border-red-500 focus:ring-red-500' : 'border-gray-200 dark:border-gray-700 focus:ring-blue-500'
                } focus:outline-none focus:ring-2 dark:bg-gray-800 dark:text-white text-sm`}
              />
              {usernameError && (
                <p className="mt-1 text-sm text-red-500">{usernameError}</p>
              )}
              {checkingUsername && (
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Checking username availability...</p>
              )}
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-4">
            <div>
              <input
                id="password"
                type="password"
                required
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="Password"
                className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:text-white text-sm"
              />
            </div>
            <div>
              <input
                id="confirmPassword"
                type="password"
                required
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                placeholder="Confirm Password"
                className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:text-white text-sm"
              />
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  const renderStepIndicator = () => {
    return (
      <div className="flex justify-center space-x-2 mb-4">
        {[1, 2, 3].map((step) => (
          <div 
            key={step}
            className={`w-2 h-2 rounded-full ${
              step === currentStep 
                ? 'bg-blue-500' 
                : step < currentStep 
                  ? 'bg-blue-300' 
                  : 'bg-gray-300 dark:bg-gray-600'
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="auth-page">
      <div className="auth-container bg-white dark:bg-gray-800 rounded-3xl shadow-xl p-6 w-full max-w-sm">
        <div className="text-center mb-4">
          <div className="inline-flex items-center justify-center mb-3">
            <MountainLogo className="w-14 h-14" />
          </div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">
            {currentStep === 1 ? 'Create an account' : currentStep === 2 ? 'Tell us about you' : 'Set your password'}
          </h1>
        </div>

        {renderStepIndicator()}

        {error && (
          <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg text-sm">
            {error}
          </div>
        )}

        <form className="space-y-4" onSubmit={handleSubmit}>
          {renderStep()}
          
          <button
            type="submit"
            disabled={loading || (currentStep === 2 && !!usernameError)}
            className="w-full py-3 px-4 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition-colors disabled:opacity-50 text-sm"
          >
            {currentStep < 3 ? 'Continue' : loading ? 'Creating account...' : 'Create account'}
          </button>
          
          {currentStep === 1 && (
            <>
              <div className="relative flex items-center justify-center my-4">
                <div className="border-t border-gray-200 dark:border-gray-700 w-full"></div>
                <span className="bg-white dark:bg-gray-800 px-3 text-xs text-gray-500 dark:text-gray-400">or</span>
                <div className="border-t border-gray-200 dark:border-gray-700 w-full"></div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={handleGoogleSignUp}
                  disabled={!!socialLoading}
                  className="flex items-center justify-center py-2 px-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50"
                >
                  {socialLoading === 'google' ? (
                    <div className="w-4 h-4 border-2 border-gray-500 dark:border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <svg viewBox="0 0 24 24" width="18" height="18" xmlns="http://www.w3.org/2000/svg">
                      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                  )}
                </button>
                <button
                  type="button"
                  onClick={handleAppleSignUp}
                  disabled={!!socialLoading}
                  className="flex items-center justify-center py-2 px-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50"
                >
                  {socialLoading === 'apple' ? (
                    <div className="w-4 h-4 border-2 border-gray-500 dark:border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor" className="text-black dark:text-white">
                      <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.21 2.33-.91 3.57-.84 1.5.12 2.63.64 3.4 1.8-3.13 1.88-2.32 5.67.02 7.12-.68 1.95-1.57 3.92-3.07 5.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.26 2.32-2.07 4.35-3.74 4.25z"/>
                    </svg>
                  )}
                </button>
              </div>
              
              <p className="text-xs text-center text-gray-500 dark:text-gray-400 mt-4">
  By continuing, you agree to our <Link to="/terms" className="underline">Terms</Link> and <Link to="/privacy" className="underline">Privacy</Link>
</p>



            </>
          )}
          
          {currentStep > 1 && (
            <button
              type="button"
              onClick={() => setCurrentStep(currentStep - 1)}
              className="w-full text-center text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 text-sm"
            >
              Back
            </button>
          )}
        </form>
        
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Already have an account?{' '}
            <Link to="/login" className="text-blue-500 hover:text-blue-600 font-medium">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}