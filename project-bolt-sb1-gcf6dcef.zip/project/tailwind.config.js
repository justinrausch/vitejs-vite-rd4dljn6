/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        blue: {
          500: '#1C88FC',
          600: '#0A78EC', // Slightly darker for hover states
          400: '#3E9AFD', // Slightly lighter for dark mode
        },
      },
      backgroundImage: {
        'price-gradient': 'linear-gradient(135deg, #0061FF 0%, #60EFFF 100%)',
        'joined-gradient': 'linear-gradient(135deg, #00875A 0%, #00BA78 100%)',
      },
      keyframes: {
        shimmer: {
          '100%': { transform: 'translateX(100%)' }
        }
      },
      animation: {
        shimmer: 'shimmer 1.5s infinite'
      }
    },
  },
  plugins: [],
};