-- Drop existing policies for coach_messages
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "View messages for participants" ON coach_messages;
  DROP POLICY IF EXISTS "Allow message creation for participants" ON coach_messages;
  DROP POLICY IF EXISTS "Students and instructors can send messages" ON coach_messages;
  DROP POLICY IF EXISTS "Anyone can view messages they're involved with" ON coach_messages;
END $$;

-- Create new policies for coach_messages
CREATE POLICY "Coaches can view all messages for their courses"
  ON coach_messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = coach_messages.course_id
      AND courses.instructor_id = auth.uid()
    )
  );

CREATE POLICY "Students can view their own messages"
  ON coach_messages FOR SELECT
  USING (auth.uid() = student_id);

CREATE POLICY "Coaches can send messages to any student"
  ON coach_messages FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = coach_messages.course_id
      AND courses.instructor_id = auth.uid()
    )
  );

CREATE POLICY "Students can send messages to their coaches"
  ON coach_messages FOR INSERT
  WITH CHECK (
    auth.uid() = student_id AND
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE enrollments.user_id = auth.uid()
      AND enrollments.course_id = coach_messages.course_id
    )
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_coach_messages_student_course_time
  ON coach_messages(student_id, course_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_coach_messages_course_time
  ON coach_messages(course_id, created_at DESC);

-- Create function to mark messages as read
CREATE OR REPLACE FUNCTION mark_messages_read(
  p_course_id uuid,
  p_student_id uuid
) RETURNS void AS $$
BEGIN
  UPDATE coach_messages
  SET read = true
  WHERE course_id = p_course_id
    AND student_id = p_student_id
    AND sender_id = p_student_id
    AND read = false;
END;
$$ LANGUAGE plpgsql;

-- Add read column to coach_messages if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'coach_messages' AND column_name = 'read'
  ) THEN
    ALTER TABLE coach_messages ADD COLUMN read boolean DEFAULT false;
  END IF;
END $$;