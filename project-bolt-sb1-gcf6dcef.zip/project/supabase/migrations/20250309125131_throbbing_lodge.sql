/*
  # Update course lessons schema with proper constraints

  1. Changes
    - Make video_url column nullable
    - Add proper foreign key relationships
*/

-- Make video_url nullable since it's not required initially
ALTER TABLE course_lessons 
ALTER COLUMN video_url DROP NOT NULL;