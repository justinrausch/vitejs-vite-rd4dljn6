/*
  # Add feature toggles to course plans

  1. New Columns
    - Add boolean columns to course_plans table for feature access control:
      - `lessons_access` - Controls access to course lessons/skills
      - `community_access` - Controls access to community features
      - `coaching_access` - Controls access to coaching features
      - `rankings_access` - Controls access to rankings

  2. Default Values
    - All features are enabled by default for backward compatibility
*/

-- Add feature toggle columns to course_plans table
ALTER TABLE course_plans 
ADD COLUMN IF NOT EXISTS lessons_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS community_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS coaching_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS rankings_access BOOLEAN DEFAULT TRUE;