/*
  # Add reply system to chat messages

  1. Changes
    - Add parent_id column to chat_messages table to create message hierarchy
    - Add reply_count column to track number of replies
    - Add indexes for better query performance
    - Update RLS policies to handle replies

  2. Security
    - Maintain existing RLS policies
    - Ensure users can only reply in channels they have access to
*/

-- Add columns for reply system
ALTER TABLE chat_messages ADD COLUMN IF NOT EXISTS parent_id uuid REFERENCES chat_messages(id) ON DELETE CASCADE;
ALTER TABLE chat_messages ADD COLUMN IF NOT EXISTS reply_count integer DEFAULT 0;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_chat_messages_parent_id ON chat_messages(parent_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_reply_count ON chat_messages(reply_count);

-- Create function to update reply count
CREATE OR REPLACE FUNCTION update_message_reply_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NEW.parent_id IS NOT NULL THEN
    UPDATE chat_messages
    SET reply_count = reply_count + 1
    WHERE id = NEW.parent_id;
  ELSIF TG_OP = 'DELETE' AND OLD.parent_id IS NOT NULL THEN
    UPDATE chat_messages
    SET reply_count = reply_count - 1
    WHERE id = OLD.parent_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for reply count
DROP TRIGGER IF EXISTS chat_messages_reply_count_trigger ON chat_messages;
CREATE TRIGGER chat_messages_reply_count_trigger
AFTER INSERT OR DELETE ON chat_messages
FOR EACH ROW
EXECUTE FUNCTION update_message_reply_count();