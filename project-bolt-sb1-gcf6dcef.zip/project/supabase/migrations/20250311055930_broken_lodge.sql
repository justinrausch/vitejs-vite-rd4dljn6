/*
  # Update Course Rankings System

  1. Changes
    - Updates course_rankings table based on completed lessons
    - Calculates points based on completed lessons (100 points per lesson)
    - Updates level based on completed lessons (level up every 3 lessons)
    - Creates trigger to automatically update rankings when lessons are completed
    - Updates get_course_rankings function with proper return type

  2. Security
    - Updates RLS policies for course_rankings table
    - Ensures proper access control through policies
*/

-- Drop existing function first to avoid return type conflict
DROP FUNCTION IF EXISTS get_course_rankings(UUID);

-- First, update the rankings for all users based on their completed lessons
DO $$
BEGIN
  -- Insert or update rankings for all users who have completed lessons
  INSERT INTO course_rankings (course_id, user_id, points, completed_lessons_count, level, last_active)
  SELECT 
    cl.course_id,
    cl.user_id,
    COUNT(*) * 100 as points,
    COUNT(*) as completed_lessons_count,
    GREATEST(1, FLOOR(COUNT(*) / 3) + 1) as level,
    NOW() as last_active
  FROM completed_lessons cl
  GROUP BY cl.course_id, cl.user_id
  ON CONFLICT (course_id, user_id) 
  DO UPDATE SET
    points = EXCLUDED.points,
    completed_lessons_count = EXCLUDED.completed_lessons_count,
    level = EXCLUDED.level,
    last_active = EXCLUDED.last_active;

  -- Insert rankings for enrolled users who haven't completed any lessons yet
  INSERT INTO course_rankings (course_id, user_id, points, completed_lessons_count, level, last_active)
  SELECT 
    e.course_id,
    e.user_id,
    0 as points,
    0 as completed_lessons_count,
    1 as level,
    NOW() as last_active
  FROM enrollments e
  LEFT JOIN course_rankings cr ON cr.course_id = e.course_id AND cr.user_id = e.user_id
  WHERE cr.id IS NULL
  ON CONFLICT (course_id, user_id) DO NOTHING;
END $$;

-- Create or replace the function to update rankings when lessons are completed
CREATE OR REPLACE FUNCTION update_rankings_on_completion()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Insert or update the ranking
    INSERT INTO course_rankings (
      course_id,
      user_id,
      points,
      completed_lessons_count,
      level,
      last_active
    )
    SELECT
      NEW.course_id,
      NEW.user_id,
      COALESCE((
        SELECT COUNT(*) * 100
        FROM completed_lessons
        WHERE course_id = NEW.course_id AND user_id = NEW.user_id
      ), 100) as points,
      COALESCE((
        SELECT COUNT(*)
        FROM completed_lessons
        WHERE course_id = NEW.course_id AND user_id = NEW.user_id
      ), 1) as completed_lessons_count,
      GREATEST(1, FLOOR(COALESCE((
        SELECT COUNT(*)
        FROM completed_lessons
        WHERE course_id = NEW.course_id AND user_id = NEW.user_id
      ), 1) / 3) + 1) as level,
      NOW()
    ON CONFLICT (course_id, user_id)
    DO UPDATE SET
      points = EXCLUDED.points,
      completed_lessons_count = EXCLUDED.completed_lessons_count,
      level = EXCLUDED.level,
      last_active = EXCLUDED.last_active;
  ELSIF TG_OP = 'DELETE' THEN
    -- Update the ranking
    UPDATE course_rankings
    SET
      points = COALESCE((
        SELECT COUNT(*) * 100
        FROM completed_lessons
        WHERE course_id = OLD.course_id AND user_id = OLD.user_id
      ), 0),
      completed_lessons_count = COALESCE((
        SELECT COUNT(*)
        FROM completed_lessons
        WHERE course_id = OLD.course_id AND user_id = OLD.user_id
      ), 0),
      level = GREATEST(1, FLOOR(COALESCE((
        SELECT COUNT(*)
        FROM completed_lessons
        WHERE course_id = OLD.course_id AND user_id = OLD.user_id
      ), 0) / 3) + 1),
      last_active = NOW()
    WHERE course_id = OLD.course_id AND user_id = OLD.user_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS update_rankings_on_completion ON completed_lessons;

-- Create the trigger
CREATE TRIGGER update_rankings_on_completion
AFTER INSERT OR DELETE ON completed_lessons
FOR EACH ROW
EXECUTE FUNCTION update_rankings_on_completion();

-- Update RLS policies
DROP POLICY IF EXISTS "Users can update their own rankings through triggers" ON course_rankings;
DROP POLICY IF EXISTS "Course rankings are viewable by everyone" ON course_rankings;

-- Add new policies
CREATE POLICY "Users can manage rankings"
ON course_rankings FOR ALL
TO authenticated
USING (
  auth.uid() = user_id OR 
  EXISTS (
    SELECT 1 FROM courses 
    WHERE id = course_id AND instructor_id = auth.uid()
  )
)
WITH CHECK (
  auth.uid() = user_id OR 
  EXISTS (
    SELECT 1 FROM courses 
    WHERE id = course_id AND instructor_id = auth.uid()
  )
);

-- Create a function to get course rankings with proper return type
CREATE FUNCTION get_course_rankings(course_id_param UUID)
RETURNS TABLE (
  id UUID,
  user_id UUID,
  points INTEGER,
  completed_lessons_count INTEGER,
  level INTEGER,
  username TEXT,
  avatar_url TEXT,
  is_coach BOOLEAN,
  email TEXT
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    cr.id,
    cr.user_id,
    cr.points,
    cr.completed_lessons_count,
    cr.level,
    p.username,
    p.avatar_url,
    p.is_coach,
    p.email
  FROM course_rankings cr
  JOIN profiles p ON p.id = cr.user_id
  WHERE cr.course_id = course_id_param
  ORDER BY cr.points DESC, cr.last_active DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;