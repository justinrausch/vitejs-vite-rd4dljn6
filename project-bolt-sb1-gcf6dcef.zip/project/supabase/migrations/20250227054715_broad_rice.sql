/*
  # Add email field to profiles table

  1. Changes
     - Add email field to profiles table if it doesn't exist
     - Update admin profiles with admin badge
*/

-- Add email field to profiles table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'email'
  ) THEN
    ALTER TABLE profiles ADD COLUMN email text;
  END IF;
END $$;

-- Update profiles with email information from auth.users
DO $$
BEGIN
  UPDATE profiles
  SET email = users.email
  FROM auth.users
  WHERE profiles.id = users.id
  AND profiles.email IS NULL;
  
  -- Specifically ensure admin users have their emails set
  UPDATE profiles
  SET email = 'gaspar@mastery.to'
  WHERE id IN (
    SELECT id FROM auth.users WHERE email = 'gaspar@mastery.to'
  );
  
  UPDATE profiles
  SET email = 'justin@mastery.to'
  WHERE id IN (
    SELECT id FROM auth.users WHERE email = 'justin@mastery.to'
  );
END $$;