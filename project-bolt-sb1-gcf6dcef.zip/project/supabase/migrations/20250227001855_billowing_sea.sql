/*
  # Restore missing courses

  1. Changes
    - Restore courses that might have been accidentally deleted
    - Ensure all course data is properly available
*/

-- Check if courses exist and restore them if needed
DO $$
DECLARE
  course_count INTEGER;
BEGIN
  -- Check how many courses exist
  SELECT COUNT(*) INTO course_count FROM courses;
  
  -- If no courses exist, restore them
  IF course_count = 0 THEN
    -- Insert example courses using the function
    PERFORM insert_course_with_data(
      'Mountain Bike Fundamentals',
      'Master the essential skills of mountain biking from basic techniques to advanced trail riding.',
      49.99,
      'MTB',
      'https://images.unsplash.com/photo-1576858574144-9ae1ebcf5ae5?auto=format&fit=crop&q=80',
      '[
        {
          "title": "Getting Started",
          "position": 1,
          "lessons": [
            {"title": "Bike Setup", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Safety Basics", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        },
        {
          "title": "Basic Techniques",
          "position": 2,
          "lessons": [
            {"title": "Body Position", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Braking Technique", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        },
        {
          "title": "Trail Skills",
          "position": 3,
          "lessons": [
            {"title": "Reading the Trail", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Cornering", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        }
      ]'::json,
      '[
        {
          "title": "Monthly Access",
          "price": 49.99,
          "renewal_period": "monthly",
          "features": ["Full course access", "Community forum access", "Monthly Q&A sessions"]
        },
        {
          "title": "Lifetime Access",
          "price": 399.99,
          "renewal_period": null,
          "features": ["Lifetime course access", "Community forum access", "Private coaching session"]
        }
      ]'::json,
      ARRAY['MTB', 'Beginner', 'Skills']
    );

    PERFORM insert_course_with_data(
      'Advanced Trail Building',
      'Learn how to design, build, and maintain sustainable mountain bike trails.',
      79.99,
      'Trail Building',
      'https://images.unsplash.com/photo-1605540436563-5bca919ae766?auto=format&fit=crop&q=80',
      '[
        {
          "title": "Trail Design Principles",
          "position": 1,
          "lessons": [
            {"title": "Site Analysis", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Flow Concepts", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        },
        {
          "title": "Building Techniques",
          "position": 2,
          "lessons": [
            {"title": "Building Berms", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Jump Construction", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        },
        {
          "title": "Maintenance",
          "position": 3,
          "lessons": [
            {"title": "Drainage Systems", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Regular Upkeep", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        }
      ]'::json,
      '[
        {
          "title": "Monthly Access",
          "price": 79.99,
          "renewal_period": "monthly",
          "features": ["Full course access", "Trail building templates", "Monthly workshops"]
        },
        {
          "title": "Lifetime Access",
          "price": 599.99,
          "renewal_period": null,
          "features": ["Lifetime course access", "Trail building templates", "On-site consultation"]
        }
      ]'::json,
      ARRAY['Trail Building', 'Advanced', 'Design']
    );

    PERFORM insert_course_with_data(
      'Enduro Racing Mastery',
      'Comprehensive guide to enduro racing techniques, training, and race day strategies.',
      89.99,
      'Enduro',
      'https://images.unsplash.com/photo-1564417947365-8dbc9d0e718e?auto=format&fit=crop&q=80',
      '[
        {
          "title": "Race Preparation",
          "position": 1,
          "lessons": [
            {"title": "Bike Setup for Racing", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Course Analysis", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        },
        {
          "title": "Racing Techniques",
          "position": 2,
          "lessons": [
            {"title": "High-Speed Cornering", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Technical Descents", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        },
        {
          "title": "Recovery and Training",
          "position": 3,
          "lessons": [
            {"title": "Recovery Techniques", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Training Plans", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        }
      ]'::json,
      '[
        {
          "title": "Monthly Access",
          "price": 89.99,
          "renewal_period": "monthly",
          "features": ["Full course access", "Training plans", "Race day preparation guide"]
        },
        {
          "title": "Lifetime Access",
          "price": 699.99,
          "renewal_period": null,
          "features": ["Lifetime course access", "Training plans", "Personal race strategy session"]
        }
      ]'::json,
      ARRAY['Enduro', 'Racing', 'Advanced']
    );

    PERFORM insert_course_with_data(
      'Bike Maintenance Essentials',
      'Keep your bike in top condition with professional maintenance techniques.',
      39.99,
      'Maintenance',
      'https://images.unsplash.com/photo-1599058917765-a780eda07a3e?auto=format&fit=crop&q=80',
      '[
        {
          "title": "Basic Maintenance",
          "position": 1,
          "lessons": [
            {"title": "Safety Checks", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Cleaning Techniques", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        },
        {
          "title": "Drivetrain Service",
          "position": 2,
          "lessons": [
            {"title": "Chain Maintenance", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Gear Indexing", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        },
        {
          "title": "Suspension Setup",
          "position": 3,
          "lessons": [
            {"title": "Fork Setup", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Shock Tuning", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        }
      ]'::json,
      '[
        {
          "title": "Monthly Access",
          "price": 39.99,
          "renewal_period": "monthly",
          "features": ["Full course access", "Maintenance checklist", "Tool guide"]
        },
        {
          "title": "Lifetime Access",
          "price": 299.99,
          "renewal_period": null,
          "features": ["Lifetime course access", "Maintenance checklist", "Workshop session"]
        }
      ]'::json,
      ARRAY['Maintenance', 'Technical', 'Beginner']
    );

    PERFORM insert_course_with_data(
      'Freeride Progression',
      'Progress your freeride skills from intermediate jumps to advanced features.',
      69.99,
      'Freeride',
      'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?auto=format&fit=crop&q=80',
      '[
        {
          "title": "Jump Fundamentals",
          "position": 1,
          "lessons": [
            {"title": "Bunny Hops", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Table Tops", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        },
        {
          "title": "Drop Techniques",
          "position": 2,
          "lessons": [
            {"title": "Drop Basics", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Advanced Drops", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        },
        {
          "title": "Advanced Features",
          "position": 3,
          "lessons": [
            {"title": "Gap Jumps", "video_url": "dQw4w9WgXcQ", "position": 1},
            {"title": "Step Downs", "video_url": "dQw4w9WgXcQ", "position": 2}
          ]
        }
      ]'::json,
      '[
        {
          "title": "Monthly Access",
          "price": 69.99,
          "renewal_period": "monthly",
          "features": ["Full course access", "Progression roadmap", "Technique analysis"]
        },
        {
          "title": "Lifetime Access",
          "price": 499.99,
          "renewal_period": null,
          "features": ["Lifetime course access", "Progression roadmap", "Private coaching session"]
        }
      ]'::json,
      ARRAY['Freeride', 'Advanced', 'Jumping']
    );
    
    -- Create default channels for the courses
    INSERT INTO chat_channels (course_id, name, description)
    SELECT id, 'general', 'General discussion about the course'
    FROM courses
    WHERE NOT EXISTS (
      SELECT 1 FROM chat_channels
      WHERE chat_channels.course_id = courses.id
      AND chat_channels.name = 'general'
    );

    INSERT INTO chat_channels (course_id, name, description)
    SELECT id, 'tricks', 'Share and discuss tricks and techniques'
    FROM courses
    WHERE NOT EXISTS (
      SELECT 1 FROM chat_channels
      WHERE chat_channels.course_id = courses.id
      AND chat_channels.name = 'tricks'
    );

    INSERT INTO chat_channels (course_id, name, description)
    SELECT id, 'wins', 'Celebrate your achievements and progress'
    FROM courses
    WHERE NOT EXISTS (
      SELECT 1 FROM chat_channels
      WHERE chat_channels.course_id = courses.id
      AND chat_channels.name = 'wins'
    );
  END IF;
END $$;

-- Make sure the instructor profile is properly set up
UPDATE profiles
SET 
  username = 'Christian Arehart',
  avatar_url = 'https://images.unsplash.com/photo-1600486913747-55e5470d6f40?auto=format&fit=crop&q=80',
  is_coach = true
WHERE id IN (
  SELECT instructor_id FROM courses LIMIT 1
);