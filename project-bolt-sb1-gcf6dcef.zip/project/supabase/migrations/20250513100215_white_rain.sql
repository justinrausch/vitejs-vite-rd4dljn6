-- Create support_tickets table if it doesn't exist
CREATE TABLE IF NOT EXISTS support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  subject text NOT NULL,
  message text NOT NULL,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved')),
  created_at timestamptz DEFAULT now()
);

-- Create ticket_replies table if it doesn't exist
CREATE TABLE IF NOT EXISTS ticket_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid REFERENCES support_tickets(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE ticket_replies ENABLE ROW LEVEL SECURITY;

-- Create indexes for better performance (with IF NOT EXISTS to avoid errors)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'idx_support_tickets_user_id'
  ) THEN
    CREATE INDEX idx_support_tickets_user_id ON support_tickets(user_id);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'idx_support_tickets_status'
  ) THEN
    CREATE INDEX idx_support_tickets_status ON support_tickets(status);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'idx_support_tickets_created_at'
  ) THEN
    CREATE INDEX idx_support_tickets_created_at ON support_tickets(created_at DESC);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'idx_ticket_replies_ticket_id'
  ) THEN
    CREATE INDEX idx_ticket_replies_ticket_id ON ticket_replies(ticket_id);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'idx_ticket_replies_user_id'
  ) THEN
    CREATE INDEX idx_ticket_replies_user_id ON ticket_replies(user_id);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'idx_ticket_replies_created_at'
  ) THEN
    CREATE INDEX idx_ticket_replies_created_at ON ticket_replies(created_at);
  END IF;
END $$;

-- Add is_admin column to profiles if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'is_admin'
  ) THEN
    ALTER TABLE profiles ADD COLUMN is_admin boolean DEFAULT false;
  END IF;
END $$;

-- Set admin status for admin users
UPDATE profiles
SET is_admin = true
WHERE email IN ('gaspar@mastery.to', 'justin@mastery.to', 'admin@example.com');

-- Drop existing policies if they exist to avoid conflicts
DO $$ 
BEGIN
  -- Drop support_tickets policies
  DROP POLICY IF EXISTS "Users can view their own tickets" ON support_tickets;
  DROP POLICY IF EXISTS "Admins can view all tickets" ON support_tickets;
  DROP POLICY IF EXISTS "Users can create tickets" ON support_tickets;
  DROP POLICY IF EXISTS "Users can update their own tickets" ON support_tickets;
  DROP POLICY IF EXISTS "Admins can update any ticket" ON support_tickets;
  
  -- Drop ticket_replies policies
  DROP POLICY IF EXISTS "Users can view replies to their tickets" ON ticket_replies;
  DROP POLICY IF EXISTS "Admins can view all replies" ON ticket_replies;
  DROP POLICY IF EXISTS "Users can add replies to their tickets" ON ticket_replies;
EXCEPTION
  WHEN undefined_object THEN
    NULL;
END $$;

-- RLS Policies for support_tickets

-- Users can view their own tickets
CREATE POLICY "Users can view their own tickets"
  ON support_tickets FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Admins can view all tickets
CREATE POLICY "Admins can view all tickets"
  ON support_tickets FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

-- Users can create tickets
CREATE POLICY "Users can create tickets"
  ON support_tickets FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Users can update their own tickets
CREATE POLICY "Users can update their own tickets"
  ON support_tickets FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Admins can update any ticket
CREATE POLICY "Admins can update any ticket"
  ON support_tickets FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

-- RLS Policies for ticket_replies

-- Users can view replies to their tickets
CREATE POLICY "Users can view replies to their tickets"
  ON ticket_replies FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM support_tickets
      WHERE support_tickets.id = ticket_replies.ticket_id
      AND support_tickets.user_id = auth.uid()
    )
  );

-- Admins can view all replies
CREATE POLICY "Admins can view all replies"
  ON ticket_replies FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

-- Users can add replies to their tickets
CREATE POLICY "Users can add replies to their tickets"
  ON ticket_replies FOR INSERT
  TO authenticated
  WITH CHECK (
    (
      EXISTS (
        SELECT 1 FROM support_tickets
        WHERE support_tickets.id = ticket_replies.ticket_id
        AND support_tickets.user_id = auth.uid()
      )
      AND user_id = auth.uid()
    )
    OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );