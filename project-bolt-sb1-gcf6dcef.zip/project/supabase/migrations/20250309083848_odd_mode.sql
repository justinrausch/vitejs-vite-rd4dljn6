/*
  # Add private channels and permissions

  1. Changes
    - Add is_private column to chat_channels table
    - Update chat messages policy to handle private channels
    - Only coaches can send messages in private channels
    - Everyone can send messages in public channels

  2. Security
    - Enable RLS for chat_messages table
    - Add policy for message creation based on channel privacy
*/

-- Add is_private column to chat_channels
ALTER TABLE chat_channels ADD COLUMN IF NOT EXISTS is_private boolean DEFAULT false;

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Users can send messages in public channels" ON chat_messages;
DROP POLICY IF EXISTS "Only coaches can send messages in private channels" ON chat_messages;

-- Create policy for public channels
CREATE POLICY "Users can send messages in public channels"
ON chat_messages
FOR INSERT
TO public
WITH CHECK (
  NOT EXISTS (
    SELECT 1 
    FROM chat_channels
    WHERE id = chat_messages.channel_id 
    AND is_private = true
  )
);

-- Create policy for private channels (coaches only)
CREATE POLICY "Only coaches can send messages in private channels"
ON chat_messages
FOR INSERT
TO public
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM chat_channels c
    JOIN courses co ON co.id = c.course_id
    WHERE c.id = chat_messages.channel_id
    AND c.is_private = true
    AND co.instructor_id = auth.uid()
  )
);