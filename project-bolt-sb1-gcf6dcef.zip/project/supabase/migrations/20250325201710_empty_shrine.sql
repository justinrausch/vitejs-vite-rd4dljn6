/*
  # Add Stripe fields to enrollments table

  1. Changes
    - Add stripe_customer_id column
    - Add stripe_subscription_id column
    - Add indexes for faster lookups
*/

-- Add Stripe fields to enrollments table
ALTER TABLE enrollments
ADD COLUMN IF NOT EXISTS stripe_customer_id text,
ADD COLUMN IF NOT EXISTS stripe_subscription_id text;

-- Add indexes for Stripe fields
CREATE INDEX IF NOT EXISTS idx_enrollments_stripe_customer_id 
ON enrollments(stripe_customer_id);

CREATE INDEX IF NOT EXISTS idx_enrollments_stripe_subscription_id 
ON enrollments(stripe_subscription_id);