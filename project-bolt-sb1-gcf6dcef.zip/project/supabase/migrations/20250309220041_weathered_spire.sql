/*
  # Fix RLS policies for course rankings and completed lessons

  1. Changes
    - Add RLS policies for course_rankings table
    - Add RLS policies for completed_lessons table
    - Fix policy permissions for lesson completion tracking

  2. Security
    - Enable RLS on both tables
    - Allow users to manage their own rankings and completed lessons
    - Allow instructors to view rankings for their courses
*/

-- Enable RLS on tables if not already enabled
ALTER TABLE course_rankings ENABLE ROW LEVEL SECURITY;
ALTER TABLE completed_lessons ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Users can manage their own rankings" ON course_rankings;
DROP POLICY IF EXISTS "Course instructors can view rankings" ON course_rankings;
DROP POLICY IF EXISTS "Users can manage completed lessons" ON completed_lessons;

-- Create new policies for course_rankings
CREATE POLICY "Users can manage their own rankings"
  ON course_rankings
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Course instructors can view rankings"
  ON course_rankings
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = course_rankings.course_id
      AND courses.instructor_id = auth.uid()
    )
  );

-- Create new policies for completed_lessons
CREATE POLICY "Users can manage completed lessons"
  ON completed_lessons
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);