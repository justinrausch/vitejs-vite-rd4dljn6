/*
  # Update course instructors

  1. Changes
    - Assign different coaches to different courses
    - Update instructor profiles with more details
  
  2. Instructors
    - Sarah Johnson - Snowboard Freestyle Fundamentals
    - Mike Chen - Enduro Racing Mastery
    - Emma Rodriguez - Bike Maintenance Essentials
    - Christian Arehart - Freeride Progression and Mountain Bike Fundamentals
*/

-- Find existing coach profiles
DO $$
DECLARE
  sarah_id uuid;
  mike_id uuid;
  emma_id uuid;
  christian_id uuid;
BEGIN
  -- Get Christian's ID (original instructor)
  SELECT id INTO christian_id FROM profiles WHERE username = 'Christian Arehart';
  
  -- Get other coach IDs
  SELECT id INTO sarah_id FROM profiles WHERE username = 'Sarah Johnson';
  SELECT id INTO mike_id FROM profiles WHERE username = 'Mike Chen';
  SELECT id INTO emma_id FROM profiles WHERE username = 'Emma Rodriguez';
  
  -- Update course instructors if the coach profiles exist
  IF sarah_id IS NOT NULL THEN
    UPDATE courses SET instructor_id = sarah_id 
    WHERE title = 'Snowboard Freestyle Fundamentals';
  END IF;
  
  IF mike_id IS NOT NULL THEN
    UPDATE courses SET instructor_id = mike_id 
    WHERE title = 'Enduro Racing Mastery';
  END IF;
  
  IF emma_id IS NOT NULL THEN
    UPDATE courses SET instructor_id = emma_id 
    WHERE title = 'Bike Maintenance Essentials';
  END IF;
  
  -- Make sure Christian is still the instructor for his courses
  IF christian_id IS NOT NULL THEN
    UPDATE courses SET instructor_id = christian_id 
    WHERE title IN ('Freeride Progression', 'Mountain Bike Fundamentals');
  END IF;
  
  -- Create coach profiles if they don't exist
  IF sarah_id IS NULL THEN
    INSERT INTO profiles (
      id, 
      username, 
      avatar_url, 
      description, 
      instagram, 
      youtube, 
      full_name, 
      is_coach
    ) VALUES (
      gen_random_uuid(),
      'Sarah Johnson',
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80',
      'Former pro snowboarder turned coach. Helping riders of all levels improve their skills.',
      'sarah_rides',
      'sarahjohnson',
      'Sarah Johnson',
      true
    )
    RETURNING id INTO sarah_id;
    
    -- Assign Sarah to Snowboard course
    UPDATE courses SET instructor_id = sarah_id 
    WHERE title = 'Snowboard Freestyle Fundamentals';
  END IF;
  
  IF mike_id IS NULL THEN
    INSERT INTO profiles (
      id, 
      username, 
      avatar_url, 
      description, 
      instagram, 
      youtube, 
      full_name, 
      is_coach
    ) VALUES (
      gen_random_uuid(),
      'Mike Chen',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80',
      'Enduro specialist with a passion for teaching technical riding skills.',
      'mike_mtb',
      'mikechenrider',
      'Mike Chen',
      true
    )
    RETURNING id INTO mike_id;
    
    -- Assign Mike to Enduro course
    UPDATE courses SET instructor_id = mike_id 
    WHERE title = 'Enduro Racing Mastery';
  END IF;
  
  IF emma_id IS NULL THEN
    INSERT INTO profiles (
      id, 
      username, 
      avatar_url, 
      description, 
      instagram, 
      youtube, 
      full_name, 
      is_coach
    ) VALUES (
      gen_random_uuid(),
      'Emma Rodriguez',
      'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80',
      'Bike mechanic and skills coach. I love helping riders understand both the technical and mechanical aspects of mountain biking.',
      'emma_wrenches',
      'emmarod',
      'Emma Rodriguez',
      true
    )
    RETURNING id INTO emma_id;
    
    -- Assign Emma to Maintenance course
    UPDATE courses SET instructor_id = emma_id 
    WHERE title = 'Bike Maintenance Essentials';
  END IF;
  
  -- Make sure Christian is properly set up
  IF christian_id IS NULL THEN
    INSERT INTO profiles (
      id, 
      username, 
      avatar_url, 
      description, 
      instagram, 
      youtube, 
      full_name, 
      is_coach
    ) VALUES (
      gen_random_uuid(),
      'Christian Arehart',
      'https://images.unsplash.com/photo-1600486913747-55e5470d6f40?auto=format&fit=crop&q=80',
      'Professional mountain biker with over 10 years of experience. Specialized in freeride and downhill techniques.',
      'christian_arehart',
      'christianarehart',
      'Christian Arehart',
      true
    )
    RETURNING id INTO christian_id;
    
    -- Assign Christian to his courses
    UPDATE courses SET instructor_id = christian_id 
    WHERE title IN ('Freeride Progression', 'Mountain Bike Fundamentals');
  END IF;
  
  -- Create a Snowboard course if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Snowboard Freestyle Fundamentals') AND sarah_id IS NOT NULL THEN
    INSERT INTO courses (
      id,
      title,
      description,
      price,
      instructor_id,
      category,
      image_url
    ) VALUES (
      gen_random_uuid(),
      'Snowboard Freestyle Fundamentals',
      'Master the basics of freestyle snowboarding with former pro Sarah Johnson. From your first jumps to advanced park tricks.',
      59.99,
      sarah_id,
      'Snowboarding',
      'https://images.unsplash.com/photo-1522056615691-da7b8106c665?auto=format&fit=crop&q=80'
    );
  END IF;
END $$;