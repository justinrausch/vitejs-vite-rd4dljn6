-- Ensure proper RLS policies for enrollments
DO $$ 
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Users can view their own enrollments" ON enrollments;
  DROP POLICY IF EXISTS "Users can view course enrollments" ON enrollments;
  DROP POLICY IF EXISTS "Users can enroll in courses" ON enrollments;
  
  -- Create new policies
  CREATE POLICY "Anyone can view course enrollments"
    ON enrollments FOR SELECT
    USING (true);

  -- Only create the enrollment policy if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'enrollments' 
    AND policyname = 'Users can enroll in courses'
  ) THEN
    CREATE POLICY "Users can enroll in courses"
      ON enrollments FOR INSERT
      WITH CHECK (auth.uid() = user_id);
  END IF;

  CREATE POLICY "Users can manage their own enrollments"
    ON enrollments FOR DELETE
    USING (auth.uid() = user_id);
END $$;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_enrollments_course_user_id ON enrollments(course_id, user_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_enrolled_at ON enrollments(enrolled_at DESC);

-- Add function to get course members
CREATE OR REPLACE FUNCTION get_course_members(course_id_param uuid)
RETURNS TABLE (
  user_id uuid,
  username text,
  avatar_url text,
  is_coach boolean,
  email text,
  enrolled_at timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as user_id,
    p.username,
    p.avatar_url,
    p.is_coach,
    p.email,
    e.enrolled_at
  FROM enrollments e
  INNER JOIN profiles p ON p.id = e.user_id
  WHERE e.course_id = course_id_param
  ORDER BY e.enrolled_at DESC;
END;
$$ LANGUAGE plpgsql;