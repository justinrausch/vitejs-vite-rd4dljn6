/*
  # Add channel management policies

  1. Security
    - Add policies for coaches to manage channels
    - Coaches can create, update, and delete channels for their courses
    
  2. Changes
    - Add RLS policies for channel management
    - Ensure coaches can only manage channels in their own courses
*/

-- Add policies for channel management
CREATE POLICY "Coaches can manage channels"
  ON chat_channels
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = chat_channels.course_id
      AND courses.instructor_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = chat_channels.course_id
      AND courses.instructor_id = auth.uid()
    )
  );