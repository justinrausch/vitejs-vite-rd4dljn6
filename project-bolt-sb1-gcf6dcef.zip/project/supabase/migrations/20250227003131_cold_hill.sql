-- Add indexes to improve performance
CREATE INDEX IF NOT EXISTS idx_courses_instructor_id ON courses(instructor_id);
CREATE INDEX IF NOT EXISTS idx_course_chapters_course_id ON course_chapters(course_id);
CREATE INDEX IF NOT EXISTS idx_course_lessons_chapter_id ON course_lessons(chapter_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_user_id_course_id ON enrollments(user_id, course_id);
CREATE INDEX IF NOT EXISTS idx_completed_lessons_user_id_course_id ON completed_lessons(user_id, course_id);

-- Optimize chat message loading
CREATE INDEX IF NOT EXISTS idx_chat_messages_channel_id_created_at ON chat_messages(channel_id, created_at);

-- Check if chat_messages is already in the publication before adding it
DO $$
DECLARE
  table_exists BOOLEAN;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND schemaname = 'public' 
    AND tablename = 'chat_messages'
  ) INTO table_exists;
  
  IF NOT table_exists THEN
    -- Add the table to the publication
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages';
  END IF;
END $$;

-- Ensure the instructor profile is properly set up
UPDATE profiles
SET 
  username = 'Christian Arehart',
  avatar_url = 'https://images.unsplash.com/photo-1600486913747-55e5470d6f40?auto=format&fit=crop&q=80',
  is_coach = true
WHERE id IN (
  SELECT instructor_id FROM courses LIMIT 1
);

-- Make sure the admin user has a different username
UPDATE profiles
SET username = 'Admin User'
WHERE id IN (
  SELECT id FROM auth.users WHERE email = 'admin@gmail.com'
);