/*
  # Fix course rankings RLS policies

  1. Changes
    - Drop existing policies to avoid conflicts
    - Enable RLS on course_rankings table
    - Add policies for:
      - Viewing rankings (public)
      - Managing own rankings (authenticated users)
      - Updating rankings (system triggers)
      - Managing completed lessons

  2. Security
    - Enable RLS
    - Add appropriate policies for CRUD operations
*/

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Course rankings are viewable by everyone" ON course_rankings;
DROP POLICY IF EXISTS "Users can manage their own rankings" ON course_rankings;
DROP POLICY IF EXISTS "System can update rankings through triggers" ON course_rankings;
DROP POLICY IF EXISTS "Users can view their completed lessons" ON completed_lessons;
DROP POLICY IF EXISTS "Users can manage completed lessons" ON completed_lessons;

-- Enable RLS
ALTER TABLE course_rankings ENABLE ROW LEVEL SECURITY;
ALTER TABLE completed_lessons ENABLE ROW LEVEL SECURITY;

-- Allow anyone to view rankings
CREATE POLICY "Course rankings are viewable by everyone" 
ON course_rankings
FOR SELECT
TO public
USING (true);

-- Allow users to manage their own rankings
CREATE POLICY "Users can manage their own rankings"
ON course_rankings
FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Allow the system to update rankings through triggers
CREATE POLICY "System can update rankings through triggers"
ON course_rankings
FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

-- Allow users to view their own completed lessons
CREATE POLICY "Users can view their completed lessons"
ON completed_lessons
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- Allow users to manage their completed lessons
CREATE POLICY "Users can manage completed lessons"
ON completed_lessons
FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);