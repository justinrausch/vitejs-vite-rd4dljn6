-- Create a function to create a bucket for each course
CREATE OR REPLACE FUNCTION create_course_bucket(course_id uuid)
RETURNS void AS $$
DECLARE
  bucket_name text;
BEGIN
  bucket_name := 'course_' || course_id::text;
  
  -- Create the bucket if it doesn't exist
  INSERT INTO storage.buckets (id, name, public)
  VALUES (bucket_name, bucket_name, false)
  ON CONFLICT (id) DO NOTHING;
  
  -- Create policies for the bucket
  
  -- Allow instructors to upload to their course bucket
  EXECUTE format('
    CREATE POLICY "Instructors can upload to %s"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id = %L AND
      EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = %L::uuid
        AND courses.instructor_id = auth.uid()
      )
    )', bucket_name, bucket_name, course_id);
  
  -- Allow instructors to update objects in their course bucket
  EXECUTE format('
    CREATE POLICY "Instructors can update objects in %s"
    ON storage.objects FOR UPDATE
    USING (
      bucket_id = %L AND
      EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = %L::uuid
        AND courses.instructor_id = auth.uid()
      )
    )', bucket_name, bucket_name, course_id);
  
  -- Allow instructors to delete objects in their course bucket
  EXECUTE format('
    CREATE POLICY "Instructors can delete objects in %s"
    ON storage.objects FOR DELETE
    USING (
      bucket_id = %L AND
      EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = %L::uuid
        AND courses.instructor_id = auth.uid()
      )
    )', bucket_name, bucket_name, course_id);
  
  -- Allow enrolled users to view objects in the course bucket
  EXECUTE format('
    CREATE POLICY "Enrolled users can view objects in %s"
    ON storage.objects FOR SELECT
    USING (
      bucket_id = %L AND
      EXISTS (
        SELECT 1 FROM enrollments
        WHERE enrollments.course_id = %L::uuid
        AND enrollments.user_id = auth.uid()
      )
    )', bucket_name, bucket_name, course_id);
END;
$$ LANGUAGE plpgsql;

-- Create a function to create a bucket for each lesson
CREATE OR REPLACE FUNCTION create_lesson_bucket(lesson_id uuid, course_id uuid)
RETURNS void AS $$
DECLARE
  bucket_name text;
BEGIN
  bucket_name := 'lesson_' || lesson_id::text;
  
  -- Create the bucket if it doesn't exist
  INSERT INTO storage.buckets (id, name, public)
  VALUES (bucket_name, bucket_name, false)
  ON CONFLICT (id) DO NOTHING;
  
  -- Create policies for the bucket
  
  -- Allow instructors to upload to their lesson bucket
  EXECUTE format('
    CREATE POLICY "Instructors can upload to %s"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id = %L AND
      EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = %L::uuid
        AND courses.instructor_id = auth.uid()
      )
    )', bucket_name, bucket_name, course_id);
  
  -- Allow instructors to update objects in their lesson bucket
  EXECUTE format('
    CREATE POLICY "Instructors can update objects in %s"
    ON storage.objects FOR UPDATE
    USING (
      bucket_id = %L AND
      EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = %L::uuid
        AND courses.instructor_id = auth.uid()
      )
    )', bucket_name, bucket_name, course_id);
  
  -- Allow instructors to delete objects in their lesson bucket
  EXECUTE format('
    CREATE POLICY "Instructors can delete objects in %s"
    ON storage.objects FOR DELETE
    USING (
      bucket_id = %L AND
      EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = %L::uuid
        AND courses.instructor_id = auth.uid()
      )
    )', bucket_name, bucket_name, course_id);
  
  -- Allow enrolled users to view objects in the lesson bucket
  EXECUTE format('
    CREATE POLICY "Enrolled users can view objects in %s"
    ON storage.objects FOR SELECT
    USING (
      bucket_id = %L AND
      EXISTS (
        SELECT 1 FROM enrollments
        WHERE enrollments.course_id = %L::uuid
        AND enrollments.user_id = auth.uid()
      )
    )', bucket_name, bucket_name, course_id);
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to automatically create buckets for new courses
CREATE OR REPLACE FUNCTION create_course_bucket_trigger()
RETURNS trigger AS $$
BEGIN
  PERFORM create_course_bucket(NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to automatically create buckets for new lessons
CREATE OR REPLACE FUNCTION create_lesson_bucket_trigger()
RETURNS trigger AS $$
DECLARE
  course_id uuid;
BEGIN
  -- Get the course ID for this lesson
  SELECT courses.id INTO course_id
  FROM course_chapters
  JOIN courses ON courses.id = course_chapters.course_id
  WHERE course_chapters.id = NEW.chapter_id;
  
  IF course_id IS NOT NULL THEN
    PERFORM create_lesson_bucket(NEW.id, course_id);
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
DROP TRIGGER IF EXISTS on_course_created ON courses;
CREATE TRIGGER on_course_created
  AFTER INSERT ON courses
  FOR EACH ROW
  EXECUTE FUNCTION create_course_bucket_trigger();

DROP TRIGGER IF EXISTS on_lesson_created ON course_lessons;
CREATE TRIGGER on_lesson_created
  AFTER INSERT ON course_lessons
  FOR EACH ROW
  EXECUTE FUNCTION create_lesson_bucket_trigger();

-- Create buckets for existing courses and lessons
DO $$
DECLARE
  course_rec RECORD;
  lesson_rec RECORD;
BEGIN
  -- Create buckets for existing courses
  FOR course_rec IN SELECT id FROM courses LOOP
    PERFORM create_course_bucket(course_rec.id);
  END LOOP;
  
  -- Create buckets for existing lessons
  FOR lesson_rec IN 
    SELECT course_lessons.id, courses.id AS course_id
    FROM course_lessons
    JOIN course_chapters ON course_chapters.id = course_lessons.chapter_id
    JOIN courses ON courses.id = course_chapters.course_id
  LOOP
    PERFORM create_lesson_bucket(lesson_rec.id, lesson_rec.course_id);
  END LOOP;
END $$;