/*
  # Video Progress Tracking

  1. New Tables
    - `video_progress`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to profiles)
      - `course_id` (uuid, foreign key to courses)
      - `lesson_id` (uuid, foreign key to course_lessons)
      - `progress` (integer, default 0)
      - `watched_seconds` (numeric, default 0)
      - `last_watched_at` (timestamp with time zone)
      - `created_at` (timestamp with time zone)

  2. Security
    - Enable RLS on `video_progress` table
    - Add policies for users to manage their own progress
    - Add policies for instructors to view progress

  3. Changes
    - Add indexes for efficient querying
    - Add foreign key constraints
*/

-- Create video progress table
CREATE TABLE IF NOT EXISTS video_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  lesson_id uuid NOT NULL REFERENCES course_lessons(id) ON DELETE CASCADE,
  progress integer NOT NULL DEFAULT 0,
  watched_seconds numeric NOT NULL DEFAULT 0,
  last_watched_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, lesson_id)
);

-- Enable RLS
ALTER TABLE video_progress ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_video_progress_user_lesson ON video_progress(user_id, lesson_id);
CREATE INDEX IF NOT EXISTS idx_video_progress_user_course ON video_progress(user_id, course_id);
CREATE INDEX IF NOT EXISTS idx_video_progress_user_course_time ON video_progress(user_id, course_id, last_watched_at DESC);

-- Create policies with unique names
CREATE POLICY "video_progress_select_own"
  ON video_progress
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "video_progress_insert_own"
  ON video_progress
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "video_progress_update_own"
  ON video_progress
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "video_progress_select_instructor"
  ON video_progress
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = video_progress.course_id
      AND courses.instructor_id = auth.uid()
    )
  );