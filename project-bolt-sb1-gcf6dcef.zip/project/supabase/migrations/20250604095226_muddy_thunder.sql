/*
  # Add feature access flags to course plans
  
  1. Changes
    - Add feature access columns to course_plans table
      - lessons_access (boolean, default true)
      - community_access (boolean, default false)
      - coaching_access (boolean, default false)
      - rankings_access (boolean, default false)
*/

ALTER TABLE course_plans
ADD COLUMN lessons_access boolean DEFAULT true,
ADD COLUMN community_access boolean DEFAULT false,
ADD COLUMN coaching_access boolean DEFAULT false,
ADD COLUMN rankings_access boolean DEFAULT false;