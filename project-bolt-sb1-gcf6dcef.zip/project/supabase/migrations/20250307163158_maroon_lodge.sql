/*
  # Storage Policies for Course Content

  1. Security Changes
    - Enable RLS on storage.buckets
    - Add policies for bucket management
    - Add policies for object management
    
  2. Policies Added
    - Coaches can create and manage course buckets
    - Public can read course buckets
    - Instructors can manage course objects
*/

-- Enable RLS
ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

-- Allow coaches to create and manage course buckets
CREATE POLICY "Coaches can create and manage course buckets"
ON storage.buckets
FOR ALL
TO public
USING (
  EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
    AND p.is_coach = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
    AND p.is_coach = true
  )
);

-- Allow public read access to course buckets
CREATE POLICY "Public can read course buckets"
ON storage.buckets
FOR SELECT
TO public
USING (true);

-- Allow instructors to manage their course objects
CREATE POLICY "Instructors can manage course objects"
ON storage.objects
FOR ALL 
TO public
USING (
  bucket_id IN (
    SELECT b.name FROM storage.buckets b
    INNER JOIN public.courses c ON c.instructor_id = auth.uid()
    WHERE b.name LIKE 'course_%'
    OR b.name LIKE 'lesson_%'
  )
)
WITH CHECK (
  bucket_id IN (
    SELECT b.name FROM storage.buckets b
    INNER JOIN public.courses c ON c.instructor_id = auth.uid()
    WHERE b.name LIKE 'course_%'
    OR b.name LIKE 'lesson_%'
  )
);