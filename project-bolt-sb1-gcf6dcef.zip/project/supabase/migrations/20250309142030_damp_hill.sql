/*
  # Add total watch time tracking

  1. Changes
    - Add total_watch_time column to video_progress parent table
    - Update RLS policies to ensure proper access control
    - The column will automatically propagate to all partitions

  2. Security
    - Maintain existing RLS policies
    - Ensure proper access control for video progress tracking
*/

-- Add total_watch_time column to the parent table
-- This will automatically propagate to all partitions
ALTER TABLE video_progress 
ADD COLUMN IF NOT EXISTS total_watch_time numeric DEFAULT 0;

-- Ensure RLS policies are correct
ALTER TABLE video_progress ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "video_progress_insert_own" ON video_progress;
DROP POLICY IF EXISTS "video_progress_select_own" ON video_progress;
DROP POLICY IF EXISTS "video_progress_update_own" ON video_progress;
DROP POLICY IF EXISTS "video_progress_select_instructor" ON video_progress;

-- Create policies with proper access control
CREATE POLICY "video_progress_insert_own"
ON video_progress
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "video_progress_select_own"
ON video_progress
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "video_progress_update_own"
ON video_progress
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Allow course instructors to view progress
CREATE POLICY "video_progress_select_instructor"
ON video_progress
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM courses
    WHERE courses.id = video_progress.course_id
    AND courses.instructor_id = auth.uid()
  )
);