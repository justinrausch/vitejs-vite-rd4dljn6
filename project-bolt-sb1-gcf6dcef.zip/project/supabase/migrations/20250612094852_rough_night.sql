/*
  # Add feature access controls to course plans
  
  1. Schema Updates
    - Add feature access boolean columns to course_plans table
    - Each column controls access to a specific feature (lessons, community, coaching, rankings)
  
  2. Access Policies
    - Add policies that check plan permissions before allowing access to features
    - Ensure course creators can manage their plans
    - Create feature-specific access policies for different parts of the application
*/

-- Add feature access columns to course_plans table
ALTER TABLE IF EXISTS public.course_plans 
ADD COLUMN IF NOT EXISTS lessons_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS community_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS coaching_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS rankings_access BOOLEAN DEFAULT TRUE;

-- Check if policy exists before creating
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_plans' 
    AND policyname = 'Course creators can manage plans'
  ) THEN
    -- Update RLS policies for course_plans
    EXECUTE 'CREATE POLICY "Course creators can manage plans" 
    ON public.course_plans
    FOR ALL
    TO authenticated
    USING (EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = course_plans.course_id
      AND courses.instructor_id = auth.uid()
    ))';
  END IF;
END
$$;

-- Check if policy exists before creating
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'chat_messages' 
    AND policyname = 'Users can access community if their plan allows'
  ) THEN
    -- Update RLS policies for course community
    EXECUTE 'CREATE POLICY "Users can access community if their plan allows" 
    ON public.chat_messages
    FOR ALL
    TO authenticated
    USING (EXISTS (
      SELECT 1 FROM enrollments e
      JOIN course_plans p ON e.plan_id = p.id
      WHERE e.user_id = auth.uid()
      AND e.course_id = (
        SELECT chat_channels.course_id 
        FROM chat_channels 
        WHERE chat_channels.id = chat_messages.channel_id
      )
      AND p.community_access = true
    ))';
  END IF;
END
$$;

-- Check if policy exists before creating
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_rankings' 
    AND policyname = 'Users can access rankings if their plan allows'
  ) THEN
    -- Update RLS policies for course rankings
    EXECUTE 'CREATE POLICY "Users can access rankings if their plan allows" 
    ON public.course_rankings
    FOR ALL
    TO authenticated
    USING (EXISTS (
      SELECT 1 FROM enrollments e
      JOIN course_plans p ON e.plan_id = p.id
      WHERE e.user_id = auth.uid()
      AND e.course_id = course_rankings.course_id
      AND p.rankings_access = true
    ))';
  END IF;
END
$$;

-- Check if policy exists before creating
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'coach_messages' 
    AND policyname = 'Users can access coaching if their plan allows'
  ) THEN
    -- Update RLS policies for coaching
    EXECUTE 'CREATE POLICY "Users can access coaching if their plan allows" 
    ON public.coach_messages
    FOR ALL
    TO authenticated
    USING (EXISTS (
      SELECT 1 FROM enrollments e
      JOIN course_plans p ON e.plan_id = p.id
      WHERE e.user_id = auth.uid()
      AND e.course_id = coach_messages.course_id
      AND p.coaching_access = true
    ))';
  END IF;
END
$$;