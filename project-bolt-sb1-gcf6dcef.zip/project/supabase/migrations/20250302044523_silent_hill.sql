-- Make category field nullable and add default value
ALTER TABLE courses ALTER COLUMN category DROP NOT NULL;
ALTER TABLE courses ALTER COLUMN category SET DEFAULT 'general';

-- Update existing courses with categories based on sport/disciplines
UPDATE courses 
SET category = CASE
  WHEN sport = 'Mountain biking' AND disciplines @> ARRAY['Cross country'] THEN 'XC'
  WHEN sport = 'Mountain biking' AND disciplines @> ARRAY['Enduro'] THEN 'Enduro'
  WHEN sport = 'Mountain biking' AND disciplines @> ARRAY['Freeride'] THEN 'Freeride'
  WHEN sport = 'Mountain biking' AND disciplines @> ARRAY['Trail building'] THEN 'Trail Building'
  ELSE 'general'
END
WHERE category IS NULL;

-- Add function to create course with chapters
CREATE OR REPLACE FUNCTION create_course_with_chapters(
  p_title text,
  p_tagline text,
  p_description text,
  p_image_url text,
  p_price numeric,
  p_sport text,
  p_disciplines text[],
  p_instructor_id uuid
) RETURNS uuid AS $$
DECLARE
  v_course_id uuid;
BEGIN
  -- Insert the course
  INSERT INTO courses (
    title,
    tagline,
    description,
    image_url,
    price,
    sport,
    disciplines,
    instructor_id,
    category
  ) VALUES (
    p_title,
    p_tagline,
    p_description,
    p_image_url,
    p_price,
    p_sport,
    p_disciplines,
    p_instructor_id,
    'general'
  ) RETURNING id INTO v_course_id;

  -- Return the new course ID
  RETURN v_course_id;
END;
$$ LANGUAGE plpgsql;

-- Create function to add chapter
CREATE OR REPLACE FUNCTION add_course_chapter(
  p_course_id uuid,
  p_title text,
  p_position integer
) RETURNS uuid AS $$
DECLARE
  v_chapter_id uuid;
BEGIN
  -- Insert the chapter
  INSERT INTO course_chapters (
    course_id,
    title,
    position
  ) VALUES (
    p_course_id,
    p_title,
    p_position
  ) RETURNING id INTO v_chapter_id;

  -- Return the new chapter ID
  RETURN v_chapter_id;
END;
$$ LANGUAGE plpgsql;