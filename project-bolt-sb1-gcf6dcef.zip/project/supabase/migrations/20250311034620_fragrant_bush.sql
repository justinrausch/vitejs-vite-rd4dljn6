/*
  # Fix course rankings trigger for lesson uncompletion

  1. Changes
    - Update the trigger function to properly handle lesson uncompletion
    - Ensure course_id is preserved when updating rankings
    - Add safety checks to prevent null course_id

  2. Security
    - No changes to RLS policies
*/

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS update_rankings_on_completion ON completed_lessons;

-- Update the trigger function
CREATE OR REPLACE FUNCTION update_rankings_on_completion()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Get or create course ranking
    INSERT INTO course_rankings (user_id, course_id, completed_lessons_count, points)
    VALUES (NEW.user_id, NEW.course_id, 1, 100)
    ON CONFLICT (user_id, course_id) 
    DO UPDATE SET 
      completed_lessons_count = course_rankings.completed_lessons_count + 1,
      points = course_rankings.points + 100;
      
  ELSIF TG_OP = 'DELETE' THEN
    -- Update existing ranking
    UPDATE course_rankings
    SET 
      completed_lessons_count = GREATEST(completed_lessons_count - 1, 0),
      points = GREATEST(points - 100, 0)
    WHERE user_id = OLD.user_id AND course_id = OLD.course_id;
    
    -- Remove ranking if no completed lessons remain
    DELETE FROM course_rankings
    WHERE user_id = OLD.user_id 
      AND course_id = OLD.course_id
      AND completed_lessons_count = 0;
  END IF;
  
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Recreate the trigger
CREATE TRIGGER update_rankings_on_completion
AFTER INSERT OR DELETE ON completed_lessons
FOR EACH ROW
EXECUTE FUNCTION update_rankings_on_completion();