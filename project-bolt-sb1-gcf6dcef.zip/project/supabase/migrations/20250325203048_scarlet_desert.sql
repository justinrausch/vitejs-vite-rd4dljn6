/*
  # Add Stripe price ID to course plans

  1. Changes
    - Add stripe_price_id column to course_plans table
    - Add index for faster lookups
*/

-- Add stripe_price_id column to course_plans table
ALTER TABLE course_plans
ADD COLUMN IF NOT EXISTS stripe_price_id text;

-- Add index for stripe_price_id
CREATE INDEX IF NOT EXISTS idx_course_plans_stripe_price_id 
ON course_plans(stripe_price_id);