/*
  # Check and Create Enrollments Table

  This migration checks if the enrollments table exists and creates it if needed.
  Since the table and policies might already exist, we use IF NOT EXISTS clauses.
*/

DO $$ 
BEGIN
  -- Check if enrollments table exists
  IF NOT EXISTS (
    SELECT FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename = 'enrollments'
  ) THEN
    -- Create enrollments table
    CREATE TABLE enrollments (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
      course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
      enrolled_at timestamptz DEFAULT now(),
      completed boolean DEFAULT false,
      UNIQUE(user_id, course_id)
    );

    -- Enable RLS
    ALTER TABLE enrollments ENABLE ROW LEVEL SECURITY;

    -- Create policies
    CREATE POLICY "Users can view their own enrollments"
      ON enrollments FOR SELECT
      USING (auth.uid() = user_id);

    CREATE POLICY "Users can enroll in courses"
      ON enrollments FOR INSERT
      WITH CHECK (auth.uid() = user_id);

    CREATE POLICY "Users can update their own enrollments"
      ON enrollments FOR UPDATE
      USING (auth.uid() = user_id);
  END IF;
END $$;