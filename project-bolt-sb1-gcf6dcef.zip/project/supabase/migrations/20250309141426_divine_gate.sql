/*
  # Fix Rankings and Video Progress Schema

  1. Changes
    - Add missing columns to course_rankings table
    - Update video_progress table schema
    - Add necessary indexes for performance

  2. Details
    - Add level column to course_rankings
    - Add total_watch_time to video_progress
    - Add indexes for efficient querying
*/

-- Add level column to course_rankings if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'course_rankings' AND column_name = 'level'
  ) THEN
    ALTER TABLE course_rankings 
    ADD COLUMN level integer DEFAULT 1;
  END IF;
END $$;

-- Add total_watch_time to video_progress if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'video_progress' AND column_name = 'total_watch_time'
  ) THEN
    ALTER TABLE video_progress 
    ADD COLUMN total_watch_time numeric DEFAULT 0;
  END IF;
END $$;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_course_rankings_level 
ON course_rankings(level);

CREATE INDEX IF NOT EXISTS idx_video_progress_total_time 
ON video_progress(total_watch_time);

-- Update the update_course_ranking function to handle level
CREATE OR REPLACE FUNCTION update_course_ranking()
RETURNS TRIGGER AS $$
BEGIN
  -- Calculate level based on completed lessons (every 3 lessons = 1 level)
  NEW.level := GREATEST(1, FLOOR(NEW.completed_lessons_count::numeric / 3) + 1);
  
  -- Calculate points (100 per completed lesson)
  NEW.points := NEW.completed_lessons_count * 100;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Update existing rankings with correct levels
UPDATE course_rankings
SET level = GREATEST(1, FLOOR(completed_lessons_count::numeric / 3) + 1)
WHERE level IS NULL OR level = 1;

-- Update existing video progress entries
UPDATE video_progress
SET total_watch_time = watched_seconds
WHERE total_watch_time IS NULL;