/*
  # Add message reactions support
  
  1. New Tables
    - `message_reactions`
      - `id` (uuid, primary key)
      - `message_id` (uuid, references chat_messages)
      - `user_id` (uuid, references profiles)
      - `emoji` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on message_reactions table
    - Add policies for:
      - Everyone can view reactions
      - Users can add/remove their own reactions
      - Unique constraint on message/user/emoji combination

  3. Changes
    - Add foreign key constraints
    - Add indexes for performance
*/

-- Create message reactions table if it doesn't exist
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS message_reactions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id uuid NOT NULL,
    user_id uuid NOT NULL,
    emoji text NOT NULL,
    created_at timestamptz DEFAULT now(),
    CONSTRAINT message_reactions_message_id_user_id_emoji_key UNIQUE (message_id, user_id, emoji)
  );
EXCEPTION
  WHEN duplicate_table THEN
    NULL;
END $$;

-- Add foreign key constraints if they don't exist
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'message_reactions_message_id_fkey'
  ) THEN
    ALTER TABLE message_reactions
      ADD CONSTRAINT message_reactions_message_id_fkey 
      FOREIGN KEY (message_id) 
      REFERENCES chat_messages(id)
      ON DELETE CASCADE;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'message_reactions_user_id_fkey'
  ) THEN
    ALTER TABLE message_reactions
      ADD CONSTRAINT message_reactions_user_id_fkey 
      FOREIGN KEY (user_id) 
      REFERENCES profiles(id)
      ON DELETE CASCADE;
  END IF;
END $$;

-- Add indexes if they don't exist
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_message_reactions_message_id'
  ) THEN
    CREATE INDEX idx_message_reactions_message_id ON message_reactions(message_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_message_reactions_user_id'
  ) THEN
    CREATE INDEX idx_message_reactions_user_id ON message_reactions(user_id);
  END IF;
END $$;

-- Enable RLS
ALTER TABLE message_reactions ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Everyone can view reactions" ON message_reactions;
DROP POLICY IF EXISTS "Users can add reactions" ON message_reactions;
DROP POLICY IF EXISTS "Users can remove their reactions" ON message_reactions;

-- Add RLS policies
CREATE POLICY "Everyone can view reactions"
  ON message_reactions
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can add reactions"
  ON message_reactions
  FOR INSERT
  TO public
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove their reactions"
  ON message_reactions
  FOR DELETE
  TO public
  USING (auth.uid() = user_id);