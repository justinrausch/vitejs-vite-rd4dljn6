/*
  # Add function to mark messages as read

  1. New Function
    - Creates a stored procedure to mark multiple messages as read efficiently
    - Takes an array of message IDs as input
    - Updates all specified messages atomically

  2. Security
    - Function is accessible to authenticated users only
    - Validates message ownership before updating
*/

CREATE OR REPLACE FUNCTION mark_messages_read(message_ids uuid[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE coach_messages
  SET read = true
  WHERE id = ANY(message_ids);
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION mark_messages_read(uuid[]) TO authenticated;