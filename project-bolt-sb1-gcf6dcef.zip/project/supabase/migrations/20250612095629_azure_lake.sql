/*
  # Add feature access controls to course plans

  1. New Columns
    - Add feature access control columns to course_plans table
      - lessons_access (boolean, default true)
      - community_access (boolean, default true)
      - coaching_access (boolean, default true)
      - rankings_access (boolean, default true)
  
  2. RLS Policies
    - Add policies to control access to features based on plan permissions
    - Ensure policies don't conflict with existing ones
*/

-- Add feature access columns to course_plans table
ALTER TABLE IF EXISTS public.course_plans 
ADD COLUMN IF NOT EXISTS lessons_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS community_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS coaching_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS rankings_access BOOLEAN DEFAULT TRUE;

-- Create policies with checks to avoid conflicts
DO $$
BEGIN
  -- Check if "Course creators can manage plans" policy exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_plans' 
    AND policyname = 'Course creators can manage plans'
  ) THEN
    EXECUTE format('
      CREATE POLICY "Course creators can manage plans" 
      ON public.course_plans
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = course_plans.course_id
        AND courses.instructor_id = auth.uid()
      ))
    ');
  END IF;
  
  -- Check if "Users can access community if their plan allows" policy exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'chat_messages' 
    AND policyname = 'Users can access community if their plan allows'
  ) THEN
    EXECUTE format('
      CREATE POLICY "Users can access community if their plan allows" 
      ON public.chat_messages
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM enrollments e
        JOIN course_plans p ON e.plan_id = p.id
        WHERE e.user_id = auth.uid()
        AND e.course_id = (
          SELECT chat_channels.course_id 
          FROM chat_channels 
          WHERE chat_channels.id = chat_messages.channel_id
        )
        AND p.community_access = true
      ))
    ');
  END IF;
  
  -- Check if "Users can access rankings if their plan allows" policy exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_rankings' 
    AND policyname = 'Users can access rankings if their plan allows'
  ) THEN
    EXECUTE format('
      CREATE POLICY "Users can access rankings if their plan allows" 
      ON public.course_rankings
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM enrollments e
        JOIN course_plans p ON e.plan_id = p.id
        WHERE e.user_id = auth.uid()
        AND e.course_id = course_rankings.course_id
        AND p.rankings_access = true
      ))
    ');
  END IF;
  
  -- Check if "Users can access coaching if their plan allows" policy exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'coach_messages' 
    AND policyname = 'Users can access coaching if their plan allows'
  ) THEN
    EXECUTE format('
      CREATE POLICY "Users can access coaching if their plan allows" 
      ON public.coach_messages
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM enrollments e
        JOIN course_plans p ON e.plan_id = p.id
        WHERE e.user_id = auth.uid()
        AND e.course_id = coach_messages.course_id
        AND p.coaching_access = true
      ))
    ');
  END IF;
END $$;