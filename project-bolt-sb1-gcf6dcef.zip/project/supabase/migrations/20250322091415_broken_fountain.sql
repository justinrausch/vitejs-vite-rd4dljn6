-- Drop existing policies
DROP POLICY IF EXISTS "Users can create reviews" ON course_reviews;

-- Create new policy that allows any authenticated user to create reviews
CREATE POLICY "Users can create reviews"
  ON course_reviews FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE user_id = auth.uid()
      AND course_id = course_reviews.course_id
    )
  );