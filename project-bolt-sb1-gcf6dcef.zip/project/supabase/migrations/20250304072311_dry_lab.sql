-- Add read field to coach_messages if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'coach_messages' AND column_name = 'read'
  ) THEN
    ALTER TABLE coach_messages ADD COLUMN read boolean DEFAULT false;
  END IF;
END $$;

-- Create function to mark messages as read
CREATE OR REPLACE FUNCTION mark_messages_read(
  p_course_id uuid,
  p_student_id uuid
) RETURNS void AS $$
BEGIN
  UPDATE coach_messages
  SET read = true
  WHERE course_id = p_course_id
    AND student_id = p_student_id
    AND sender_id = p_student_id
    AND read = false;
END;
$$ LANGUAGE plpgsql;

-- Create function to get unread message count
CREATE OR REPLACE FUNCTION get_unread_message_count(
  p_course_id uuid,
  p_student_id uuid
) RETURNS integer AS $$
BEGIN
  RETURN (
    SELECT COUNT(*)::integer
    FROM coach_messages
    WHERE course_id = p_course_id
      AND student_id = p_student_id
      AND sender_id = p_student_id
      AND read = false
  );
END;
$$ LANGUAGE plpgsql;

-- Create function to get student list with message stats
CREATE OR REPLACE FUNCTION get_students_with_messages(
  p_course_id uuid
) RETURNS TABLE (
  student_id uuid,
  username text,
  avatar_url text,
  last_message_at timestamptz,
  unread_count integer
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as student_id,
    p.username,
    p.avatar_url,
    MAX(cm.created_at) as last_message_at,
    COUNT(CASE WHEN cm.read = false AND cm.sender_id = p.id THEN 1 END)::integer as unread_count
  FROM enrollments e
  JOIN profiles p ON p.id = e.user_id
  LEFT JOIN coach_messages cm ON cm.student_id = p.id AND cm.course_id = p_course_id
  WHERE e.course_id = p_course_id
  GROUP BY p.id, p.username, p.avatar_url
  ORDER BY last_message_at DESC NULLS LAST;
END;
$$ LANGUAGE plpgsql;

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Coaches can view all messages for their courses" ON coach_messages;
  DROP POLICY IF EXISTS "Students can view their own messages" ON coach_messages;
  DROP POLICY IF EXISTS "Coaches can send messages to any student" ON coach_messages;
  DROP POLICY IF EXISTS "Students can send messages to their coaches" ON coach_messages;
END $$;

-- Create new policies
CREATE POLICY "Coaches can view all messages for their courses"
  ON coach_messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = coach_messages.course_id
      AND courses.instructor_id = auth.uid()
    )
  );

CREATE POLICY "Students can view their own messages"
  ON coach_messages FOR SELECT
  USING (auth.uid() = student_id);

CREATE POLICY "Coaches can send messages"
  ON coach_messages FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = coach_messages.course_id
      AND courses.instructor_id = auth.uid()
    ) AND auth.uid() = sender_id
  );

CREATE POLICY "Students can send messages"
  ON coach_messages FOR INSERT
  WITH CHECK (
    auth.uid() = student_id AND
    auth.uid() = sender_id AND
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE enrollments.user_id = auth.uid()
      AND enrollments.course_id = coach_messages.course_id
    )
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_coach_messages_student_course_time
  ON coach_messages(student_id, course_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_coach_messages_course_time
  ON coach_messages(course_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_coach_messages_lesson
  ON coach_messages(lesson_id);

-- Check if coach_messages is already in the publication before adding it
DO $$
DECLARE
  table_exists BOOLEAN;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND schemaname = 'public' 
    AND tablename = 'coach_messages'
  ) INTO table_exists;
  
  IF NOT table_exists THEN
    -- Add the table to the publication
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.coach_messages';
  END IF;
END $$;