/*
  # Course Creation Schema

  1. Storage Policies
    - Enable RLS on storage buckets and objects
    - Allow coaches to create and manage course buckets
    - Allow public read access to course content
    - Enforce instructor-only access for course content management

  2. Security
    - Bucket and object level policies
    - Coach-only bucket creation
    - Public read access
    - Instructor-specific write access
*/

-- Enable RLS on storage buckets and objects
ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Allow coaches to create and manage course buckets
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'buckets' 
    AND schemaname = 'storage'
    AND policyname = 'Coaches can create and manage course buckets'
  ) THEN
    CREATE POLICY "Coaches can create and manage course buckets"
    ON storage.buckets
    FOR ALL
    TO public
    USING (
      EXISTS (
        SELECT 1 FROM public.profiles
        WHERE profiles.id = auth.uid()
        AND profiles.is_coach = true
      )
    )
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM public.profiles
        WHERE profiles.id = auth.uid()
        AND profiles.is_coach = true
      )
    );
  END IF;
END $$;

-- Allow public read access to course buckets
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'buckets' 
    AND schemaname = 'storage'
    AND policyname = 'Public can read course buckets'
  ) THEN
    CREATE POLICY "Public can read course buckets"
    ON storage.buckets
    FOR SELECT
    TO public
    USING (true);
  END IF;
END $$;

-- Allow instructors to manage their course objects
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage'
    AND policyname = 'Instructors can manage course objects'
  ) THEN
    CREATE POLICY "Instructors can manage course objects"
    ON storage.objects
    FOR ALL 
    TO public
    USING (
      bucket_id IN (
        SELECT b.id FROM storage.buckets b
        JOIN public.courses c ON c.id::text = b.name
        WHERE c.instructor_id = auth.uid()
      )
    )
    WITH CHECK (
      bucket_id IN (
        SELECT b.id FROM storage.buckets b
        JOIN public.courses c ON c.id::text = b.name
        WHERE c.instructor_id = auth.uid()
      )
    );
  END IF;
END $$;

-- Allow public read access to course objects
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND schemaname = 'storage'
    AND policyname = 'Public can read course objects'
  ) THEN
    CREATE POLICY "Public can read course objects"
    ON storage.objects
    FOR SELECT
    TO public
    USING (true);
  END IF;
END $$;