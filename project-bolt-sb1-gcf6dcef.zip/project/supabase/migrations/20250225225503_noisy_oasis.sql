/*
  # Add Chat System

  1. New Tables
    - `chat_channels`
      - `id` (uuid, primary key)
      - `course_id` (uuid, references courses)
      - `name` (text) - Channel name (e.g., 'general', 'tricks', 'wins')
      - `description` (text)
      - `created_at` (timestamptz)

    - `chat_messages`
      - `id` (uuid, primary key)
      - `channel_id` (uuid, references chat_channels)
      - `user_id` (uuid, references profiles)
      - `content` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `parent_id` (uuid, self-reference for replies)
      - `metadata` (jsonb) - For additional message data (attachments, etc.)

  2. Security
    - Enable RLS on both tables
    - Add policies for reading and writing messages
*/

-- Create chat_channels table
CREATE TABLE chat_channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(course_id, name)
);

-- Create chat_messages table
CREATE TABLE chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id uuid REFERENCES chat_channels(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  parent_id uuid REFERENCES chat_messages(id) ON DELETE CASCADE,
  metadata jsonb DEFAULT '{}'::jsonb,
  CONSTRAINT content_not_empty CHECK (char_length(trim(content)) > 0)
);

-- Enable RLS
ALTER TABLE chat_channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- Policies for chat_channels
CREATE POLICY "Chat channels are viewable by enrolled users"
  ON chat_channels FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE enrollments.course_id = chat_channels.course_id
      AND enrollments.user_id = auth.uid()
    )
  );

-- Policies for chat_messages
CREATE POLICY "Chat messages are viewable by enrolled users"
  ON chat_messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM chat_channels
      JOIN enrollments ON enrollments.course_id = chat_channels.course_id
      WHERE chat_channels.id = chat_messages.channel_id
      AND enrollments.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create messages in channels they have access to"
  ON chat_messages FOR INSERT
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM chat_channels
      JOIN enrollments ON enrollments.course_id = chat_channels.course_id
      WHERE chat_channels.id = chat_messages.channel_id
      AND enrollments.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update their own messages"
  ON chat_messages FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own messages"
  ON chat_messages FOR DELETE
  USING (auth.uid() = user_id);

-- Function to create default channels for a course
CREATE OR REPLACE FUNCTION create_default_channels()
RETURNS trigger AS $$
BEGIN
  -- Create default channels for the new course
  INSERT INTO chat_channels (course_id, name, description)
  VALUES
    (NEW.id, 'general', 'General discussion about the course'),
    (NEW.id, 'tricks', 'Share and discuss tricks and techniques'),
    (NEW.id, 'wins', 'Celebrate your achievements and progress');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create default channels when a course is created
CREATE TRIGGER create_course_channels
  AFTER INSERT ON courses
  FOR EACH ROW
  EXECUTE FUNCTION create_default_channels();

-- Create default channels for existing courses
INSERT INTO chat_channels (course_id, name, description)
SELECT id, 'general', 'General discussion about the course'
FROM courses
WHERE NOT EXISTS (
  SELECT 1 FROM chat_channels
  WHERE chat_channels.course_id = courses.id
  AND chat_channels.name = 'general'
);

INSERT INTO chat_channels (course_id, name, description)
SELECT id, 'tricks', 'Share and discuss tricks and techniques'
FROM courses
WHERE NOT EXISTS (
  SELECT 1 FROM chat_channels
  WHERE chat_channels.course_id = courses.id
  AND chat_channels.name = 'tricks'
);

INSERT INTO chat_channels (course_id, name, description)
SELECT id, 'wins', 'Celebrate your achievements and progress'
FROM courses
WHERE NOT EXISTS (
  SELECT 1 FROM chat_channels
  WHERE chat_channels.course_id = courses.id
  AND chat_channels.name = 'wins'
);