-- Create course_rankings table to store user rankings
CREATE TABLE IF NOT EXISTS course_rankings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  points integer DEFAULT 0,
  level integer DEFAULT 1,
  completed_lessons_count integer DEFAULT 0,
  total_watch_time numeric DEFAULT 0,
  last_active timestamptz DEFAULT now(),
  rank integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(course_id, user_id)
);

-- Enable RLS
ALTER TABLE course_rankings ENABLE ROW LEVEL SECURITY;

-- Create policy to allow anyone to view rankings
CREATE POLICY "Rankings are viewable by everyone"
  ON course_rankings FOR SELECT
  USING (true);

-- Create policy to allow system to update rankings
CREATE POLICY "System can update rankings"
  ON course_rankings FOR ALL
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

-- Create indexes for better performance
CREATE INDEX idx_course_rankings_course_points 
  ON course_rankings(course_id, points DESC);
CREATE INDEX idx_course_rankings_user 
  ON course_rankings(user_id);
CREATE INDEX idx_course_rankings_last_active 
  ON course_rankings(last_active DESC);

-- Function to calculate and update rankings for a course
CREATE OR REPLACE FUNCTION calculate_course_rankings(course_id_param uuid)
RETURNS void AS $$
BEGIN
  -- First, update points and levels for all users in the course
  WITH user_stats AS (
    SELECT 
      e.user_id,
      COUNT(cl.id) as completed_count,
      COALESCE(SUM(vp.watched_seconds), 0) as watch_time,
      GREATEST(MAX(cl.completed_at), MAX(vp.last_watched_at), e.enrolled_at) as last_active_at
    FROM enrollments e
    LEFT JOIN completed_lessons cl ON cl.user_id = e.user_id AND cl.course_id = e.course_id
    LEFT JOIN video_progress vp ON vp.user_id = e.user_id AND vp.course_id = e.course_id
    WHERE e.course_id = course_id_param
    GROUP BY e.user_id, e.enrolled_at
  )
  INSERT INTO course_rankings (
    course_id,
    user_id,
    points,
    level,
    completed_lessons_count,
    total_watch_time,
    last_active,
    rank
  )
  SELECT 
    course_id_param,
    us.user_id,
    us.completed_count * 100,
    GREATEST(1, FLOOR(us.completed_count::float / 3)::integer + 1),
    us.completed_count,
    us.watch_time,
    us.last_active_at,
    RANK() OVER (
      ORDER BY 
        us.completed_count DESC,
        us.watch_time DESC,
        us.last_active_at DESC
    )
  FROM user_stats us
  ON CONFLICT (course_id, user_id) DO UPDATE SET
    points = EXCLUDED.points,
    level = EXCLUDED.level,
    completed_lessons_count = EXCLUDED.completed_lessons_count,
    total_watch_time = EXCLUDED.total_watch_time,
    last_active = EXCLUDED.last_active,
    rank = EXCLUDED.rank,
    updated_at = now();
END;
$$ LANGUAGE plpgsql;

-- Function to update rankings when lessons are completed
CREATE OR REPLACE FUNCTION update_rankings_on_completion()
RETURNS trigger AS $$
BEGIN
  -- Calculate rankings for the affected course
  PERFORM calculate_course_rankings(
    CASE TG_OP 
      WHEN 'DELETE' THEN OLD.course_id
      ELSE NEW.course_id
    END
  );
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Function to update rankings when video progress changes
CREATE OR REPLACE FUNCTION update_rankings_on_progress()
RETURNS trigger AS $$
BEGIN
  -- Calculate rankings for the affected course
  PERFORM calculate_course_rankings(NEW.course_id);
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for ranking updates
DROP TRIGGER IF EXISTS rankings_completion_trigger ON completed_lessons;
CREATE TRIGGER rankings_completion_trigger
  AFTER INSERT OR DELETE ON completed_lessons
  FOR EACH ROW
  EXECUTE FUNCTION update_rankings_on_completion();

DROP TRIGGER IF EXISTS rankings_progress_trigger ON video_progress;
CREATE TRIGGER rankings_progress_trigger
  AFTER INSERT OR UPDATE ON video_progress
  FOR EACH ROW
  EXECUTE FUNCTION update_rankings_on_progress();

-- Initialize rankings for all courses
DO $$
DECLARE
  course_rec RECORD;
BEGIN
  FOR course_rec IN SELECT id FROM courses LOOP
    PERFORM calculate_course_rankings(course_rec.id);
  END LOOP;
END $$;