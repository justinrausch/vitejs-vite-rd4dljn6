/*
  # Add channel deletion cascade and fix private channels

  1. Changes
    - Add ON DELETE CASCADE to chat_messages foreign key
    - Update chat_messages policies for private channels
    - Add policy for channel deletion

  2. Security
    - Only course instructors can delete channels
    - Messages are automatically deleted when channel is deleted
*/

-- First ensure the chat_messages foreign key has ON DELETE CASCADE
ALTER TABLE chat_messages
  DROP CONSTRAINT IF EXISTS chat_messages_channel_id_fkey,
  ADD CONSTRAINT chat_messages_channel_id_fkey
    FOREIGN KEY (channel_id)
    REFERENCES chat_channels(id)
    ON DELETE CASCADE;

-- Add policy for channel deletion
CREATE POLICY "Course instructors can delete channels"
  ON chat_channels
  FOR DELETE
  TO public
  USING (
    EXISTS (
      SELECT 1
      FROM courses
      WHERE courses.id = chat_channels.course_id
      AND courses.instructor_id = auth.uid()
    )
  );