-- Drop existing storage policies
DO $$ 
BEGIN
  -- Drop policies for course_videos bucket
  DROP POLICY IF EXISTS "Instructors can upload course videos" ON storage.objects;
  DROP POLICY IF EXISTS "Instructors can update their own videos" ON storage.objects;
  DROP POLICY IF EXISTS "Instructors can delete their own videos" ON storage.objects;
  DROP POLICY IF EXISTS "Enrolled users can view course videos" ON storage.objects;
  DROP POLICY IF EXISTS "Coaches can manage course videos" ON storage.objects;
  DROP POLICY IF EXISTS "Coaches can upload files" ON storage.objects;
  
  -- Drop policies for public bucket
  DROP POLICY IF EXISTS "Public Access" ON storage.objects;
  DROP POLICY IF EXISTS "Authenticated users can upload" ON storage.objects;
  DROP POLICY IF EXISTS "Users can update their own objects" ON storage.objects;
  DROP POLICY IF EXISTS "Users can delete their own objects" ON storage.objects;
END $$;

-- Create new storage policies
DO $$ 
BEGIN
  -- Allow public access to read objects from public bucket
  CREATE POLICY "Public Access"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'public');

  -- Allow authenticated users to upload to public bucket
  CREATE POLICY "Authenticated users can upload"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id = 'public' AND
      auth.role() = 'authenticated'
    );

  -- Allow users to update their own objects
  CREATE POLICY "Users can update their own objects"
    ON storage.objects FOR UPDATE
    USING (
      bucket_id = 'public' AND
      auth.uid()::text = (storage.foldername(name))[1]
    );

  -- Allow users to delete their own objects
  CREATE POLICY "Users can delete their own objects"
    ON storage.objects FOR DELETE
    USING (
      bucket_id = 'public' AND
      auth.uid()::text = (storage.foldername(name))[1]
    );

  -- Allow coaches to manage course videos
  CREATE POLICY "Coaches can manage course videos v2"
    ON storage.objects FOR ALL
    USING (
      bucket_id IN ('course_videos', 'public') AND
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = auth.uid()
        AND is_coach = true
      )
    );
END $$;

-- Create buckets if they don't exist
INSERT INTO storage.buckets (id, name, public)
VALUES 
  ('public', 'public', true),
  ('course_videos', 'course_videos', false)
ON CONFLICT (id) DO NOTHING;