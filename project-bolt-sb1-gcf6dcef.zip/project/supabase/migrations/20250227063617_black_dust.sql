-- Create bookmarked_lessons table if it doesn't exist
CREATE TABLE IF NOT EXISTS bookmarked_lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
  lesson_id uuid REFERENCES course_lessons(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, lesson_id)
);

-- Enable RLS on the bookmarked_lessons table
ALTER TABLE bookmarked_lessons ENABLE ROW LEVEL SECURITY;

-- Create policies for the bookmarked_lessons table
CREATE POLICY "Users can view their own bookmarked lessons"
  ON bookmarked_lessons FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can bookmark lessons"
  ON bookmarked_lessons FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove their bookmarks"
  ON bookmarked_lessons FOR DELETE
  USING (auth.uid() = user_id);

-- Add index for faster queries
CREATE INDEX IF NOT EXISTS idx_bookmarked_lessons_user_course
  ON bookmarked_lessons(user_id, course_id);

-- Update the clean_up_course_data function to also clean up bookmarks
CREATE OR REPLACE FUNCTION clean_up_course_data()
RETURNS trigger AS $$
BEGIN
  -- Delete completed lessons
  DELETE FROM completed_lessons
  WHERE user_id = OLD.user_id
  AND course_id = OLD.course_id;

  -- Delete bookmarked lessons
  DELETE FROM bookmarked_lessons
  WHERE user_id = OLD.user_id
  AND course_id = OLD.course_id;

  -- Delete chat messages
  DELETE FROM chat_messages
  WHERE user_id = OLD.user_id
  AND channel_id IN (
    SELECT id FROM chat_channels
    WHERE course_id = OLD.course_id
  );

  RETURN OLD;
END;
$$ LANGUAGE plpgsql;