-- Make category field nullable and add default value
ALTER TABLE courses ALTER COLUMN category DROP NOT NULL;
ALTER TABLE courses ALTER COLUMN category SET DEFAULT 'general';

-- Update storage policies to be more permissive for course creation
DO $$ 
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Instructors can upload course videos" ON storage.objects;
  DROP POLICY IF EXISTS "Instructors can update their own videos" ON storage.objects;
  DROP POLICY IF EXISTS "Instructors can delete their own videos" ON storage.objects;
  
  -- Create more permissive policies for coaches
  CREATE POLICY "Coaches can manage course videos"
    ON storage.objects
    USING (
      bucket_id IN ('course_videos', 'public') AND
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = auth.uid()
        AND is_coach = true
      )
    );

  -- Allow coaches to insert files
  CREATE POLICY "Coaches can upload files"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id IN ('course_videos', 'public') AND
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = auth.uid()
        AND is_coach = true
      )
    );
END $$;

-- Update course creation function to handle null category
CREATE OR REPLACE FUNCTION create_course_with_chapters(
  p_title text,
  p_tagline text,
  p_description text,
  p_image_url text,
  p_price numeric,
  p_sport text,
  p_disciplines text[],
  p_instructor_id uuid
) RETURNS uuid AS $$
DECLARE
  v_course_id uuid;
BEGIN
  -- Insert the course with a default category
  INSERT INTO courses (
    title,
    tagline,
    description,
    image_url,
    price,
    sport,
    disciplines,
    instructor_id,
    category
  ) VALUES (
    p_title,
    p_tagline,
    p_description,
    p_image_url,
    p_price,
    p_sport,
    p_disciplines,
    p_instructor_id,
    'general'
  ) RETURNING id INTO v_course_id;

  -- Return the new course ID
  RETURN v_course_id;
END;
$$ LANGUAGE plpgsql;

-- Update RLS policies for courses
DO $$ 
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Courses are viewable by everyone" ON courses;
  DROP POLICY IF EXISTS "Instructors can create courses" ON courses;
  DROP POLICY IF EXISTS "Instructors can update their own courses" ON courses;

  -- Create new policies
  CREATE POLICY "Courses are viewable by everyone"
    ON courses FOR SELECT
    USING (true);

  CREATE POLICY "Coaches can create courses"
    ON courses FOR INSERT
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = auth.uid()
        AND is_coach = true
      )
    );

  CREATE POLICY "Coaches can update their own courses"
    ON courses FOR UPDATE
    USING (
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = auth.uid()
        AND is_coach = true
      )
    );

  CREATE POLICY "Coaches can delete their own courses"
    ON courses FOR DELETE
    USING (
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = auth.uid()
        AND is_coach = true
      )
    );
END $$;