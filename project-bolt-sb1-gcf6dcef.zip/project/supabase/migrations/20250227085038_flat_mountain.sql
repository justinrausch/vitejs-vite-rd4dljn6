-- Create a private bucket for course videos
CREATE TABLE IF NOT EXISTS storage.buckets (
  id text PRIMARY KEY,
  name text NOT NULL,
  owner uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  public boolean DEFAULT false
);

-- Insert the course_videos bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('course_videos', 'course_videos', false)
ON CONFLICT (id) DO NOTHING;

-- Allow instructors to upload videos for their courses
CREATE POLICY "Instructors can upload course videos"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'course_videos' AND
  EXISTS (
    SELECT 1 FROM courses
    WHERE courses.instructor_id = auth.uid()
  )
);

-- Allow instructors to update their own videos
CREATE POLICY "Instructors can update their own videos"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'course_videos' AND
  EXISTS (
    SELECT 1 FROM courses
    WHERE courses.instructor_id = auth.uid()
  )
);

-- Allow instructors to delete their own videos
CREATE POLICY "Instructors can delete their own videos"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'course_videos' AND
  EXISTS (
    SELECT 1 FROM courses
    WHERE courses.instructor_id = auth.uid()
  )
);

-- Allow enrolled users to view course videos
CREATE POLICY "Enrolled users can view course videos"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'course_videos' AND
  EXISTS (
    SELECT 1 FROM enrollments
    JOIN course_lessons ON course_lessons.id::text = split_part(name, '/', 1)
    JOIN course_chapters ON course_chapters.id = course_lessons.chapter_id
    WHERE enrollments.user_id = auth.uid()
    AND enrollments.course_id = course_chapters.course_id
  )
);