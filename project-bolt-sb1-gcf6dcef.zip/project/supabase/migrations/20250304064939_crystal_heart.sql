-- Drop and recreate policies for course_rankings
DO $$ 
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Rankings are viewable by everyone" ON course_rankings;
  DROP POLICY IF EXISTS "System can update rankings" ON course_rankings;

  -- Create new, more permissive policies
  CREATE POLICY "Anyone can view all rankings"
    ON course_rankings FOR SELECT
    USING (true);

  CREATE POLICY "System can update rankings"
    ON course_rankings FOR INSERT
    WITH CHECK (true);

  CREATE POLICY "System can modify rankings"
    ON course_rankings FOR UPDATE
    USING (true);
END $$;

-- Create a function to debug ranking issues
CREATE OR REPLACE FUNCTION debug_course_rankings(course_id_param uuid)
RETURNS TABLE (
  user_id uuid,
  username text,
  completed_count bigint,
  points bigint,
  level integer,
  last_completion timestamptz,
  last_progress timestamptz,
  enrollment_date timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.username,
    COUNT(DISTINCT cl.id) as completed_count,
    COUNT(DISTINCT cl.id) * 100 as points,
    GREATEST(1, FLOOR(COUNT(DISTINCT cl.id)::float / 3)::integer + 1) as level,
    MAX(cl.completed_at) as last_completion,
    MAX(vp.last_watched_at) as last_progress,
    e.enrolled_at
  FROM enrollments e
  JOIN profiles p ON p.id = e.user_id
  LEFT JOIN completed_lessons cl ON cl.user_id = p.id AND cl.course_id = course_id_param
  LEFT JOIN video_progress vp ON vp.user_id = p.id AND vp.course_id = course_id_param
  WHERE e.course_id = course_id_param
  GROUP BY p.id, p.username, e.enrolled_at
  ORDER BY points DESC, last_completion DESC NULLS LAST;
END;
$$ LANGUAGE plpgsql;

-- Function to force refresh rankings
CREATE OR REPLACE FUNCTION force_refresh_rankings(course_id_param uuid)
RETURNS void AS $$
BEGIN
  -- Clear existing rankings
  DELETE FROM course_rankings WHERE course_id = course_id_param;
  
  -- Recalculate rankings
  WITH user_stats AS (
    SELECT 
      p.id as user_id,
      COUNT(DISTINCT cl.id) as completed_count,
      COUNT(DISTINCT cl.id) * 100 as points,
      GREATEST(1, FLOOR(COUNT(DISTINCT cl.id)::float / 3)::integer + 1) as level,
      COALESCE(SUM(vp.watched_seconds), 0) as total_watch_time,
      GREATEST(MAX(cl.completed_at), MAX(vp.last_watched_at), e.enrolled_at) as last_active
    FROM enrollments e
    JOIN profiles p ON p.id = e.user_id
    LEFT JOIN completed_lessons cl ON cl.user_id = p.id AND cl.course_id = course_id_param
    LEFT JOIN video_progress vp ON vp.user_id = p.id AND vp.course_id = course_id_param
    WHERE e.course_id = course_id_param
    GROUP BY p.id, e.enrolled_at
  )
  INSERT INTO course_rankings (
    course_id,
    user_id,
    points,
    level,
    completed_lessons_count,
    total_watch_time,
    last_active,
    rank
  )
  SELECT 
    course_id_param,
    us.user_id,
    us.points,
    us.level,
    us.completed_count,
    us.total_watch_time,
    us.last_active,
    RANK() OVER (ORDER BY us.points DESC, us.total_watch_time DESC)
  FROM user_stats us;

  -- Notify about the refresh
  PERFORM pg_notify(
    'rankings_refreshed',
    json_build_object(
      'course_id', course_id_param,
      'timestamp', now()
    )::text
  );
END;
$$ LANGUAGE plpgsql;