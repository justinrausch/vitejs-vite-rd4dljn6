/*
  # Add message reactions

  1. New Tables
    - `message_reactions`
      - `id` (uuid, primary key)
      - `message_id` (uuid, references chat_messages)
      - `user_id` (uuid, references profiles)
      - `emoji` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `message_reactions` table
    - Add policies for viewing and managing reactions
    - Add unique constraint to prevent duplicate reactions

  3. Indexes
    - Add indexes for better query performance
*/

-- Create message reactions table if it doesn't exist
CREATE TABLE IF NOT EXISTS message_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES chat_messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  emoji text NOT NULL,
  created_at timestamptz DEFAULT now(),
  
  -- Prevent duplicate reactions from same user with same emoji
  UNIQUE(message_id, user_id, emoji)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_message_reactions_message_id ON message_reactions(message_id);
CREATE INDEX IF NOT EXISTS idx_message_reactions_user_id ON message_reactions(user_id);

-- Enable RLS
ALTER TABLE message_reactions ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Everyone can view reactions" ON message_reactions;
  DROP POLICY IF EXISTS "Users can add reactions" ON message_reactions;
  DROP POLICY IF EXISTS "Users can remove their reactions" ON message_reactions;
END $$;

-- Create policies
CREATE POLICY "Everyone can view reactions" ON message_reactions
  FOR SELECT TO public
  USING (true);

CREATE POLICY "Users can add reactions" ON message_reactions
  FOR INSERT TO public
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove their reactions" ON message_reactions
  FOR DELETE TO public
  USING (auth.uid() = user_id);