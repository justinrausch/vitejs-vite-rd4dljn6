/*
  # Fix Course Rankings and Member Count

  1. New Features
    - Add member_count column to courses table
    - Create trigger to automatically update member_count when users enroll or leave
    - Fix ranking queries to show all enrolled users

  2. Changes
    - Add member_count column to courses table if it doesn't exist
    - Create or replace functions to maintain member count
    - Create triggers for enrollment changes
*/

-- Add member_count column to courses table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'courses' AND column_name = 'member_count'
  ) THEN
    ALTER TABLE courses ADD COLUMN member_count integer DEFAULT 0;
  END IF;
END $$;

-- Create function to update course member count
CREATE OR REPLACE FUNCTION update_course_member_count()
RETURNS trigger AS $$
BEGIN
  -- Update the member count in the courses table
  IF TG_OP = 'INSERT' THEN
    UPDATE courses
    SET member_count = (
      SELECT COUNT(*) FROM enrollments WHERE course_id = NEW.course_id
    )
    WHERE id = NEW.course_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE courses
    SET member_count = (
      SELECT COUNT(*) FROM enrollments WHERE course_id = OLD.course_id
    )
    WHERE id = OLD.course_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for enrollment changes
DROP TRIGGER IF EXISTS enrollment_insert_trigger ON enrollments;
CREATE TRIGGER enrollment_insert_trigger
  AFTER INSERT ON enrollments
  FOR EACH ROW
  EXECUTE FUNCTION update_course_member_count();

DROP TRIGGER IF EXISTS enrollment_delete_trigger ON enrollments;
CREATE TRIGGER enrollment_delete_trigger
  AFTER DELETE ON enrollments
  FOR EACH ROW
  EXECUTE FUNCTION update_course_member_count();

-- Initialize member_count for all courses
UPDATE courses
SET member_count = (
  SELECT COUNT(*) FROM enrollments WHERE course_id = courses.id
);