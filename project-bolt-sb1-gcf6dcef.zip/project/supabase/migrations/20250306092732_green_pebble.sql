/*
  # Fix Rankings System Implementation

  1. Changes
    - Drop existing triggers before functions
    - Drop functions in correct order
    - Clean up stale data
    - Add ranking history tracking
    - Improve validation and logging
    
  2. Security
    - Maintain RLS policies
    - Add audit logging
*/

-- First, drop all triggers to avoid dependency issues
DROP TRIGGER IF EXISTS rankings_completion_trigger ON completed_lessons;
DROP TRIGGER IF EXISTS rankings_enrollment_trigger ON enrollments;
DROP TRIGGER IF EXISTS rankings_progress_trigger ON video_progress;

-- Now drop the functions in correct order
DROP FUNCTION IF EXISTS update_rankings_on_completion();
DROP FUNCTION IF EXISTS update_rankings_on_enrollment();
DROP FUNCTION IF EXISTS update_rankings_on_progress();
DROP FUNCTION IF EXISTS get_course_rankings(UUID);
DROP FUNCTION IF EXISTS update_course_rankings(UUID, UUID);

-- Clean up stale data
DELETE FROM course_rankings cr
WHERE NOT EXISTS (
  SELECT 1 FROM profiles p
  WHERE p.id = cr.user_id
)
OR NOT EXISTS (
  SELECT 1 FROM enrollments e
  WHERE e.user_id = cr.user_id
  AND e.course_id = cr.course_id
);

-- Add ranking history table
CREATE TABLE IF NOT EXISTS ranking_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  points INTEGER NOT NULL,
  level INTEGER NOT NULL,
  rank INTEGER NOT NULL,
  recorded_at TIMESTAMPTZ DEFAULT now(),
  reason TEXT NOT NULL
);

-- Enable RLS on history table
ALTER TABLE ranking_history ENABLE ROW LEVEL SECURITY;

-- Add RLS policy for history table
CREATE POLICY "Ranking history viewable by everyone" ON ranking_history
  FOR SELECT TO public
  USING (true);

-- Add audit logging function
CREATE OR REPLACE FUNCTION log_ranking_change(
  p_user_id UUID,
  p_course_id UUID,
  p_points INTEGER,
  p_level INTEGER,
  p_rank INTEGER,
  p_reason TEXT
) RETURNS VOID AS $$
BEGIN
  INSERT INTO ranking_history (
    user_id,
    course_id,
    points,
    level,
    rank,
    reason
  ) VALUES (
    p_user_id,
    p_course_id,
    p_points,
    p_level,
    p_rank,
    p_reason
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create the main ranking update function
CREATE OR REPLACE FUNCTION update_course_rankings(
  p_course_id UUID,
  p_user_id UUID
) RETURNS VOID AS $$
DECLARE
  v_points INTEGER;
  v_completed_count INTEGER;
  v_level INTEGER;
  v_is_enrolled BOOLEAN;
  v_old_rank INTEGER;
  v_new_rank INTEGER;
  v_watch_time NUMERIC;
BEGIN
  -- Verify user exists and is enrolled
  SELECT EXISTS (
    SELECT 1 FROM enrollments
    WHERE user_id = p_user_id AND course_id = p_course_id
  ) INTO v_is_enrolled;

  IF NOT v_is_enrolled THEN
    RETURN;
  END IF;

  -- Get completed lessons count
  SELECT COUNT(*)
  INTO v_completed_count
  FROM completed_lessons cl
  JOIN course_lessons l ON l.id = cl.lesson_id
  JOIN course_chapters ch ON ch.id = l.chapter_id
  WHERE cl.user_id = p_user_id 
    AND cl.course_id = p_course_id
    AND ch.course_id = p_course_id;

  -- Get total watch time
  SELECT COALESCE(SUM(watched_seconds), 0)
  INTO v_watch_time
  FROM video_progress
  WHERE user_id = p_user_id
    AND course_id = p_course_id;
  
  -- Calculate points
  v_points := v_completed_count * 100 + FLOOR(v_watch_time / 60);
  v_level := GREATEST(1, FLOOR(v_completed_count::float / 3) + 1);

  -- Get old rank for logging
  SELECT rank 
  INTO v_old_rank
  FROM course_rankings
  WHERE course_id = p_course_id AND user_id = p_user_id;
  
  -- Update rankings
  INSERT INTO course_rankings (
    course_id,
    user_id,
    points,
    level,
    completed_lessons_count,
    total_watch_time,
    last_active
  ) VALUES (
    p_course_id,
    p_user_id,
    v_points,
    v_level,
    v_completed_count,
    v_watch_time,
    NOW()
  )
  ON CONFLICT (course_id, user_id) DO UPDATE SET
    points = EXCLUDED.points,
    level = EXCLUDED.level,
    completed_lessons_count = EXCLUDED.completed_lessons_count,
    total_watch_time = EXCLUDED.total_watch_time,
    last_active = EXCLUDED.last_active,
    updated_at = NOW();

  -- Update ranks
  WITH ranked_users AS (
    SELECT 
      id,
      ROW_NUMBER() OVER (
        PARTITION BY course_id 
        ORDER BY points DESC, completed_lessons_count DESC, total_watch_time DESC, last_active DESC
      ) as new_rank
    FROM course_rankings
    WHERE course_id = p_course_id
    AND EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = course_rankings.user_id
    )
  )
  UPDATE course_rankings cr
  SET rank = ru.new_rank
  FROM ranked_users ru
  WHERE cr.id = ru.id;

  -- Get new rank and log change
  SELECT rank 
  INTO v_new_rank
  FROM course_rankings
  WHERE course_id = p_course_id AND user_id = p_user_id;

  IF v_old_rank IS NULL OR v_old_rank != v_new_rank THEN
    PERFORM log_ranking_change(
      p_user_id,
      p_course_id,
      v_points,
      v_level,
      v_new_rank,
      CASE
        WHEN v_old_rank IS NULL THEN 'Initial ranking'
        WHEN v_new_rank < v_old_rank THEN 'Rank improved'
        ELSE 'Rank decreased'
      END
    );
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create the rankings query function
CREATE OR REPLACE FUNCTION get_course_rankings(course_id_param UUID)
RETURNS TABLE (
  id UUID,
  user_id UUID,
  username TEXT,
  avatar_url TEXT,
  is_coach BOOLEAN,
  email TEXT,
  completed_lessons_count INTEGER,
  points INTEGER,
  level INTEGER,
  rank INTEGER,
  total_watch_time NUMERIC,
  last_active TIMESTAMPTZ
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    cr.user_id,
    p.username,
    p.avatar_url,
    p.is_coach,
    p.email,
    cr.completed_lessons_count,
    cr.points,
    cr.level,
    cr.rank,
    cr.total_watch_time,
    cr.last_active
  FROM course_rankings cr
  JOIN profiles p ON p.id = cr.user_id
  WHERE cr.course_id = course_id_param
  AND EXISTS (
    SELECT 1 FROM enrollments e
    WHERE e.user_id = cr.user_id
    AND e.course_id = cr.course_id
  )
  ORDER BY cr.rank ASC NULLS LAST;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger functions
CREATE OR REPLACE FUNCTION update_rankings_on_completion() 
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM update_course_rankings(NEW.course_id, NEW.user_id);
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM update_course_rankings(OLD.course_id, OLD.user_id);
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION update_rankings_on_enrollment() 
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO course_rankings (
      course_id,
      user_id,
      points,
      level,
      completed_lessons_count,
      total_watch_time,
      last_active
    ) VALUES (
      NEW.course_id,
      NEW.user_id,
      0,
      1,
      0,
      0,
      NOW()
    );
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION update_rankings_on_progress() 
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    PERFORM update_course_rankings(NEW.course_id, NEW.user_id);
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create triggers
CREATE TRIGGER rankings_completion_trigger
  AFTER INSERT OR DELETE ON completed_lessons
  FOR EACH ROW
  EXECUTE FUNCTION update_rankings_on_completion();

CREATE TRIGGER rankings_enrollment_trigger
  AFTER INSERT ON enrollments
  FOR EACH ROW
  EXECUTE FUNCTION update_rankings_on_enrollment();

CREATE TRIGGER rankings_progress_trigger
  AFTER INSERT OR UPDATE ON video_progress
  FOR EACH ROW
  EXECUTE FUNCTION update_rankings_on_progress();

-- Recalculate all rankings
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN (
    SELECT DISTINCT e.course_id, e.user_id
    FROM enrollments e
    JOIN profiles p ON p.id = e.user_id
  ) LOOP
    PERFORM update_course_rankings(r.course_id, r.user_id);
  END LOOP;
END $$;