/*
  # Fix user registration and profile loading

  1. Updates
    - Fix the handle_new_user function to properly create profiles
    - Ensure username is set from email or user_metadata
    - Add fallback for avatar_url
  2. Fixes
    - Addresses "user_already_exists" error during registration
    - Fixes profile loading errors
*/

-- Drop and recreate the function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  -- Extract username from metadata or email
  DECLARE
    username_val text;
    avatar_url_val text;
  BEGIN
    -- Get username from metadata or fallback to email
    IF new.raw_user_meta_data->>'username' IS NOT NULL THEN
      username_val := new.raw_user_meta_data->>'username';
    ELSE
      username_val := split_part(new.email, '@', 1);
    END IF;
    
    -- Get avatar URL if available
    avatar_url_val := new.raw_user_meta_data->>'avatar_url';
    
    -- Insert into profiles with proper values
    INSERT INTO public.profiles (
      id, 
      username, 
      avatar_url,
      updated_at
    )
    VALUES (
      new.id, 
      username_val, 
      avatar_url_val,
      now()
    )
    ON CONFLICT (id) DO UPDATE
    SET 
      username = EXCLUDED.username,
      avatar_url = EXCLUDED.avatar_url,
      updated_at = now();
      
    RETURN new;
  END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Ensure the trigger exists
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Fix any existing users without profiles
DO $$
DECLARE
  user_rec RECORD;
BEGIN
  FOR user_rec IN 
    SELECT id, email, raw_user_meta_data 
    FROM auth.users 
    WHERE id NOT IN (SELECT id FROM profiles)
  LOOP
    INSERT INTO profiles (
      id, 
      username, 
      avatar_url,
      updated_at
    )
    VALUES (
      user_rec.id, 
      COALESCE(
        user_rec.raw_user_meta_data->>'username', 
        split_part(user_rec.email, '@', 1)
      ),
      user_rec.raw_user_meta_data->>'avatar_url',
      now()
    )
    ON CONFLICT (id) DO NOTHING;
  END LOOP;
END $$;

-- Add unique constraint to username if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'profiles_username_key' 
    AND conrelid = 'profiles'::regclass
  ) THEN
    ALTER TABLE profiles ADD CONSTRAINT profiles_username_key UNIQUE (username);
  END IF;
END $$;