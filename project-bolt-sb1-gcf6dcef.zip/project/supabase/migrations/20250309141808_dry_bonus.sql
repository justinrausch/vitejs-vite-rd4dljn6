/*
  # Fix course rankings RLS policies

  1. Changes
    - Add RLS policies for course_rankings table
    - Allow authenticated users to insert/update their own rankings
    - Allow viewing of all rankings
    - Fix completion tracking policies

  2. Security
    - Enable RLS on course_rankings table
    - Add policies for authenticated users
*/

-- Enable RLS
ALTER TABLE course_rankings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any
DROP POLICY IF EXISTS "Course rankings are viewable by everyone" ON course_rankings;
DROP POLICY IF EXISTS "Rankings can be updated through functions only" ON course_rankings;

-- Create new policies
CREATE POLICY "Course rankings are viewable by everyone"
ON course_rankings
FOR SELECT
TO public
USING (true);

CREATE POLICY "Users can manage their own rankings"
ON course_rankings
FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Ensure completed_lessons policies are correct
DROP POLICY IF EXISTS "Users can mark lessons as completed" ON completed_lessons;
DROP POLICY IF EXISTS "Users can unmark completed lessons" ON completed_lessons;
DROP POLICY IF EXISTS "Users can view their own completed lessons" ON completed_lessons;

CREATE POLICY "Users can mark lessons as completed"
ON completed_lessons
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unmark completed lessons"
ON completed_lessons
FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can view their own completed lessons"
ON completed_lessons
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);