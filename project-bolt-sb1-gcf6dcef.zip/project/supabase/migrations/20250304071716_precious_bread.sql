-- Add read field to coach_messages if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'coach_messages' AND column_name = 'read'
  ) THEN
    ALTER TABLE coach_messages ADD COLUMN read boolean DEFAULT false;
  END IF;
END $$;

-- Create function to mark messages as read
CREATE OR REPLACE FUNCTION mark_messages_read(
  p_course_id uuid,
  p_student_id uuid
) RETURNS void AS $$
BEGIN
  UPDATE coach_messages
  SET read = true
  WHERE course_id = p_course_id
    AND student_id = p_student_id
    AND sender_id = p_student_id
    AND read = false;
END;
$$ LANGUAGE plpgsql;

-- Drop existing function before recreating with new return type
DROP FUNCTION IF EXISTS get_course_rankings(uuid);

-- Create function to get course rankings
CREATE FUNCTION get_course_rankings(course_id_param uuid)
RETURNS TABLE (
  id uuid,
  username text,
  avatar_url text,
  is_coach boolean,
  email text,
  enrolled_at timestamptz,
  completed_lessons_count bigint,
  points bigint,
  level integer
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.username,
    p.avatar_url,
    p.is_coach,
    p.email,
    e.enrolled_at,
    COUNT(cl.id) as completed_lessons_count,
    COUNT(cl.id) * 100 as points,
    GREATEST(1, FLOOR(COUNT(cl.id)::float / 3)::integer + 1) as level
  FROM enrollments e
  JOIN profiles p ON p.id = e.user_id
  LEFT JOIN completed_lessons cl ON cl.user_id = p.id AND cl.course_id = course_id_param
  WHERE e.course_id = course_id_param
  GROUP BY p.id, p.username, p.avatar_url, p.is_coach, p.email, e.enrolled_at
  ORDER BY points DESC, completed_lessons_count DESC, enrolled_at ASC;
END;
$$ LANGUAGE plpgsql;