/*
  # Update instructor profiles and course images

  1. Changes
    - Update instructor profile with proper name and avatar
    - Fix course images for specific courses
*/

DO $$ 
BEGIN
  -- Update instructor profile
  UPDATE profiles
  SET 
    username = 'Christian Arehart',
    avatar_url = 'https://images.unsplash.com/photo-1600486913747-55e5470d6f40?auto=format&fit=crop&q=80'
  WHERE username LIKE '%@%'
  AND id IN (SELECT id FROM profiles ORDER BY updated_at ASC LIMIT 1);

  -- Update course images
  UPDATE courses
  SET image_url = 'https://images.unsplash.com/photo-1622044939799-a87e10f18334?auto=format&fit=crop&q=80'
  WHERE title = 'Freeride Progression';

  UPDATE courses
  SET image_url = 'https://images.unsplash.com/photo-1506316940527-b7b6a24f27c9?auto=format&fit=crop&q=80'
  WHERE title = 'Enduro Racing Mastery';
END $$;