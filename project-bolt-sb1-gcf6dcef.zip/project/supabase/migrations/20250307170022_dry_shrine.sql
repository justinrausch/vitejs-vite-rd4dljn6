/*
  # Course Chapters RLS Policies

  1. Security
    - Enable RLS on course_chapters table
    - Add policies for:
      - Course creators can manage their own chapters
      - Everyone can view chapters
    - Ensure proper cascading deletes
    - Add position column for ordering

  2. Changes
    - Add RLS policies if they don't exist
    - Add indexes for performance
*/

-- Enable RLS if not already enabled
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename = 'course_chapters' 
    AND rowsecurity = true
  ) THEN
    ALTER TABLE course_chapters ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Course creators can manage their own chapters (only create if doesn't exist)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_chapters' 
    AND policyname = 'Course creators can manage chapters'
  ) THEN
    CREATE POLICY "Course creators can manage chapters"
    ON course_chapters
    FOR ALL
    TO authenticated
    USING (
      EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = course_chapters.course_id
        AND courses.instructor_id = auth.uid()
      )
    );
  END IF;
END $$;

-- Everyone can view chapters (only create if doesn't exist)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_chapters' 
    AND policyname = 'Course chapters are viewable by everyone'
  ) THEN
    CREATE POLICY "Course chapters are viewable by everyone"
    ON course_chapters
    FOR SELECT
    TO public
    USING (true);
  END IF;
END $$;

-- Add indexes if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'course_chapters' 
    AND indexname = 'idx_course_chapters_course_id'
  ) THEN
    CREATE INDEX idx_course_chapters_course_id
    ON course_chapters(course_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'course_chapters' 
    AND indexname = 'idx_course_chapters_position'
  ) THEN
    CREATE INDEX idx_course_chapters_position
    ON course_chapters(position);
  END IF;
END $$;