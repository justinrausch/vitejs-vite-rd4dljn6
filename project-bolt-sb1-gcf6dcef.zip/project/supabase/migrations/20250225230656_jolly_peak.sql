/*
  # Fix Chat Real-time Updates

  1. Changes
    - Add trigger for real-time updates
    - Add function to notify on new messages
    - Add indexes for better performance

  2. Performance
    - Add index on channel_id for faster message queries
    - Add index on created_at for message ordering
*/

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS chat_messages_channel_id_idx ON chat_messages(channel_id);
CREATE INDEX IF NOT EXISTS chat_messages_created_at_idx ON chat_messages(created_at);

-- Create function to notify on new messages
CREATE OR REPLACE FUNCTION notify_new_message()
RETURNS trigger AS $$
BEGIN
  PERFORM pg_notify(
    'new_chat_message',
    json_build_object(
      'channel_id', NEW.channel_id,
      'message', json_build_object(
        'id', NEW.id,
        'content', NEW.content,
        'created_at', NEW.created_at,
        'user_id', NEW.user_id
      )
    )::text
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for real-time updates
DROP TRIGGER IF EXISTS chat_messages_notify ON chat_messages;
CREATE TRIGGER chat_messages_notify
  AFTER INSERT ON chat_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_message();