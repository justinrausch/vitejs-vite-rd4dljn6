/*
  # Channel management for coaches

  1. Changes
    - Add RLS policies for coaches to manage channels
    - Allow coaches to create and update channels
    - Ensure only course instructors can manage their course channels

  2. Security
    - Enable policies for channel management
    - Restrict channel management to course instructors only
*/

-- Add policies for channel management
CREATE POLICY "Course instructors can manage channels"
ON chat_channels
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM courses
    WHERE courses.id = chat_channels.course_id
    AND courses.instructor_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM courses
    WHERE courses.id = chat_channels.course_id
    AND courses.instructor_id = auth.uid()
  )
);