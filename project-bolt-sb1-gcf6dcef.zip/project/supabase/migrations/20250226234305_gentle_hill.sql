-- Update course images for Freeride Progression and Enduro Racing Mastery
UPDATE courses
SET image_url = 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?auto=format&fit=crop&q=80'
WHERE title = 'Freeride Progression';

UPDATE courses
SET image_url = 'https://images.unsplash.com/photo-1564417947365-8dbc9d0e718e?auto=format&fit=crop&q=80'
WHERE title = 'Enduro Racing Mastery';