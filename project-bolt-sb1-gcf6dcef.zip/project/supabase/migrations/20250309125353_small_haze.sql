/*
  # Update lessons schema

  1. Changes
    - Make video_url nullable in course_lessons table
    - Add lecture_notes column for storing lesson content
    - Add indexes for better query performance

  2. Security
    - Maintain existing RLS policies
    - No changes to permissions
*/

-- Make video_url nullable (if not already) and add lecture_notes
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'course_lessons' 
    AND column_name = 'lecture_notes'
  ) THEN
    ALTER TABLE course_lessons 
    ADD COLUMN lecture_notes text;
  END IF;
END $$;

-- Add indexes for common queries
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'course_lessons' 
    AND indexname = 'idx_course_lessons_course_id'
  ) THEN
    CREATE INDEX idx_course_lessons_course_id ON course_lessons(course_id);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'course_lessons' 
    AND indexname = 'idx_course_lessons_chapter_id'
  ) THEN
    CREATE INDEX idx_course_lessons_chapter_id ON course_lessons(chapter_id);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'course_lessons' 
    AND indexname = 'idx_course_lessons_chapter_position'
  ) THEN
    CREATE INDEX idx_course_lessons_chapter_position ON course_lessons(chapter_id, position);
  END IF;
END $$;