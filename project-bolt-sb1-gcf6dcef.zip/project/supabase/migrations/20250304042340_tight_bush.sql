-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Anyone can view chat messages" ON chat_messages;
  DROP POLICY IF EXISTS "Authenticated users can create messages" ON chat_messages;
END $$;

-- Create more specific policies for chat messages
CREATE POLICY "Enrolled users can view messages"
  ON chat_messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM enrollments
      JOIN chat_channels ON chat_channels.course_id = enrollments.course_id
      WHERE enrollments.user_id = auth.uid()
      AND chat_channels.id = chat_messages.channel_id
    )
  );

CREATE POLICY "Enrolled users can send messages"
  ON chat_messages FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM enrollments
      JOIN chat_channels ON chat_channels.course_id = enrollments.course_id
      WHERE enrollments.user_id = auth.uid()
      AND chat_channels.id = chat_messages.channel_id
    ) AND auth.uid() = user_id
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_chat_messages_channel_created 
  ON chat_messages(channel_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_chat_messages_user_channel 
  ON chat_messages(user_id, channel_id);

-- Add function to notify on new messages
CREATE OR REPLACE FUNCTION notify_chat_message()
RETURNS trigger AS $$
BEGIN
  PERFORM pg_notify(
    'new_chat_message',
    json_build_object(
      'channel_id', NEW.channel_id,
      'message', json_build_object(
        'id', NEW.id,
        'content', NEW.content,
        'created_at', NEW.created_at,
        'user_id', NEW.user_id
      )
    )::text
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for realtime updates
DROP TRIGGER IF EXISTS chat_messages_notify ON chat_messages;
CREATE TRIGGER chat_messages_notify
  AFTER INSERT ON chat_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_chat_message();

-- Enable realtime for chat_messages
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND schemaname = 'public' 
    AND tablename = 'chat_messages'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE chat_messages;
  END IF;
END $$;