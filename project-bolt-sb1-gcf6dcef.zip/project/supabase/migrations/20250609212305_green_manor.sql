/*
  # Add media support to chat messages

  1. Changes
    - Add `image_url` column to `chat_messages` table
    - Update content constraint to allow empty content when image is present
    - Add storage bucket for chat media

  2. Security
    - Update RLS policies to allow media uploads
*/

-- Add image_url column to chat_messages if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'chat_messages' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE chat_messages ADD COLUMN image_url TEXT;
  END IF;
END $$;

-- Update the constraint to allow empty content if image_url is present
ALTER TABLE chat_messages DROP CONSTRAINT IF EXISTS content_or_image_required;
ALTER TABLE chat_messages ADD CONSTRAINT content_or_image_required 
  CHECK ((char_length(TRIM(BOTH FROM content)) > 0) OR (image_url IS NOT NULL));

-- Create storage bucket for chat media if it doesn't exist
-- Note: In a real implementation, this would be done through Supabase UI or API
-- This is a placeholder to indicate the need for a storage bucket