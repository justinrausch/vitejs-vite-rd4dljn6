/*
  # Add notifications system
  
  1. New Tables
    - `notifications`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `type` (text) - 'course', 'mention', 'reply', 'coaching'
      - `title` (text)
      - `message` (text)
      - `data` (jsonb) - Additional data like course_id, message_id, etc.
      - `read` (boolean)
      - `created_at` (timestamp)
  
  2. Security
    - Enable RLS on notifications table
    - Add policy for users to view their own notifications
    - Add policy for system to create notifications
*/

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  data jsonb DEFAULT '{}'::jsonb,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_created ON notifications(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(user_id) WHERE read = false;

-- Add RLS policies
CREATE POLICY "Users can view their own notifications"
  ON notifications
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can mark their notifications as read"
  ON notifications
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Function to create course notifications
CREATE OR REPLACE FUNCTION notify_new_course()
RETURNS trigger AS $$
BEGIN
  INSERT INTO notifications (user_id, type, title, message, data)
  SELECT 
    e.user_id,
    'course',
    'New Course Available',
    'A new course has been added that you might be interested in: ' || NEW.title,
    jsonb_build_object(
      'course_id', NEW.id,
      'course_title', NEW.title,
      'instructor_id', NEW.instructor_id
    )
  FROM enrollments e
  WHERE e.user_id != NEW.instructor_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to create mention notifications
CREATE OR REPLACE FUNCTION notify_mention()
RETURNS trigger AS $$
DECLARE
  mentioned_users text[];
  username text;
BEGIN
  -- Extract usernames from message content using regex
  SELECT ARRAY(
    SELECT DISTINCT substring(mention from '@([a-zA-Z0-9_]+)')
    FROM regexp_matches(NEW.content, '@([a-zA-Z0-9_]+)', 'g') AS mention
  ) INTO mentioned_users;
  
  -- Create notifications for mentioned users
  FOR username IN SELECT UNNEST(mentioned_users)
  LOOP
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      data
    )
    SELECT 
      p.id,
      'mention',
      'New Mention',
      'You were mentioned in a message by ' || (SELECT username FROM profiles WHERE id = NEW.user_id),
      jsonb_build_object(
        'message_id', NEW.id,
        'channel_id', NEW.channel_id,
        'mentioned_by', NEW.user_id
      )
    FROM profiles p
    WHERE p.username = username
    AND p.id != NEW.user_id;
  END LOOP;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to create reply notifications
CREATE OR REPLACE FUNCTION notify_reply()
RETURNS trigger AS $$
BEGIN
  IF NEW.parent_id IS NOT NULL THEN
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      data
    )
    SELECT 
      m.user_id,
      'reply',
      'New Reply',
      'Someone replied to your message',
      jsonb_build_object(
        'message_id', NEW.id,
        'parent_id', NEW.parent_id,
        'channel_id', NEW.channel_id,
        'replied_by', NEW.user_id
      )
    FROM chat_messages m
    WHERE m.id = NEW.parent_id
    AND m.user_id != NEW.user_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to create coaching notifications
CREATE OR REPLACE FUNCTION notify_coaching_message()
RETURNS trigger AS $$
BEGIN
  -- Only notify if the message is from the coach to the student
  IF EXISTS (
    SELECT 1 FROM courses 
    WHERE id = NEW.course_id 
    AND instructor_id = NEW.sender_id
  ) THEN
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      data
    )
    VALUES (
      NEW.student_id,
      'coaching',
      'New Coach Message',
      'Your coach has replied to your question',
      jsonb_build_object(
        'course_id', NEW.course_id,
        'message_id', NEW.id,
        'coach_id', NEW.sender_id
      )
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER notify_new_course_trigger
  AFTER INSERT ON courses
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_course();

CREATE TRIGGER notify_mention_trigger
  AFTER INSERT ON chat_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_mention();

CREATE TRIGGER notify_reply_trigger
  AFTER INSERT ON chat_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_reply();

CREATE TRIGGER notify_coaching_message_trigger
  AFTER INSERT ON coach_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_coaching_message();