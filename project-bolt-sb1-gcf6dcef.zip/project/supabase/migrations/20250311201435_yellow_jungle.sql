/*
  # Add additional profile fields

  1. Changes
    - Add location field for user's location
    - Add website field for user's website
    - Add birthdate field for user's birthdate
    - Add disciplines array for user's sports
    - Add experience_level field for skill level
*/

-- Add new columns to profiles table
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS location text,
ADD COLUMN IF NOT EXISTS website text,
ADD COLUMN IF NOT EXISTS birthdate date,
ADD COLUMN IF NOT EXISTS disciplines text[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS experience_level text;

-- Add indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_profiles_disciplines ON profiles USING gin(disciplines);
CREATE INDEX IF NOT EXISTS idx_profiles_experience_level ON profiles(experience_level);