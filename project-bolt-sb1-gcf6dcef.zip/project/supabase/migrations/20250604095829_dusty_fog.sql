/*
  # Add feature access controls to course plans

  1. Changes
    - Add feature access columns to course_plans table:
      - lessons_access (boolean, default true)
      - community_access (boolean, default false)
      - coaching_access (boolean, default false)
      - rankings_access (boolean, default false)

  2. Security
    - Maintain existing RLS policies
*/

-- Add feature access columns to course_plans
ALTER TABLE course_plans 
ADD COLUMN IF NOT EXISTS lessons_access boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS community_access boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS coaching_access boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS rankings_access boolean DEFAULT false;