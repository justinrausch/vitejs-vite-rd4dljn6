-- Drop existing storage policies
DO $$ 
BEGIN
  -- Drop policies for course_videos bucket
  DROP POLICY IF EXISTS "Instructors can upload course videos" ON storage.objects;
  DROP POLICY IF EXISTS "Instructors can update their own videos" ON storage.objects;
  DROP POLICY IF EXISTS "Instructors can delete their own videos" ON storage.objects;
  DROP POLICY IF EXISTS "Enrolled users can view course videos" ON storage.objects;
  
  -- Drop policies for public bucket
  DROP POLICY IF EXISTS "Public Access" ON storage.objects;
  DROP POLICY IF EXISTS "Authenticated users can upload" ON storage.objects;
  DROP POLICY IF EXISTS "Users can update their own objects" ON storage.objects;
  DROP POLICY IF EXISTS "Users can delete their own objects" ON storage.objects;
END $$;

-- Create new storage policies
DO $$ 
BEGIN
  -- Allow public access to read objects
  CREATE POLICY "Public Access"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'public');

  -- Allow authenticated users to upload objects
  CREATE POLICY "Authenticated users can upload"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id = 'public' AND
      auth.role() = 'authenticated'
    );

  -- Allow users to update their own objects
  CREATE POLICY "Users can update their own objects"
    ON storage.objects FOR UPDATE
    USING (
      bucket_id = 'public' AND
      auth.uid() = owner
    );

  -- Allow users to delete their own objects
  CREATE POLICY "Users can delete their own objects"
    ON storage.objects FOR DELETE
    USING (
      bucket_id = 'public' AND
      auth.uid() = owner
    );

  -- Allow instructors to upload course videos
  CREATE POLICY "Instructors can upload course videos"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id = 'course_videos' AND
      EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid()
        AND is_coach = true
      )
    );

  -- Allow instructors to update their own videos
  CREATE POLICY "Instructors can update their own videos"
    ON storage.objects FOR UPDATE
    USING (
      bucket_id = 'course_videos' AND
      EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid()
        AND is_coach = true
      )
    );

  -- Allow instructors to delete their own videos
  CREATE POLICY "Instructors can delete their own videos"
    ON storage.objects FOR DELETE
    USING (
      bucket_id = 'course_videos' AND
      EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid()
        AND is_coach = true
      )
    );

  -- Allow enrolled users to view course videos
  CREATE POLICY "Enrolled users can view course videos"
    ON storage.objects FOR SELECT
    USING (
      bucket_id = 'course_videos' AND
      EXISTS (
        SELECT 1 FROM public.enrollments
        WHERE user_id = auth.uid()
      )
    );
END $$;

-- Create course_videos bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('course_videos', 'course_videos', false)
ON CONFLICT (id) DO NOTHING;

-- Create public bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('public', 'public', true)
ON CONFLICT (id) DO NOTHING;

-- Update RLS policies for courses table
DO $$ 
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Courses are viewable by everyone" ON public.courses;
  DROP POLICY IF EXISTS "Instructors can create courses" ON public.courses;
  DROP POLICY IF EXISTS "Instructors can update their own courses" ON public.courses;

  -- Create new policies
  CREATE POLICY "Courses are viewable by everyone"
    ON public.courses FOR SELECT
    USING (true);

  CREATE POLICY "Instructors can create courses"
    ON public.courses FOR INSERT
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid()
        AND is_coach = true
      )
    );

  CREATE POLICY "Instructors can update their own courses"
    ON public.courses FOR UPDATE
    USING (
      EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid()
        AND is_coach = true
      )
    );
END $$;