/*
  # Fix chat messages content constraint

  1. Changes
    - Drop existing content constraint
    - Add new constraint that allows empty content when image is present
    - Ensures messages have either content or an image
*/

-- Drop existing content constraint
ALTER TABLE chat_messages 
DROP CONSTRAINT IF EXISTS content_not_empty;

-- Add new constraint that allows empty content when image is present
ALTER TABLE chat_messages
ADD CONSTRAINT content_or_image_required 
CHECK (
  char_length(trim(content)) > 0 
  OR image_url IS NOT NULL
);