/*
  # Create lesson progress table

  1. New Tables
    - `lesson_progress`
      - `lesson_id` (uuid, references course_lessons)
      - `course_id` (uuid, references courses)
      - `progress` (integer)
      - `watched_seconds` (integer)
      - `last_watched_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

CREATE TABLE IF NOT EXISTS lesson_progress (
  lesson_id uuid REFERENCES course_lessons(id) ON DELETE CASCADE,
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  progress integer DEFAULT 0,
  watched_seconds integer DEFAULT 0,
  last_watched_at timestamptz DEFAULT now(),
  PRIMARY KEY (lesson_id)
);

ALTER TABLE lesson_progress ENABLE ROW LEVEL SECURITY;

CREATE POLICY "lesson_progress_select_policy"
  ON lesson_progress
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "lesson_progress_insert_policy"
  ON lesson_progress
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "lesson_progress_update_policy"
  ON lesson_progress
  FOR UPDATE
  TO authenticated
  USING (true);