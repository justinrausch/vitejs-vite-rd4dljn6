/*
  # Update username for admin user

  1. Changes
     - Update the username for gaspar@mastery.to to be @gaspar
     - Ensure admin users have proper profile information
*/

-- Update the username for gaspar@mastery.to to @gaspar
DO $$ 
BEGIN
  -- Update the username for gaspar@mastery.to
  UPDATE profiles
  SET 
    username = 'gaspar',
    full_name = 'Gaspar Admin'
  WHERE email = 'gaspar@mastery.to';
  
  -- Also ensure justin@mastery.to has a proper username
  UPDATE profiles
  SET 
    username = 'justin',
    full_name = 'Justin Admin'
  WHERE email = 'justin@mastery.to';
  
  -- Make sure both admin users have the proper avatar and description
  UPDATE profiles
  SET 
    avatar_url = 'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?auto=format&fit=crop&q=80',
    description = 'Platform administrator'
  WHERE email IN ('gaspar@mastery.to', 'justin@mastery.to');
END $$;