-- Add disciplines array field to courses table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'courses' AND column_name = 'disciplines'
  ) THEN
    ALTER TABLE courses ADD COLUMN disciplines text[] DEFAULT '{}';
  END IF;
END $$;

-- Add index for better search performance
CREATE INDEX IF NOT EXISTS idx_courses_disciplines ON courses USING gin(disciplines);

-- Update existing courses with sample disciplines
UPDATE courses SET disciplines = CASE 
  WHEN title = 'Mountain Bike Fundamentals' THEN ARRAY['Cross country', 'Trail riding']
  WHEN title = 'Advanced Trail Building' THEN ARRAY['Trail building', 'Design']
  WHEN title = 'Enduro Racing Mastery' THEN ARRAY['Enduro', 'Downhill']
  WHEN title = 'Bike Maintenance Essentials' THEN ARRAY['Maintenance', 'Technical']
  WHEN title = 'Freeride Progression' THEN ARRAY['Freeride', 'Slopestyle', 'Jumping']
  ELSE ARRAY['Skills', 'Technique']
END
WHERE disciplines = '{}' OR disciplines IS NULL;