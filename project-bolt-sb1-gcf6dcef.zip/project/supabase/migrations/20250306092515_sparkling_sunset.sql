/*
  # Clean Up Rankings and Fix Functions

  1. Changes
    - Clean up stale data from rankings and related tables
    - Drop and recreate get_course_rankings function with correct signature
    - Update update_course_rankings function to be more strict
    - Ensure data integrity with proper checks

  2. Security
    - Maintain existing RLS policies
    - Use security definer for functions
*/

-- First drop the existing function to avoid conflicts
DROP FUNCTION IF EXISTS get_course_rankings(UUID);

-- Clean up stale data
DELETE FROM course_rankings cr
WHERE NOT EXISTS (
  SELECT 1 FROM profiles p
  WHERE p.id = cr.user_id
);

DELETE FROM completed_lessons cl
WHERE NOT EXISTS (
  SELECT 1 FROM profiles p
  WHERE p.id = cl.user_id
);

DELETE FROM video_progress vp
WHERE NOT EXISTS (
  SELECT 1 FROM profiles p
  WHERE p.id = vp.user_id
);

-- Update the update_course_rankings function to be more strict
CREATE OR REPLACE FUNCTION update_course_rankings(
  p_course_id UUID,
  p_user_id UUID
) RETURNS VOID AS $$
DECLARE
  v_points INTEGER;
  v_completed_count INTEGER;
  v_level INTEGER;
  v_is_enrolled BOOLEAN;
BEGIN
  -- Check if user exists and is enrolled
  SELECT EXISTS (
    SELECT 1 FROM enrollments
    WHERE user_id = p_user_id AND course_id = p_course_id
  ) INTO v_is_enrolled;

  IF NOT v_is_enrolled THEN
    RETURN;
  END IF;

  -- Get completed lessons count only for valid lessons
  SELECT COUNT(*)
  INTO v_completed_count
  FROM completed_lessons cl
  JOIN course_lessons l ON l.id = cl.lesson_id
  JOIN course_chapters ch ON ch.id = l.chapter_id
  WHERE cl.user_id = p_user_id 
    AND cl.course_id = p_course_id
    AND ch.course_id = p_course_id;
  
  -- Calculate points (100 per completed lesson)
  v_points := v_completed_count * 100;
  
  -- Calculate level (increases every 3 lessons)
  v_level := GREATEST(1, FLOOR(v_completed_count::float / 3) + 1);
  
  -- Update or insert into course_rankings
  INSERT INTO course_rankings (
    course_id,
    user_id,
    points,
    level,
    completed_lessons_count,
    last_active
  ) VALUES (
    p_course_id,
    p_user_id,
    v_points,
    v_level,
    v_completed_count,
    NOW()
  )
  ON CONFLICT (course_id, user_id) DO UPDATE SET
    points = EXCLUDED.points,
    level = EXCLUDED.level,
    completed_lessons_count = EXCLUDED.completed_lessons_count,
    last_active = EXCLUDED.last_active,
    updated_at = NOW();

  -- Update ranks for all valid users in this course
  WITH ranked_users AS (
    SELECT 
      id,
      ROW_NUMBER() OVER (
        PARTITION BY course_id 
        ORDER BY points DESC, completed_lessons_count DESC, last_active DESC
      ) as new_rank
    FROM course_rankings cr
    WHERE course_id = p_course_id
    AND EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = cr.user_id
    )
  )
  UPDATE course_rankings cr
  SET rank = ru.new_rank
  FROM ranked_users ru
  WHERE cr.id = ru.id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new get_course_rankings function with correct signature
CREATE OR REPLACE FUNCTION get_course_rankings(course_id_param UUID)
RETURNS TABLE (
  id UUID,
  user_id UUID,
  username TEXT,
  avatar_url TEXT,
  is_coach BOOLEAN,
  email TEXT,
  completed_lessons_count INTEGER,
  points INTEGER,
  level INTEGER,
  rank INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    cr.user_id,
    p.username,
    p.avatar_url,
    p.is_coach,
    p.email,
    cr.completed_lessons_count,
    cr.points,
    cr.level,
    cr.rank
  FROM course_rankings cr
  JOIN profiles p ON p.id = cr.user_id
  WHERE cr.course_id = course_id_param
  AND EXISTS (
    SELECT 1 FROM enrollments e
    WHERE e.user_id = cr.user_id
    AND e.course_id = cr.course_id
  )
  ORDER BY cr.rank ASC NULLS LAST;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recalculate all rankings to apply the new logic
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN (
    SELECT DISTINCT course_id, user_id 
    FROM enrollments e
    WHERE EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = e.user_id
    )
  ) LOOP
    PERFORM update_course_rankings(r.course_id, r.user_id);
  END LOOP;
END $$;