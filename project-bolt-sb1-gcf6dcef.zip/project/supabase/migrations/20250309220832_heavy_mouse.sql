/*
  # Fix video progress tracking

  1. Changes
    - Create a single video_progress table to replace the monthly partitioned tables
    - Add proper indexes and constraints
    - Add RLS policies for security
    
  2. Structure
    - Single table with user_id, lesson_id, progress tracking
    - Automatically updates last_watched_at on changes
    
  3. Security
    - Enable RLS
    - Users can only view/modify their own progress
*/

-- Drop existing partitioned tables
DROP TABLE IF EXISTS video_progress_y2025m03;
DROP TABLE IF EXISTS video_progress_y2025m04;
DROP TABLE IF EXISTS video_progress_y2025m05;
DROP TABLE IF EXISTS video_progress_y2025m06;
DROP TABLE IF EXISTS video_progress_y2025m07;
DROP TABLE IF EXISTS video_progress_y2025m08;
DROP TABLE IF EXISTS video_progress_y2025m09;
DROP TABLE IF EXISTS video_progress_y2025m10;
DROP TABLE IF EXISTS video_progress_y2025m11;
DROP TABLE IF EXISTS video_progress_y2025m12;
DROP TABLE IF EXISTS video_progress_y2026m01;
DROP TABLE IF EXISTS video_progress_y2026m02;

-- Create new video progress table
CREATE TABLE IF NOT EXISTS video_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  lesson_id uuid NOT NULL REFERENCES course_lessons(id) ON DELETE CASCADE,
  progress integer NOT NULL DEFAULT 0,
  watched_seconds numeric NOT NULL DEFAULT 0,
  last_watched_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, lesson_id)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_video_progress_user_lesson ON video_progress(user_id, lesson_id);
CREATE INDEX IF NOT EXISTS idx_video_progress_user_course ON video_progress(user_id, course_id);
CREATE INDEX IF NOT EXISTS idx_video_progress_last_watched ON video_progress(last_watched_at DESC);

-- Enable RLS
ALTER TABLE video_progress ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own progress"
  ON video_progress
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own progress"
  ON video_progress
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can modify their own progress"
  ON video_progress
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);