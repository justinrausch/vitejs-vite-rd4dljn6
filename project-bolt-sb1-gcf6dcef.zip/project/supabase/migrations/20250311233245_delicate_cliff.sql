/*
  # Fix chat message storage and policies

  1. Changes
    - Simplify chat message policies to ensure proper storage
    - Fix notification triggers
    - Add proper indexes for performance
    
  2. Security
    - Maintain security while allowing proper message creation
    - Ensure messages are properly stored
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view messages in channels they have access to" ON chat_messages;
DROP POLICY IF EXISTS "Users can insert messages in channels they have access to" ON chat_messages;

-- Create simplified policies that ensure proper message storage
CREATE POLICY "Users can view messages in channels they have access to"
ON chat_messages
FOR SELECT
TO public
USING (
  EXISTS (
    SELECT 1 FROM enrollments e
    JOIN chat_channels c ON c.course_id = e.course_id
    WHERE c.id = chat_messages.channel_id
    AND (e.user_id = auth.uid() OR NOT c.is_private)
  ) OR EXISTS (
    SELECT 1 FROM chat_channels c
    JOIN courses co ON co.id = c.course_id
    WHERE c.id = chat_messages.channel_id
    AND co.instructor_id = auth.uid()
  )
);

CREATE POLICY "Users can send messages in channels they have access to"
ON chat_messages
FOR INSERT
TO public
WITH CHECK (
  auth.uid() = user_id AND (
    EXISTS (
      SELECT 1 FROM enrollments e
      JOIN chat_channels c ON c.course_id = e.course_id
      WHERE c.id = chat_messages.channel_id
      AND e.user_id = auth.uid()
      AND NOT c.is_private
    ) OR EXISTS (
      SELECT 1 FROM chat_channels c
      JOIN courses co ON co.id = c.course_id
      WHERE c.id = chat_messages.channel_id
      AND co.instructor_id = auth.uid()
    )
  )
);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_chat_messages_channel_user_time 
ON chat_messages(channel_id, user_id, created_at DESC);

-- Enable realtime for chat_messages if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND schemaname = 'public' 
    AND tablename = 'chat_messages'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE chat_messages;
  END IF;
END $$;