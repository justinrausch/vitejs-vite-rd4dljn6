/*
  # Fix Course Creation RLS Policies

  1. Changes
     - Simplify RLS policies for courses table
     - Ensure courses can be read by anyone
     - Allow coaches to create courses
     - Allow instructors to update/delete their own courses
*/

-- First, drop existing policies on the courses table
DROP POLICY IF EXISTS "Anyone can view courses" ON public.courses;
DROP POLICY IF EXISTS "Coaches can create courses" ON public.courses;
DROP POLICY IF EXISTS "Instructors can delete their courses" ON public.courses;
DROP POLICY IF EXISTS "Instructors can update their courses" ON public.courses;

-- Create simplified policies

-- Allow anyone to view courses (public read access)
CREATE POLICY "Anyone can view courses" 
ON public.courses
FOR SELECT 
TO public
USING (true);

-- Allow coaches to create courses
CREATE POLICY "Coaches can create courses" 
ON public.courses
FOR INSERT 
TO authenticated
WITH CHECK (
  (instructor_id = auth.uid()) AND 
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.is_coach = true
  )
);

-- Allow instructors to update their own courses
CREATE POLICY "Instructors can update their courses" 
ON public.courses
FOR UPDATE 
TO authenticated
USING (instructor_id = auth.uid())
WITH CHECK (instructor_id = auth.uid());

-- Allow instructors to delete their own courses
CREATE POLICY "Instructors can delete their courses" 
ON public.courses
FOR DELETE 
TO authenticated
USING (instructor_id = auth.uid());