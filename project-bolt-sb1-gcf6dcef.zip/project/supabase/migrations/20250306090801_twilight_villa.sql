/*
  # Update Rankings System

  1. New Functions
    - `calculate_user_points`: Calculates points based on completed lessons
    - `update_course_rankings`: Updates rankings table with latest stats
    - `update_rankings_on_completion`: Trigger function for lesson completion
    - `update_rankings_on_enrollment`: Trigger function for new enrollments
    - `get_course_rankings`: Returns course rankings with user details

  2. Changes
    - Add trigger to update rankings on lesson completion
    - Add trigger to create initial ranking on enrollment
    - Add function to recalculate all rankings

  3. Security
    - Functions are security definer to ensure proper access control
*/

-- Function to calculate user points
CREATE OR REPLACE FUNCTION calculate_user_points(
  p_user_id UUID,
  p_course_id UUID
) RETURNS INTEGER AS $$
DECLARE
  completed_count INTEGER;
BEGIN
  SELECT COUNT(*)
  INTO completed_count
  FROM completed_lessons
  WHERE user_id = p_user_id AND course_id = p_course_id;
  
  RETURN completed_count * 100;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update course rankings
CREATE OR REPLACE FUNCTION update_course_rankings(
  p_course_id UUID,
  p_user_id UUID
) RETURNS VOID AS $$
DECLARE
  v_points INTEGER;
  v_completed_count INTEGER;
  v_level INTEGER;
BEGIN
  -- Get completed lessons count
  SELECT COUNT(*)
  INTO v_completed_count
  FROM completed_lessons
  WHERE user_id = p_user_id AND course_id = p_course_id;
  
  -- Calculate points (100 per completed lesson)
  v_points := v_completed_count * 100;
  
  -- Calculate level (increases every 3 lessons)
  v_level := GREATEST(1, FLOOR(v_completed_count::float / 3) + 1);
  
  -- Update or insert into course_rankings
  INSERT INTO course_rankings (
    course_id,
    user_id,
    points,
    level,
    completed_lessons_count,
    last_active
  ) VALUES (
    p_course_id,
    p_user_id,
    v_points,
    v_level,
    v_completed_count,
    NOW()
  )
  ON CONFLICT (course_id, user_id) DO UPDATE SET
    points = EXCLUDED.points,
    level = EXCLUDED.level,
    completed_lessons_count = EXCLUDED.completed_lessons_count,
    last_active = EXCLUDED.last_active,
    updated_at = NOW();

  -- Update ranks for all users in this course
  WITH ranked_users AS (
    SELECT 
      id,
      ROW_NUMBER() OVER (
        PARTITION BY course_id 
        ORDER BY points DESC, completed_lessons_count DESC, last_active DESC
      ) as new_rank
    FROM course_rankings
    WHERE course_id = p_course_id
  )
  UPDATE course_rankings cr
  SET rank = ru.new_rank
  FROM ranked_users ru
  WHERE cr.id = ru.id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger function for lesson completion
CREATE OR REPLACE FUNCTION update_rankings_on_completion() 
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM update_course_rankings(NEW.course_id, NEW.user_id);
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM update_course_rankings(OLD.course_id, OLD.user_id);
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger function for enrollment
CREATE OR REPLACE FUNCTION update_rankings_on_enrollment() 
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Create initial ranking entry
    INSERT INTO course_rankings (
      course_id,
      user_id,
      points,
      level,
      completed_lessons_count,
      last_active
    ) VALUES (
      NEW.course_id,
      NEW.user_id,
      0,
      1,
      0,
      NOW()
    );
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS rankings_completion_trigger ON completed_lessons;
DROP TRIGGER IF EXISTS rankings_enrollment_trigger ON enrollments;

-- Create new triggers
CREATE TRIGGER rankings_completion_trigger
  AFTER INSERT OR DELETE ON completed_lessons
  FOR EACH ROW
  EXECUTE FUNCTION update_rankings_on_completion();

CREATE TRIGGER rankings_enrollment_trigger
  AFTER INSERT ON enrollments
  FOR EACH ROW
  EXECUTE FUNCTION update_rankings_on_enrollment();

-- Drop existing get_course_rankings function if it exists
DROP FUNCTION IF EXISTS get_course_rankings(UUID);

-- Create new get_course_rankings function
CREATE FUNCTION get_course_rankings(course_id_param UUID)
RETURNS TABLE (
  id UUID,
  username TEXT,
  avatar_url TEXT,
  is_coach BOOLEAN,
  email TEXT,
  completed_lessons_count INTEGER,
  points INTEGER,
  level INTEGER,
  rank INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.username,
    p.avatar_url,
    p.is_coach,
    p.email,
    cr.completed_lessons_count,
    cr.points,
    cr.level,
    cr.rank
  FROM course_rankings cr
  JOIN profiles p ON p.id = cr.user_id
  WHERE cr.course_id = course_id_param
  ORDER BY cr.rank ASC NULLS LAST;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to recalculate all rankings for a course
CREATE OR REPLACE FUNCTION recalculate_course_rankings(p_course_id UUID)
RETURNS VOID AS $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN (
    SELECT DISTINCT user_id 
    FROM enrollments 
    WHERE course_id = p_course_id
  ) LOOP
    PERFORM update_course_rankings(p_course_id, r.user_id);
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;