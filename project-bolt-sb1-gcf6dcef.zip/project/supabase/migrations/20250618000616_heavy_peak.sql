-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  data jsonb DEFAULT '{}'::jsonb,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(user_id) WHERE (read = false);

-- Enable RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own notifications" 
  ON notifications 
  FOR SELECT 
  TO authenticated 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can mark their notifications as read" 
  ON notifications 
  FOR UPDATE 
  TO authenticated 
  USING (auth.uid() = user_id);

-- Create trigger functions for notifications

-- Function to notify when a new coach message is sent
CREATE OR REPLACE FUNCTION notify_coach_message()
RETURNS TRIGGER AS $$
BEGIN
  -- If the sender is the coach (instructor), notify the student
  IF EXISTS (
    SELECT 1 FROM courses 
    WHERE id = NEW.course_id AND instructor_id = NEW.sender_id
  ) THEN
    -- Get coach username
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      data
    )
    SELECT
      NEW.student_id,
      'new_message',
      'New Message from Coach',
      'You have a new message from your coach ' || p.username,
      jsonb_build_object(
        'courseId', NEW.course_id,
        'username', p.username,
        'avatarUrl', p.avatar_url
      )
    FROM profiles p
    WHERE p.id = NEW.sender_id;
  
  -- If the sender is the student, notify the coach (instructor)
  ELSE
    -- Get student username
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      data
    )
    SELECT
      c.instructor_id,
      'new_message',
      'New Message from Student',
      'You have a new message from ' || p.username,
      jsonb_build_object(
        'courseId', NEW.course_id,
        'username', p.username,
        'avatarUrl', p.avatar_url
      )
    FROM profiles p, courses c
    WHERE p.id = NEW.student_id AND c.id = NEW.course_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to notify when a new lesson is added
CREATE OR REPLACE FUNCTION notify_new_lesson()
RETURNS TRIGGER AS $$
BEGIN
  -- Notify all enrolled students
  INSERT INTO notifications (
    user_id,
    type,
    title,
    message,
    data
  )
  SELECT
    e.user_id,
    'new_lesson',
    'New Lesson Available',
    'A new lesson "' || NEW.title || '" has been added to ' || c.title,
    jsonb_build_object(
      'courseId', NEW.course_id,
      'lessonId', NEW.id
    )
  FROM enrollments e
  JOIN courses c ON c.id = e.course_id
  WHERE e.course_id = NEW.course_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to notify when a user completes a lesson
CREATE OR REPLACE FUNCTION notify_achievement()
RETURNS TRIGGER AS $$
DECLARE
  completed_count INTEGER;
  course_title TEXT;
BEGIN
  -- Count how many lessons the user has completed in this course
  SELECT COUNT(*) INTO completed_count
  FROM completed_lessons
  WHERE user_id = NEW.user_id AND course_id = NEW.course_id;
  
  -- Get course title
  SELECT title INTO course_title
  FROM courses
  WHERE id = NEW.course_id;
  
  -- Create achievement notifications at certain milestones
  IF completed_count IN (1, 5, 10, 25, 50, 100) THEN
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      data
    )
    VALUES (
      NEW.user_id,
      'achievement',
      'Achievement Unlocked!',
      'You completed ' || completed_count || ' lessons in ' || course_title,
      jsonb_build_object(
        'courseId', NEW.course_id,
        'count', completed_count
      )
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to notify when someone likes a comment
CREATE OR REPLACE FUNCTION notify_comment_like()
RETURNS TRIGGER AS $$
BEGIN
  -- Get the comment owner and notify them if it's not their own like
  IF NEW.user_id != (SELECT user_id FROM course_post_comments WHERE id = NEW.post_id) THEN
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      data
    )
    SELECT
      c.user_id,
      'comment_like',
      'New Like on Your Comment',
      p.username || ' liked your comment',
      jsonb_build_object(
        'courseId', c.post_id,
        'commentId', c.id,
        'username', p.username,
        'avatarUrl', p.avatar_url
      )
    FROM course_post_comments c
    JOIN profiles p ON p.id = NEW.user_id
    WHERE c.id = NEW.post_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to notify when someone likes a message
CREATE OR REPLACE FUNCTION notify_message_like()
RETURNS TRIGGER AS $$
BEGIN
  -- Get the message owner and notify them if it's not their own like
  IF NEW.user_id != (SELECT user_id FROM chat_messages WHERE id = NEW.message_id) THEN
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      data
    )
    SELECT
      m.user_id,
      'message_like',
      'New Reaction to Your Message',
      p.username || ' reacted to your message with ' || NEW.emoji,
      jsonb_build_object(
        'courseId', (SELECT course_id FROM chat_channels WHERE id = m.channel_id),
        'messageId', m.id,
        'username', p.username,
        'avatarUrl', p.avatar_url
      )
    FROM chat_messages m
    JOIN profiles p ON p.id = NEW.user_id
    WHERE m.id = NEW.message_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
DROP TRIGGER IF EXISTS notify_new_lesson_trigger ON course_lessons;
CREATE TRIGGER notify_new_lesson_trigger
  AFTER INSERT ON course_lessons
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_lesson();

DROP TRIGGER IF EXISTS notify_achievement_trigger ON completed_lessons;
CREATE TRIGGER notify_achievement_trigger
  AFTER INSERT ON completed_lessons
  FOR EACH ROW
  EXECUTE FUNCTION notify_achievement();

DROP TRIGGER IF EXISTS notify_comment_like_trigger ON course_post_likes;
CREATE TRIGGER notify_comment_like_trigger
  AFTER INSERT ON course_post_likes
  FOR EACH ROW
  EXECUTE FUNCTION notify_comment_like();

DROP TRIGGER IF EXISTS notify_message_like_trigger ON message_reactions;
CREATE TRIGGER notify_message_like_trigger
  AFTER INSERT ON message_reactions
  FOR EACH ROW
  EXECUTE FUNCTION notify_message_like();