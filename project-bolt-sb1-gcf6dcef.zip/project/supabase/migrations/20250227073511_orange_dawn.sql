-- Ensure member_count is correctly updated for all courses
UPDATE courses
SET member_count = (
  SELECT COUNT(*) FROM enrollments WHERE enrollments.course_id = courses.id
);

-- Create additional test enrollments for better testing
DO $$
DECLARE
  target_course_id uuid;
  user_ids uuid[];
  i int;
BEGIN
  -- Get the Advanced Trail Building course ID specifically
  SELECT id INTO target_course_id FROM courses WHERE title = 'Advanced Trail Building' LIMIT 1;
  
  -- Get user IDs that aren't already enrolled in this course
  -- Fixed the ambiguous column reference by using table aliases
  SELECT array_agg(p.id) INTO user_ids
  FROM profiles p
  WHERE p.id NOT IN (
    SELECT e.user_id FROM enrollments e WHERE e.course_id = target_course_id
  )
  AND p.id NOT IN (SELECT instructor_id FROM courses)
  LIMIT 10;
  
  -- Create enrollments for these users
  IF user_ids IS NOT NULL AND array_length(user_ids, 1) > 0 THEN
    FOR i IN 1..array_length(user_ids, 1) LOOP
      -- Create enrollment
      INSERT INTO enrollments (user_id, course_id)
      VALUES (user_ids[i], target_course_id)
      ON CONFLICT (user_id, course_id) DO NOTHING;
      
      -- Add some completed lessons for these users
      INSERT INTO completed_lessons (user_id, course_id, lesson_id)
      SELECT 
        user_ids[i], 
        target_course_id, 
        cl.id
      FROM course_lessons cl
      JOIN course_chapters cc ON cl.chapter_id = cc.id
      WHERE cc.course_id = target_course_id
      ORDER BY random()
      LIMIT floor(random() * 4)::int
      ON CONFLICT (user_id, lesson_id) DO NOTHING;
    END LOOP;
  END IF;
  
  -- Update member count for this course
  UPDATE courses
  SET member_count = (
    SELECT COUNT(*) FROM enrollments e WHERE e.course_id = target_course_id
  )
  WHERE id = target_course_id;
END $$;