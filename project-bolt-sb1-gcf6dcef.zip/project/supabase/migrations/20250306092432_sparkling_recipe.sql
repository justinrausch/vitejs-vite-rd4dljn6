/*
  # Fix Rankings System

  1. Changes
    - Drop and recreate get_course_rankings function
    - Clean up rankings table and policies
    - Add proper indexes and constraints
    - Ensure proper function security

  2. Security
    - Enable RLS
    - Add proper policies for rankings access
    - Use security definer for functions
*/

-- Drop existing function first to avoid return type conflict
DROP FUNCTION IF EXISTS get_course_rankings(UUID);

-- Create course_rankings table if it doesn't exist
CREATE TABLE IF NOT EXISTS course_rankings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  points INTEGER DEFAULT 0,
  level INTEGER DEFAULT 1,
  completed_lessons_count INTEGER DEFAULT 0,
  total_watch_time NUMERIC DEFAULT 0,
  last_active TIMESTAMPTZ DEFAULT now(),
  rank INTEGER,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(course_id, user_id)
);

-- Enable RLS
ALTER TABLE course_rankings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Course rankings are viewable by everyone" ON course_rankings;
DROP POLICY IF EXISTS "System can update rankings" ON course_rankings;

-- Add RLS policies
CREATE POLICY "Course rankings are viewable by everyone" ON course_rankings
  FOR SELECT TO public
  USING (true);

CREATE POLICY "System can update rankings" ON course_rankings
  FOR ALL TO public
  USING (true)
  WITH CHECK (true);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_course_rankings_course_points 
  ON course_rankings(course_id, points DESC);

CREATE INDEX IF NOT EXISTS idx_course_rankings_user 
  ON course_rankings(user_id);

CREATE INDEX IF NOT EXISTS idx_course_rankings_last_active 
  ON course_rankings(last_active DESC);

-- Function to update course rankings
CREATE OR REPLACE FUNCTION update_course_rankings(
  p_course_id UUID,
  p_user_id UUID
) RETURNS VOID AS $$
DECLARE
  v_points INTEGER;
  v_completed_count INTEGER;
  v_level INTEGER;
BEGIN
  -- Get completed lessons count
  SELECT COUNT(*)
  INTO v_completed_count
  FROM completed_lessons
  WHERE user_id = p_user_id AND course_id = p_course_id;
  
  -- Calculate points (100 per completed lesson)
  v_points := v_completed_count * 100;
  
  -- Calculate level (increases every 3 lessons)
  v_level := GREATEST(1, FLOOR(v_completed_count::float / 3) + 1);
  
  -- Update or insert into course_rankings
  INSERT INTO course_rankings (
    course_id,
    user_id,
    points,
    level,
    completed_lessons_count,
    last_active
  ) VALUES (
    p_course_id,
    p_user_id,
    v_points,
    v_level,
    v_completed_count,
    NOW()
  )
  ON CONFLICT (course_id, user_id) DO UPDATE SET
    points = EXCLUDED.points,
    level = EXCLUDED.level,
    completed_lessons_count = EXCLUDED.completed_lessons_count,
    last_active = EXCLUDED.last_active,
    updated_at = NOW();

  -- Update ranks for all users in this course
  WITH ranked_users AS (
    SELECT 
      id,
      ROW_NUMBER() OVER (
        PARTITION BY course_id 
        ORDER BY points DESC, completed_lessons_count DESC, last_active DESC
      ) as new_rank
    FROM course_rankings
    WHERE course_id = p_course_id
  )
  UPDATE course_rankings cr
  SET rank = ru.new_rank
  FROM ranked_users ru
  WHERE cr.id = ru.id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new get_course_rankings function with correct return type
CREATE OR REPLACE FUNCTION get_course_rankings(course_id_param UUID)
RETURNS TABLE (
  id UUID,
  user_id UUID,
  username TEXT,
  avatar_url TEXT,
  is_coach BOOLEAN,
  email TEXT,
  completed_lessons_count INTEGER,
  points INTEGER,
  level INTEGER,
  rank INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    cr.user_id,
    p.username,
    p.avatar_url,
    p.is_coach,
    p.email,
    cr.completed_lessons_count,
    cr.points,
    cr.level,
    cr.rank
  FROM course_rankings cr
  JOIN profiles p ON p.id = cr.user_id
  WHERE cr.course_id = course_id_param
  ORDER BY cr.rank ASC NULLS LAST;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS rankings_completion_trigger ON completed_lessons;
DROP TRIGGER IF EXISTS rankings_enrollment_trigger ON enrollments;

-- Trigger function for lesson completion
CREATE OR REPLACE FUNCTION update_rankings_on_completion() 
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM update_course_rankings(NEW.course_id, NEW.user_id);
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM update_course_rankings(OLD.course_id, OLD.user_id);
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger function for enrollment
CREATE OR REPLACE FUNCTION update_rankings_on_enrollment() 
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Create initial ranking entry
    INSERT INTO course_rankings (
      course_id,
      user_id,
      points,
      level,
      completed_lessons_count,
      last_active
    ) VALUES (
      NEW.course_id,
      NEW.user_id,
      0,
      1,
      0,
      NOW()
    );
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new triggers
CREATE TRIGGER rankings_completion_trigger
  AFTER INSERT OR DELETE ON completed_lessons
  FOR EACH ROW
  EXECUTE FUNCTION update_rankings_on_completion();

CREATE TRIGGER rankings_enrollment_trigger
  AFTER INSERT ON enrollments
  FOR EACH ROW
  EXECUTE FUNCTION update_rankings_on_enrollment();

-- Function to recalculate all rankings for a course
CREATE OR REPLACE FUNCTION recalculate_course_rankings(p_course_id UUID)
RETURNS VOID AS $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN (
    SELECT DISTINCT user_id 
    FROM enrollments 
    WHERE course_id = p_course_id
  ) LOOP
    PERFORM update_course_rankings(p_course_id, r.user_id);
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Clean up any stale rankings
DELETE FROM course_rankings cr
WHERE NOT EXISTS (
  SELECT 1 FROM enrollments e
  WHERE e.user_id = cr.user_id AND e.course_id = cr.course_id
);

-- Recalculate rankings for all existing courses
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN (SELECT id FROM courses) LOOP
    PERFORM recalculate_course_rankings(r.id);
  END LOOP;
END $$;