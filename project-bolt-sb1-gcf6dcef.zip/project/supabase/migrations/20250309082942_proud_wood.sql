/*
  # Fix chat message policies for private channels

  1. Changes
    - Add policies for private channels
    - Update existing policies to handle private channels
    - Ensure proper access control for coaches and regular users

  2. Security
    - Only coaches can send messages in private channels
    - All users can read messages in all channels
    - Messages are properly secured based on channel privacy settings
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Only coaches can send messages in private channels" ON chat_messages;
DROP POLICY IF EXISTS "Enrolled users and instructors can send messages" ON chat_messages;

-- Create new policies for message creation
CREATE POLICY "Users can send messages in public channels"
ON chat_messages
FOR INSERT
TO public
WITH CHECK (
  -- Allow if channel is not private
  NOT EXISTS (
    SELECT 1 FROM chat_channels 
    WHERE id = chat_messages.channel_id 
    AND is_private = true
  )
  AND
  -- And user is enrolled or is instructor
  (
    EXISTS (
      SELECT 1
      FROM enrollments e
      JOIN chat_channels c ON c.course_id = e.course_id
      WHERE e.user_id = auth.uid()
      AND c.id = chat_messages.channel_id
    )
    OR
    EXISTS (
      SELECT 1
      FROM chat_channels c
      JOIN courses co ON co.id = c.course_id
      WHERE c.id = chat_messages.channel_id
      AND co.instructor_id = auth.uid()
    )
  )
);

CREATE POLICY "Coaches can send messages in any channel"
ON chat_messages
FOR INSERT
TO public
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM chat_channels c
    JOIN courses co ON co.id = c.course_id
    WHERE c.id = chat_messages.channel_id
    AND co.instructor_id = auth.uid()
  )
);