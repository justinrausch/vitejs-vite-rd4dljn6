/*
  # Update feature access defaults

  1. Changes
    - Update default values for feature access columns to be true
    - This makes all features available by default, allowing restriction rather than enabling
  
  2. Security
    - No changes to RLS policies needed
*/

-- Update default values for feature access columns
ALTER TABLE course_plans 
ALTER COLUMN lessons_access SET DEFAULT true,
ALTER COLUMN community_access SET DEFAULT true,
ALTER COLUMN coaching_access SET DEFAULT true,
ALTER COLUMN rankings_access SET DEFAULT true;

-- Update existing plans to have all features enabled by default
UPDATE course_plans
SET 
  lessons_access = true,
  community_access = true,
  coaching_access = true,
  rankings_access = true
WHERE lessons_access IS NULL 
   OR community_access IS NULL 
   OR coaching_access IS NULL 
   OR rankings_access IS NULL;