/*
  # Add lecture notes to lessons

  1. Changes
    - Add `lecture_notes` column to `course_lessons` table
      - Text field to store formatted lecture notes
      - Nullable since not all lessons will have notes initially
      - Default to NULL

  2. Security
    - No additional security changes needed
    - Existing RLS policies will cover the new column
*/

ALTER TABLE course_lessons 
ADD COLUMN IF NOT EXISTS lecture_notes text;