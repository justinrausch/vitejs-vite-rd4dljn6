/*
  # Fix Course Creation Policies

  1. Changes
    - Drops and recreates policies for course management
    - Ensures policies don't conflict with existing ones
    - Uses DO blocks to check if policies exist before attempting to create them
  
  2. Purpose
    - Fixes the "Failed to create course" error during course creation
    - Ensures proper RLS policies for course management
*/

-- Drop existing problematic policies if they exist
DROP POLICY IF EXISTS "Course creators can manage their courses" ON courses;
DROP POLICY IF EXISTS "Courses are viewable by everyone" ON courses;

-- Check if "Coaches can create courses" policy exists before dropping
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'courses' 
    AND policyname = 'Coaches can create courses'
  ) THEN
    DROP POLICY "Coaches can create courses" ON courses;
  END IF;
END
$$;

-- Create comprehensive policies for course management
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'courses' 
    AND policyname = 'Course creators can manage their courses'
  ) THEN
    CREATE POLICY "Course creators can manage their courses"
      ON courses
      FOR ALL
      TO authenticated
      USING (instructor_id = auth.uid())
      WITH CHECK (instructor_id = auth.uid());
  END IF;
END
$$;

-- Allow everyone to view courses (public access)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'courses' 
    AND policyname = 'Courses are viewable by everyone'
  ) THEN
    CREATE POLICY "Courses are viewable by everyone"
      ON courses
      FOR SELECT
      TO public
      USING (true);
  END IF;
END
$$;

-- Ensure coaches can create courses
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'courses' 
    AND policyname = 'Coaches can create courses'
  ) THEN
    CREATE POLICY "Coaches can create courses"
      ON courses
      FOR INSERT
      TO authenticated
      WITH CHECK (
        EXISTS (
          SELECT 1 FROM profiles
          WHERE profiles.id = auth.uid()
          AND profiles.is_coach = true
        )
        AND instructor_id = auth.uid()
      );
  END IF;
END
$$;