-- Add trigger for enrollments to update rankings
CREATE OR REPLACE FUNCTION update_rankings_on_enrollment()
RETURNS trigger AS $$
BEGIN
  -- Calculate rankings for the affected course
  PERFORM calculate_course_rankings(
    CASE TG_OP 
      WHEN 'DELETE' THEN OLD.course_id
      ELSE NEW.course_id
    END
  );
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for enrollment changes
DROP TRIGGER IF EXISTS rankings_enrollment_trigger ON enrollments;
CREATE TRIGGER rankings_enrollment_trigger
  AFTER INSERT OR DELETE ON enrollments
  FOR EACH ROW
  EXECUTE FUNCTION update_rankings_on_enrollment();

-- Recalculate all rankings to ensure consistency
DO $$
DECLARE
  course_rec RECORD;
BEGIN
  FOR course_rec IN SELECT id FROM courses LOOP
    PERFORM calculate_course_rankings(course_rec.id);
  END LOOP;
END $$;