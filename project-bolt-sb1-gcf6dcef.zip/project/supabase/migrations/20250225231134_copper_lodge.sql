/*
  # Fix Chat and Add Unjoin Functionality

  1. Changes
    - Add policy for deleting enrollments
    - Add function to clean up user data when leaving a course
*/

-- Add policy to allow users to delete their own enrollments
CREATE POLICY "Users can delete their own enrollments"
  ON enrollments FOR DELETE
  USING (auth.uid() = user_id);

-- Create function to clean up user data when leaving a course
CREATE OR REPLACE FUNCTION clean_up_course_data()
RETURNS trigger AS $$
BEGIN
  -- Delete completed lessons
  DELETE FROM completed_lessons
  WHERE user_id = OLD.user_id
  AND course_id = OLD.course_id;

  -- Delete chat messages
  DELETE FROM chat_messages
  WHERE user_id = OLD.user_id
  AND channel_id IN (
    SELECT id FROM chat_channels
    WHERE course_id = OLD.course_id
  );

  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to clean up data when a user leaves a course
CREATE TRIGGER on_course_leave
  BEFORE DELETE ON enrollments
  FOR EACH ROW
  EXECUTE FUNCTION clean_up_course_data();