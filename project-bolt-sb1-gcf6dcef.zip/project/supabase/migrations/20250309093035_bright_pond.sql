/*
  # Fix message reactions table

  1. Changes
    - Drop existing message_reactions table if it exists
    - Create message_reactions table with proper structure and constraints
    - Add necessary indexes for performance
    - Set up RLS policies for security

  2. Security
    - Enable RLS on message_reactions table
    - Allow public read access to reactions
    - Allow authenticated users to add/remove their own reactions
*/

-- Drop existing table if it exists
DROP TABLE IF EXISTS message_reactions CASCADE;

-- Create message reactions table
CREATE TABLE IF NOT EXISTS message_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES chat_messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  emoji text NOT NULL,
  created_at timestamptz DEFAULT now(),
  
  -- Prevent duplicate reactions from same user with same emoji
  UNIQUE(message_id, user_id, emoji)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_message_reactions_message_id ON message_reactions(message_id);
CREATE INDEX IF NOT EXISTS idx_message_reactions_user_id ON message_reactions(user_id);

-- Enable RLS
ALTER TABLE message_reactions ENABLE ROW LEVEL SECURITY;

-- Drop any existing policies
DROP POLICY IF EXISTS "Everyone can view reactions" ON message_reactions;
DROP POLICY IF EXISTS "Users can add reactions" ON message_reactions;
DROP POLICY IF EXISTS "Users can remove their reactions" ON message_reactions;

-- Create new policies
CREATE POLICY "Everyone can view reactions"
ON message_reactions
FOR SELECT
TO public
USING (true);

CREATE POLICY "Users can add reactions"
ON message_reactions
FOR INSERT
TO public
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove their reactions"
ON message_reactions
FOR DELETE
TO public
USING (auth.uid() = user_id);