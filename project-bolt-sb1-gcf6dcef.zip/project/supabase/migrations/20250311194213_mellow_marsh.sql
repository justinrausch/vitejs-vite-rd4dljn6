/*
  # Add verified status to profiles

  1. Changes
    - Add is_verified column to profiles table
    - Default value is false
    - Add index for faster queries
*/

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_verified boolean DEFAULT false;
CREATE INDEX IF NOT EXISTS idx_profiles_is_verified ON profiles(is_verified);

-- Update some existing profiles to be verified
UPDATE profiles 
SET is_verified = true 
WHERE username IN ('Christian Arehart', 'Sarah Johnson', 'Mike Chen')
OR email IN ('gaspar@mastery.to', 'justin@mastery.to');