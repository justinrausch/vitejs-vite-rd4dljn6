/*
  # Add logo_url to courses table

  1. Changes
    - Add logo_url column to courses table
    - This allows coaches to add a logo for their course
    - The logo will appear next to the course title on course cards
*/

-- Add logo_url column to courses table
ALTER TABLE courses
ADD COLUMN IF NOT EXISTS logo_url text;