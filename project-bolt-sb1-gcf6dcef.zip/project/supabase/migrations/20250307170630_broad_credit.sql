/*
  # Fix Course Chapters Policy

  1. Changes
    - Add IF NOT EXISTS check before creating policy
    - Ensures policy is only created if it doesn't already exist
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'course_chapters' 
    AND policyname = 'Course creators can manage chapters'
  ) THEN
    CREATE POLICY "Course creators can manage chapters" ON public.course_chapters
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = course_chapters.course_id
        AND courses.instructor_id = auth.uid()
      ))
      WITH CHECK (EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = course_chapters.course_id
        AND courses.instructor_id = auth.uid()
      ));
  END IF;
END $$;