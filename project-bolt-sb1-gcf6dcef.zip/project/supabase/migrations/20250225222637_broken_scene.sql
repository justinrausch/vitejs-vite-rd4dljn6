/*
  # Add completed lessons tracking

  1. New Tables
    - `completed_lessons`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `course_id` (uuid, references courses)
      - `lesson_id` (uuid, references course_lessons)
      - `completed_at` (timestamp)

  2. Security
    - Enable RLS on `completed_lessons` table
    - Add policies for users to manage their completed lessons
*/

CREATE TABLE completed_lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
  lesson_id uuid REFERENCES course_lessons(id) ON DELETE CASCADE NOT NULL,
  completed_at timestamptz DEFAULT now(),
  UNIQUE(user_id, lesson_id)
);

ALTER TABLE completed_lessons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own completed lessons"
  ON completed_lessons FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can mark lessons as completed"
  ON completed_lessons FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unmark completed lessons"
  ON completed_lessons FOR DELETE
  USING (auth.uid() = user_id);