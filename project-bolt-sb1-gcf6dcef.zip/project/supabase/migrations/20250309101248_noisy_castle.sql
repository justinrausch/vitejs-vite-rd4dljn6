/*
  # Add message reactions

  1. New Tables
    - `message_reactions`
      - `id` (uuid, primary key)
      - `message_id` (uuid, references chat_messages)
      - `user_id` (uuid, references profiles)
      - `emoji` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `message_reactions` table
    - Add policies for:
      - Everyone can view reactions
      - Authenticated users can add/remove their own reactions
      - One reaction per emoji per user per message

  3. Changes
    - Add indexes for better query performance
    - Add unique constraint to prevent duplicate reactions
*/

-- Create message reactions table if it doesn't exist
CREATE TABLE IF NOT EXISTS message_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES chat_messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  emoji text NOT NULL,
  created_at timestamptz DEFAULT now(),
  
  -- Ensure one reaction per emoji per user per message
  CONSTRAINT message_reactions_message_id_user_id_emoji_key UNIQUE (message_id, user_id, emoji)
);

-- Create indexes for better performance if they don't exist
CREATE INDEX IF NOT EXISTS idx_message_reactions_message_id ON message_reactions(message_id);
CREATE INDEX IF NOT EXISTS idx_message_reactions_user_id ON message_reactions(user_id);

-- Enable RLS if not already enabled
ALTER TABLE message_reactions ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Reactions are viewable by everyone" ON message_reactions;
DROP POLICY IF EXISTS "Users can add reactions" ON message_reactions;
DROP POLICY IF EXISTS "Users can remove their reactions" ON message_reactions;

-- Create new policies
CREATE POLICY "Reactions are viewable by everyone" ON message_reactions
  FOR SELECT USING (true);

CREATE POLICY "Users can add reactions" ON message_reactions
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove their reactions" ON message_reactions
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);