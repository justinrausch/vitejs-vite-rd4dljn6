/*
  # Add private channels support

  1. Changes
    - Add is_private column to chat_channels table
    - Update chat_messages policies to restrict message creation in private channels

  2. Security
    - Only coaches can send messages in private channels
    - Everyone can send messages in non-private channels
*/

-- Add is_private column to chat_channels
ALTER TABLE chat_channels ADD COLUMN IF NOT EXISTS is_private boolean DEFAULT false;

-- Drop existing policies
DROP POLICY IF EXISTS "Enrolled users and instructors can send messages" ON chat_messages;

-- Create new policy for sending messages
CREATE POLICY "Enrolled users and instructors can send messages"
ON chat_messages
FOR INSERT
TO public
WITH CHECK (
  (
    -- User must be enrolled in the course
    EXISTS (
      SELECT 1
      FROM enrollments e
      JOIN chat_channels c ON c.course_id = e.course_id
      WHERE e.user_id = auth.uid()
      AND c.id = chat_messages.channel_id
      AND (
        -- Channel is not private OR user is the course instructor
        NOT c.is_private OR
        EXISTS (
          SELECT 1
          FROM courses co
          WHERE co.id = c.course_id
          AND co.instructor_id = auth.uid()
        )
      )
    )
  ) OR (
    -- Or user is the course instructor
    EXISTS (
      SELECT 1
      FROM chat_channels c
      JOIN courses co ON co.id = c.course_id
      WHERE c.id = chat_messages.channel_id
      AND co.instructor_id = auth.uid()
    )
  )
  -- Ensure the user is the message sender
  AND auth.uid() = chat_messages.user_id
);