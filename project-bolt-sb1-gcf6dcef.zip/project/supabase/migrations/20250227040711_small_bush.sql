/*
  # Create public bucket for images

  1. New Storage Bucket
    - `public` bucket for storing publicly accessible images
  2. Security
    - Enable RLS on the bucket
    - Add policies for authenticated users to upload and manage their images
    - Allow public read access to all images
*/

-- Create public bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('public', 'public', true)
ON CONFLICT (id) DO NOTHING;

-- Create policies only if they don't exist
DO $$
BEGIN
  -- Check if "Public Access" policy exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Public Access'
  ) THEN
    -- Allow public access to read objects
    EXECUTE 'CREATE POLICY "Public Access" ON storage.objects FOR SELECT USING (bucket_id = ''public'')';
  END IF;

  -- Check if "Authenticated users can upload" policy exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Authenticated users can upload'
  ) THEN
    -- Allow authenticated users to upload objects
    EXECUTE 'CREATE POLICY "Authenticated users can upload" ON storage.objects FOR INSERT WITH CHECK (bucket_id = ''public'' AND auth.role() = ''authenticated'')';
  END IF;

  -- Check if "Users can update their own objects" policy exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can update their own objects'
  ) THEN
    -- Allow users to update their own objects
    EXECUTE 'CREATE POLICY "Users can update their own objects" ON storage.objects FOR UPDATE USING (bucket_id = ''public'' AND auth.uid() = owner)';
  END IF;

  -- Check if "Users can delete their own objects" policy exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Users can delete their own objects'
  ) THEN
    -- Allow users to delete their own objects
    EXECUTE 'CREATE POLICY "Users can delete their own objects" ON storage.objects FOR DELETE USING (bucket_id = ''public'' AND auth.uid() = owner)';
  END IF;
END $$;