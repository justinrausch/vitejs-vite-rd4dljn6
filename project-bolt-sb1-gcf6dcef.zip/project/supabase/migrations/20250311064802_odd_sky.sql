/*
  # Chat messages and reactions schema update

  1. Changes
    - Add proper indexes for performance
    - Add message reactions table and policies
    - Add remaining RLS policies for chat messages
    - Add content validation using text type functions

  2. Security
    - Enable RLS on all tables
    - Add policies for proper access control
*/

-- Add proper indexes for performance if they don't exist
CREATE INDEX IF NOT EXISTS idx_chat_messages_channel_created 
ON chat_messages(channel_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_chat_messages_user_channel 
ON chat_messages(user_id, channel_id);

-- Enable RLS if not already enabled
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- Add content validation constraint using length() for text type
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'content_not_empty'
  ) THEN
    ALTER TABLE chat_messages
    ADD CONSTRAINT content_not_empty CHECK (length(trim(content)) > 0);
  END IF;
END $$;

-- Drop existing policies if they exist and recreate them
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can view messages in channels they have access to" ON chat_messages;
  DROP POLICY IF EXISTS "Users can insert messages in channels they have access to" ON chat_messages;
  DROP POLICY IF EXISTS "Users can delete their own messages" ON chat_messages;
END $$;

-- Create policies
CREATE POLICY "Users can view messages in channels they have access to"
ON chat_messages
FOR SELECT
TO public
USING (
  EXISTS (
    SELECT 1 FROM chat_channels c
    LEFT JOIN courses co ON c.course_id = co.id
    LEFT JOIN enrollments e ON e.course_id = co.id
    WHERE 
      c.id = chat_messages.channel_id 
      AND (
        e.user_id = auth.uid()
        OR co.instructor_id = auth.uid()
        OR NOT c.is_private
      )
  )
);

CREATE POLICY "Users can insert messages in channels they have access to"
ON chat_messages
FOR INSERT
TO public
WITH CHECK (
  EXISTS (
    SELECT 1 FROM chat_channels c
    LEFT JOIN courses co ON c.course_id = co.id
    LEFT JOIN enrollments e ON e.course_id = co.id
    WHERE 
      c.id = chat_messages.channel_id 
      AND (
        (e.user_id = auth.uid() AND NOT c.is_private)
        OR co.instructor_id = auth.uid()
      )
  )
);

CREATE POLICY "Users can delete their own messages"
ON chat_messages
FOR DELETE
TO public
USING (user_id = auth.uid());

-- Message reactions table
CREATE TABLE IF NOT EXISTS message_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES chat_messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  emoji text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(message_id, user_id, emoji)
);

-- Enable RLS on reactions
ALTER TABLE message_reactions ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist and recreate them
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can view all reactions" ON message_reactions;
  DROP POLICY IF EXISTS "Users can add reactions" ON message_reactions;
  DROP POLICY IF EXISTS "Users can remove their own reactions" ON message_reactions;
END $$;

-- Add RLS policies for reactions
CREATE POLICY "Users can view all reactions"
ON message_reactions
FOR SELECT
TO public
USING (true);

CREATE POLICY "Users can add reactions"
ON message_reactions
FOR INSERT
TO public
WITH CHECK (
  EXISTS (
    SELECT 1 FROM chat_messages m
    JOIN chat_channels c ON m.channel_id = c.id
    LEFT JOIN courses co ON c.course_id = co.id
    LEFT JOIN enrollments e ON e.course_id = co.id
    WHERE 
      m.id = message_reactions.message_id
      AND (
        e.user_id = auth.uid()
        OR co.instructor_id = auth.uid()
      )
  )
);

CREATE POLICY "Users can remove their own reactions"
ON message_reactions
FOR DELETE
TO public
USING (user_id = auth.uid());