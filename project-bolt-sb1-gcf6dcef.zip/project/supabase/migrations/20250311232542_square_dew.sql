/*
  # Fix Chat Messages Policies and Functions

  1. Changes
    - Drop triggers before functions
    - Update chat message policies
    - Recreate notification functions with proper text handling
    
  2. Security
    - Maintain existing RLS policies
    - Ensure proper access control
*/

-- First drop the triggers that depend on the functions
DROP TRIGGER IF EXISTS notify_mention_trigger ON chat_messages;
DROP TRIGGER IF EXISTS chat_messages_notify ON chat_messages;

-- Now we can safely drop the functions
DROP FUNCTION IF EXISTS notify_mention();
DROP FUNCTION IF EXISTS notify_chat_message();

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view messages in channels they have access to" ON chat_messages;
DROP POLICY IF EXISTS "Users can insert messages in channels they have access to" ON chat_messages;

-- Create new policies with fixed SQL
CREATE POLICY "Users can view messages in channels they have access to"
ON chat_messages
FOR SELECT
TO public
USING (
  EXISTS (
    SELECT 1 FROM chat_channels c
    LEFT JOIN courses co ON c.course_id = co.id
    LEFT JOIN enrollments e ON e.course_id = co.id
    WHERE 
      c.id = chat_messages.channel_id 
      AND (
        e.user_id = auth.uid()
        OR co.instructor_id = auth.uid()
        OR NOT c.is_private
      )
  )
);

CREATE POLICY "Users can insert messages in channels they have access to"
ON chat_messages
FOR INSERT
TO public
WITH CHECK (
  EXISTS (
    SELECT 1 FROM chat_channels c
    LEFT JOIN courses co ON c.course_id = co.id
    LEFT JOIN enrollments e ON e.course_id = co.id
    WHERE 
      c.id = chat_messages.channel_id 
      AND (
        (e.user_id = auth.uid() AND NOT c.is_private)
        OR co.instructor_id = auth.uid()
      )
  )
  AND auth.uid() = user_id
);

-- Create new notify_mention function with proper text handling
CREATE OR REPLACE FUNCTION notify_mention()
RETURNS TRIGGER AS $$
DECLARE
  mention text;
  username text;
BEGIN
  FOR mention IN 
    SELECT regexp_matches(NEW.content, '@([a-zA-Z0-9_]+)', 'g')
  LOOP
    username := substring(mention[1] from 1);
    
    IF username IS NOT NULL THEN
      INSERT INTO notifications (
        user_id,
        type,
        title,
        message,
        data
      )
      SELECT 
        p.id,
        'mention',
        'New Mention',
        'You were mentioned in a message by ' || (SELECT username FROM profiles WHERE id = NEW.user_id),
        jsonb_build_object(
          'message_id', NEW.id,
          'channel_id', NEW.channel_id,
          'mentioned_by', NEW.user_id
        )
      FROM profiles p
      WHERE p.username = username
      AND p.id != NEW.user_id;
    END IF;
  END LOOP;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create new notify_chat_message function
CREATE OR REPLACE FUNCTION notify_chat_message()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM pg_notify(
    'new_chat_message',
    json_build_object(
      'channel_id', NEW.channel_id,
      'message', json_build_object(
        'id', NEW.id,
        'content', NEW.content,
        'created_at', NEW.created_at,
        'user_id', NEW.user_id
      )
    )::text
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER notify_mention_trigger
  AFTER INSERT ON chat_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_mention();

CREATE TRIGGER chat_messages_notify
  AFTER INSERT ON chat_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_chat_message();