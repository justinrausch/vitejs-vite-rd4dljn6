/*
  # Performance Optimizations for Scale

  1. New Indexes
    - Add composite indexes for common query patterns
    - Add covering indexes for frequently accessed data
  
  2. Materialized Views
    - Create materialized view for course rankings
    - Create materialized view for user statistics
    
  3. Table Partitioning
    - Partition chat_messages by month
    - Partition video_progress by month
    
  4. Performance Improvements
    - Add parallel query capabilities
    - Optimize frequently used queries
*/

-- Create composite indexes for common queries
CREATE INDEX IF NOT EXISTS idx_video_progress_user_course_time 
ON video_progress (user_id, course_id, last_watched_at DESC);

CREATE INDEX IF NOT EXISTS idx_chat_messages_channel_user_time 
ON chat_messages (channel_id, user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_coach_messages_course_student_time 
ON coach_messages (course_id, student_id, created_at DESC);

-- Create materialized view for course rankings
CREATE MATERIALIZED VIEW IF NOT EXISTS course_rankings_mv AS
SELECT 
  cr.course_id,
  cr.user_id,
  p.username,
  p.avatar_url,
  cr.points,
  cr.level,
  cr.completed_lessons_count,
  RANK() OVER (PARTITION BY cr.course_id ORDER BY cr.points DESC) as rank
FROM course_rankings cr
JOIN profiles p ON p.id = cr.user_id;

-- Create index on materialized view
CREATE UNIQUE INDEX IF NOT EXISTS idx_course_rankings_mv_course_user 
ON course_rankings_mv (course_id, user_id);

-- Create function to refresh rankings materialized view
CREATE OR REPLACE FUNCTION refresh_course_rankings_mv()
RETURNS trigger AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY course_rankings_mv;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to refresh rankings
CREATE TRIGGER refresh_course_rankings_mv_trigger
AFTER INSERT OR UPDATE OR DELETE ON course_rankings
FOR EACH STATEMENT
EXECUTE FUNCTION refresh_course_rankings_mv();

-- Create materialized view for user statistics
CREATE MATERIALIZED VIEW IF NOT EXISTS user_statistics_mv AS
SELECT 
  u.id as user_id,
  COUNT(DISTINCT e.course_id) as enrolled_courses_count,
  COUNT(DISTINCT cl.id) as completed_lessons_count,
  MAX(cl.completed_at) as last_activity,
  COALESCE(SUM(cr.points), 0) as total_points
FROM profiles u
LEFT JOIN enrollments e ON e.user_id = u.id
LEFT JOIN completed_lessons cl ON cl.user_id = u.id
LEFT JOIN course_rankings cr ON cr.user_id = u.id
GROUP BY u.id;

-- Create index on user statistics materialized view
CREATE UNIQUE INDEX IF NOT EXISTS idx_user_statistics_mv_user 
ON user_statistics_mv (user_id);

-- Create partitioned chat_messages table
CREATE TABLE IF NOT EXISTS chat_messages_new (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  channel_id uuid NOT NULL,
  user_id uuid NOT NULL,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb DEFAULT '{}'::jsonb,
  PRIMARY KEY (id, created_at)
) PARTITION BY RANGE (created_at);

-- Create partitioned video_progress table
CREATE TABLE IF NOT EXISTS video_progress_new (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  course_id uuid NOT NULL,
  lesson_id uuid NOT NULL,
  progress integer NOT NULL DEFAULT 0,
  watched_seconds numeric NOT NULL DEFAULT 0,
  last_watched_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id, last_watched_at)
) PARTITION BY RANGE (last_watched_at);

-- Create partitions for chat_messages
DO $$
BEGIN
  FOR i IN 0..11 LOOP
    EXECUTE format(
      'CREATE TABLE IF NOT EXISTS chat_messages_y%sm%s 
       PARTITION OF chat_messages_new
       FOR VALUES FROM (%L) TO (%L)',
      to_char(CURRENT_DATE + (interval '1 month' * i), 'YYYY'),
      to_char(CURRENT_DATE + (interval '1 month' * i), 'MM'),
      date_trunc('month', CURRENT_DATE + (interval '1 month' * i)),
      date_trunc('month', CURRENT_DATE + (interval '1 month' * (i + 1)))
    );
  END LOOP;
END $$;

-- Create partitions for video_progress
DO $$
BEGIN
  FOR i IN 0..11 LOOP
    EXECUTE format(
      'CREATE TABLE IF NOT EXISTS video_progress_y%sm%s 
       PARTITION OF video_progress_new
       FOR VALUES FROM (%L) TO (%L)',
      to_char(CURRENT_DATE + (interval '1 month' * i), 'YYYY'),
      to_char(CURRENT_DATE + (interval '1 month' * i), 'MM'),
      date_trunc('month', CURRENT_DATE + (interval '1 month' * i)),
      date_trunc('month', CURRENT_DATE + (interval '1 month' * (i + 1)))
    );
  END LOOP;
END $$;

-- Add foreign key constraints to partitioned tables
ALTER TABLE chat_messages_new
  ADD CONSTRAINT chat_messages_new_channel_id_fkey
  FOREIGN KEY (channel_id) REFERENCES chat_channels(id) ON DELETE CASCADE,
  ADD CONSTRAINT chat_messages_new_user_id_fkey
  FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE;

ALTER TABLE video_progress_new
  ADD CONSTRAINT video_progress_new_user_id_fkey
  FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE,
  ADD CONSTRAINT video_progress_new_course_id_fkey
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  ADD CONSTRAINT video_progress_new_lesson_id_fkey
  FOREIGN KEY (lesson_id) REFERENCES course_lessons(id) ON DELETE CASCADE;

-- Enable RLS on new tables
ALTER TABLE chat_messages_new ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_progress_new ENABLE ROW LEVEL SECURITY;

-- Copy RLS policies from old tables
CREATE POLICY "Chat messages are viewable by enrolled users" ON chat_messages_new
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM enrollments e
      JOIN chat_channels c ON c.course_id = e.course_id
      WHERE e.user_id = auth.uid()
      AND c.id = chat_messages_new.channel_id
    )
  );

CREATE POLICY "Users can view their own video progress" ON video_progress_new
  FOR SELECT USING (auth.uid() = user_id);

-- Enable parallel query for large tables
ALTER TABLE chat_messages SET (parallel_workers = 4);
ALTER TABLE video_progress SET (parallel_workers = 4);
ALTER TABLE completed_lessons SET (parallel_workers = 4);

-- Create statistics for better query planning
ANALYZE chat_messages;
ANALYZE video_progress;
ANALYZE completed_lessons;
ANALYZE course_rankings;