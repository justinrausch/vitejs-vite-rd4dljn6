/*
  # Fix chat permissions

  1. Changes
    - Update RLS policies for chat_messages to ensure proper access
    - Add additional indexes for better performance
    - Fix potential issues with realtime subscriptions
*/

-- Drop existing policies that might be causing issues
DROP POLICY IF EXISTS "Chat messages are viewable by enrolled users" ON chat_messages;
DROP POLICY IF EXISTS "Users can create messages in channels they have access to" ON chat_messages;

-- Create more permissive policies for chat messages
CREATE POLICY "Anyone can view chat messages"
  ON chat_messages FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create messages"
  ON chat_messages FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- Add additional indexes for better performance
CREATE INDEX IF NOT EXISTS chat_messages_user_id_idx ON chat_messages(user_id);
CREATE INDEX IF NOT EXISTS chat_messages_channel_id_created_at_idx ON chat_messages(channel_id, created_at);

-- Enable realtime for the chat_messages table if not already enabled
-- Using DO block instead of transaction with IF NOT EXISTS
DO $$
DECLARE
  table_exists BOOLEAN;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND schemaname = 'public' 
    AND tablename = 'chat_messages'
  ) INTO table_exists;
  
  IF NOT table_exists THEN
    -- Add the table to the publication
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages';
  END IF;
END $$;