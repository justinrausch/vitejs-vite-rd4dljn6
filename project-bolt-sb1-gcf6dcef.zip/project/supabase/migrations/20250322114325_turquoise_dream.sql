/*
  # Add image support to chat messages

  1. Changes
    - Add image_url column to parent chat_messages table
    - Create storage bucket for chat images
    - Add storage policies for image access
    - Update notification function to include image_url

  2. Security
    - Public read access for chat images
    - Authenticated users can upload images
*/

-- Add image_url column to parent table only
-- It will automatically propagate to all partitions
ALTER TABLE chat_messages ADD COLUMN IF NOT EXISTS image_url text;

-- Create storage bucket for chat images if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-images', 'chat-images', true)
ON CONFLICT (id) DO NOTHING;

-- Add storage policies for chat images
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Public Access to Chat Images'
    AND tablename = 'objects'
    AND schemaname = 'storage'
  ) THEN
    CREATE POLICY "Public Access to Chat Images"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'chat-images');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE policyname = 'Authenticated users can upload chat images'
    AND tablename = 'objects'
    AND schemaname = 'storage'
  ) THEN
    CREATE POLICY "Authenticated users can upload chat images"
    ON storage.objects FOR INSERT
    WITH CHECK (
      bucket_id = 'chat-images' AND
      auth.role() = 'authenticated'
    );
  END IF;
END $$;

-- Update notify_chat_message function to include image_url
CREATE OR REPLACE FUNCTION notify_chat_message()
RETURNS trigger AS $$
BEGIN
  PERFORM pg_notify(
    'new_chat_message',
    json_build_object(
      'channel_id', NEW.channel_id,
      'message', json_build_object(
        'id', NEW.id,
        'content', NEW.content,
        'created_at', NEW.created_at,
        'user_id', NEW.user_id,
        'image_url', NEW.image_url
      )
    )::text
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;