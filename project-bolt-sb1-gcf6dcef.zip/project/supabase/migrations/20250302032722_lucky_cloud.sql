-- Add tagline field to courses table
ALTER TABLE courses ADD COLUMN IF NOT EXISTS tagline text;

-- Add index for better search performance
CREATE INDEX IF NOT EXISTS idx_courses_tagline ON courses USING gin(to_tsvector('english', COALESCE(tagline, '')));

-- Update existing courses with sample taglines
UPDATE courses SET tagline = CASE 
  WHEN title = 'Mountain Bike Fundamentals' THEN 'Master essential MTB skills from scratch'
  WHEN title = 'Advanced Trail Building' THEN 'Design and build sustainable MTB trails'
  WHEN title = 'Enduro Racing Mastery' THEN 'Dominate enduro races with pro techniques'
  WHEN title = 'Bike Maintenance Essentials' THEN 'Keep your bike running perfectly'
  WHEN title = 'Freeride Progression' THEN 'Level up your freeride skills safely'
  ELSE 'Master new skills with expert guidance'
END
WHERE tagline IS NULL;