/*
  # Add coach property to profiles

  1. Changes
    - Add `is_coach` boolean column to profiles table with default value of false
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'is_coach'
  ) THEN
    ALTER TABLE profiles ADD COLUMN is_coach boolean DEFAULT false;
  END IF;
END $$;