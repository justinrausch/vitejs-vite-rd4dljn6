/*
  # Simplify Video Storage Structure

  1. Changes
    - Remove video bucketing system
    - Store all course videos in a single location
    - Update triggers and functions to use simplified storage

  2. Security
    - Maintain existing RLS policies
    - Update storage permissions
*/

-- Drop existing triggers
DROP TRIGGER IF EXISTS on_course_created ON courses;
DROP TRIGGER IF EXISTS on_lesson_created ON course_lessons;

-- Drop existing functions
DROP FUNCTION IF EXISTS create_course_bucket_trigger;
DROP FUNCTION IF EXISTS create_lesson_bucket_trigger;

-- Update course_lessons table to use simplified video storage
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'course_lessons' AND column_name = 'video_path'
  ) THEN
    ALTER TABLE course_lessons ADD COLUMN video_path text;
  END IF;
END $$;

-- Create function to handle video storage
CREATE OR REPLACE FUNCTION handle_video_storage()
RETURNS trigger AS $$
BEGIN
  -- Set video path using a standardized format
  NEW.video_path := 'courses/' || NEW.course_id || '/videos/' || NEW.id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for video path management
CREATE TRIGGER handle_lesson_video
  BEFORE INSERT OR UPDATE ON course_lessons
  FOR EACH ROW
  EXECUTE FUNCTION handle_video_storage();