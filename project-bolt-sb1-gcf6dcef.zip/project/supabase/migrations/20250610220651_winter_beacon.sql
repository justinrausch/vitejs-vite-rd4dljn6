/*
  # Course Posts and Comments System

  1. New Tables
    - `course_posts` - Stores posts, announcements, and polls for courses
    - `course_post_comments` - Stores comments on posts
    - `course_post_likes` - Stores likes on posts
    - `course_poll_votes` - Stores votes on polls

  2. Security
    - Enable RLS on all tables
    - Add policies for course instructors and enrolled students
*/

-- Create course_posts table
CREATE TABLE IF NOT EXISTS course_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  media_url text,
  media_type text CHECK (media_type IN ('image', 'video')),
  post_type text NOT NULL CHECK (post_type IN ('post', 'announcement', 'poll')),
  poll_options text[] DEFAULT NULL,
  poll_results jsonb DEFAULT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create course_post_comments table
CREATE TABLE IF NOT EXISTS course_post_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES course_posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  parent_id uuid REFERENCES course_post_comments(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

-- Create course_post_likes table
CREATE TABLE IF NOT EXISTS course_post_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES course_posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- Create course_poll_votes table
CREATE TABLE IF NOT EXISTS course_poll_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES course_posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  option text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_course_posts_course_id ON course_posts(course_id);
CREATE INDEX IF NOT EXISTS idx_course_posts_user_id ON course_posts(user_id);
CREATE INDEX IF NOT EXISTS idx_course_posts_created_at ON course_posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_course_post_comments_post_id ON course_post_comments(post_id);
CREATE INDEX IF NOT EXISTS idx_course_post_comments_parent_id ON course_post_comments(parent_id);
CREATE INDEX IF NOT EXISTS idx_course_post_likes_post_id ON course_post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_course_poll_votes_post_id ON course_poll_votes(post_id);

-- Enable RLS
ALTER TABLE course_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_post_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_poll_votes ENABLE ROW LEVEL SECURITY;

-- RLS Policies for course_posts

-- Everyone can view posts
CREATE POLICY "Course posts are viewable by enrolled users and instructors" 
ON course_posts FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM enrollments e
    WHERE e.course_id = course_posts.course_id
    AND e.user_id = auth.uid()
  ) OR 
  EXISTS (
    SELECT 1 FROM courses c
    WHERE c.id = course_posts.course_id
    AND c.instructor_id = auth.uid()
  )
);

-- Only instructors can create posts
CREATE POLICY "Course instructors can create posts" 
ON course_posts FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM courses c
    WHERE c.id = course_posts.course_id
    AND c.instructor_id = auth.uid()
  )
);

-- Instructors can update their own posts
CREATE POLICY "Course instructors can update their posts" 
ON course_posts FOR UPDATE 
USING (
  user_id = auth.uid() AND
  EXISTS (
    SELECT 1 FROM courses c
    WHERE c.id = course_posts.course_id
    AND c.instructor_id = auth.uid()
  )
);

-- Instructors can delete their own posts
CREATE POLICY "Course instructors can delete their posts" 
ON course_posts FOR DELETE 
USING (
  user_id = auth.uid() AND
  EXISTS (
    SELECT 1 FROM courses c
    WHERE c.id = course_posts.course_id
    AND c.instructor_id = auth.uid()
  )
);

-- RLS Policies for course_post_comments

-- Everyone can view comments
CREATE POLICY "Course post comments are viewable by enrolled users and instructors" 
ON course_post_comments FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM course_posts p
    JOIN enrollments e ON e.course_id = p.course_id
    WHERE p.id = course_post_comments.post_id
    AND e.user_id = auth.uid()
  ) OR 
  EXISTS (
    SELECT 1 FROM course_posts p
    JOIN courses c ON c.id = p.course_id
    WHERE p.id = course_post_comments.post_id
    AND c.instructor_id = auth.uid()
  )
);

-- Enrolled users and instructors can create comments
CREATE POLICY "Enrolled users and instructors can create comments" 
ON course_post_comments FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM course_posts p
    JOIN enrollments e ON e.course_id = p.course_id
    WHERE p.id = course_post_comments.post_id
    AND e.user_id = auth.uid()
  ) OR 
  EXISTS (
    SELECT 1 FROM course_posts p
    JOIN courses c ON c.id = p.course_id
    WHERE p.id = course_post_comments.post_id
    AND c.instructor_id = auth.uid()
  )
);

-- Users can update their own comments
CREATE POLICY "Users can update their own comments" 
ON course_post_comments FOR UPDATE 
USING (user_id = auth.uid());

-- Users can delete their own comments
CREATE POLICY "Users can delete their own comments" 
ON course_post_comments FOR DELETE 
USING (user_id = auth.uid());

-- Instructors can delete any comments on their course posts
CREATE POLICY "Instructors can delete any comments on their course posts" 
ON course_post_comments FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM course_posts p
    JOIN courses c ON c.id = p.course_id
    WHERE p.id = course_post_comments.post_id
    AND c.instructor_id = auth.uid()
  )
);

-- RLS Policies for course_post_likes

-- Everyone can view likes
CREATE POLICY "Course post likes are viewable by everyone" 
ON course_post_likes FOR SELECT 
USING (true);

-- Enrolled users and instructors can like posts
CREATE POLICY "Enrolled users and instructors can like posts" 
ON course_post_likes FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM course_posts p
    JOIN enrollments e ON e.course_id = p.course_id
    WHERE p.id = course_post_likes.post_id
    AND e.user_id = auth.uid()
  ) OR 
  EXISTS (
    SELECT 1 FROM course_posts p
    JOIN courses c ON c.id = p.course_id
    WHERE p.id = course_post_likes.post_id
    AND c.instructor_id = auth.uid()
  )
);

-- Users can delete their own likes
CREATE POLICY "Users can delete their own likes" 
ON course_post_likes FOR DELETE 
USING (user_id = auth.uid());

-- RLS Policies for course_poll_votes

-- Everyone can view poll votes
CREATE POLICY "Course poll votes are viewable by everyone" 
ON course_poll_votes FOR SELECT 
USING (true);

-- Enrolled users and instructors can vote in polls
CREATE POLICY "Enrolled users and instructors can vote in polls" 
ON course_poll_votes FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM course_posts p
    JOIN enrollments e ON e.course_id = p.course_id
    WHERE p.id = course_poll_votes.post_id
    AND e.user_id = auth.uid()
  ) OR 
  EXISTS (
    SELECT 1 FROM course_posts p
    JOIN courses c ON c.id = p.course_id
    WHERE p.id = course_poll_votes.post_id
    AND c.instructor_id = auth.uid()
  )
);

-- Users can update their own votes
CREATE POLICY "Users can update their own votes" 
ON course_poll_votes FOR UPDATE 
USING (user_id = auth.uid());

-- Create trigger to update post updated_at timestamp
CREATE OR REPLACE FUNCTION update_course_post_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_course_post_updated_at
BEFORE UPDATE ON course_posts
FOR EACH ROW
EXECUTE FUNCTION update_course_post_updated_at();

-- Create trigger to update post comments_count
CREATE OR REPLACE FUNCTION update_post_comments_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE course_posts
    SET comments_count = COALESCE(comments_count, 0) + 1
    WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE course_posts
    SET comments_count = GREATEST(COALESCE(comments_count, 0) - 1, 0)
    WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_post_comments_count
AFTER INSERT OR DELETE ON course_post_comments
FOR EACH ROW
EXECUTE FUNCTION update_post_comments_count();

-- Create trigger to update post likes_count
CREATE OR REPLACE FUNCTION update_post_likes_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE course_posts
    SET likes_count = COALESCE(likes_count, 0) + 1
    WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE course_posts
    SET likes_count = GREATEST(COALESCE(likes_count, 0) - 1, 0)
    WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_post_likes_count
AFTER INSERT OR DELETE ON course_post_likes
FOR EACH ROW
EXECUTE FUNCTION update_post_likes_count();

-- Add likes_count and comments_count columns to course_posts if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'course_posts' AND column_name = 'likes_count') THEN
    ALTER TABLE course_posts ADD COLUMN likes_count integer DEFAULT 0;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'course_posts' AND column_name = 'comments_count') THEN
    ALTER TABLE course_posts ADD COLUMN comments_count integer DEFAULT 0;
  END IF;
END $$;