/*
  # Add Strava username to profiles

  1. Changes
    - Add `strava` column to `profiles` table for storing Strava usernames
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'strava'
  ) THEN
    ALTER TABLE profiles ADD COLUMN strava text;
  END IF;
END $$;