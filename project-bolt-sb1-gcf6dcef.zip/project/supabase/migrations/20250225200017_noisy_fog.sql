/*
  # Create course structure and sample data

  1. New Tables
    - course_chapters: Organizes course content into chapters
    - course_lessons: Individual video lessons within chapters
    - course_plans: Different pricing options for courses
    - course_tags: Course categorization and filtering

  2. Security
    - Enable RLS on all new tables
    - Add policies for public course viewing
*/

-- Create course_chapters table
CREATE TABLE course_chapters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  title text NOT NULL,
  position integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create course_lessons table
CREATE TABLE course_lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chapter_id uuid REFERENCES course_chapters(id) ON DELETE CASCADE,
  title text NOT NULL,
  video_url text NOT NULL,
  position integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create course_plans table
CREATE TABLE course_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  title text NOT NULL,
  price numeric NOT NULL,
  renewal_period text,
  features text[] NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create course_tags table
CREATE TABLE course_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  tag text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(course_id, tag)
);

-- Enable RLS on new tables
ALTER TABLE course_chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_tags ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Course chapters are viewable by everyone"
  ON course_chapters FOR SELECT
  USING (true);

CREATE POLICY "Course lessons are viewable by everyone"
  ON course_lessons FOR SELECT
  USING (true);

CREATE POLICY "Course plans are viewable by everyone"
  ON course_plans FOR SELECT
  USING (true);

CREATE POLICY "Course tags are viewable by everyone"
  ON course_tags FOR SELECT
  USING (true);

-- Function to insert course with all related data
CREATE OR REPLACE FUNCTION insert_course_with_data(
  title text,
  description text,
  price numeric,
  category text,
  image_url text,
  chapters json,
  plans json,
  tags text[]
) RETURNS uuid AS $$
DECLARE
  course_id uuid;
  chapter_data json;
  chapter_id uuid;
  lesson_data json;
  plan_data json;
  tag text;
BEGIN
  -- Insert course
  INSERT INTO courses (id, title, description, price, instructor_id, category, image_url)
  VALUES (
    gen_random_uuid(),
    title,
    description,
    price,
    (SELECT id FROM profiles LIMIT 1),
    category,
    image_url
  )
  RETURNING id INTO course_id;

  -- Insert chapters and lessons
  FOR chapter_data IN SELECT * FROM json_array_elements(chapters)
  LOOP
    INSERT INTO course_chapters (course_id, title, position)
    VALUES (
      course_id,
      (chapter_data->>'title'),
      (chapter_data->>'position')::integer
    )
    RETURNING id INTO chapter_id;

    FOR lesson_data IN SELECT * FROM json_array_elements(chapter_data->'lessons')
    LOOP
      INSERT INTO course_lessons (chapter_id, title, video_url, position)
      VALUES (
        chapter_id,
        (lesson_data->>'title'),
        (lesson_data->>'video_url'),
        (lesson_data->>'position')::integer
      );
    END LOOP;
  END LOOP;

  -- Insert plans
  FOR plan_data IN SELECT * FROM json_array_elements(plans)
  LOOP
    INSERT INTO course_plans (course_id, title, price, renewal_period, features)
    VALUES (
      course_id,
      (plan_data->>'title'),
      (plan_data->>'price')::numeric,
      (plan_data->>'renewal_period'),
      (SELECT array_agg(x) FROM json_array_elements_text(plan_data->'features') x)
    );
  END LOOP;

  -- Insert tags
  FOREACH tag IN ARRAY tags
  LOOP
    INSERT INTO course_tags (course_id, tag)
    VALUES (course_id, tag);
  END LOOP;

  RETURN course_id;
END;
$$ LANGUAGE plpgsql;

-- Insert example courses using the function
SELECT insert_course_with_data(
  'Mountain Bike Fundamentals',
  'Master the essential skills of mountain biking from basic techniques to advanced trail riding.',
  49.99,
  'MTB',
  'https://images.unsplash.com/photo-1576858574144-9ae1ebcf5ae5?auto=format&fit=crop&q=80',
  '[
    {
      "title": "Getting Started",
      "position": 1,
      "lessons": [
        {"title": "Bike Setup", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Safety Basics", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    },
    {
      "title": "Basic Techniques",
      "position": 2,
      "lessons": [
        {"title": "Body Position", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Braking Technique", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    },
    {
      "title": "Trail Skills",
      "position": 3,
      "lessons": [
        {"title": "Reading the Trail", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Cornering", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    }
  ]'::json,
  '[
    {
      "title": "Monthly Access",
      "price": 49.99,
      "renewal_period": "monthly",
      "features": ["Full course access", "Community forum access", "Monthly Q&A sessions"]
    },
    {
      "title": "Lifetime Access",
      "price": 399.99,
      "renewal_period": null,
      "features": ["Lifetime course access", "Community forum access", "Private coaching session"]
    }
  ]'::json,
  ARRAY['MTB', 'Beginner', 'Skills']
);

SELECT insert_course_with_data(
  'Advanced Trail Building',
  'Learn how to design, build, and maintain sustainable mountain bike trails.',
  79.99,
  'Trail Building',
  'https://images.unsplash.com/photo-1605540436563-5bca919ae766?auto=format&fit=crop&q=80',
  '[
    {
      "title": "Trail Design Principles",
      "position": 1,
      "lessons": [
        {"title": "Site Analysis", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Flow Concepts", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    },
    {
      "title": "Building Techniques",
      "position": 2,
      "lessons": [
        {"title": "Building Berms", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Jump Construction", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    },
    {
      "title": "Maintenance",
      "position": 3,
      "lessons": [
        {"title": "Drainage Systems", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Regular Upkeep", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    }
  ]'::json,
  '[
    {
      "title": "Monthly Access",
      "price": 79.99,
      "renewal_period": "monthly",
      "features": ["Full course access", "Trail building templates", "Monthly workshops"]
    },
    {
      "title": "Lifetime Access",
      "price": 599.99,
      "renewal_period": null,
      "features": ["Lifetime course access", "Trail building templates", "On-site consultation"]
    }
  ]'::json,
  ARRAY['Trail Building', 'Advanced', 'Design']
);

SELECT insert_course_with_data(
  'Enduro Racing Mastery',
  'Comprehensive guide to enduro racing techniques, training, and race day strategies.',
  89.99,
  'Enduro',
  'https://images.unsplash.com/photo-1565109698955-9673769e0e80?auto=format&fit=crop&q=80',
  '[
    {
      "title": "Race Preparation",
      "position": 1,
      "lessons": [
        {"title": "Bike Setup for Racing", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Course Analysis", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    },
    {
      "title": "Racing Techniques",
      "position": 2,
      "lessons": [
        {"title": "High-Speed Cornering", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Technical Descents", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    },
    {
      "title": "Recovery and Training",
      "position": 3,
      "lessons": [
        {"title": "Recovery Techniques", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Training Plans", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    }
  ]'::json,
  '[
    {
      "title": "Monthly Access",
      "price": 89.99,
      "renewal_period": "monthly",
      "features": ["Full course access", "Training plans", "Race day preparation guide"]
    },
    {
      "title": "Lifetime Access",
      "price": 699.99,
      "renewal_period": null,
      "features": ["Lifetime course access", "Training plans", "Personal race strategy session"]
    }
  ]'::json,
  ARRAY['Enduro', 'Racing', 'Advanced']
);

SELECT insert_course_with_data(
  'Bike Maintenance Essentials',
  'Keep your bike in top condition with professional maintenance techniques.',
  39.99,
  'Maintenance',
  'https://images.unsplash.com/photo-1599058917765-a780eda07a3e?auto=format&fit=crop&q=80',
  '[
    {
      "title": "Basic Maintenance",
      "position": 1,
      "lessons": [
        {"title": "Safety Checks", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Cleaning Techniques", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    },
    {
      "title": "Drivetrain Service",
      "position": 2,
      "lessons": [
        {"title": "Chain Maintenance", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Gear Indexing", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    },
    {
      "title": "Suspension Setup",
      "position": 3,
      "lessons": [
        {"title": "Fork Setup", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Shock Tuning", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    }
  ]'::json,
  '[
    {
      "title": "Monthly Access",
      "price": 39.99,
      "renewal_period": "monthly",
      "features": ["Full course access", "Maintenance checklist", "Tool guide"]
    },
    {
      "title": "Lifetime Access",
      "price": 299.99,
      "renewal_period": null,
      "features": ["Lifetime course access", "Maintenance checklist", "Workshop session"]
    }
  ]'::json,
  ARRAY['Maintenance', 'Technical', 'Beginner']
);

SELECT insert_course_with_data(
  'Freeride Progression',
  'Progress your freeride skills from intermediate jumps to advanced features.',
  69.99,
  'Freeride',
  'https://images.unsplash.com/photo-1583722276291-35e9d6a214b1?auto=format&fit=crop&q=80',
  '[
    {
      "title": "Jump Fundamentals",
      "position": 1,
      "lessons": [
        {"title": "Bunny Hops", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Table Tops", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    },
    {
      "title": "Drop Techniques",
      "position": 2,
      "lessons": [
        {"title": "Drop Basics", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Advanced Drops", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    },
    {
      "title": "Advanced Features",
      "position": 3,
      "lessons": [
        {"title": "Gap Jumps", "video_url": "dQw4w9WgXcQ", "position": 1},
        {"title": "Step Downs", "video_url": "dQw4w9WgXcQ", "position": 2}
      ]
    }
  ]'::json,
  '[
    {
      "title": "Monthly Access",
      "price": 69.99,
      "renewal_period": "monthly",
      "features": ["Full course access", "Progression roadmap", "Technique analysis"]
    },
    {
      "title": "Lifetime Access",
      "price": 499.99,
      "renewal_period": null,
      "features": ["Lifetime course access", "Progression roadmap", "Private coaching session"]
    }
  ]'::json,
  ARRAY['Freeride', 'Advanced', 'Jumping']
);