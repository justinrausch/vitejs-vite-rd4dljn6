/*
  # Fix course lessons ordering

  1. Changes
    - Add composite index on course_chapters(course_id, position)
    - Add composite index on course_lessons(chapter_id, position)
    - Add foreign key constraint to ensure course_id consistency

  2. Indexes
    - Optimize queries that order by position within chapters
    - Support efficient filtering and sorting of lessons by chapter position

  3. Constraints
    - Ensure data integrity between courses, chapters, and lessons
*/

-- Add composite indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_course_chapters_course_position 
ON course_chapters(course_id, position);

CREATE INDEX IF NOT EXISTS idx_course_lessons_chapter_position 
ON course_lessons(chapter_id, position);

-- Add foreign key to ensure course_id consistency
ALTER TABLE course_lessons
ADD COLUMN IF NOT EXISTS course_id uuid REFERENCES courses(id) ON DELETE CASCADE;

-- Update course_id for existing lessons
DO $$
BEGIN
  UPDATE course_lessons
  SET course_id = course_chapters.course_id
  FROM course_chapters
  WHERE course_lessons.chapter_id = course_chapters.id
  AND course_lessons.course_id IS NULL;
END $$;

-- Make course_id NOT NULL after updating existing records
ALTER TABLE course_lessons
ALTER COLUMN course_id SET NOT NULL;

-- Add index for direct course_id queries
CREATE INDEX IF NOT EXISTS idx_course_lessons_course_id
ON course_lessons(course_id);