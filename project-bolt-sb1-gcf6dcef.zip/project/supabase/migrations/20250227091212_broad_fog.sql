-- Create video_progress table if it doesn't exist
CREATE TABLE IF NOT EXISTS video_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
  lesson_id uuid REFERENCES course_lessons(id) ON DELETE CASCADE NOT NULL,
  progress integer NOT NULL DEFAULT 0,
  watched_seconds numeric NOT NULL DEFAULT 0,
  last_watched_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, lesson_id)
);

-- Enable RLS on the video_progress table
ALTER TABLE video_progress ENABLE ROW LEVEL SECURITY;

-- Create policies for the video_progress table
DO $$ 
BEGIN
  -- Check if the policy already exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'video_progress' 
    AND policyname = 'Users can view their own video progress'
  ) THEN
    CREATE POLICY "Users can view their own video progress"
      ON video_progress FOR SELECT
      USING (auth.uid() = user_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'video_progress' 
    AND policyname = 'Users can insert their own video progress'
  ) THEN
    CREATE POLICY "Users can insert their own video progress"
      ON video_progress FOR INSERT
      WITH CHECK (auth.uid() = user_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'video_progress' 
    AND policyname = 'Users can update their own video progress'
  ) THEN
    CREATE POLICY "Users can update their own video progress"
      ON video_progress FOR UPDATE
      USING (auth.uid() = user_id);
  END IF;
END $$;

-- Add index for faster queries if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'video_progress' 
    AND indexname = 'idx_video_progress_user_lesson'
  ) THEN
    CREATE INDEX idx_video_progress_user_lesson
      ON video_progress(user_id, lesson_id);
  END IF;
END $$;

-- Update the clean_up_course_data function to also clean up video progress
CREATE OR REPLACE FUNCTION clean_up_course_data()
RETURNS trigger AS $$
BEGIN
  -- Delete completed lessons
  DELETE FROM completed_lessons
  WHERE user_id = OLD.user_id
  AND course_id = OLD.course_id;

  -- Delete bookmarked lessons
  DELETE FROM bookmarked_lessons
  WHERE user_id = OLD.user_id
  AND course_id = OLD.course_id;

  -- Delete video progress
  DELETE FROM video_progress
  WHERE user_id = OLD.user_id
  AND course_id = OLD.course_id;

  -- Delete chat messages
  DELETE FROM chat_messages
  WHERE user_id = OLD.user_id
  AND channel_id IN (
    SELECT id FROM chat_channels
    WHERE course_id = OLD.course_id
  );

  RETURN OLD;
END;
$$ LANGUAGE plpgsql;