/*
  # Add course rankings based on enrollments

  1. Changes
    - Add member_count column to courses table
    - Add trigger to update member_count on enrollment changes
    - Add function to calculate course rankings
*/

-- Add member_count column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'courses' AND column_name = 'member_count'
  ) THEN
    ALTER TABLE courses ADD COLUMN member_count integer DEFAULT 0;
  END IF;
END $$;

-- Create function to update course member count
CREATE OR REPLACE FUNCTION update_course_member_count()
RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE courses
    SET member_count = (
      SELECT COUNT(*) FROM enrollments WHERE course_id = NEW.course_id
    )
    WHERE id = NEW.course_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE courses
    SET member_count = (
      SELECT COUNT(*) FROM enrollments WHERE course_id = OLD.course_id
    )
    WHERE id = OLD.course_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for enrollment changes
DROP TRIGGER IF EXISTS enrollment_insert_trigger ON enrollments;
CREATE TRIGGER enrollment_insert_trigger
  AFTER INSERT ON enrollments
  FOR EACH ROW
  EXECUTE FUNCTION update_course_member_count();

DROP TRIGGER IF EXISTS enrollment_delete_trigger ON enrollments;
CREATE TRIGGER enrollment_delete_trigger
  AFTER DELETE ON enrollments
  FOR EACH ROW
  EXECUTE FUNCTION update_course_member_count();

-- Update existing member counts
UPDATE courses
SET member_count = (
  SELECT COUNT(*) FROM enrollments WHERE enrollments.course_id = courses.id
);

-- Create index for faster ranking queries
CREATE INDEX IF NOT EXISTS idx_courses_member_count ON courses(member_count DESC);