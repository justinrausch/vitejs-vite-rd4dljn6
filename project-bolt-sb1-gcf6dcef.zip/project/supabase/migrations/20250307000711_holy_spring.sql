/*
  # Update chat message policies for instructors

  1. Changes
    - Drop existing chat message policies
    - Create new policies that allow instructors to view and send messages in their courses
  
  2. Security
    - Instructors can view all messages in their courses
    - Instructors can send messages in their courses
    - Maintains existing permissions for enrolled users
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enrolled users can view messages" ON chat_messages;
DROP POLICY IF EXISTS "Enrolled users can send messages" ON chat_messages;

-- Create new policy for viewing messages
CREATE POLICY "Enrolled users and instructors can view messages" ON chat_messages
FOR SELECT TO public
USING (
  EXISTS (
    SELECT 1 FROM enrollments e
    JOIN chat_channels c ON c.course_id = e.course_id
    WHERE e.user_id = auth.uid() 
    AND c.id = chat_messages.channel_id
  )
  OR 
  EXISTS (
    SELECT 1 FROM chat_channels c
    JOIN courses co ON co.id = c.course_id
    WHERE co.instructor_id = auth.uid()
    AND c.id = chat_messages.channel_id
  )
);

-- Create new policy for sending messages
CREATE POLICY "Enrolled users and instructors can send messages" ON chat_messages
FOR INSERT TO public
WITH CHECK (
  (
    EXISTS (
      SELECT 1 FROM enrollments e
      JOIN chat_channels c ON c.course_id = e.course_id
      WHERE e.user_id = auth.uid() 
      AND c.id = chat_messages.channel_id
    )
    OR 
    EXISTS (
      SELECT 1 FROM chat_channels c
      JOIN courses co ON co.id = c.course_id
      WHERE co.instructor_id = auth.uid()
      AND c.id = chat_messages.channel_id
    )
  )
  AND auth.uid() = chat_messages.user_id
);