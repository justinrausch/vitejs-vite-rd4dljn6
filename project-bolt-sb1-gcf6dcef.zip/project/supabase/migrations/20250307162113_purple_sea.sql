/*
  # Storage and Course Creation Setup

  1. Storage Configuration
    - Enable RLS on storage buckets and objects
    - Configure public bucket for course content
    - Set up secure access policies
  
  2. Course Management
    - Update course creation policies
    - Configure bucket creation trigger
*/

-- Enable RLS on storage buckets and objects
ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Create public bucket for course content
INSERT INTO storage.buckets (id, name)
VALUES ('public', 'public')
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to create and manage their course content
CREATE POLICY "Authenticated users can create course content"
ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'public');

CREATE POLICY "Users can update their own course content"
ON storage.objects
FOR UPDATE TO authenticated
USING (auth.uid() IN (
  SELECT instructor_id FROM courses 
  WHERE id = (SELECT SUBSTRING(name FROM 'course_(.*?)/.*') AS course_id)::uuid
));

CREATE POLICY "Users can delete their own course content"
ON storage.objects
FOR DELETE TO authenticated
USING (auth.uid() IN (
  SELECT instructor_id FROM courses 
  WHERE id = (SELECT SUBSTRING(name FROM 'course_(.*?)/.*') AS course_id)::uuid
));

CREATE POLICY "Anyone can view course content"
ON storage.objects
FOR SELECT TO public
USING (bucket_id = 'public');

-- Create a function to handle course data cleanup
CREATE OR REPLACE FUNCTION clean_up_course_data()
RETURNS TRIGGER AS $$
BEGIN
  -- Delete course content from storage
  DELETE FROM storage.objects
  WHERE name LIKE 'course_' || OLD.id || '/%';
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for course deletion cleanup
DROP TRIGGER IF EXISTS on_course_delete ON courses;
CREATE TRIGGER on_course_delete
BEFORE DELETE ON courses
FOR EACH ROW
EXECUTE FUNCTION clean_up_course_data();

-- Update course creation policy
DROP POLICY IF EXISTS "Course creators can create courses" ON courses;
CREATE POLICY "Course creators can create courses"
ON courses
FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.is_coach = true
  )
);

-- Update course management policy
DROP POLICY IF EXISTS "Course creators can manage their courses" ON courses;
CREATE POLICY "Course creators can manage their courses"
ON courses
FOR ALL TO authenticated
USING (instructor_id = auth.uid());

-- Update chapter management policy
DROP POLICY IF EXISTS "Course creators can manage chapters" ON course_chapters;
CREATE POLICY "Course creators can manage chapters"
ON course_chapters
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM courses
    WHERE courses.id = course_chapters.course_id
    AND courses.instructor_id = auth.uid()
  )
);