/*
  # Fix course lessons ordering

  1. Changes
    - Add composite indexes for efficient ordering
    - Add course_id to course_lessons for direct querying
    - Update existing records with course_id

  2. Indexes
    - Optimize queries for ordering by chapter and lesson position
    - Support efficient filtering and sorting

  3. Security
    - Maintain RLS policies
    - Ensure data integrity
*/

-- Add course_id to course_lessons if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'course_lessons' AND column_name = 'course_id'
  ) THEN
    ALTER TABLE course_lessons
    ADD COLUMN course_id uuid REFERENCES courses(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Update existing lessons with course_id
UPDATE course_lessons
SET course_id = course_chapters.course_id
FROM course_chapters
WHERE course_lessons.chapter_id = course_chapters.id
AND course_lessons.course_id IS NULL;

-- Make course_id NOT NULL
ALTER TABLE course_lessons
ALTER COLUMN course_id SET NOT NULL;

-- Create indexes for efficient ordering
CREATE INDEX IF NOT EXISTS idx_course_lessons_ordering 
ON course_lessons(course_id, chapter_id, position);

CREATE INDEX IF NOT EXISTS idx_course_chapters_ordering
ON course_chapters(course_id, position);