-- Create coach_messages table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'coach_messages'
  ) THEN
    CREATE TABLE coach_messages (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
      student_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
      sender_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
      content text NOT NULL,
      lesson_id uuid REFERENCES course_lessons(id) ON DELETE SET NULL,
      image_url text,
      created_at timestamptz DEFAULT now()
    );

    -- Enable RLS
    ALTER TABLE coach_messages ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Create indexes for better performance if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'coach_messages' 
    AND indexname = 'idx_coach_messages_course_student'
  ) THEN
    CREATE INDEX idx_coach_messages_course_student
      ON coach_messages(course_id, student_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'coach_messages' 
    AND indexname = 'idx_coach_messages_lesson'
  ) THEN
    CREATE INDEX idx_coach_messages_lesson
      ON coach_messages(lesson_id);
  END IF;
END $$;

-- Update the clean_up_course_data function to also clean up coach messages
CREATE OR REPLACE FUNCTION clean_up_course_data()
RETURNS trigger AS $$
BEGIN
  -- Delete completed lessons
  DELETE FROM completed_lessons
  WHERE user_id = OLD.user_id
  AND course_id = OLD.course_id;

  -- Delete bookmarked lessons
  DELETE FROM bookmarked_lessons
  WHERE user_id = OLD.user_id
  AND course_id = OLD.course_id;

  -- Delete video progress
  DELETE FROM video_progress
  WHERE user_id = OLD.user_id
  AND course_id = OLD.course_id;

  -- Delete coach messages
  DELETE FROM coach_messages
  WHERE student_id = OLD.user_id
  AND course_id = OLD.course_id;

  -- Delete chat messages
  DELETE FROM chat_messages
  WHERE user_id = OLD.user_id
  AND channel_id IN (
    SELECT id FROM chat_channels
    WHERE course_id = OLD.course_id
  );

  RETURN OLD;
END;
$$ LANGUAGE plpgsql;