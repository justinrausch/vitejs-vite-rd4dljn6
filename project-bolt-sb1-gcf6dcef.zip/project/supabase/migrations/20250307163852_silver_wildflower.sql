/*
  # Course Creation Schema

  1. New Tables
    - courses
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - price (numeric)
      - category (text)
      - instructor_id (uuid, references profiles)
      - image_url (text)
      - created_at (timestamp)
      - updated_at (timestamp)
      - member_count (integer)
      - tagline (text)
      - disciplines (text[])
      - sport (text)

  2. Security
    - Enable RLS on all tables
    - Only coaches can create courses
    - Public can view courses
    - Course creators can manage their own courses

  3. Changes
    - Add tables if they don't exist
    - Add policies if they don't exist
    - Add triggers and functions
*/

-- Create courses table
CREATE TABLE IF NOT EXISTS public.courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  price numeric NOT NULL CHECK (price >= 0),
  category text,
  instructor_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  member_count integer DEFAULT 0,
  tagline text,
  disciplines text[],
  sport text DEFAULT 'Mountain biking',
  CONSTRAINT courses_instructor_must_be_coach CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = instructor_id
      AND profiles.is_coach = true
    )
  )
);

-- Create chapters table
CREATE TABLE IF NOT EXISTS public.course_chapters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  title text NOT NULL,
  position integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create lessons table
CREATE TABLE IF NOT EXISTS public.course_lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chapter_id uuid NOT NULL REFERENCES public.course_chapters(id) ON DELETE CASCADE,
  title text NOT NULL,
  video_url text,
  position integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.course_chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.course_lessons ENABLE ROW LEVEL SECURITY;

-- Create policies if they don't exist
DO $$ 
BEGIN
  -- Courses policies
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'courses' 
    AND policyname = 'Courses are viewable by everyone'
  ) THEN
    CREATE POLICY "Courses are viewable by everyone" 
    ON public.courses FOR SELECT TO public 
    USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'courses' 
    AND policyname = 'Course creators can manage their courses'
  ) THEN
    CREATE POLICY "Course creators can manage their courses" 
    ON public.courses FOR ALL TO authenticated 
    USING (instructor_id = auth.uid())
    WITH CHECK (instructor_id = auth.uid());
  END IF;

  -- Chapters policies
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_chapters' 
    AND policyname = 'Course chapters are viewable by everyone'
  ) THEN
    CREATE POLICY "Course chapters are viewable by everyone" 
    ON public.course_chapters FOR SELECT TO public 
    USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_chapters' 
    AND policyname = 'Course creators can manage chapters'
  ) THEN
    CREATE POLICY "Course creators can manage chapters" 
    ON public.course_chapters FOR ALL TO authenticated 
    USING (
      EXISTS (
        SELECT 1 FROM courses 
        WHERE courses.id = course_chapters.course_id 
        AND courses.instructor_id = auth.uid()
      )
    );
  END IF;

  -- Lessons policies
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_lessons' 
    AND policyname = 'Course lessons are viewable by everyone'
  ) THEN
    CREATE POLICY "Course lessons are viewable by everyone" 
    ON public.course_lessons FOR SELECT TO public 
    USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_lessons' 
    AND policyname = 'Course creators can manage lessons'
  ) THEN
    CREATE POLICY "Course creators can manage lessons" 
    ON public.course_lessons FOR ALL TO authenticated 
    USING (
      EXISTS (
        SELECT 1 FROM course_chapters 
        JOIN courses ON courses.id = course_chapters.course_id 
        WHERE course_chapters.id = course_lessons.chapter_id 
        AND courses.instructor_id = auth.uid()
      )
    );
  END IF;
END $$;

-- Create updated_at trigger function if it doesn't exist
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Drop trigger if it exists and recreate it
DROP TRIGGER IF EXISTS update_courses_updated_at ON public.courses;
CREATE TRIGGER update_courses_updated_at
  BEFORE UPDATE ON public.courses
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create course bucket trigger function
CREATE OR REPLACE FUNCTION create_course_bucket_trigger()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO storage.buckets (id, name)
  VALUES (NEW.id, 'course_' || NEW.id);
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Drop trigger if it exists and recreate it
DROP TRIGGER IF EXISTS on_course_created ON public.courses;
CREATE TRIGGER on_course_created
  AFTER INSERT ON public.courses
  FOR EACH ROW
  EXECUTE FUNCTION create_course_bucket_trigger();

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_courses_instructor_id ON public.courses(instructor_id);
CREATE INDEX IF NOT EXISTS idx_course_chapters_course_id ON public.course_chapters(course_id);
CREATE INDEX IF NOT EXISTS idx_course_lessons_chapter_id ON public.course_lessons(chapter_id);