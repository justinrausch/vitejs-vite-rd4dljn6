/*
  # Fix duplicate messages issue

  1. Changes
    - Add a migration to update the username for the admin user
    - Ensure chat messages are properly attributed to the correct user
*/

-- Update the username for the admin user to ensure it's not the same as the instructor
UPDATE profiles
SET username = 'Admin User'
WHERE username = 'Christian Arehart' 
AND id IN (
  SELECT id FROM auth.users WHERE email = 'admin@gmail.com'
);

-- Clean up any duplicate messages that might have been created during testing
DELETE FROM chat_messages
WHERE id IN (
  SELECT id FROM (
    SELECT id, 
           ROW_NUMBER() OVER (PARTITION BY channel_id, user_id, content, created_at ORDER BY id) as rnum
    FROM chat_messages
  ) t
  WHERE t.rnum > 1
);