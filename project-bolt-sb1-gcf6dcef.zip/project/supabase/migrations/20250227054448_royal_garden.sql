/*
  # Update coach profiles

  1. Changes
     - Temporarily rename existing coach profiles to avoid unique constraint violations
     - Update profiles for new coach accounts with proper information
     - Update course instructor references to point to the new profiles
     - Reset the old profiles to remove coach status
*/

-- First, get the IDs of the existing coaches and temporarily rename them
DO $$
DECLARE
  christian_old_id uuid;
  sarah_old_id uuid;
  emma_old_id uuid;
  mike_old_id uuid;
BEGIN
  -- Get existing coach IDs
  SELECT id INTO christian_old_id FROM profiles WHERE username = 'Christian Arehart' LIMIT 1;
  SELECT id INTO sarah_old_id FROM profiles WHERE username = 'Sarah Johnson' LIMIT 1;
  SELECT id INTO emma_old_id FROM profiles WHERE username = 'Emma Rodriguez' LIMIT 1;
  SELECT id INTO mike_old_id FROM profiles WHERE username = 'Mike Chen' LIMIT 1;
  
  -- First, temporarily rename the existing profiles to avoid unique constraint violations
  UPDATE profiles 
  SET username = username || '_old_' || floor(random() * 1000)::text
  WHERE id IN (christian_old_id, sarah_old_id, emma_old_id, mike_old_id)
  AND id IS NOT NULL;
  
  -- Store the courses associated with each coach
  CREATE TEMP TABLE coach_courses AS
  SELECT 
    instructor_id,
    array_agg(id) as course_ids
  FROM courses
  WHERE instructor_id IN (
    SELECT id FROM (VALUES 
      (christian_old_id), 
      (sarah_old_id), 
      (emma_old_id), 
      (mike_old_id)
    ) AS t(id)
    WHERE id IS NOT NULL
  )
  GROUP BY instructor_id;
  
  -- Create or update profiles for the new coach accounts
  -- Christian Arehart
  WITH new_christian AS (
    SELECT id FROM auth.users WHERE email = 'christian@gmail.com' LIMIT 1
  )
  UPDATE profiles
  SET 
    username = 'Christian Arehart',
    avatar_url = 'https://images.unsplash.com/photo-1600486913747-55e5470d6f40?auto=format&fit=crop&q=80',
    description = 'Professional mountain biker with over 10 years of experience. Specialized in freeride and downhill techniques.',
    instagram = 'christian_arehart',
    youtube = 'christianarehart',
    full_name = 'Christian Arehart',
    is_coach = true
  FROM new_christian
  WHERE profiles.id = new_christian.id;
  
  -- Sarah Johnson
  WITH new_sarah AS (
    SELECT id FROM auth.users WHERE email = 'sarah@gmail.com' LIMIT 1
  )
  UPDATE profiles
  SET 
    username = 'Sarah Johnson',
    avatar_url = 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80',
    description = 'Former pro snowboarder turned coach. Helping riders of all levels improve their skills.',
    instagram = 'sarah_rides',
    youtube = 'sarahjohnson',
    full_name = 'Sarah Johnson',
    is_coach = true
  FROM new_sarah
  WHERE profiles.id = new_sarah.id;
  
  -- Emma Rodriguez
  WITH new_emma AS (
    SELECT id FROM auth.users WHERE email = 'emma@gmail.com' LIMIT 1
  )
  UPDATE profiles
  SET 
    username = 'Emma Rodriguez',
    avatar_url = 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80',
    description = 'Bike mechanic and skills coach. I love helping riders understand both the technical and mechanical aspects of mountain biking.',
    instagram = 'emma_wrenches',
    youtube = 'emmarod',
    full_name = 'Emma Rodriguez',
    is_coach = true
  FROM new_emma
  WHERE profiles.id = new_emma.id;
  
  -- Update course instructor references
  -- For Christian's courses
  IF christian_old_id IS NOT NULL THEN
    UPDATE courses
    SET instructor_id = (SELECT id FROM auth.users WHERE email = 'christian@gmail.com' LIMIT 1)
    WHERE instructor_id = christian_old_id;
  END IF;
  
  -- For Sarah's courses
  IF sarah_old_id IS NOT NULL THEN
    UPDATE courses
    SET instructor_id = (SELECT id FROM auth.users WHERE email = 'sarah@gmail.com' LIMIT 1)
    WHERE instructor_id = sarah_old_id;
  END IF;
  
  -- For Emma's courses
  IF emma_old_id IS NOT NULL THEN
    UPDATE courses
    SET instructor_id = (SELECT id FROM auth.users WHERE email = 'emma@gmail.com' LIMIT 1)
    WHERE instructor_id = emma_old_id;
  END IF;
  
  -- Reset the old profiles to remove coach status
  UPDATE profiles
  SET 
    is_coach = false,
    description = NULL,
    instagram = NULL,
    youtube = NULL
  WHERE id IN (
    SELECT id FROM (VALUES 
      (christian_old_id), 
      (sarah_old_id), 
      (emma_old_id), 
      (mike_old_id)
    ) AS t(id)
    WHERE id IS NOT NULL
  );
  
  -- Drop the temporary table
  DROP TABLE coach_courses;
END $$;

-- Create a Snowboard course for Sarah if it doesn't exist
DO $$
DECLARE
  sarah_id uuid;
BEGIN
  -- Get Sarah's ID
  SELECT id INTO sarah_id FROM auth.users WHERE email = 'sarah@gmail.com' LIMIT 1;
  
  -- Create a Snowboard course if it doesn't exist and Sarah exists
  IF sarah_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM courses WHERE title = 'Snowboard Freestyle Fundamentals') THEN
    INSERT INTO courses (
      id,
      title,
      description,
      price,
      instructor_id,
      category,
      image_url
    ) VALUES (
      gen_random_uuid(),
      'Snowboard Freestyle Fundamentals',
      'Master the basics of freestyle snowboarding with former pro Sarah Johnson. From your first jumps to advanced park tricks.',
      59.99,
      sarah_id,
      'Snowboarding',
      'https://images.unsplash.com/photo-1522056615691-da7b8106c665?auto=format&fit=crop&q=80'
    );
  END IF;
END $$;