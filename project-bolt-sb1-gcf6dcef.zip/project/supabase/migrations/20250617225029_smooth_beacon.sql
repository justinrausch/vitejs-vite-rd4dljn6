/*
  # Fix Course Creation RLS Policies

  1. Security Updates
    - Update RLS policies for courses table to ensure course creators can read their newly created courses
    - Ensure INSERT operations return data properly by fixing SELECT policies
    
  2. Changes
    - Drop and recreate the SELECT policy for courses to ensure it works with INSERT...SELECT operations
    - Ensure the instructor can immediately read their course after creation
*/

-- Drop existing policies that might be conflicting
DROP POLICY IF EXISTS "Courses are viewable by everyone" ON courses;
DROP POLICY IF EXISTS "Course creators can manage their courses" ON courses;

-- Create a comprehensive SELECT policy that allows:
-- 1. Everyone to view courses (public access)
-- 2. Course creators to view their own courses immediately after creation
CREATE POLICY "Courses are viewable by everyone and creators can read their own"
  ON courses
  FOR SELECT
  TO public
  USING (true);

-- Ensure the course creator management policy is properly set
CREATE POLICY "Course creators can manage their courses"
  ON courses
  FOR ALL
  TO authenticated
  USING (instructor_id = auth.uid())
  WITH CHECK (instructor_id = auth.uid());

-- Ensure INSERT policy allows course creators to create courses
DROP POLICY IF EXISTS "Coaches can create courses" ON courses;
DROP POLICY IF EXISTS "Course creators can create courses" ON courses;

CREATE POLICY "Authenticated users with coach role can create courses"
  ON courses
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.is_coach = true
    ) 
    AND instructor_id = auth.uid()
  );