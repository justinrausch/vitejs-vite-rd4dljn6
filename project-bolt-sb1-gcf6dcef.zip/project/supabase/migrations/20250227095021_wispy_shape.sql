-- Drop and recreate policies for coach_messages
DO $$ 
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Students can view their own messages" ON coach_messages;
  DROP POLICY IF EXISTS "Instructors can view messages for their courses" ON coach_messages;
  DROP POLICY IF EXISTS "Students can send messages" ON coach_messages;
  DROP POLICY IF EXISTS "Instructors can reply to messages" ON coach_messages;
  DROP POLICY IF EXISTS "Anyone can view messages they're involved with" ON coach_messages;
  DROP POLICY IF EXISTS "Students and instructors can send messages" ON coach_messages;

  -- Create new policies with fixed permissions
  CREATE POLICY "Anyone can view messages they're involved with"
    ON coach_messages FOR SELECT
    USING (
      auth.uid() = student_id OR
      EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = coach_messages.course_id
        AND courses.instructor_id = auth.uid()
      )
    );

  CREATE POLICY "Students and instructors can send messages"
    ON coach_messages FOR INSERT
    WITH CHECK (
      -- Students can send messages to their courses
      (auth.uid() = student_id AND auth.uid() = sender_id) OR
      -- Instructors can reply to messages in their courses
      (EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = coach_messages.course_id
        AND courses.instructor_id = auth.uid()
      ) AND auth.uid() = sender_id)
    );
END $$;

-- Enable realtime for coach_messages if not already enabled
DO $$
DECLARE
  table_exists BOOLEAN;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND schemaname = 'public' 
    AND tablename = 'coach_messages'
  ) INTO table_exists;
  
  IF NOT table_exists THEN
    -- Add the table to the publication
    ALTER PUBLICATION supabase_realtime ADD TABLE coach_messages;
  END IF;
END $$;

-- Add additional indexes for better performance
CREATE INDEX IF NOT EXISTS idx_coach_messages_sender_created
  ON coach_messages(sender_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_coach_messages_student_course
  ON coach_messages(student_id, course_id, created_at DESC);

-- Add trigger for realtime updates
CREATE OR REPLACE FUNCTION notify_coach_message()
RETURNS trigger AS $$
BEGIN
  PERFORM pg_notify(
    'new_coach_message',
    json_build_object(
      'course_id', NEW.course_id,
      'student_id', NEW.student_id,
      'sender_id', NEW.sender_id,
      'message', json_build_object(
        'id', NEW.id,
        'content', NEW.content,
        'created_at', NEW.created_at,
        'lesson_id', NEW.lesson_id,
        'image_url', NEW.image_url
      )
    )::text
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for realtime updates
DROP TRIGGER IF EXISTS coach_messages_notify ON coach_messages;
CREATE TRIGGER coach_messages_notify
  AFTER INSERT ON coach_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_coach_message();