-- Update profiles to include social media links
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'instagram'
  ) THEN
    ALTER TABLE profiles ADD COLUMN instagram text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'youtube'
  ) THEN
    ALTER TABLE profiles ADD COLUMN youtube text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'description'
  ) THEN
    ALTER TABLE profiles ADD COLUMN description text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'full_name'
  ) THEN
    ALTER TABLE profiles ADD COLUMN full_name text;
  END IF;
END $$;

-- Update the existing coach profile with more details
DO $$
BEGIN
  UPDATE profiles
  SET 
    description = 'Professional mountain biker with over 10 years of experience. Specialized in freeride and downhill techniques.',
    instagram = 'christian_arehart',
    youtube = 'christianarehart',
    full_name = 'Christian Arehart',
    is_coach = true
  WHERE username = 'Christian Arehart';
END $$;

-- Create mock coach profiles by creating auth users first, then profiles
DO $$
DECLARE
  user_id1 uuid;
  user_id2 uuid;
  user_id3 uuid;
  coach_id uuid;
BEGIN
  -- Instead of creating profiles directly with random UUIDs,
  -- we'll create entries in the profiles table for existing users
  -- or update existing profiles with coach information
  
  -- Find existing users that aren't already coaches
  UPDATE profiles
  SET 
    username = 'Sarah Johnson',
    avatar_url = 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80',
    description = 'Former pro snowboarder turned coach. Helping riders of all levels improve their skills.',
    instagram = 'sarah_rides',
    youtube = 'sarahjohnson',
    full_name = 'Sarah Johnson',
    is_coach = true
  WHERE id IN (
    SELECT id FROM profiles 
    WHERE is_coach IS NOT TRUE 
    AND id != (SELECT instructor_id FROM courses LIMIT 1)
    LIMIT 1
  )
  RETURNING id INTO coach_id;
  
  -- If we found a user to make a coach, create a course for them
  IF coach_id IS NOT NULL THEN
    INSERT INTO courses (
      id, 
      title, 
      description, 
      price, 
      instructor_id, 
      category, 
      image_url
    )
    VALUES (
      gen_random_uuid(),
      'Snowboard Freestyle Fundamentals',
      'Master the basics of freestyle snowboarding with former pro Sarah Johnson. From your first jumps to advanced park tricks.',
      59.99,
      coach_id,
      'Snowboarding',
      'https://images.unsplash.com/photo-1522056615691-da7b8106c665?auto=format&fit=crop&q=80'
    )
    ON CONFLICT DO NOTHING;
  END IF;
  
  -- Update more existing profiles to be coaches
  UPDATE profiles
  SET 
    username = 'Mike Chen',
    avatar_url = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80',
    description = 'Enduro specialist with a passion for teaching technical riding skills.',
    instagram = 'mike_mtb',
    youtube = 'mikechenrider',
    full_name = 'Mike Chen',
    is_coach = true
  WHERE id IN (
    SELECT id FROM profiles 
    WHERE is_coach IS NOT TRUE 
    AND id != COALESCE(coach_id, uuid_nil())
    AND id != (SELECT instructor_id FROM courses LIMIT 1)
    LIMIT 1
  );
  
  UPDATE profiles
  SET 
    username = 'Emma Rodriguez',
    avatar_url = 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80',
    description = 'Bike mechanic and skills coach. I love helping riders understand both the technical and mechanical aspects of mountain biking.',
    instagram = 'emma_wrenches',
    youtube = 'emmarod',
    full_name = 'Emma Rodriguez',
    is_coach = true
  WHERE id IN (
    SELECT id FROM profiles 
    WHERE is_coach IS NOT TRUE 
    AND id != COALESCE(coach_id, uuid_nil())
    AND id != (SELECT instructor_id FROM courses LIMIT 1)
    AND username != 'Mike Chen'
    LIMIT 1
  );
END $$;