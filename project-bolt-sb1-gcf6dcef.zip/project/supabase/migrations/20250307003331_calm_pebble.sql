/*
  # Create Course Rankings System

  1. New Tables
    - `course_rankings`: Stores user rankings and progress for each course
      - Points system
      - Level tracking
      - Completion statistics
      - Watch time tracking
  
  2. Views
    - `course_rankings_mv`: Materialized view for efficient ranking queries
    - `user_statistics_mv`: Overall user statistics across courses
  
  3. Functions & Triggers
    - Automatic ranking updates on:
      - Lesson completion
      - Course enrollment
      - Video progress
    - Materialized view refresh mechanism
  
  4. Security
    - RLS enabled
    - Public read access
    - User-specific write access
*/

-- Drop existing triggers first
DROP TRIGGER IF EXISTS rankings_completion_trigger ON completed_lessons;
DROP TRIGGER IF EXISTS rankings_enrollment_trigger ON enrollments;
DROP TRIGGER IF EXISTS rankings_progress_trigger ON video_progress;
DROP TRIGGER IF EXISTS refresh_course_rankings_mv_trigger ON course_rankings;

-- Drop existing functions
DROP FUNCTION IF EXISTS refresh_course_rankings_mv();
DROP FUNCTION IF EXISTS update_rankings_on_completion();
DROP FUNCTION IF EXISTS update_rankings_on_enrollment();
DROP FUNCTION IF EXISTS update_rankings_on_progress();
DROP FUNCTION IF EXISTS get_course_rankings(uuid);

-- Drop dependent objects
DROP MATERIALIZED VIEW IF EXISTS user_statistics_mv;
DROP MATERIALIZED VIEW IF EXISTS course_rankings_mv;
DROP TABLE IF EXISTS ranking_history;
DROP TABLE IF EXISTS course_rankings;

-- Create new course_rankings table
CREATE TABLE course_rankings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  points integer DEFAULT 0,
  level integer DEFAULT 1,
  completed_lessons_count integer DEFAULT 0,
  total_watch_time numeric DEFAULT 0,
  last_active timestamptz DEFAULT now(),
  rank integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(course_id, user_id)
);

-- Create indexes for better performance
CREATE INDEX idx_course_rankings_course_points ON course_rankings(course_id, points DESC);
CREATE INDEX idx_course_rankings_user ON course_rankings(user_id);
CREATE INDEX idx_course_rankings_last_active ON course_rankings(last_active DESC);

-- Enable RLS
ALTER TABLE course_rankings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Course rankings are viewable by everyone" 
ON course_rankings FOR SELECT 
TO public 
USING (true);

-- Create materialized view for efficient ranking queries
CREATE MATERIALIZED VIEW course_rankings_mv AS
SELECT 
  cr.course_id,
  cr.user_id,
  p.username,
  p.avatar_url,
  cr.points,
  cr.level,
  cr.completed_lessons_count,
  RANK() OVER (
    PARTITION BY cr.course_id 
    ORDER BY cr.points DESC, cr.completed_lessons_count DESC, cr.last_active DESC
  ) as rank
FROM course_rankings cr
JOIN profiles p ON p.id = cr.user_id;

-- Create index on materialized view
CREATE UNIQUE INDEX course_rankings_mv_unique 
ON course_rankings_mv(course_id, user_id);

-- Function to refresh rankings materialized view
CREATE OR REPLACE FUNCTION refresh_course_rankings_mv()
RETURNS trigger AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY course_rankings_mv;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to refresh rankings when changes occur
CREATE TRIGGER refresh_course_rankings_mv_trigger
AFTER INSERT OR DELETE OR UPDATE ON course_rankings
FOR EACH STATEMENT
EXECUTE FUNCTION refresh_course_rankings_mv();

-- Function to update rankings on lesson completion
CREATE OR REPLACE FUNCTION update_rankings_on_completion()
RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Add points and update stats for lesson completion
    INSERT INTO course_rankings (course_id, user_id, points, completed_lessons_count)
    VALUES (NEW.course_id, NEW.user_id, 100, 1)
    ON CONFLICT (course_id, user_id) DO UPDATE
    SET 
      points = course_rankings.points + 100,
      completed_lessons_count = course_rankings.completed_lessons_count + 1,
      level = GREATEST(1, FLOOR((course_rankings.completed_lessons_count + 1) / 3) + 1),
      last_active = now(),
      updated_at = now();
  ELSIF TG_OP = 'DELETE' THEN
    -- Remove points and update stats when uncompleting a lesson
    UPDATE course_rankings
    SET 
      points = GREATEST(0, points - 100),
      completed_lessons_count = GREATEST(0, completed_lessons_count - 1),
      level = GREATEST(1, FLOOR((completed_lessons_count - 1) / 3) + 1),
      updated_at = now()
    WHERE course_id = OLD.course_id AND user_id = OLD.user_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for lesson completion
CREATE TRIGGER rankings_completion_trigger
AFTER INSERT OR DELETE ON completed_lessons
FOR EACH ROW
EXECUTE FUNCTION update_rankings_on_completion();

-- Function to update rankings on enrollment
CREATE OR REPLACE FUNCTION update_rankings_on_enrollment()
RETURNS trigger AS $$
BEGIN
  -- Create initial ranking entry for new enrollment
  INSERT INTO course_rankings (course_id, user_id)
  VALUES (NEW.course_id, NEW.user_id)
  ON CONFLICT (course_id, user_id) DO NOTHING;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new enrollments
CREATE TRIGGER rankings_enrollment_trigger
AFTER INSERT ON enrollments
FOR EACH ROW
EXECUTE FUNCTION update_rankings_on_enrollment();

-- Function to update rankings based on video progress
CREATE OR REPLACE FUNCTION update_rankings_on_progress()
RETURNS trigger AS $$
BEGIN
  -- Update total watch time and last active
  UPDATE course_rankings
  SET 
    total_watch_time = total_watch_time + (NEW.watched_seconds - COALESCE(OLD.watched_seconds, 0)),
    last_active = now(),
    updated_at = now()
  WHERE course_id = NEW.course_id AND user_id = NEW.user_id;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for video progress updates
CREATE TRIGGER rankings_progress_trigger
AFTER INSERT OR UPDATE ON video_progress
FOR EACH ROW
EXECUTE FUNCTION update_rankings_on_progress();

-- Function to get course rankings
CREATE OR REPLACE FUNCTION get_course_rankings(course_id_param uuid)
RETURNS TABLE (
  user_id uuid,
  username text,
  avatar_url text,
  is_coach boolean,
  email text,
  points integer,
  level integer,
  completed_lessons_count integer,
  rank bigint
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    cr.user_id,
    p.username,
    p.avatar_url,
    p.is_coach,
    p.email,
    cr.points,
    cr.level,
    cr.completed_lessons_count,
    RANK() OVER (ORDER BY cr.points DESC, cr.completed_lessons_count DESC, cr.last_active DESC)
  FROM course_rankings cr
  JOIN profiles p ON p.id = cr.user_id
  WHERE cr.course_id = course_id_param
  ORDER BY points DESC, completed_lessons_count DESC, last_active DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate user statistics view
CREATE MATERIALIZED VIEW user_statistics_mv AS
SELECT
  user_id,
  COUNT(DISTINCT course_id) as enrolled_courses_count,
  SUM(completed_lessons_count) as completed_lessons_count,
  MAX(last_active) as last_activity,
  SUM(points) as total_points
FROM course_rankings
GROUP BY user_id;

-- Grant necessary permissions
GRANT SELECT ON course_rankings TO authenticated;
GRANT SELECT ON course_rankings_mv TO authenticated;
GRANT SELECT ON user_statistics_mv TO authenticated;