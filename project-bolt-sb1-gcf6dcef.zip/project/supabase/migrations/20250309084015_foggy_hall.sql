/*
  # Add message reactions system

  1. New Tables
    - `message_reactions`
      - `id` (uuid, primary key)
      - `message_id` (uuid, references chat_messages)
      - `user_id` (uuid, references profiles)
      - `emoji` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on message_reactions table
    - Add policies for reaction management
    - Users can add/remove their own reactions
    - Everyone can view reactions

  3. Constraints
    - One reaction per emoji per user per message
*/

-- Create message reactions table
CREATE TABLE IF NOT EXISTS message_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES chat_messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  emoji text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(message_id, user_id, emoji)
);

-- Enable RLS
ALTER TABLE message_reactions ENABLE ROW LEVEL SECURITY;

-- Policies for message reactions
CREATE POLICY "Users can add reactions"
  ON message_reactions
  FOR INSERT
  TO public
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove their reactions"
  ON message_reactions
  FOR DELETE
  TO public
  USING (auth.uid() = user_id);

CREATE POLICY "Everyone can view reactions"
  ON message_reactions
  FOR SELECT
  TO public
  USING (true);

-- Create index for faster lookups
CREATE INDEX idx_message_reactions_message_id ON message_reactions(message_id);
CREATE INDEX idx_message_reactions_user_id ON message_reactions(user_id);