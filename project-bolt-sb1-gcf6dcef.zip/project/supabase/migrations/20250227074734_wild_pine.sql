/*
  # Add Test Enrollments for Course Rankings

  1. Creates test enrollments for multiple users in courses
  2. Adds completed lessons for these users to generate rankings
  3. Updates member_count for courses
*/

-- Create test enrollments for multiple users
DO $$
DECLARE
  course_ids uuid[];
  user_ids uuid[];
  i int;
  j int;
  random_course_id uuid;
  random_user_id uuid;
BEGIN
  -- Get all course IDs
  SELECT array_agg(id) INTO course_ids FROM courses;
  
  -- Get all user IDs (excluding instructors)
  SELECT array_agg(id) INTO user_ids 
  FROM profiles 
  WHERE id NOT IN (SELECT DISTINCT instructor_id FROM courses)
  LIMIT 20;
  
  -- Create enrollments for these users and courses
  IF user_ids IS NOT NULL AND array_length(user_ids, 1) > 0 AND
     course_ids IS NOT NULL AND array_length(course_ids, 1) > 0 THEN
    
    -- For each user, enroll in 1-3 random courses
    FOR i IN 1..array_length(user_ids, 1) LOOP
      -- Determine how many courses this user will join (1-3)
      FOR j IN 1..floor(random() * 3)::int + 1 LOOP
        -- Select a random course
        random_course_id := course_ids[floor(random() * array_length(course_ids, 1))::int + 1];
        
        -- Create enrollment if it doesn't exist
        INSERT INTO enrollments (user_id, course_id)
        VALUES (user_ids[i], random_course_id)
        ON CONFLICT (user_id, course_id) DO NOTHING;
        
        -- Add some completed lessons for these users
        INSERT INTO completed_lessons (user_id, course_id, lesson_id)
        SELECT 
          user_ids[i], 
          random_course_id, 
          course_lessons.id
        FROM course_lessons
        JOIN course_chapters ON course_lessons.chapter_id = course_chapters.id
        WHERE course_chapters.course_id = random_course_id
        ORDER BY random()
        LIMIT floor(random() * 5)::int
        ON CONFLICT (user_id, lesson_id) DO NOTHING;
      END LOOP;
    END LOOP;
  END IF;
  
  -- Update member counts for all courses
  UPDATE courses
  SET member_count = (
    SELECT COUNT(*) FROM enrollments WHERE enrollments.course_id = courses.id
  );
END $$;

-- Create some test profiles if we don't have enough
DO $$
DECLARE
  profile_count integer;
BEGIN
  -- Check how many profiles we have
  SELECT COUNT(*) INTO profile_count FROM profiles;
  
  -- If we have fewer than 10 profiles, create some test ones
  IF profile_count < 10 THEN
    -- Create test profiles
    INSERT INTO profiles (id, username, avatar_url, is_coach, email)
    VALUES 
      (gen_random_uuid(), 'TestUser1', 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80', false, 'test1@example.com'),
      (gen_random_uuid(), 'TestUser2', 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?auto=format&fit=crop&q=80', false, 'test2@example.com'),
      (gen_random_uuid(), 'TestUser3', 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80', false, 'test3@example.com'),
      (gen_random_uuid(), 'TestUser4', 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80', false, 'test4@example.com'),
      (gen_random_uuid(), 'TestUser5', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80', false, 'test5@example.com')
    ON CONFLICT (username) DO NOTHING;
    
    -- Enroll these test users in courses
    INSERT INTO enrollments (user_id, course_id)
    SELECT 
      profiles.id, 
      courses.id
    FROM 
      profiles, 
      courses
    WHERE 
      profiles.username LIKE 'TestUser%'
    ORDER BY random()
    LIMIT 15
    ON CONFLICT (user_id, course_id) DO NOTHING;
    
    -- Add completed lessons for these users
    INSERT INTO completed_lessons (user_id, course_id, lesson_id)
    SELECT 
      enrollments.user_id,
      enrollments.course_id,
      course_lessons.id
    FROM 
      enrollments
    JOIN profiles ON enrollments.user_id = profiles.id
    JOIN course_chapters ON course_chapters.course_id = enrollments.course_id
    JOIN course_lessons ON course_lessons.chapter_id = course_chapters.id
    WHERE 
      profiles.username LIKE 'TestUser%'
    ORDER BY random()
    LIMIT 30
    ON CONFLICT (user_id, lesson_id) DO NOTHING;
  END IF;
  
  -- Update member counts for all courses
  UPDATE courses
  SET member_count = (
    SELECT COUNT(*) FROM enrollments WHERE enrollments.course_id = courses.id
  );
END $$;