-- Drop and recreate policies for coach_messages
DO $$ 
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Students can view their own messages" ON coach_messages;
  DROP POLICY IF EXISTS "Instructors can view messages for their courses" ON coach_messages;
  DROP POLICY IF EXISTS "Students can send messages" ON coach_messages;
  DROP POLICY IF EXISTS "Instructors can reply to messages" ON coach_messages;

  -- Create new policies with fixed permissions
  CREATE POLICY "Anyone can view messages they're involved with"
    ON coach_messages FOR SELECT
    USING (
      auth.uid() = student_id OR
      EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = coach_messages.course_id
        AND courses.instructor_id = auth.uid()
      )
    );

  CREATE POLICY "Students and instructors can send messages"
    ON coach_messages FOR INSERT
    WITH CHECK (
      -- Students can send messages to their courses
      (auth.uid() = student_id AND auth.uid() = sender_id) OR
      -- Instructors can reply to messages in their courses
      (EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = coach_messages.course_id
        AND courses.instructor_id = auth.uid()
      ) AND auth.uid() = sender_id)
    );
END $$;

-- Enable realtime for coach_messages
ALTER PUBLICATION supabase_realtime ADD TABLE coach_messages;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_coach_messages_sender_created
  ON coach_messages(sender_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_coach_messages_student_course
  ON coach_messages(student_id, course_id, created_at DESC);