/*
  # Fix Course Creation RLS Policies

  1. Security Changes
    - Simplify RLS policies on courses table to allow basic operations
    - Ensure instructors can create, read, update, and delete their own courses
    - Allow public read access to all courses
    - Remove overly restrictive policies that prevent course creation

  This migration fixes the "Course creation failed - no data returned" error
  by ensuring that after a course is created, the creator can immediately
  read it back from the database.
*/

-- Drop existing policies on courses table
DROP POLICY IF EXISTS "Authenticated users with coach role can create courses" ON courses;
DROP POLICY IF EXISTS "Coaches can delete their own courses" ON courses;
DROP POLICY IF EXISTS "Coaches can update their own courses" ON courses;
DROP POLICY IF EXISTS "Course creators can manage their courses" ON courses;
DROP POLICY IF EXISTS "Courses are viewable by everyone and creators can read their ow" ON courses;

-- Create simplified RLS policies for courses table
CREATE POLICY "Anyone can view courses"
  ON courses
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Coaches can create courses"
  ON courses
  FOR INSERT
  TO authenticated
  WITH CHECK (
    instructor_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() AND is_coach = true
    )
  );

CREATE POLICY "Instructors can update their courses"
  ON courses
  FOR UPDATE
  TO authenticated
  USING (instructor_id = auth.uid())
  WITH CHECK (instructor_id = auth.uid());

CREATE POLICY "Instructors can delete their courses"
  ON courses
  FOR DELETE
  TO authenticated
  USING (instructor_id = auth.uid());