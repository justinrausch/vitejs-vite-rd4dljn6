-- Drop trigger first since it depends on the function
DROP TRIGGER IF EXISTS course_rankings_update ON completed_lessons;

-- Now we can safely drop the functions
DROP FUNCTION IF EXISTS get_course_rankings(uuid);
DROP FUNCTION IF EXISTS get_user_course_ranking(uuid, uuid);
DROP FUNCTION IF EXISTS update_course_rankings();

-- Create or replace the get_course_rankings function with more detailed stats
CREATE FUNCTION get_course_rankings(course_id_param uuid)
RETURNS TABLE (
  user_id uuid,
  username text,
  avatar_url text,
  is_coach boolean,
  email text,
  completed_lessons_count bigint,
  points bigint,
  level integer,
  rank bigint,
  total_watch_time numeric,
  last_active timestamptz
) AS $$
BEGIN
  RETURN QUERY
  WITH user_stats AS (
    SELECT 
      p.id as user_id,
      p.username,
      p.avatar_url,
      p.is_coach,
      p.email,
      COUNT(DISTINCT cl.id) as completed_lessons_count,
      COUNT(DISTINCT cl.id) * 100 as points,
      GREATEST(1, FLOOR(COUNT(DISTINCT cl.id)::float / 3)::integer + 1) as level,
      COALESCE(SUM(vp.watched_seconds), 0) as total_watch_time,
      MAX(GREATEST(COALESCE(cl.completed_at, '1970-01-01'), COALESCE(vp.last_watched_at, '1970-01-01'))) as last_active
    FROM enrollments e
    JOIN profiles p ON p.id = e.user_id
    LEFT JOIN completed_lessons cl ON cl.user_id = p.id AND cl.course_id = course_id_param
    LEFT JOIN video_progress vp ON vp.user_id = p.id AND vp.course_id = course_id_param
    WHERE e.course_id = course_id_param
    GROUP BY p.id, p.username, p.avatar_url, p.is_coach, p.email
  )
  SELECT 
    us.*,
    DENSE_RANK() OVER (ORDER BY us.points DESC, us.total_watch_time DESC) as rank
  FROM user_stats us
  ORDER BY points DESC, total_watch_time DESC;
END;
$$ LANGUAGE plpgsql;

-- Create a function to get a user's ranking details
CREATE FUNCTION get_user_course_ranking(user_id_param uuid, course_id_param uuid)
RETURNS TABLE (
  rank bigint,
  total_users bigint,
  points bigint,
  level integer,
  completed_lessons_count bigint,
  total_watch_time numeric
) AS $$
BEGIN
  RETURN QUERY
  WITH rankings AS (
    SELECT 
      user_id,
      DENSE_RANK() OVER (ORDER BY points DESC, total_watch_time DESC) as rank,
      COUNT(*) OVER () as total_users,
      points,
      level,
      completed_lessons_count,
      total_watch_time
    FROM get_course_rankings(course_id_param)
  )
  SELECT 
    rank,
    total_users,
    points,
    level,
    completed_lessons_count,
    total_watch_time
  FROM rankings
  WHERE user_id = user_id_param;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger function to update rankings when lessons are completed
CREATE FUNCTION update_course_rankings()
RETURNS trigger AS $$
BEGIN
  -- Notify clients about the ranking update
  PERFORM pg_notify(
    'course_rankings',
    json_build_object(
      'course_id', NEW.course_id,
      'user_id', NEW.user_id,
      'event', TG_OP
    )::text
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for ranking updates
CREATE TRIGGER course_rankings_update
  AFTER INSERT OR DELETE ON completed_lessons
  FOR EACH ROW
  EXECUTE FUNCTION update_course_rankings();

-- Create some test completed lessons to populate rankings
DO $$
DECLARE
  course_rec RECORD;
  user_rec RECORD;
  lesson_rec RECORD;
  completion_count INT;
BEGIN
  -- For each course
  FOR course_rec IN SELECT id FROM courses LOOP
    -- For each enrolled user (including test users)
    FOR user_rec IN 
      SELECT DISTINCT e.user_id 
      FROM enrollments e 
      WHERE e.course_id = course_rec.id 
    LOOP
      -- Randomly complete between 1 and 8 lessons
      completion_count := 1 + floor(random() * 8);
      
      FOR i IN 1..completion_count LOOP
        -- Get a random lesson from this course
        SELECT cl.id INTO lesson_rec
        FROM course_lessons cl
        JOIN course_chapters cc ON cc.id = cl.chapter_id
        WHERE cc.course_id = course_rec.id
        ORDER BY random()
        LIMIT 1;
        
        IF lesson_rec IS NOT NULL THEN
          -- Insert completed lesson if it doesn't exist
          INSERT INTO completed_lessons (
            user_id,
            course_id,
            lesson_id,
            completed_at
          )
          VALUES (
            user_rec.user_id,
            course_rec.id,
            lesson_rec.id,
            now() - (random() * interval '30 days')
          )
          ON CONFLICT (user_id, lesson_id) DO NOTHING;
          
          -- Add some video progress
          INSERT INTO video_progress (
            user_id,
            course_id,
            lesson_id,
            progress,
            watched_seconds,
            last_watched_at
          )
          VALUES (
            user_rec.user_id,
            course_rec.id,
            lesson_rec.id,
            100,
            floor(random() * 1200 + 300), -- Random watch time between 5-25 minutes
            now() - (random() * interval '30 days')
          )
          ON CONFLICT (user_id, lesson_id) DO NOTHING;
        END IF;
      END LOOP;
    END LOOP;
  END LOOP;
END $$;

-- Check if tables are already in the publication before adding them
DO $$
DECLARE
  completed_lessons_exists boolean;
  video_progress_exists boolean;
BEGIN
  -- Check if completed_lessons is already in the publication
  SELECT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND schemaname = 'public' 
    AND tablename = 'completed_lessons'
  ) INTO completed_lessons_exists;
  
  -- Check if video_progress is already in the publication
  SELECT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' 
    AND schemaname = 'public' 
    AND tablename = 'video_progress'
  ) INTO video_progress_exists;
  
  -- Only add tables if they're not already in the publication
  IF NOT completed_lessons_exists THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE completed_lessons;
  END IF;
  
  IF NOT video_progress_exists THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE video_progress;
  END IF;
END $$;