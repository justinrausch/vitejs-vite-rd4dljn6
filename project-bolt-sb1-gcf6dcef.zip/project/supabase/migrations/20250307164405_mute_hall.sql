/*
  # Course Schema Implementation

  1. New Tables
    - courses: Main course table with metadata
    - course_chapters: Course chapters with ordering
    - course_lessons: Lessons within chapters
    - course_tags: Course tags for categorization

  2. Security
    - RLS policies for all tables
    - Coach-only course creation
    - Public read access
    - Instructor-specific write access

  3. Features
    - Automatic bucket creation
    - Updated timestamps
    - Position tracking
    - Tag uniqueness
*/

-- Create courses table
CREATE TABLE IF NOT EXISTS public.courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  price numeric NOT NULL CHECK (price >= 0),
  category text,
  instructor_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  member_count integer DEFAULT 0,
  tagline text,
  disciplines text[],
  sport text DEFAULT 'Mountain biking',
  CONSTRAINT courses_instructor_must_be_coach CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = instructor_id
      AND profiles.is_coach = true
    )
  )
);

-- Create chapters table
CREATE TABLE IF NOT EXISTS public.course_chapters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  title text NOT NULL,
  position integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create lessons table
CREATE TABLE IF NOT EXISTS public.course_lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chapter_id uuid NOT NULL REFERENCES public.course_chapters(id) ON DELETE CASCADE,
  title text NOT NULL,
  video_url text,
  position integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create course tags table
CREATE TABLE IF NOT EXISTS public.course_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES public.courses(id) ON DELETE CASCADE,
  tag text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(course_id, tag)
);

-- Enable RLS
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.course_chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.course_lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.course_tags ENABLE ROW LEVEL SECURITY;

-- Create RLS Policies with existence checks

-- Courses policies
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'courses' 
    AND schemaname = 'public'
    AND policyname = 'Courses are viewable by everyone'
  ) THEN
    CREATE POLICY "Courses are viewable by everyone"
    ON public.courses FOR SELECT
    TO public
    USING (true);
  END IF;
END $$;

DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'courses' 
    AND schemaname = 'public'
    AND policyname = 'Course creators can create courses'
  ) THEN
    CREATE POLICY "Course creators can create courses"
    ON public.courses FOR INSERT
    TO authenticated
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM public.profiles
        WHERE profiles.id = auth.uid()
        AND profiles.is_coach = true
      )
    );
  END IF;
END $$;

DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'courses' 
    AND schemaname = 'public'
    AND policyname = 'Course creators can manage their courses'
  ) THEN
    CREATE POLICY "Course creators can manage their courses"
    ON public.courses FOR ALL
    TO authenticated
    USING (instructor_id = auth.uid())
    WITH CHECK (instructor_id = auth.uid());
  END IF;
END $$;

-- Chapters policies
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_chapters' 
    AND schemaname = 'public'
    AND policyname = 'Course chapters are viewable by everyone'
  ) THEN
    CREATE POLICY "Course chapters are viewable by everyone"
    ON public.course_chapters FOR SELECT
    TO public
    USING (true);
  END IF;
END $$;

DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_chapters' 
    AND schemaname = 'public'
    AND policyname = 'Course creators can manage chapters'
  ) THEN
    CREATE POLICY "Course creators can manage chapters"
    ON public.course_chapters FOR ALL
    TO authenticated
    USING (
      EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = course_chapters.course_id
        AND courses.instructor_id = auth.uid()
      )
    );
  END IF;
END $$;

-- Lessons policies
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_lessons' 
    AND schemaname = 'public'
    AND policyname = 'Course lessons are viewable by everyone'
  ) THEN
    CREATE POLICY "Course lessons are viewable by everyone"
    ON public.course_lessons FOR SELECT
    TO public
    USING (true);
  END IF;
END $$;

DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_lessons' 
    AND schemaname = 'public'
    AND policyname = 'Course creators can manage lessons'
  ) THEN
    CREATE POLICY "Course creators can manage lessons"
    ON public.course_lessons FOR ALL
    TO authenticated
    USING (
      EXISTS (
        SELECT 1 FROM course_chapters
        JOIN courses ON courses.id = course_chapters.course_id
        WHERE course_chapters.id = course_lessons.chapter_id
        AND courses.instructor_id = auth.uid()
      )
    );
  END IF;
END $$;

-- Tags policies
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_tags' 
    AND schemaname = 'public'
    AND policyname = 'Course tags are viewable by everyone'
  ) THEN
    CREATE POLICY "Course tags are viewable by everyone"
    ON public.course_tags FOR SELECT
    TO public
    USING (true);
  END IF;
END $$;

DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'course_tags' 
    AND schemaname = 'public'
    AND policyname = 'Course creators can manage tags'
  ) THEN
    CREATE POLICY "Course creators can manage tags"
    ON public.course_tags FOR ALL
    TO authenticated
    USING (
      EXISTS (
        SELECT 1 FROM courses
        WHERE courses.id = course_tags.course_id
        AND courses.instructor_id = auth.uid()
      )
    );
  END IF;
END $$;

-- Create updated_at trigger function if it doesn't exist
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Add updated_at trigger to courses
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_courses_updated_at'
  ) THEN
    CREATE TRIGGER update_courses_updated_at
      BEFORE UPDATE ON public.courses
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;

-- Create course bucket trigger function
CREATE OR REPLACE FUNCTION create_course_bucket_trigger()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO storage.buckets (id, name)
  VALUES (NEW.id, 'course_' || NEW.id);
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Add course bucket creation trigger
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'on_course_created'
  ) THEN
    CREATE TRIGGER on_course_created
      AFTER INSERT ON public.courses
      FOR EACH ROW
      EXECUTE FUNCTION create_course_bucket_trigger();
  END IF;
END $$;

-- Create lesson bucket trigger function
CREATE OR REPLACE FUNCTION create_lesson_bucket_trigger()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO storage.buckets (id, name)
  VALUES (NEW.id, 'lesson_' || NEW.id);
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Add lesson bucket creation trigger
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'on_lesson_created'
  ) THEN
    CREATE TRIGGER on_lesson_created
      AFTER INSERT ON public.course_lessons
      FOR EACH ROW
      EXECUTE FUNCTION create_lesson_bucket_trigger();
  END IF;
END $$;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_courses_instructor_id ON public.courses(instructor_id);
CREATE INDEX IF NOT EXISTS idx_course_chapters_course_id ON public.course_chapters(course_id);
CREATE INDEX IF NOT EXISTS idx_course_lessons_chapter_id ON public.course_lessons(chapter_id);