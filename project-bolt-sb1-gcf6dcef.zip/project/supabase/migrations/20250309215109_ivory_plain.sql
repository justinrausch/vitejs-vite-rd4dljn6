/*
  # Video Progress System Overhaul

  1. Changes
    - Replace existing video progress tables with a new partitioned system
    - Add proper indexing for performance
    - Implement RLS policies for security
    
  2. Details
    - Creates a partitioned table by month from March 2025 to February 2026
    - Adds indexes for efficient querying
    - Includes total watch time tracking
    - Implements proper security policies
*/

-- Drop existing tables if they exist
DROP TABLE IF EXISTS video_progress CASCADE;
DROP TABLE IF EXISTS video_progress_y2025m03 CASCADE;
DROP TABLE IF EXISTS video_progress_y2025m04 CASCADE;
DROP TABLE IF EXISTS video_progress_y2025m05 CASCADE;
DROP TABLE IF EXISTS video_progress_y2025m06 CASCADE;
DROP TABLE IF EXISTS video_progress_y2025m07 CASCADE;
DROP TABLE IF EXISTS video_progress_y2025m08 CASCADE;
DROP TABLE IF EXISTS video_progress_y2025m09 CASCADE;
DROP TABLE IF EXISTS video_progress_y2025m10 CASCADE;
DROP TABLE IF EXISTS video_progress_y2025m11 CASCADE;
DROP TABLE IF EXISTS video_progress_y2025m12 CASCADE;
DROP TABLE IF EXISTS video_progress_y2026m01 CASCADE;
DROP TABLE IF EXISTS video_progress_y2026m02 CASCADE;

-- Create the parent table with partitioning
CREATE TABLE video_progress (
    id uuid DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    lesson_id uuid NOT NULL REFERENCES course_lessons(id) ON DELETE CASCADE,
    progress integer DEFAULT 0 NOT NULL,
    watched_seconds numeric DEFAULT 0 NOT NULL,
    total_watch_time numeric DEFAULT 0,
    last_watched_at timestamp with time zone NOT NULL DEFAULT now(),
    PRIMARY KEY (id, last_watched_at)
) PARTITION BY RANGE (last_watched_at);

-- Create indexes on the parent table
CREATE INDEX idx_video_progress_user_course ON video_progress(user_id, course_id);
CREATE INDEX idx_video_progress_user_lesson ON video_progress(user_id, lesson_id);
CREATE INDEX idx_video_progress_total_time ON video_progress(total_watch_time);
CREATE INDEX idx_video_progress_last_watched ON video_progress(last_watched_at DESC);

-- Create partition tables
CREATE TABLE video_progress_y2025m03 PARTITION OF video_progress
    FOR VALUES FROM ('2025-03-01') TO ('2025-04-01');

CREATE TABLE video_progress_y2025m04 PARTITION OF video_progress
    FOR VALUES FROM ('2025-04-01') TO ('2025-05-01');

CREATE TABLE video_progress_y2025m05 PARTITION OF video_progress
    FOR VALUES FROM ('2025-05-01') TO ('2025-06-01');

CREATE TABLE video_progress_y2025m06 PARTITION OF video_progress
    FOR VALUES FROM ('2025-06-01') TO ('2025-07-01');

CREATE TABLE video_progress_y2025m07 PARTITION OF video_progress
    FOR VALUES FROM ('2025-07-01') TO ('2025-08-01');

CREATE TABLE video_progress_y2025m08 PARTITION OF video_progress
    FOR VALUES FROM ('2025-08-01') TO ('2025-09-01');

CREATE TABLE video_progress_y2025m09 PARTITION OF video_progress
    FOR VALUES FROM ('2025-09-01') TO ('2025-10-01');

CREATE TABLE video_progress_y2025m10 PARTITION OF video_progress
    FOR VALUES FROM ('2025-10-01') TO ('2025-11-01');

CREATE TABLE video_progress_y2025m11 PARTITION OF video_progress
    FOR VALUES FROM ('2025-11-01') TO ('2025-12-01');

CREATE TABLE video_progress_y2025m12 PARTITION OF video_progress
    FOR VALUES FROM ('2025-12-01') TO ('2026-01-01');

CREATE TABLE video_progress_y2026m01 PARTITION OF video_progress
    FOR VALUES FROM ('2026-01-01') TO ('2026-02-01');

CREATE TABLE video_progress_y2026m02 PARTITION OF video_progress
    FOR VALUES FROM ('2026-02-01') TO ('2026-03-01');

-- Create a function to handle the unique constraint
CREATE OR REPLACE FUNCTION check_video_progress_unique()
RETURNS trigger AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM video_progress
    WHERE user_id = NEW.user_id 
    AND lesson_id = NEW.lesson_id 
    AND id != NEW.id
  ) THEN
    -- If a record exists, update it instead
    UPDATE video_progress
    SET progress = NEW.progress,
        watched_seconds = NEW.watched_seconds,
        total_watch_time = COALESCE(NEW.total_watch_time, total_watch_time),
        last_watched_at = NEW.last_watched_at
    WHERE user_id = NEW.user_id 
    AND lesson_id = NEW.lesson_id;
    RETURN NULL;  -- Abort the insert/update
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to enforce uniqueness
CREATE TRIGGER video_progress_unique_trigger
  BEFORE INSERT OR UPDATE ON video_progress
  FOR EACH ROW
  EXECUTE FUNCTION check_video_progress_unique();

-- Enable RLS
ALTER TABLE video_progress ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own video progress"
    ON video_progress
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own video progress"
    ON video_progress
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own video progress"
    ON video_progress
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);