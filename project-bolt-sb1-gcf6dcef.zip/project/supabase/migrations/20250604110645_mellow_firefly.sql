/*
  # Add feature access tracking

  1. Changes
    - Add plan tracking to enrollments
    - Add RLS policies for feature access control
  
  2. Security
    - Add policies to control access to community, rankings, and coaching features
    - Policies check user's plan permissions before allowing access
*/

-- Add plan tracking to enrollments
ALTER TABLE enrollments
ADD COLUMN IF NOT EXISTS plan_id uuid REFERENCES course_plans(id);

-- Update RLS policies for feature access

-- Community access policy
CREATE POLICY "Users can access community if their plan allows"
ON chat_messages
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM enrollments e
    JOIN course_plans p ON e.plan_id = p.id
    WHERE e.user_id = auth.uid()
    AND e.course_id = (
      SELECT course_id FROM chat_channels WHERE id = chat_messages.channel_id
    )
    AND p.community_access = true
  )
);

-- Rankings access policy
CREATE POLICY "Users can access rankings if their plan allows"
ON course_rankings
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM enrollments e
    JOIN course_plans p ON e.plan_id = p.id
    WHERE e.user_id = auth.uid()
    AND e.course_id = course_rankings.course_id
    AND p.rankings_access = true
  )
);

-- Coaching access policy
CREATE POLICY "Users can access coaching if their plan allows"
ON coach_messages
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM enrollments e
    JOIN course_plans p ON e.plan_id = p.id
    WHERE e.user_id = auth.uid()
    AND e.course_id = coach_messages.course_id
    AND p.coaching_access = true
  )
);