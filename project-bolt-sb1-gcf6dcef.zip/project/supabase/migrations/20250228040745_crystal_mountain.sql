-- Ensure member_count column exists on courses table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'courses' AND column_name = 'member_count'
  ) THEN
    ALTER TABLE courses ADD COLUMN member_count integer DEFAULT 0;
  END IF;
END $$;

-- Create or replace function to update course member count
CREATE OR REPLACE FUNCTION update_course_member_count()
RETURNS trigger AS $$
BEGIN
  -- Update the member count in the courses table
  IF TG_OP = 'INSERT' THEN
    UPDATE courses
    SET member_count = (
      SELECT COUNT(*) FROM enrollments WHERE course_id = NEW.course_id
    )
    WHERE id = NEW.course_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE courses
    SET member_count = (
      SELECT COUNT(*) FROM enrollments WHERE course_id = OLD.course_id
    )
    WHERE id = OLD.course_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS enrollment_insert_trigger ON enrollments;
DROP TRIGGER IF EXISTS enrollment_delete_trigger ON enrollments;

-- Create triggers for enrollment changes
CREATE TRIGGER enrollment_insert_trigger
  AFTER INSERT ON enrollments
  FOR EACH ROW
  EXECUTE FUNCTION update_course_member_count();

CREATE TRIGGER enrollment_delete_trigger
  AFTER DELETE ON enrollments
  FOR EACH ROW
  EXECUTE FUNCTION update_course_member_count();

-- Update member_count for all courses to ensure accuracy
UPDATE courses
SET member_count = (
  SELECT COUNT(*) FROM enrollments WHERE enrollments.course_id = courses.id
);

-- Add indexes for faster enrollment queries if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'enrollments' 
    AND indexname = 'idx_enrollments_course_id'
  ) THEN
    CREATE INDEX idx_enrollments_course_id ON enrollments(course_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'enrollments' 
    AND indexname = 'idx_enrollments_user_id'
  ) THEN
    CREATE INDEX idx_enrollments_user_id ON enrollments(user_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'enrollments' 
    AND indexname = 'idx_enrollments_user_course_id'
  ) THEN
    CREATE INDEX idx_enrollments_user_course_id ON enrollments(user_id, course_id);
  END IF;
END $$;

-- Add indexes for completed_lessons to improve ranking queries
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'completed_lessons' 
    AND indexname = 'idx_completed_lessons_user_course'
  ) THEN
    CREATE INDEX idx_completed_lessons_user_course ON completed_lessons(user_id, course_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'completed_lessons' 
    AND indexname = 'idx_completed_lessons_course_id'
  ) THEN
    CREATE INDEX idx_completed_lessons_course_id ON completed_lessons(course_id);
  END IF;
END $$;

-- Create function to calculate user ranking in a course
CREATE OR REPLACE FUNCTION get_user_course_rank(user_id_param uuid, course_id_param uuid)
RETURNS integer AS $$
DECLARE
  user_rank integer;
BEGIN
  SELECT rank INTO user_rank
  FROM (
    SELECT 
      user_id,
      RANK() OVER (ORDER BY COUNT(*) DESC) as rank
    FROM completed_lessons
    WHERE course_id = course_id_param
    GROUP BY user_id
  ) rankings
  WHERE user_id = user_id_param;
  
  RETURN COALESCE(user_rank, 0);
END;
$$ LANGUAGE plpgsql;