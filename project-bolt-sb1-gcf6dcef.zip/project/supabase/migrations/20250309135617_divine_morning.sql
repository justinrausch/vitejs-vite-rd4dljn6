/*
  # Simplified Course Rankings System

  1. Changes
    - Remove existing course_rankings table
    - Create new simplified rankings table with essential fields
    - Add necessary indexes for performance
    - Add RLS policies for security

  2. New Table Structure
    - course_rankings
      - id (uuid, primary key)
      - course_id (uuid, foreign key)
      - user_id (uuid, foreign key) 
      - points (integer)
      - completed_lessons_count (integer)
      - rank (integer)
      - updated_at (timestamp)

  3. Security
    - Enable RLS
    - Add policies for viewing and updating rankings
*/

-- Drop existing rankings related objects
DROP TABLE IF EXISTS course_rankings CASCADE;
DROP MATERIALIZED VIEW IF EXISTS course_rankings_mv CASCADE;

-- Create new simplified rankings table
CREATE TABLE course_rankings (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    points integer DEFAULT 0,
    completed_lessons_count integer DEFAULT 0,
    rank integer,
    updated_at timestamptz DEFAULT now(),
    UNIQUE(course_id, user_id)
);

-- Create indexes for performance
CREATE INDEX idx_course_rankings_course_points ON course_rankings(course_id, points DESC);
CREATE INDEX idx_course_rankings_user ON course_rankings(user_id);
CREATE INDEX idx_course_rankings_course_user ON course_rankings(course_id, user_id);

-- Enable RLS
ALTER TABLE course_rankings ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Course rankings are viewable by everyone" 
ON course_rankings FOR SELECT 
TO public 
USING (true);

CREATE POLICY "Rankings can be updated through functions only" 
ON course_rankings FOR ALL 
TO authenticated 
USING (false)
WITH CHECK (false);

-- Function to update rankings
CREATE OR REPLACE FUNCTION update_course_ranking()
RETURNS TRIGGER AS $$
BEGIN
  -- Calculate points (100 points per completed lesson)
  UPDATE course_rankings
  SET 
    points = completed_lessons_count * 100,
    updated_at = now()
  WHERE course_id = NEW.course_id AND user_id = NEW.user_id;

  -- Update ranks for all users in the course
  WITH ranked_users AS (
    SELECT 
      id,
      ROW_NUMBER() OVER (
        PARTITION BY course_id 
        ORDER BY points DESC, completed_lessons_count DESC, updated_at ASC
      ) as new_rank
    FROM course_rankings
    WHERE course_id = NEW.course_id
  )
  UPDATE course_rankings cr
  SET rank = ru.new_rank
  FROM ranked_users ru
  WHERE cr.id = ru.id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update rankings when lessons are completed
CREATE OR REPLACE FUNCTION update_rankings_on_lesson_completion()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert or update the ranking entry
  INSERT INTO course_rankings (course_id, user_id, completed_lessons_count)
  VALUES (NEW.course_id, NEW.user_id, 1)
  ON CONFLICT (course_id, user_id)
  DO UPDATE SET 
    completed_lessons_count = course_rankings.completed_lessons_count + 1;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add trigger to completed_lessons table
DROP TRIGGER IF EXISTS update_rankings_trigger ON completed_lessons;
CREATE TRIGGER update_rankings_trigger
AFTER INSERT ON completed_lessons
FOR EACH ROW
EXECUTE FUNCTION update_rankings_on_lesson_completion();

-- Add trigger to course_rankings table
DROP TRIGGER IF EXISTS update_ranking_points_trigger ON course_rankings;
CREATE TRIGGER update_ranking_points_trigger
AFTER INSERT OR UPDATE OF completed_lessons_count ON course_rankings
FOR EACH ROW
EXECUTE FUNCTION update_course_ranking();