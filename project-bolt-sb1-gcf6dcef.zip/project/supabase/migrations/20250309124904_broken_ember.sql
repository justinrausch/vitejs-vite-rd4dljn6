/*
  # Allow null video URLs in course lessons

  1. Changes
    - Make video_url column nullable in course_lessons table
    - This allows creating lessons before uploading a video

  2. Reason
    - Instructors should be able to create lessons and add videos later
    - Improves course creation workflow flexibility
*/

ALTER TABLE course_lessons 
ALTER COLUMN video_url DROP NOT NULL;