/*
  # Add Course Reviews System

  1. New Tables
    - `course_reviews`
      - `id` (uuid, primary key)
      - `course_id` (uuid, references courses)
      - `user_id` (uuid, references profiles)
      - `rating` (integer, 1-5)
      - `content` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policies for:
      - Anyone can view reviews
      - Only verified users can create reviews
      - Users can update/delete their own reviews
*/

-- Create course reviews table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_name = 'course_reviews'
  ) THEN
    CREATE TABLE course_reviews (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
      user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
      rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
      content text,
      created_at timestamptz DEFAULT now(),
      updated_at timestamptz DEFAULT now(),
      UNIQUE(course_id, user_id)
    );
  END IF;
END $$;

-- Enable RLS
ALTER TABLE course_reviews ENABLE ROW LEVEL SECURITY;

-- Create indexes if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'course_reviews' 
    AND indexname = 'idx_course_reviews_course_id'
  ) THEN
    CREATE INDEX idx_course_reviews_course_id ON course_reviews(course_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'course_reviews' 
    AND indexname = 'idx_course_reviews_user_id'
  ) THEN
    CREATE INDEX idx_course_reviews_user_id ON course_reviews(user_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'course_reviews' 
    AND indexname = 'idx_course_reviews_rating'
  ) THEN
    CREATE INDEX idx_course_reviews_rating ON course_reviews(rating);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'course_reviews' 
    AND indexname = 'idx_course_reviews_created_at'
  ) THEN
    CREATE INDEX idx_course_reviews_created_at ON course_reviews(created_at DESC);
  END IF;
END $$;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Course reviews are viewable by everyone" ON course_reviews;
  DROP POLICY IF EXISTS "Users can create reviews" ON course_reviews;
  DROP POLICY IF EXISTS "Users can update their own reviews" ON course_reviews;
  DROP POLICY IF EXISTS "Users can delete their own reviews" ON course_reviews;
END $$;

-- Create new policies
CREATE POLICY "Course reviews are viewable by everyone"
  ON course_reviews FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can create reviews"
  ON course_reviews FOR INSERT
  TO authenticated
  WITH CHECK (
    -- User must be verified
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND is_verified = true
    )
  );

CREATE POLICY "Users can update their own reviews"
  ON course_reviews FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own reviews"
  ON course_reviews FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create function to update updated_at on review changes
CREATE OR REPLACE FUNCTION update_course_review_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS update_course_review_updated_at ON course_reviews;

-- Create trigger for updated_at
CREATE TRIGGER update_course_review_updated_at
  BEFORE UPDATE ON course_reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_course_review_updated_at();