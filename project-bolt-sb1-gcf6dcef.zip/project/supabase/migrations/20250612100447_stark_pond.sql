/*
  # Feature Access Controls for Course Plans

  1. New Columns
    - Add feature access control columns to course_plans table
    - Add plan_id reference to enrollments table
  
  2. Security
    - Add policies for feature access based on plan settings
    - Ensure policies don't conflict with existing ones
*/

-- Add feature access columns to course_plans table
ALTER TABLE IF EXISTS public.course_plans 
ADD COLUMN IF NOT EXISTS lessons_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS community_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS coaching_access BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS rankings_access BOOLEAN DEFAULT TRUE;

-- Add plan_id to enrollments table if it doesn't exist
ALTER TABLE IF EXISTS public.enrollments
ADD COLUMN IF NOT EXISTS plan_id UUID REFERENCES public.course_plans(id);

-- Check and drop existing policies if they exist
DO $$
BEGIN
    -- Check for chat_messages policy
    IF EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'chat_messages' 
        AND policyname = 'Users can access community if their plan allows'
    ) THEN
        DROP POLICY "Users can access community if their plan allows" ON public.chat_messages;
    END IF;
    
    -- Check for course_rankings policy
    IF EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'course_rankings' 
        AND policyname = 'Users can access rankings if their plan allows'
    ) THEN
        DROP POLICY "Users can access rankings if their plan allows" ON public.course_rankings;
    END IF;
    
    -- Check for coach_messages policy
    IF EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'coach_messages' 
        AND policyname = 'Users can access coaching if their plan allows'
    ) THEN
        DROP POLICY "Users can access coaching if their plan allows" ON public.coach_messages;
    END IF;
END
$$;

-- Create policies for feature access
CREATE POLICY "Users can access community if their plan allows" 
ON public.chat_messages
FOR ALL
TO authenticated
USING (EXISTS (
  SELECT 1 FROM enrollments e
  JOIN course_plans p ON e.plan_id = p.id
  WHERE e.user_id = auth.uid()
  AND e.course_id = (
    SELECT chat_channels.course_id 
    FROM chat_channels 
    WHERE chat_channels.id = chat_messages.channel_id
  )
  AND p.community_access = true
));

CREATE POLICY "Users can access rankings if their plan allows" 
ON public.course_rankings
FOR ALL
TO authenticated
USING (EXISTS (
  SELECT 1 FROM enrollments e
  JOIN course_plans p ON e.plan_id = p.id
  WHERE e.user_id = auth.uid()
  AND e.course_id = course_rankings.course_id
  AND p.rankings_access = true
));

CREATE POLICY "Users can access coaching if their plan allows" 
ON public.coach_messages
FOR ALL
TO authenticated
USING (EXISTS (
  SELECT 1 FROM enrollments e
  JOIN course_plans p ON e.plan_id = p.id
  WHERE e.user_id = auth.uid()
  AND e.course_id = coach_messages.course_id
  AND p.coaching_access = true
));