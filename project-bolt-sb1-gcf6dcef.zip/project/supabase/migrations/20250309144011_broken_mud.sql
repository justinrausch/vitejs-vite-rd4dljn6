/*
  # Course Rankings System

  1. New Tables
    - `course_rankings`
      - `id` (uuid, primary key)
      - `course_id` (uuid, references courses)
      - `user_id` (uuid, references profiles)
      - `points` (integer, default 0)
      - `completed_lessons_count` (integer, default 0)
      - `rank` (integer)
      - `level` (integer, default 1)
      - `last_active` (timestamp with time zone)
      - `updated_at` (timestamp with time zone)

  2. Functions
    - `update_course_ranking()`: Updates points and level based on completed lessons
    - `update_rankings_on_completion()`: Trigger function to update rankings when lessons are completed

  3. Security
    - Enable RLS on course_rankings table
    - Add policies for viewing and updating rankings
*/

-- Create course rankings table
CREATE TABLE IF NOT EXISTS course_rankings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  points integer DEFAULT 0,
  completed_lessons_count integer DEFAULT 0,
  rank integer,
  level integer DEFAULT 1,
  last_active timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(course_id, user_id)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_course_rankings_course_points ON course_rankings(course_id, points DESC);
CREATE INDEX IF NOT EXISTS idx_course_rankings_course_user ON course_rankings(course_id, user_id);
CREATE INDEX IF NOT EXISTS idx_course_rankings_user ON course_rankings(user_id);
CREATE INDEX IF NOT EXISTS idx_course_rankings_level ON course_rankings(level);
CREATE INDEX IF NOT EXISTS idx_course_rankings_last_active ON course_rankings(last_active DESC);

-- Enable RLS
ALTER TABLE course_rankings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Course rankings are viewable by everyone" ON course_rankings;
  DROP POLICY IF EXISTS "Users can manage their own rankings" ON course_rankings;
EXCEPTION
  WHEN undefined_object THEN
    NULL;
END $$;

-- Create policies
CREATE POLICY "Course rankings are viewable by everyone" 
ON course_rankings FOR SELECT 
TO public 
USING (true);

CREATE POLICY "Users can manage their own rankings" 
ON course_rankings FOR ALL 
TO authenticated 
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Function to update ranking points and level
CREATE OR REPLACE FUNCTION update_course_ranking()
RETURNS TRIGGER AS $$
BEGIN
  -- Update points (100 points per completed lesson)
  NEW.points := NEW.completed_lessons_count * 100;
  
  -- Update level (level up every 3 completed lessons)
  NEW.level := GREATEST(1, FLOOR(NEW.completed_lessons_count::float / 3) + 1);
  
  -- Update last active timestamp
  NEW.last_active := now();
  NEW.updated_at := now();
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS update_ranking_points_trigger ON course_rankings;

-- Trigger to update points and level when completed_lessons_count changes
CREATE TRIGGER update_ranking_points_trigger
  BEFORE INSERT OR UPDATE OF completed_lessons_count
  ON course_rankings
  FOR EACH ROW
  EXECUTE FUNCTION update_course_ranking();

-- Function to update rankings when lessons are completed
CREATE OR REPLACE FUNCTION update_rankings_on_completion()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert or update course ranking
  INSERT INTO course_rankings (course_id, user_id, completed_lessons_count)
  VALUES (NEW.course_id, NEW.user_id, 1)
  ON CONFLICT (course_id, user_id)
  DO UPDATE SET 
    completed_lessons_count = course_rankings.completed_lessons_count + 1;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS course_rankings_update ON completed_lessons;

-- Trigger to update rankings when lessons are completed
CREATE TRIGGER course_rankings_update
  AFTER INSERT ON completed_lessons
  FOR EACH ROW
  EXECUTE FUNCTION update_rankings_on_completion();