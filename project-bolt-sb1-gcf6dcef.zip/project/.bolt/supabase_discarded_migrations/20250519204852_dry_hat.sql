/*
  # Add Course Media Table

  1. New Tables
    - `course_media`
      - `id` (uuid, primary key)
      - `course_id` (uuid, references courses)
      - `type` (text) - 'image' or 'video'
      - `url` (text)
      - `thumbnail_url` (text, optional)
      - `position` (integer)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on course_media table
    - Add policies for:
      - Everyone can view course media
      - Course creators can manage their course media
*/

-- Create course_media table
CREATE TABLE IF NOT EXISTS course_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL CHECK (type IN ('image', 'video')),
  url text NOT NULL,
  thumbnail_url text,
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE course_media ENABLE ROW LEVEL SECURITY;

-- Create indexes for better performance
CREATE INDEX idx_course_media_course_id ON course_media(course_id);
CREATE INDEX idx_course_media_position ON course_media(position);

-- Add RLS policies
CREATE POLICY "Course media is viewable by everyone"
  ON course_media FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Course creators can manage media"
  ON course_media FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM courses
      WHERE courses.id = course_media.course_id
      AND courses.instructor_id = auth.uid()
    )
  );