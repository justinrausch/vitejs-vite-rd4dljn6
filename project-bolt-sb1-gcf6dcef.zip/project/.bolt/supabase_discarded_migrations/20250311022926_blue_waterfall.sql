/*
  # Reset Database Schema

  1. Changes
    - Remove course_rankings table and related triggers
    - Remove ranking-related columns from other tables
    - Clean up functions related to rankings
    - Reset lesson progress tracking to basics

  2. Tables Affected
    - course_rankings (dropped)
    - completed_lessons (preserved)
    - lesson_progress (preserved)
    - enrollments (modified)

  3. Functions Affected
    - Removed: update_rankings_on_completion
    - Removed: update_rankings_on_enrollment
    - Removed: update_course_ranking
    - Removed: update_rankings_on_lesson_completion
*/

-- Drop ranking-related functions
DROP FUNCTION IF EXISTS public.update_rankings_on_completion() CASCADE;
DROP FUNCTION IF EXISTS public.update_rankings_on_enrollment() CASCADE;
DROP FUNCTION IF EXISTS public.update_course_ranking() CASCADE;
DROP FUNCTION IF EXISTS public.update_rankings_on_lesson_completion() CASCADE;

-- Drop ranking-related triggers if they exist
DROP TRIGGER IF EXISTS course_rankings_update ON public.completed_lessons;
DROP TRIGGER IF EXISTS rankings_completion_trigger ON public.completed_lessons;
DROP TRIGGER IF EXISTS rankings_enrollment_trigger ON public.enrollments;
DROP TRIGGER IF EXISTS update_ranking_points_trigger ON public.course_rankings;
DROP TRIGGER IF EXISTS update_rankings_trigger ON public.completed_lessons;

-- Drop course_rankings table
DROP TABLE IF EXISTS public.course_rankings;

-- Remove ranking-related columns from enrollments if they exist
DO $$ 
BEGIN
  IF EXISTS (
    SELECT FROM information_schema.columns 
    WHERE table_schema = 'public' AND table_name = 'enrollments' AND column_name = 'points'
  ) THEN
    ALTER TABLE public.enrollments DROP COLUMN points;
  END IF;
  
  IF EXISTS (
    SELECT FROM information_schema.columns 
    WHERE table_schema = 'public' AND table_name = 'enrollments' AND column_name = 'level'
  ) THEN
    ALTER TABLE public.enrollments DROP COLUMN level;
  END IF;
END $$;

-- Reset tables
TRUNCATE TABLE public.lesson_progress CASCADE;
TRUNCATE TABLE public.completed_lessons CASCADE;
TRUNCATE TABLE public.enrollments CASCADE;

-- Create or replace the lesson completion notification function
CREATE OR REPLACE FUNCTION public.notify_lesson_completion()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM pg_notify(
    'lesson_completed',
    json_build_object(
      'user_id', NEW.user_id,
      'lesson_id', NEW.lesson_id,
      'course_id', NEW.course_id
    )::text
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS lesson_completion_notify ON public.completed_lessons;

-- Create new trigger
CREATE TRIGGER lesson_completion_notify
AFTER INSERT ON public.completed_lessons
FOR EACH ROW
EXECUTE FUNCTION public.notify_lesson_completion();

-- Add indexes for better performance if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'lesson_progress' 
    AND indexname = 'idx_lesson_progress_user_lesson'
  ) THEN
    CREATE INDEX idx_lesson_progress_user_lesson 
      ON public.lesson_progress(user_id, lesson_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'completed_lessons' 
    AND indexname = 'idx_completed_lessons_user_course'
  ) THEN
    CREATE INDEX idx_completed_lessons_user_course 
      ON public.completed_lessons(user_id, course_id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' 
    AND tablename = 'completed_lessons' 
    AND indexname = 'idx_completed_lessons_lesson'
  ) THEN
    CREATE INDEX idx_completed_lessons_lesson 
      ON public.completed_lessons(lesson_id);
  END IF;
END $$;