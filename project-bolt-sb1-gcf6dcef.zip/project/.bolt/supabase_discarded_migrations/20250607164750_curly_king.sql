/*
  # Username Uniqueness System

  1. New Constraints
    - Add unique constraint on profiles.username
    - Add trigger to handle username generation for new users
  
  2. Functions
    - Create function to generate unique usernames
    - Create function to handle new user registration
*/

-- First, ensure username is unique in the profiles table
ALTER TABLE profiles ADD CONSTRAINT profiles_username_unique UNIQUE (username);

-- Create a function to generate a unique username
CREATE OR REPLACE FUNCTION generate_unique_username(base_username TEXT)
RETURNS TEXT AS $$
DECLARE
  new_username TEXT;
  counter INTEGER := 0;
  username_exists BOOLEAN;
BEGIN
  -- Start with the base username
  new_username := base_username;
  
  -- Check if the username exists
  LOOP
    SELECT EXISTS(SELECT 1 FROM profiles WHERE username = new_username) INTO username_exists;
    
    -- If username doesn't exist, return it
    IF NOT username_exists THEN
      RETURN new_username;
    END IF;
    
    -- Otherwise, append a number and try again
    counter := counter + 1;
    new_username := base_username || counter;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Create a function to handle new user registration
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  base_username TEXT;
  unique_username TEXT;
BEGIN
  -- Extract username from email or metadata
  IF NEW.raw_user_meta_data->>'username' IS NOT NULL THEN
    base_username := NEW.raw_user_meta_data->>'username';
  ELSIF NEW.raw_user_meta_data->>'name' IS NOT NULL THEN
    -- Convert name to lowercase, remove spaces and special characters
    base_username := LOWER(REGEXP_REPLACE(NEW.raw_user_meta_data->>'name', '[^a-zA-Z0-9]', '', 'g'));
  ELSIF NEW.raw_user_meta_data->>'full_name' IS NOT NULL THEN
    -- Convert full_name to lowercase, remove spaces and special characters
    base_username := LOWER(REGEXP_REPLACE(NEW.raw_user_meta_data->>'full_name', '[^a-zA-Z0-9]', '', 'g'));
  ELSE
    -- Use email prefix as fallback
    base_username := SPLIT_PART(NEW.email, '@', 1);
  END IF;
  
  -- Generate a unique username
  unique_username := generate_unique_username(base_username);
  
  -- Insert into profiles with the unique username
  INSERT INTO profiles (id, username, avatar_url, email)
  VALUES (
    NEW.id,
    unique_username,
    NEW.raw_user_meta_data->>'avatar_url',
    NEW.email
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to handle new user registration
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION handle_new_user();