/*
  # Fix enrollments and course member display

  1. Changes
     - Add indexes to improve enrollment queries
     - Fix potential data inconsistencies in enrollments table
     - Ensure all users have proper profile data
     - Create test enrollments for the Advanced Trail Building course
*/

-- Add indexes to improve performance for enrollment queries
CREATE INDEX IF NOT EXISTS idx_enrollments_course_id ON enrollments(course_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_user_id ON enrollments(user_id);
CREATE INDEX IF NOT EXISTS idx_enrollments_course_user ON enrollments(course_id, user_id);

-- Ensure all users have profiles
DO $$
DECLARE
  user_rec RECORD;
BEGIN
  FOR user_rec IN 
    SELECT id, email, raw_user_meta_data 
    FROM auth.users 
    WHERE id NOT IN (SELECT id FROM profiles)
  LOOP
    INSERT INTO profiles (
      id, 
      username, 
      avatar_url,
      email,
      updated_at
    )
    VALUES (
      user_rec.id, 
      COALESCE(
        user_rec.raw_user_meta_data->>'username', 
        split_part(user_rec.email, '@', 1)
      ),
      user_rec.raw_user_meta_data->>'avatar_url',
      user_rec.email,
      now()
    )
    ON CONFLICT (id) DO NOTHING;
  END LOOP;
END $$;

-- Make sure all profiles have their email set
UPDATE profiles
SET email = users.email
FROM auth.users
WHERE profiles.id = users.id
AND (profiles.email IS NULL OR profiles.email = '');

-- Create some test enrollments for the Advanced Trail Building course
DO $$
DECLARE
  target_course_id uuid;
  user_ids uuid[];
  i int;
BEGIN
  -- Get the Advanced Trail Building course ID
  SELECT id INTO target_course_id FROM courses WHERE title = 'Advanced Trail Building' LIMIT 1;
  
  -- Get some user IDs that aren't already enrolled
  -- Fixed the ambiguous column reference by using a different variable name
  -- and explicitly referencing the table in the subquery
  SELECT array_agg(id) INTO user_ids
  FROM profiles
  WHERE id NOT IN (
    SELECT user_id FROM enrollments WHERE enrollments.course_id = target_course_id
  )
  LIMIT 5;
  
  -- Create enrollments for these users
  IF user_ids IS NOT NULL AND array_length(user_ids, 1) > 0 THEN
    FOR i IN 1..array_length(user_ids, 1) LOOP
      INSERT INTO enrollments (user_id, course_id)
      VALUES (user_ids[i], target_course_id)
      ON CONFLICT (user_id, course_id) DO NOTHING;
      
      -- Also add some completed lessons for these users
      INSERT INTO completed_lessons (user_id, course_id, lesson_id)
      SELECT 
        user_ids[i], 
        target_course_id, 
        course_lessons.id
      FROM course_lessons
      JOIN course_chapters ON course_lessons.chapter_id = course_chapters.id
      WHERE course_chapters.course_id = target_course_id
      ORDER BY random()
      LIMIT floor(random() * 5)::int + 1
      ON CONFLICT (user_id, lesson_id) DO NOTHING;
    END LOOP;
  END IF;
END $$;