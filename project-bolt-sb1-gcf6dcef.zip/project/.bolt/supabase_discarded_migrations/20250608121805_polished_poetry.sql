/*
  # Ensure unique usernames

  1. Changes
    - Add a unique constraint to the username column in the profiles table
    - Add a trigger to handle username generation for new users from OAuth providers
  
  2. Security
    - No changes to security policies
*/

-- First, ensure the username column has a unique constraint
ALTER TABLE profiles
ADD CONSTRAINT profiles_username_unique UNIQUE (username);

-- Create a function to generate a unique username
CREATE OR REPLACE FUNCTION generate_unique_username(base_username TEXT)
RETURNS TEXT AS $$
DECLARE
  new_username TEXT;
  counter INTEGER := 0;
  username_exists BOOLEAN;
BEGIN
  -- Start with the base username
  new_username := base_username;
  
  -- Check if it exists
  LOOP
    SELECT EXISTS(SELECT 1 FROM profiles WHERE username = new_username) INTO username_exists;
    
    -- If username doesn't exist, return it
    IF NOT username_exists THEN
      RETURN new_username;
    END IF;
    
    -- Otherwise, append a number and try again
    counter := counter + 1;
    new_username := base_username || counter;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger function to handle new user creation
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  base_username TEXT;
  unique_username TEXT;
BEGIN
  -- If username is already set, use it
  IF NEW.raw_user_meta_data->>'username' IS NOT NULL THEN
    NEW.username := NEW.raw_user_meta_data->>'username';
  -- Otherwise, try to generate one from email or name
  ELSE
    -- Try to get a base username from email (before the @)
    IF NEW.email IS NOT NULL THEN
      base_username := split_part(NEW.email, '@', 1);
    -- Or from the name if available
    ELSIF NEW.raw_user_meta_data->>'name' IS NOT NULL THEN
      base_username := lower(regexp_replace(NEW.raw_user_meta_data->>'name', '[^a-zA-Z0-9]', '', 'g'));
    -- Fallback to a generic username
    ELSE
      base_username := 'user';
    END IF;
    
    -- Generate a unique username
    unique_username := generate_unique_username(base_username);
    NEW.username := unique_username;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply the trigger to new user insertions
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();