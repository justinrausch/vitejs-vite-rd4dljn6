/*
  # Fix Course Media RLS Policy

  1. Changes
    - Update RLS policy for course_media table
    - Allow coaches to insert media during course creation
    - Fix issue with media uploads during course creation process
*/

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Course creators can manage media" ON course_media;

-- Create new policy that allows coaches to insert media during course creation
CREATE POLICY "Course creators can manage media"
  ON course_media FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_coach = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_coach = true
    )
  );