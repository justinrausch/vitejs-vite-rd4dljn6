/*
  # Create videos storage bucket

  1. New Storage Bucket
    - Creates a new public bucket called 'videos' for storing course lesson videos
    - Enables public access for video playback
    - Sets up proper configuration for video uploads

  2. Security
    - Enables RLS
    - Adds policy for authenticated users to upload videos
    - Adds policy for public video access
*/

-- Create the videos bucket with proper configuration
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'videos',
  'videos',
  true,
  5368709120, -- 5GB size limit
  array['video/mp4', 'video/webm', 'video/ogg']
);

-- Enable RLS
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to upload videos
CREATE POLICY "Authenticated users can upload videos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'videos' AND
  (auth.role() = 'authenticated')
);

-- Allow public access to videos
CREATE POLICY "Videos are publicly accessible"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'videos');

-- Allow video owners to delete their videos
CREATE POLICY "Users can delete their own videos"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'videos' AND
  (auth.uid())::text = owner
);